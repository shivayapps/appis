package messages.text.sms.feature.startup

import android.app.role.RoleManager
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.util.Log
import android.widget.Toast
import dagger.android.AndroidInjection
import messages.text.sms.adhelper.BannerAdHelper
import messages.text.sms.common.base.MainBaseThemedActivity
import messages.text.sms.databinding.ActivityDefaultPermissionBinding
import messages.text.sms.util.AdsConfig

class DefaultPermissionActivity :
    MainBaseThemedActivity<ActivityDefaultPermissionBinding>(ActivityDefaultPermissionBinding::inflate) {

    private val TAG = "DefaultPermissionActivity"
    private val REQUEST_SET_DEFAULT_LAUNCHER = 1003

    override fun onCreate(savedInstanceState: Bundle?) {
        AndroidInjection.inject(this)
        super.onCreate(savedInstanceState)
        setContentView(binding.root)

        binding.btnNext.setOnClickListener {
            launchSetDefaultLauncher()
        }
        binding.ivAppIcon.setOnClickListener {
            launchSetDefaultLauncher()
        }
        loadAds()
    }

    override fun onResume() {
        super.onResume()
        if (!isFinishing && StartupFlow.isDefaultLauncher(this)) {
            moveNext()
        }
    }

    fun loadAds() {
        BannerAdHelper.showBanner(
            this,
            binding.adsView,
            AdsConfig.banner_splash,
            { isLoaded, message ->

            })
    }

    private fun launchSetDefaultLauncher() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val roleManager = getSystemService(RoleManager::class.java)
            if (roleManager != null && roleManager.isRoleAvailable(RoleManager.ROLE_HOME)) {
                try {
                    @Suppress("DEPRECATION")
                    startActivityForResult(
                        roleManager.createRequestRoleIntent(RoleManager.ROLE_HOME),
                        REQUEST_SET_DEFAULT_LAUNCHER
                    )
                    return
                } catch (e: Exception) {
                    Log.e(TAG, "createRequestRoleIntent failed: $e")
                }
            }
        }

        val intent = listOf(
            Intent(Settings.ACTION_HOME_SETTINGS),
            Intent(Settings.ACTION_MANAGE_DEFAULT_APPS_SETTINGS),
            Intent(Settings.ACTION_SETTINGS),
        ).firstOrNull { it.resolveActivity(packageManager) != null }

        try {
            startActivity(intent ?: Intent(Settings.ACTION_HOME_SETTINGS))
        } catch (e: Exception) {
            Toast.makeText(this, e.toString(), Toast.LENGTH_LONG).show()
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_SET_DEFAULT_LAUNCHER && StartupFlow.isDefaultLauncher(this)) {
            moveNext()
        }
    }

    private fun moveNext() {
        if (isFinishing || isDestroyed) return
        StartupFlow.continueAfter(this, StartupFlow.Step.DEFAULT_LAUNCHER)
    }
}
