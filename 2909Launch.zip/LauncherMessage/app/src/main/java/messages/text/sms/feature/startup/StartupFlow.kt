package messages.text.sms.feature.startup

import android.app.Activity
import android.app.role.RoleManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.provider.Settings
import messages.text.sms.extensions.MiuiHelperUtils
import messages.text.sms.extensions.baseConfig
import messages.text.sms.extensions.hasPermission
import messages.text.sms.feature.localization.LocalizationActivity
import messages.text.sms.manager.PermissionManagerImpl
import messages.text.sms.util.PERMISSION_POST_NOTIFICATIONS
import messages.text.sms.util.PERMISSION_READ_PHONE_STATE
import com.shivaya.homelauncher.activities.MainActivity as LauncherHomeActivity

/**
 * Onboarding order after the splash screen:
 * language (first run only) -> default launcher -> default SMS handler + runtime permissions -> overlay -> launcher home.
 * Each screen continues with the steps after its own, so a permission that the system reports late
 * can never send the user back to a previous screen.
 */
object StartupFlow {

    enum class Step { LANGUAGE, DEFAULT_LAUNCHER, PERMISSIONS, OVERLAY }

    fun isDefaultLauncher(context: Context): Boolean {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val roleManager = context.getSystemService(RoleManager::class.java)
            if (roleManager != null && roleManager.isRoleAvailable(RoleManager.ROLE_HOME)) {
                return roleManager.isRoleHeld(RoleManager.ROLE_HOME)
            }
        }

        val homeIntent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
        val resolved = context.packageManager.resolveActivity(homeIntent, PackageManager.MATCH_DEFAULT_ONLY)
        return resolved?.activityInfo?.packageName == context.packageName
    }

    fun isPending(context: Context, step: Step): Boolean = when (step) {
        Step.LANGUAGE -> context.baseConfig.selectedLanguage.isBlank() && !context.baseConfig.clickLangDone
        Step.DEFAULT_LAUNCHER -> !isDefaultLauncher(context)
        Step.PERMISSIONS -> !PermissionManagerImpl(context).isDefaultSms() ||
                !context.hasPermission(PERMISSION_POST_NOTIFICATIONS) ||
                !context.hasPermission(PERMISSION_READ_PHONE_STATE) ||
                !MiuiHelperUtils.isAutoStartEnabled(context)

        Step.OVERLAY -> !Settings.canDrawOverlays(context) ||
                (MiuiHelperUtils.isMiui() && !MiuiHelperUtils.isBgStartAllowed(context))
    }

    /** @param after the step that was just completed, or null to evaluate the whole flow */
    fun firstPendingStep(context: Context, after: Step? = null): Step? =
        Step.entries
            .filter { after == null || it.ordinal > after.ordinal }
            .firstOrNull { isPending(context, it) }

    fun intentFor(context: Context, step: Step): Intent = when (step) {
        Step.LANGUAGE -> Intent(context, LocalizationActivity::class.java).putExtra("from_splash", true)
        Step.DEFAULT_LAUNCHER -> Intent(context, DefaultPermissionActivity::class.java)
        Step.PERMISSIONS -> Intent(context, PermissionActivity::class.java)
        Step.OVERLAY -> Intent(context, OverlayPermissionActivity::class.java)
    }

    fun nextIntent(context: Context, after: Step? = null): Intent =
        firstPendingStep(context, after)?.let { intentFor(context, it) } ?: homeIntent(context)

    fun homeIntent(context: Context): Intent = Intent(context, LauncherHomeActivity::class.java)

    /**
     * Used when the system opens the launcher home directly (e.g. the Home button), bypassing the splash.
     * Only the language and default launcher steps are enforced there, so a declined SMS permission
     * can't lock the user out of their home screen.
     */
    fun homeOnboardingIntent(context: Context): Intent? = when {
        isPending(context, Step.LANGUAGE) -> intentFor(context, Step.LANGUAGE)
        isPending(context, Step.DEFAULT_LAUNCHER) -> intentFor(context, Step.DEFAULT_LAUNCHER)
        else -> null
    }

    fun continueAfter(activity: Activity, step: Step?) {
        val intent = nextIntent(activity, step)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
        activity.startActivity(intent)
        activity.finish()
    }
}
