package messages.text.sms.common

import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.drawable.Drawable
import android.util.AttributeSet
import android.view.LayoutInflater
import android.view.View
import android.widget.FrameLayout
import androidx.appcompat.widget.AppCompatImageView
import androidx.core.content.ContextCompat
import io.reactivex.Observable
import io.reactivex.subjects.PublishSubject
import messages.text.sms.databinding.CustomChipViewBinding
import messages.text.sms.R
import messages.text.sms.extensions.resolveThemeColor

class CustomChipView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : AppCompatImageView(context, attrs, defStyleAttr) {

    private val checkedSubject = PublishSubject.create<Boolean>()

    val checkedChanges: Observable<Boolean>
        get() = checkedSubject.hide()

    private var chipIcon: Drawable? = null
    private var chipActiveIcon: Drawable? = null

    var isChecked = false
        private set

    init {
        attrs?.let {
            val a = context.obtainStyledAttributes(
                it,
                R.styleable.CustomChipView
            )

            chipIcon = a.getDrawable(
                R.styleable.CustomChipView_chipIcon
            )

            chipActiveIcon = a.getDrawable(
                R.styleable.CustomChipView_chipActiveIcon
            )

            isChecked = a.getBoolean(
                R.styleable.CustomChipView_chipChecked,
                false
            )

            a.recycle()
        }

        refreshState()

        setOnClickListener {
            //if (isEnabled) {
                setChecked(!isChecked)
            //}
        }
    }

    /**
     * Sets both enabled and checked state.
     */
    fun setChecked(
        checked: Boolean,
        //enabled: Boolean = true
    ) {
        isChecked = checked
//        isEnabled = enabled
//        isClickable = enabled
        alpha = if (isChecked) 1f else 0.8f

        refreshState()

        checkedSubject.onNext(isChecked)
    }

    private fun refreshState() {
        setImageDrawable(
            if (isChecked) {
                chipActiveIcon ?: chipIcon
            } else {
                chipIcon
            }
        )
    }

    fun setIcon(drawable: Drawable?) {
        chipIcon = drawable

        if (!isChecked) {
            setImageDrawable(drawable)
        }
    }

    fun setActiveIcon(drawable: Drawable?) {
        chipActiveIcon = drawable

        if (isChecked) {
            setImageDrawable(drawable ?: chipIcon)
        }
    }
}