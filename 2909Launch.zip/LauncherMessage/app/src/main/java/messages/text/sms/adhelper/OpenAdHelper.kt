package messages.text.sms.adhelper

import android.app.Activity
import android.content.Context
import android.util.Log
import androidx.annotation.NonNull
import com.google.android.gms.ads.AdError
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.appopen.AppOpenAd
import messages.text.sms.adhelper.AdUtil.isAnyAdShowing
import messages.text.sms.extensions.baseConfig
import messages.text.sms.util.AdsConfig
import java.util.Date

object OpenAdHelper {

    private val TAG: String = "ADCONFIG_OpenAdHelper"

    private var mAppOpenAd: AppOpenAd? = null

    private var adLoadTime: Long = 0
    private var isOpenAdShowing: Boolean = false
//    var isLoadingOpenAd = false

    var isAdLoading: Boolean = false

    private var mListener: AdsListener? = null


    fun checkAndLoadAppOpen(@NonNull fContext: Activity) {
        if (!isAdAvailable() && !isAdLoading) {
            Log.i("loadAd", "loadAd.006")
            loadOpenAd(fContext, onAdLoad = {
//                fContext.isShowOpenAd { success -> }
                Log.e("loadAd", "onAdLoad")
            }, onAdFailed = {
                Log.e("loadAd", "onAdFailed")
                //loadAppOpen2nd(fContext)
            }, onAdShow = {
                Log.e("loadAd", "onAdShow")
            })
        } else {
            Log.e("loadAd", "loadAppOpen else")
        }
    }


    private fun loadOpenAd(
        @NonNull fContext: Context, @NonNull fListener: AdsListener, mAdId: String = ""
    ) {
        var lAppOpenAd: AppOpenAd?
        var adId = AdsConfig.open_resume
        if (mAdId?.length!! > 0) {
            adId = mAdId
        }

        Log.d("LoadAd", "loadOpenAd:$adId")
        isAdLoading = true
        AppOpenAd.load(
            fContext,
            adId,
            AdRequest.Builder().build(),
            object : AppOpenAd.AppOpenAdLoadCallback() {

                override fun onAdLoaded(appOpenAd: AppOpenAd) {
                    super.onAdLoaded(appOpenAd)
                    isAdLoading = false
                    Log.i(TAG, "onAdLoaded: ")
                    lAppOpenAd = appOpenAd
                    adLoadTime = Date().time
//                    fListener.onAppOpenAdLoaded(appOpenAd = appOpenAd)
                    fListener.onAdLoaded(appOpenAd)

                    lAppOpenAd?.fullScreenContentCallback = object : FullScreenContentCallback() {
                        override fun onAdDismissedFullScreenContent() {
                            super.onAdDismissedFullScreenContent()
                            Log.i(TAG, "onAdClosed: ")
                            isOpenAdShowing = false
//                            fListener.onAdClosed()
                            fListener.onAdDismissed()

                        }

                        override fun onAdShowedFullScreenContent() {
                            super.onAdShowedFullScreenContent()
                            fListener.onAdShowed()
                            isOpenAdShowing = true
                            lAppOpenAd = null
                        }

                        override fun onAdFailedToShowFullScreenContent(adError: AdError) {
                            super.onAdFailedToShowFullScreenContent(adError)
                            lAppOpenAd = null
                            fListener.onAdFailedToShow(
                                AdsError(
                                    adError.code,
                                    "onAdFailedToShowFullScreenContent:" + adError.message
                                )
                            )
                            Log.i(
                                TAG,
                                "onAdFailedToShowFullScreenContent: \nErrorMessage::${adError.message}\nErrorCode::${adError.code}"
                            )
                        }
                    }
                }

                override fun onAdFailedToLoad(adError: LoadAdError) {
                    super.onAdFailedToLoad(adError)
                    isAdLoading = false
                    Log.i(
                        TAG,
                        "onAdFailedToLoad: Ad failed to load -> \nresponseInfo::${adError.responseInfo}\nErrorCode::${adError.code}\nErrorMessage::${adError.message}"
                    )
                    lAppOpenAd = null
                    fListener.onAdFailedToLoad(
                        AdsError(
                            adError.code, "${adError.responseInfo}"
                        )
                    )
                }
            })

    }

    /**
     * Call this method when you need to load your Open AD
     * you need to call this method only once in your launcher activity or your application class
     *
     * @param fContext this is a reference to your activity context
     * @param onAdLoad callback after ad successfully loaded
     */
    fun loadOpenAd(
        @NonNull fContext: Context,
        @NonNull onAdLoad: () -> Unit = {},
        @NonNull onAdFailed: () -> Unit = {},
        @NonNull onAdShow: () -> Unit = {}
    ) {
        if (isAdAvailable()) {
            onAdLoad.invoke()
        } else {
            loadOpenAd(fContext, object : AdsListener {
                override fun onAdLoaded(appOpenAd: Any) {
//                    super.onAdLoaded(appOpenAd)
                    mAppOpenAd = appOpenAd as AppOpenAd
                    onAdLoad.invoke()
                    mListener?.onAdLoaded()
                }

                override fun onAdLoaded() {

                }

                override fun onAdFailedToLoad(adsError: AdsError) {
                    isAnyAdShowing = false
                    mAppOpenAd?.fullScreenContentCallback = null
                    mAppOpenAd = null
//                    loadOpenAd(fContext)
                    onAdFailed.invoke()
                }

                override fun onAdFailedToShow(adsError: AdsError) {
                    isAnyAdShowing = false
                    mAppOpenAd?.fullScreenContentCallback = null
                    mAppOpenAd = null
                    loadAdSecond(fContext)
                    onAdFailed.invoke()
                }

                override fun onAdImpression() {
                }

                override fun onAdShowed() {
                    onAdShow.invoke()
                }

                override fun onAdClicked() {
                }

                override fun onAdDismissed() {
//                    super.onAdDismissed()
                    isAnyAdShowing = false
                    mAppOpenAd?.fullScreenContentCallback = null
                    mAppOpenAd = null
                    Log.i("loadAd", "loadAd.003")
                    loadOpenAd(fContext)
                    mListener?.onAdDismissed()
                }

            })
        }
    }

    fun loadAdSecond(fContext: Context) {
        Log.i("loadAd", "loadAd.005")
        loadOpenAd(fContext)
    }


    fun loadOpenAdId(
        @NonNull fContext: Context, @NonNull onAdLoad: (isLoaded: Boolean) -> Unit = {},
        mAdId: String? = ""
    ) {
        if (isAdAvailable()) {
            onAdLoad.invoke(true)
        } else {
            loadOpenAd(fContext, object : AdsListener {
                override fun onAdLoaded(appOpenAd: Any) {
//                    super.onAdLoaded(appOpenAd)
                    mAppOpenAd = appOpenAd as AppOpenAd
                    onAdLoad.invoke(true)
                    mListener?.onAdLoaded()

                }

                override fun onAdLoaded() {
                }

                override fun onAdFailedToLoad(adsError: AdsError) {
                    mListener?.onAdFailedToLoad(adsError)
                }

                override fun onAdFailedToShow(adsError: AdsError) {
                }

                override fun onAdImpression() {
                }

                override fun onAdShowed() {

                }

                override fun onAdClicked() {
                }

                override fun onAdDismissed() {
//                    super.onAdDismissed()
                    isAnyAdShowing = false
                    mAppOpenAd?.fullScreenContentCallback = null
                    mAppOpenAd = null
                    mListener?.onAdDismissed()
                }

            }, mAdId!!)
        }
    }

    private fun wasLoadTimeLessThanNHoursAgo(hours: Int = 1): Boolean {
        if (adLoadTime <= 0L) return false

        val elapsedTime = System.currentTimeMillis() - adLoadTime
        val millisPerHour = 60 * 60 * 1000L

        return elapsedTime < hours * millisPerHour
    }


    /**
     * this method will check openAd is Available or not
     */
    fun isAdAvailable(): Boolean {
//        return mAppOpenAd != null && wasLoadTimeLessThanNHoursAgo(4)
        return mAppOpenAd != null
    }


    fun Activity.showOpenAd(
        @NonNull onAdClosed: (isLoaded: Boolean) -> Unit,
    ) {
        Log.i(
            TAG, "isOpenAdShowing:$isOpenAdShowing"
        )
        if (!isOpenAdShowing) {
            mListener = object : AdsListener {
                override fun onAdClicked() {

                }

                override fun onAdDismissed() {
                    onAdClosed.invoke(true)
                }

                override fun onAdLoaded(appOpenAd: Any) {
//                    onAdLoad.invoke()
                    Log.i(TAG, "onAdLoaded")
                }

                override fun onAdLoaded() {
                }

                override fun onAdFailedToLoad(adError: AdsError) {
                    onAdClosed.invoke(false)
                    Log.i(
                        TAG, "onAdFailedToLoad:${adError.code}:${adError.error}"
                    )
                }

                override fun onAdFailedToShow(adError: AdsError) {
                    onAdClosed.invoke(true)
                    Log.i(
                        TAG, "onAdFailedToShow:${adError.code}:${adError.error}"
                    )
                }

                override fun onAdImpression() {
                    Log.i(TAG, "onAdImpression")
                }

                override fun onAdShowed() {

                }

            }

            Log.i(TAG, "isShowOpenAd:isAdAvailable()::${isAdAvailable()}")
            if (isAdAvailable()) {
                if (!isAnyAdShowing) {
                    Log.i(TAG, "isShowOpenAd: Showing Open Ad")
                    isAnyAdShowing = true
                    mAppOpenAd?.show(this)
                } else {
                    onAdClosed.invoke(false)
                }
            } else {
                onAdClosed.invoke(false)
            }
        } else {
            onAdClosed.invoke(false)
        }
    }

    fun destroy() {
        adLoadTime = 0
        isOpenAdShowing = false
        isAdLoading = false
        mListener = null
        mAppOpenAd = null
    }
}