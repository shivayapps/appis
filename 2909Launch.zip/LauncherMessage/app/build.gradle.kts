import org.jetbrains.kotlin.gradle.dsl.JvmTarget

plugins {
    alias(libs.plugins.android)
    id("realm-android")   // must come before Kotlin plugins
    alias(libs.plugins.kotlin.android)
    alias(libs.plugins.kotlin.kapt)
}

android {
    namespace = "messages.text.sms"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.messages.sms.textmessagingapp"
        minSdk = 26
        targetSdk = 36

        versionCode = 4
        versionName = "1.0.3"
    }

    buildFeatures {
        buildConfig = true
        viewBinding = true
        resValues = true
    }

    buildTypes {
        debug {
            isMinifyEnabled = false
        }
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }

    compileOptions {
        val javaVersion = JavaVersion.valueOf(libs.versions.app.build.javaVersion.get())
        sourceCompatibility = javaVersion
        targetCompatibility = javaVersion
    }

    // the MMS stack (com.android.mms / com.klinker) still uses the Apache HTTP classes
    useLibrary("org.apache.http.legacy")

    dependenciesInfo {
        includeInApk = false
        includeInBundle = false
    }

    lint {
        abortOnError = false
    }

    // both the messages screens and the launcher switch language at runtime, so every language must ship in the base APK
    bundle {
        language {
            enableSplit = false
        }
    }

    flavorDimensions += "ads"
    productFlavors {
        create("TestAd") {
            dimension = "ads"
            isDefault = true
            resValue("string", "ads_application_id", "ca-app-pub-3940256099942544~3347511713")
//            resValue("string", "banner_compose", "ca-app-pub-3940256099942544/9214589741")
//            resValue("string", "banner_home", "ca-app-pub-3940256099942544/9214589741")
//            resValue("string", "banner_splash", "ca-app-pub-3940256099942544/9214589741")
//            resValue("string", "banner_all", "ca-app-pub-3940256099942544/9214589741")
//            resValue("string", "native_language", "ca-app-pub-3940256099942544/2247696110")
//            resValue("string", "native_splash", "ca-app-pub-3940256099942544/2247696110")
//            resValue("string", "native_all", "ca-app-pub-3940256099942544/2247696110")
//            resValue("string", "open_resume", "ca-app-pub-3940256099942544/9257395921")
//            resValue("string", "inter_back", "ca-app-pub-3940256099942544/1033173712")
        }
        create("LiveAd") {
            dimension = "ads"
            resValue("string", "ads_application_id", "ca-app-pub-6815839713838719~9735724445")
//            resValue("string", "banner_compose", "ca-app-pub-6815839713838719/3655643660")
//            resValue("string", "banner_home", "ca-app-pub-6815839713838719/8305335117")
//            resValue("string", "banner_splash", "ca-app-pub-6815839713838719/3739318426")
//            resValue("string", "banner_all", "ca-app-pub-6815839713838719/7890402142")
//            resValue("string", "native_language", "ca-app-pub-6815839713838719/3136768910")
//            resValue("string", "native_splash", "ca-app-pub-6815839713838719/2889356905")
//            resValue("string", "native_all", "ca-app-pub-6815839713838719/5595411292")
//            resValue("string", "open_resume", "ca-app-pub-6815839713838719/4557661791")
//            resValue("string", "inter_back", "ca-app-pub-6815839713838719/4449850583")
        }
    }
}

base {
    archivesName.set("Messages-v${android.defaultConfig.versionName}")
}

kotlin {
    compilerOptions {
        jvmTarget.set(JvmTarget.fromTarget(libs.versions.app.build.kotlinJVMTarget.get()))
    }
}

dependencies {
// -------------------- Launcher (home screen) --------------------
    implementation(project(":launcher"))

// -------------------- AndroidX --------------------
    implementation(libs.androidx.core.ktx)
    implementation(libs.androidx.activity.ktx)
    implementation(libs.androidx.appcompat)
    implementation(libs.androidx.constraintlayout)
    implementation(libs.androidx.documentfile)
    implementation(libs.androidx.exifinterface)
    implementation(libs.androidx.emoji2.bundled)
    implementation(libs.androidx.viewpager2)
    implementation(libs.androidx.browser)
    implementation(libs.androidx.multidex)

// -------------------- Lifecycle --------------------
    implementation(libs.androidx.lifecycle.viewModel)
    implementation(libs.androidx.lifecycle.runtime)
    implementation(libs.androidx.lifecycle.livedata)
    implementation(libs.androidx.lifecycle.common.java8)
    implementation(libs.androidx.lifecycle.legacyExt)

// -------------------- WorkManager --------------------
    implementation(libs.androidx.work.runtime.ktx)
    implementation(libs.androidx.work.rxjava2)

// -------------------- Material / UI --------------------
    implementation(libs.material)
    implementation(libs.sdp.android)
    implementation(libs.conductor)
    implementation(libs.conductor.archlifecycle)
    implementation(libs.lottie)
    implementation(libs.shimmer)
    implementation(libs.photoview)
    implementation(libs.flexbox)
    implementation(libs.shortcutbadger)
    implementation(libs.singledateandtimepicker)

// -------------------- Glide --------------------
    implementation(libs.glide)
    kapt(libs.glide.compiler)

// -------------------- Media3 --------------------
    implementation(libs.media3.common)
    implementation(libs.media3.exoplayer)
    implementation(libs.media3.ui)

// -------------------- Dagger --------------------
    implementation(libs.dagger)
    implementation(libs.dagger.android.support)
    kapt(libs.dagger.compiler)
    kapt(libs.dagger.android.processor)
    // Dagger's own kotlin-metadata-jvm can't read metadata newer than Kotlin 2.2, keep it on the project's Kotlin version
    kapt(libs.kotlin.metadata.jvm)
    implementation(libs.javax.annotation.api)

// -------------------- Realm --------------------
    implementation(libs.realm.android.library)
    implementation(libs.realm.android.adapters)
    kapt(libs.realm.annotations.processor)

// -------------------- RxJava --------------------
    implementation(libs.rxjava)
    implementation(libs.rxandroid)
    implementation(libs.rxkotlin)
    implementation(libs.rxdogtag)
    implementation(libs.rxdogtag.autodispose)
    implementation(libs.rx.preferences)
    implementation(libs.rxbinding.kotlin)
    implementation(libs.rxbinding.support.v4.kotlin)

// -------------------- AutoDispose --------------------
    implementation(libs.autodispose)
    implementation(libs.autodispose.android)
    implementation(libs.autodispose.lifecycle)
    implementation(libs.autodispose.android.archcomponents)
    implementation(libs.autodispose.android.archcomponents.test)

// -------------------- Moshi / Gson --------------------
    implementation(libs.moshi)
    implementation(libs.moshi.kotlin)
    kapt(libs.moshi.kotlin.codegen)
    implementation(libs.gson)

// -------------------- Coroutines --------------------
    implementation(libs.kotlinx.coroutines.core)
    implementation(libs.kotlinx.coroutines.android)
    implementation(libs.kotlinx.coroutines.rx2)
    implementation(libs.kotlinx.coroutines.reactive)

// -------------------- Network --------------------
    implementation(libs.okhttp3)
    implementation(libs.volley)
    // MMS stack (com.android.mms / com.klinker)
    implementation(libs.okhttp2)
    implementation(libs.okhttp2.urlconnection)

// -------------------- Utils --------------------
    implementation(libs.libphonenumber.android)
    implementation(libs.dexter)
    implementation(libs.ez.vcard) {
        exclude(group = "org.jsoup", module = "jsoup")
        exclude(group = "org.freemarker", module = "freemarker")
        exclude(group = "com.fasterxml.jackson.core", module = "jackson-core")
    }

// -------------------- Google Play services & ads --------------------
    implementation(libs.play.services.location)
    implementation(libs.play.review.ktx)
    implementation(libs.play.app.update)
    implementation(libs.play.services.ads)
    implementation(libs.play.services.ads.facebook)
}
