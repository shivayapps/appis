-dontwarn org.conscrypt.**
-dontwarn org.bouncycastle.**
-dontwarn org.openjsse.**
-keep class org.bouncycastle.jcajce.provider.** { *; }
-keep class org.bouncycastle.jce.provider.** { *; }
-keep class org.bouncycastle.jsse.** { *; }
-keep class org.conscrypt.Conscrypt.** { *; }
-keep class org.openjsse.javax.net.ssl.** { *; }

-dontwarn javax.naming.**
-dontwarn org.jspecify.**
# android-smsmms
# -keep class android.net.** { *; }
-dontwarn android.net.ConnectivityManager
-dontwarn android.net.LinkProperties

-keep class com.messenger.sms.text.** { *; }

# autodispose
-dontwarn com.uber.autodispose.**

# ez-vcard
-dontwarn ezvcard.**
-dontwarn org.apache.log.**
-dontwarn org.apache.log4j.**
-dontwarn org.python.core.**

-keep class androidx.recyclerview.widget.** { *; }

# okio
#-dontwarn okio.**

-keep class com.google.gson.reflect.TypeToken

# okhttp3
# JSR 305 annotations are for embedding nullability information.
-dontwarn javax.annotation.**

# A resource is loaded with a relative path so the package of this class must be preserved.
-keepnames class okhttp3.internal.publicsuffix.PublicSuffixDatabase

# Animal Sniffer compileOnly dependency to ensure APIs are compatible with older versions of Java.
-dontwarn org.codehaus.mojo.animal_sniffer.*

# OkHttp platform used only on JVM and when Conscrypt dependency is available.
-dontwarn okhttp3.internal.platform.ConscryptPlatform

# moshi
# JSR 305 annotations are for embedding nullability information.
-dontwarn javax.annotation.**

-keepclasseswithmembers class * {
    @com.squareup.moshi.* <methods>;
}
# Keep libphonenumber classes and methods
-keep class io.michaelrocks.libphonenumber.** { *; }


-keep @com.squareup.moshi.JsonQualifier interface *

# Enum field names are used by the integrated EnumJsonAdapter.
# Annotate enums with @JsonClass(generateAdapter = false) to use them with Moshi.
-keepclassmembers @com.squareup.moshi.JsonClass class * extends java.lang.Enum {
    <fields>;
}

# The name of @JsonClass types is used to look up the generated adapter.
-keepnames @com.squareup.moshi.JsonClass class *

# Retain generated target class's synthetic defaults constructor and keep DefaultConstructorMarker's
# name. We will look this up reflectively to invoke the type's constructor.
#
# We can't _just_ keep the defaults constructor because Proguard/R8's spec doesn't allow wildcard
# matching preceding parameters.
-keepnames class kotlin.jvm.internal.DefaultConstructorMarker
-keepclassmembers @com.squareup.moshi.JsonClass class * {
    <init>(...);
}

# Retain generated JsonAdapters if annotated type is retained.
-if @com.squareup.moshi.JsonClass class *
-keep class <1>JsonAdapter {
    <init>(...);
    <fields>;
}
-if @com.squareup.moshi.JsonClass class **$*
-keep class <1>_<2>JsonAdapter {
    <init>(...);
    <fields>;
}
-if @com.squareup.moshi.JsonClass class **$*$*
-keep class <1>_<2>_<3>JsonAdapter {
    <init>(...);
    <fields>;
}
-if @com.squareup.moshi.JsonClass class **$*$*$*
-keep class <1>_<2>_<3>_<4>JsonAdapter {
    <init>(...);
    <fields>;
}
-if @com.squareup.moshi.JsonClass class **$*$*$*$*
-keep class <1>_<2>_<3>_<4>_<5>JsonAdapter {
    <init>(...);
    <fields>;
}
-if @com.squareup.moshi.JsonClass class **$*$*$*$*$*
-keep class <1>_<2>_<3>_<4>_<5>_<6>JsonAdapter {
    <init>(...);
    <fields>;
}

-dontobfuscate

# android-smsmms
# -keep class android.net.** { *; }
-dontwarn android.net.ConnectivityManager
-dontwarn android.net.LinkProperties

# autodispose
-dontwarn com.uber.autodispose.**

# ez-vcard
-dontwarn ezvcard.**
-dontwarn org.apache.log.**
-dontwarn org.apache.log4j.**
-dontwarn org.python.core.**

# okio
#-dontwarn okio.**

# okhttp3
# JSR 305 annotations are for embedding nullability information.
-dontwarn javax.annotation.**

# A resource is loaded with a relative path so the package of this class must be preserved.
-keepnames class okhttp3.internal.publicsuffix.PublicSuffixDatabase

# Animal Sniffer compileOnly dependency to ensure APIs are compatible with older versions of Java.
-dontwarn org.codehaus.mojo.animal_sniffer.*

# OkHttp platform used only on JVM and when Conscrypt dependency is available.
-dontwarn okhttp3.internal.platform.ConscryptPlatform

# moshi
# JSR 305 annotations are for embedding nullability information.
-dontwarn javax.annotation.**

-keepclasseswithmembers class * {
    @com.squareup.moshi.* <methods>;
}

-keep @com.squareup.moshi.JsonQualifier interface *

# Enum field names are used by the integrated EnumJsonAdapter.
# Annotate enums with @JsonClass(generateAdapter = false) to use them with Moshi.
-keepclassmembers @com.squareup.moshi.JsonClass class * extends java.lang.Enum {
    <fields>;
}

# The name of @JsonClass types is used to look up the generated adapter.
-keepnames @com.squareup.moshi.JsonClass class *

# Retain generated target class's synthetic defaults constructor and keep DefaultConstructorMarker's
# name. We will look this up reflectively to invoke the type's constructor.
#
# We can't _just_ keep the defaults constructor because Proguard/R8's spec doesn't allow wildcard
# matching preceding parameters.
-keepnames class kotlin.jvm.internal.DefaultConstructorMarker
-keepclassmembers @com.squareup.moshi.JsonClass class * {
    <init>(...);
}

# Retain generated JsonAdapters if annotated type is retained.
-if @com.squareup.moshi.JsonClass class *
-keep class <1>JsonAdapter {
    <init>(...);
    <fields>;
}
-if @com.squareup.moshi.JsonClass class **$*
-keep class <1>_<2>JsonAdapter {
    <init>(...);
    <fields>;
}
-if @com.squareup.moshi.JsonClass class **$*$*
-keep class <1>_<2>_<3>JsonAdapter {
    <init>(...);
    <fields>;
}
-if @com.squareup.moshi.JsonClass class **$*$*$*
-keep class <1>_<2>_<3>_<4>JsonAdapter {
    <init>(...);
    <fields>;
}
-if @com.squareup.moshi.JsonClass class **$*$*$*$*
-keep class <1>_<2>_<3>_<4>_<5>JsonAdapter {
    <init>(...);
    <fields>;
}
-if @com.squareup.moshi.JsonClass class **$*$*$*$*$*
-keep class <1>_<2>_<3>_<4>_<5>_<6>JsonAdapter {
    <init>(...);
    <fields>;
}

-dontwarn com.yalantis.ucrop**
-keep class com.yalantis.ucrop** { *; }
-keep interface com.yalantis.ucrop** { *; }


-keep public class org.apache.commons.io.**
-keep public class com.google.gson.**
-keep public class com.google.gson.** {public private protected *;}

# JSR 305 annotations are for embedding nullability information.
-dontwarn javax.annotation.**

-keepclasseswithmembers class * {
    @com.squareup.moshi.* <methods>;
}

-keep @com.squareup.moshi.JsonQualifier @interface *

# Enum field names are used by the integrated EnumJsonAdapter.
# values() is synthesized by the Kotlin compiler and is used by EnumJsonAdapter indirectly
# Annotate enums with @JsonClass(generateAdapter = false) to use them with Moshi.
-keepclassmembers @com.squareup.moshi.JsonClass class * extends java.lang.Enum {
    <fields>;
    **[] values();
}

# Keep helper method to avoid R8 optimisation that would keep all Kotlin Metadata when unwanted
-keepclassmembers class com.squareup.moshi.internal.Util {
    private static java.lang.String getKotlinMetadataClassName();
}

# Keep ToJson/FromJson-annotated methods
-keepclassmembers class * {
  @com.squareup.moshi.FromJson <methods>;
  @com.squareup.moshi.ToJson <methods>;
}

##---------------Begin: proguard configuration for Gson ----------
-keepattributes *Annotation*,Signature
-keep class com.messenger.sms.text.** { *; }
-keep class com.messenger.sms.text.common.** { *; }
-keep class com.data.repository.BackupRepositoryImpl.Backup.** { *; }
-keep public class com.data.repository.BackupRepositoryImpl$Backup { public protected *; }
-keep public class com.data.repository.BackupRepositoryImpl$BackupMessage { public protected *; }
# To support Enum type of class members
-keepclassmembers enum * { *; }
##---------------End: proguard configuration for Gson ----------

# Please add these rules to your existing keep rules in order to suppress warnings.
# This is generated automatically by the Android Gradle plugin.
-dontwarn org.bouncycastle.jsse.provider.BouncyCastleJsseProvider
-dontwarn org.conscrypt.Conscrypt$Version
-dontwarn org.conscrypt.Conscrypt
-dontwarn org.conscrypt.ConscryptHostnameVerifier
-dontwarn org.openjsse.net.ssl.OpenJSSE

-if class com.data.manager.ChangelogManagerImpl$ArrayField
-keepnames class com.data.manager.ChangelogManagerImpl$ArrayField
-if class com.data.manager.ChangelogManagerImpl$ArrayField
-keep class com.data.manager.ChangelogManagerImpl_ArrayFieldJsonAdapter {
    public <init>(com.squareup.moshi.Moshi);
}
-if class com.data.manager.ChangelogManagerImpl$ArrayValues
-keepnames class com.data.manager.ChangelogManagerImpl$ArrayValues
-if class com.data.manager.ChangelogManagerImpl$ArrayValues
-keep class com.data.manager.ChangelogManagerImpl_ArrayValuesJsonAdapter {
    public <init>(com.squareup.moshi.Moshi);
}
-if class com.data.manager.ChangelogManagerImpl$Changelog
-keepnames class com.data.manager.ChangelogManagerImpl$Changelog
-if class com.data.manager.ChangelogManagerImpl$Changelog
-keep class com.data.manager.ChangelogManagerImpl_ChangelogJsonAdapter {
    public <init>(com.squareup.moshi.Moshi);
}
-if class com.data.manager.ChangelogManagerImpl$ChangelogResponse
-keepnames class com.data.manager.ChangelogManagerImpl$ChangelogResponse
-if class com.data.manager.ChangelogManagerImpl$ChangelogResponse
-keep class com.data.manager.ChangelogManagerImpl_ChangelogResponseJsonAdapter {
    public <init>(com.squareup.moshi.Moshi);
}
-if class com.data.manager.ChangelogManagerImpl$Document
-keepnames class com.data.manager.ChangelogManagerImpl$Document
-if class com.data.manager.ChangelogManagerImpl$Document
-keep class com.data.manager.ChangelogManagerImpl_DocumentJsonAdapter {
    public <init>(com.squareup.moshi.Moshi);
}
-if class com.data.manager.ChangelogManagerImpl$IntegerField
-keepnames class com.data.manager.ChangelogManagerImpl$IntegerField
-if class com.data.manager.ChangelogManagerImpl$IntegerField
-keep class com.data.manager.ChangelogManagerImpl_IntegerFieldJsonAdapter {
    public <init>(com.squareup.moshi.Moshi);
}
-if class com.data.manager.ChangelogManagerImpl$StringField
-keepnames class com.data.manager.ChangelogManagerImpl$StringField
-if class com.data.manager.ChangelogManagerImpl$StringField
-keep class com.data.manager.ChangelogManagerImpl_StringFieldJsonAdapter {
    public <init>(com.squareup.moshi.Moshi);
}
# Please add these rules to your existing keep rules in order to suppress warnings.
# This is generated automatically by the Android Gradle plugin.
-dontwarn java.lang.invoke.StringConcatFactory


##########  AdsConfig core ##########
# Keep AdsConfig and its companion object
# --- Keep AdsConfig core and Admob helpers ---
-keep class com.adconfig.** { *; }
-dontwarn com.adconfig.**

-keep class com.adconfig.AdsConfig {
    public static final com.adconfig.AdsConfig$Companion Companion;
    *;
}
-keep class com.adconfig.AdsConfig$Companion { *; }

# Keep AdsConfig.Builder
-keep class com.adconfig.AdsConfig$Builder { *; }

# Keep AdmobInitializer if used
-keep class com.adconfig.AdmobInitializer { *; }

##########  adsutil package ##########
-keep class com.adconfig.adsutil.** { *; }
-keep class com.adconfig.adsutil.AdsParameters { *; }

##########  open ad helpers ##########
-keep class com.adconfig.adsutil.openad.AppOpenApplication { *; }
-keep class com.adconfig.adsutil.openad.AppOpenApplication$AppLifecycleListener { *; }
-keep class com.adconfig.adsutil.openad.OpenAdHelper { *; }

##########  admob implementations ##########
-keep class com.adconfig.adsutil.admob.AdmobIntersAdImpl { *; }
-keep class com.adconfig.adsutil.admob.AdmobNative { *; }
-keep class com.adconfig.adsutil.admob.BannerAdHelper { *; }
-keep class com.adconfig.adsutil.admob.NativeAdHelper { *; }
-keep class com.adconfig.adsutil.admob.NativeLayoutType { *; }

##########  utils ##########
-keep class com.adconfig.adsutil.utils.** { *; }

##########  view binding (if used) ##########
-keep class com.adconfig.databinding.LayoutShimmerAdBannerBinding { *; }
-keep class com.adconfig.databinding.LayoutShimmerGoogleNativeAdBigBinding { *; }

##########  Kotlin companion objects (safe rule) ##########
# Generic rule to keep ALL Kotlin companion objects so you don’t have to write each one
-keepclassmembers class * {
    public static final <fields>;
    companion object;
}
-keep class com.adconfig.AdsConfig { *; }
-keep class com.adconfig.AdsConfig$Companion { *; }

# Please add these rules to your existing keep rules in order to suppress warnings.
# This is generated automatically by the Android Gradle plugin.
-dontwarn com.adconfig.AdsConfig$Builder
-dontwarn com.adconfig.AdsConfig$Companion
-dontwarn com.adconfig.adsutil.AdsParameters
-dontwarn com.adconfig.adsutil.Config
-dontwarn com.adconfig.adsutil.abstract.IntersAd
-dontwarn com.adconfig.adsutil.admob.AdmobIntersAdImpl
-dontwarn com.adconfig.adsutil.admob.AdmobNative
-dontwarn com.adconfig.adsutil.admob.BannerAdHelper
-dontwarn com.adconfig.adsutil.admob.NativeAdHelper
-dontwarn com.adconfig.adsutil.admob.NativeLayoutType
-dontwarn com.adconfig.adsutil.openad.OpenAdHelper
-dontwarn com.adconfig.adsutil.utils.ExtContextKt
-dontwarn com.adconfig.adsutil.utils.ExtensionsKt
-dontwarn com.adconfig.databinding.LayoutShimmerAdBannerBinding
-dontwarn com.adconfig.databinding.LayoutShimmerGoogleNativeAdBigBinding
-dontwarn java.lang.invoke.StringConcatFactory
# Please add these rules to your existing keep rules in order to suppress warnings.
# This is generated automatically by the Android Gradle plugin.
-dontwarn java.lang.invoke.StringConcatFactory