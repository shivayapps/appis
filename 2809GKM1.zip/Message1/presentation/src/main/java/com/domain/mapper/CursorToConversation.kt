package com.domain.mapper

import android.database.Cursor
import com.domain.model.Conversation

interface CursorToConversation : Mapper<Cursor, Conversation> {

    fun getConversationsCursor(): Cursor?

}