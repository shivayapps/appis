package com.domain.interactor

import android.net.Uri
import android.util.Log
import io.reactivex.Flowable
import com.domain.extensions.mapNotNull
import com.domain.manager.ActiveConversationManager
import com.domain.manager.NotificationManager
import com.domain.repository.BlockingRepository
import com.domain.repository.ConversationRepository
import com.domain.repository.MessageRepository
import com.domain.repository.SyncRepository
import com.domain.util.Preferences
import javax.inject.Inject

class ReceiveMms @Inject constructor(
    private val activeConversationManager: ActiveConversationManager,
    private val conversationRepo: ConversationRepository,
    private val prefs: Preferences,
    private val syncManager: SyncRepository,
    private val messageRepo: MessageRepository,
    private val notificationManager: NotificationManager,
    private val updateBadge: UpdateBadge,
    private val blockingRepository: BlockingRepository
) : Interactor<Uri>() {

    override fun buildObservable(params: Uri): Flowable<*> {
        return Flowable.just(params)
            .mapNotNull(syncManager::syncMessage) // Sync the message
            .doOnNext { message ->
                // TODO: Ideally this is done when we're saving the MMS to ContentResolver
                // This change can be made once we move the MMS storing code to the Data module
                if (activeConversationManager.getActiveConversation() == message.threadId) {
                    messageRepo.markRead(message.threadId)
                }
            }
            .mapNotNull { message ->
                // Because we use the smsmms library for receiving and storing MMS, we'll need
                // to check if it should be blocked after we've pulled it into realm. If it
                // turns out that it should be dropped, then delete it
                // TODO Don't store blocked messages in the first place
                val isBlocked = blockingRepository.isBlocked(message.address)
                val shouldDrop = prefs.drop.get()
                Log.w("messageApp : ", "blocked=$isBlocked, drop=$shouldDrop")

                if (isBlocked && shouldDrop) {
                    messageRepo.deleteMessages(message.id)
                    return@mapNotNull null
                }
                message
            }
            .doOnNext { message ->
                conversationRepo.updateConversations(message.threadId) // Update the conversation
            }
            .mapNotNull { message ->
                conversationRepo.getOrCreateConversation(message.threadId) // Map message to conversation
            }
            .filter { conversation -> !conversation.blocked } // Don't notify for blocked conversations
            .doOnNext { conversation ->
                // Unarchive conversation if necessary
                if (conversation.archived) conversationRepo.markUnarchived(conversation.id)
            }
            .map { conversation -> conversation.id } // Map to the id because [delay] will put us on the wrong thread
            .doOnNext(notificationManager::update) // Update the notification
            .flatMap { updateBadge.buildObservable(Unit) } // Update the badge
    }

}