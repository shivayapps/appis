package com.domain.manager

import androidx.core.app.NotificationCompat

interface NotificationManager {

    fun update(threadId: Long)

    fun logSent(threadId: Long)

    fun notifyFailed(threadId: Long, parems: Int)

    fun createNotificationChannel(threadId: Long = 0L)

    fun buildNotificationChannelId(threadId: Long): String

    fun getNotificationForBackup(): NotificationCompat.Builder
    fun sendEvent(event: String, param_name: String, param_val: String)

}
