package com.domain.interactor.model

import io.realm.RealmObject
import io.realm.annotations.PrimaryKey
import java.io.Serializable

open class PhoneNumber(
    @PrimaryKey var id: Long = 0,
    var accountType: String? = "",
    var address: String = "",
    var type: String = "",
    var isSelected: Boolean = false,
    var isDefault: Boolean = false
) : RealmObject(), Serializable
