package com.domain.repository

import io.realm.RealmResults
import com.domain.model.Conversation
import com.domain.model.Message

interface StarredMessageRepository {

    /**
     * Returns all of the Starred messages, sorted chronologically
     */
    fun getStarredMessages(): RealmResults<Message>

    /**
     * Returns the Starred message with the given [id]
     */
    fun getStarredMessages(id: Long): Message?

    /**
     * Returns the Conversation for the given [id]
     */
    fun getConversation(id: Long): Conversation?

    /**
     * Deletes the Starred message with the given [id]
     */
    fun deleteStarredMessage(id: Long)

}