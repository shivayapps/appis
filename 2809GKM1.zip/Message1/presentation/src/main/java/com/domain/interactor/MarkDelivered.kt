package com.domain.interactor

import io.reactivex.Flowable
import com.domain.repository.MessageRepository
import javax.inject.Inject

class MarkDelivered @Inject constructor(private val messageRepo: MessageRepository) :
    Interactor<Long>() {

    override fun buildObservable(params: Long): Flowable<Unit> {
        return Flowable.just(Unit)
            .doOnNext { messageRepo.markDelivered(params) }
    }

}