package com.domain.interactor

import android.net.Uri
import io.reactivex.Flowable
import com.domain.extensions.LogE
import com.domain.extensions.mapNotNull
import com.domain.repository.ConversationRepository
import com.domain.repository.SyncRepository
import javax.inject.Inject

class SyncMessage @Inject constructor(
    private val conversationRepo: ConversationRepository,
    private val syncManager: SyncRepository,
    private val updateBadge: UpdateBadge
) : Interactor<Uri>() {

    override fun buildObservable(params: Uri): Flowable<*> {
        return Flowable.just(params)
            .mapNotNull { uri -> syncManager.syncMessage(uri) }
            .doOnNext { message ->
                LogE("messageApp : ", "Message SyncMessage updateConversations-  $message")
                conversationRepo.updateConversations(message.threadId)
            }
            .flatMap { updateBadge.buildObservable(Unit) } // Update the badge
    }

}