package com.domain.mapper

import android.database.Cursor
import com.domain.model.Contact

interface CursorToContact : Mapper<Cursor, Contact> {

    fun getContactsCursor(): Cursor?

}