package com.domain.interactor

import io.reactivex.Flowable
import com.domain.repository.BackupRepository
import javax.inject.Inject

class PerformBackup @Inject constructor(
    private val backupRepo: BackupRepository
) : Interactor<Unit>() {

    override fun buildObservable(params: Unit): Flowable<*> {
        return Flowable.just(params)
            .doOnNext { backupRepo.performBackup() }
    }

}