package com.domain.experiment

data class Variant<T>(val key: String, val value: T)