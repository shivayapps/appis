package com.data.repository

import io.realm.Realm
import io.realm.RealmResults
import com.domain.model.Conversation
import com.domain.model.Message
import com.domain.repository.StarredMessageRepository
import javax.inject.Inject

class StarredMessageRepositoryImpl @Inject constructor() : StarredMessageRepository {

    override fun getStarredMessages(): RealmResults<Message> {
        return Realm.getDefaultInstance()
            .where(Message::class.java)
            .equalTo("starred", true)
            .findAll()
    }

    override fun getConversation(threadId: Long): Conversation? {
        return Realm.getDefaultInstance()
            .apply {
                try {
                    refresh()
                } catch (e: Exception) {
                    com.data.extensions.LogE("getConversation: ", e.message.toString())
                }
            }
            .where(Conversation::class.java)
            .equalTo("id", threadId)
            .findFirst()
    }

    override fun getStarredMessages(id: Long): Message? {
        return Realm.getDefaultInstance()
            .apply { refresh() }
            .where(Message::class.java)
            .equalTo("starred", true)
            .findFirst()
    }

    override fun deleteStarredMessage(id: Long) {
        Realm.getDefaultInstance()
            .apply { refresh() }
            .use { realm ->
                val message = realm.where(Message::class.java)
                    .equalTo("id", id)
                    .findFirst()

                realm.executeTransaction { message?.deleteFromRealm() }
            }
    }

}