package com.data.receiver

import android.app.Activity
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import dagger.android.AndroidInjection
import com.domain.interactor.MarkDelivered
import com.domain.interactor.MarkDeliveryFailed
import javax.inject.Inject

class SmsDeliveredReceiver : BroadcastReceiver() {

    @Inject
    lateinit var markDelivered: MarkDelivered

    @Inject
    lateinit var markDeliveryFailed: MarkDeliveryFailed

    override fun onReceive(context: Context, intent: Intent) {
        AndroidInjection.inject(this, context)

        val id = intent.getLongExtra("id", 0L)

        when (resultCode) {
            // Notify about delivery
            Activity.RESULT_OK -> {
                val pendingResult = goAsync()
                markDelivered.execute(id) {
                    try {
                        pendingResult.finish()
                    } catch (e: IllegalStateException) {
                        com.data.extensions.LogE(
                            "IllegalStateException0:",
                            e.message.toString()
                        )
                        e.printStackTrace()
                    } catch (e: Exception) {
                        e.printStackTrace()
                    }
                }
            }

            // Notify about delivery failure
            Activity.RESULT_CANCELED -> {
                val pendingResult = goAsync()
                markDeliveryFailed.execute(
                    MarkDeliveryFailed.Params(
                        id,
                        resultCode
                    )
                ) {
                    try {
                        pendingResult.finish()
                    } catch (e: IllegalStateException) {
                        com.data.extensions.LogE(
                            "IllegalStateException: ",
                            e.message.toString()
                        )
                        e.printStackTrace()
                    } catch (e: Exception) {
                        e.printStackTrace()
                    }
                }
            }
        }
    }
}
