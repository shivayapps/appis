package com.data.receiver

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import dagger.android.AndroidInjection
import com.messenger.sms.text.R
import com.domain.interactor.MarkRead
import javax.inject.Inject

class MarkReadReceiver : BroadcastReceiver() {

    @Inject
    lateinit var markRead: MarkRead

    lateinit var notificationManager :NotificationManager

    override fun onReceive(context: Context, intent: Intent) {
        AndroidInjection.inject(this, context)
        val pendingResult = goAsync()
        val threadId = intent.getLongExtra("threadId", 0)

        notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

        val builder: NotificationCompat.Builder =
            NotificationCompat.Builder(context, getChannelIdForNotification(threadId))
                .setSmallIcon(R.drawable.ic_notifications)
                .setAutoCancel(true)
                .setContentTitle("")
                .setContentText("")
        notificationManager.notify(threadId.hashCode(), builder.build())
        notificationManager.cancel(threadId.hashCode())

        markRead.execute(listOf(threadId)) {
            try {
                pendingResult.finish()
            } catch (e: IllegalStateException) {
                com.data.extensions.LogE(
                    "IllegalStateException: ",
                    e.message.toString()
                )
                e.printStackTrace()
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    private val DEFAULT_CHANNEL_ID = "notifications_default"
    private fun getChannelIdForNotification(threadId: Long): String {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            return getNotificationChannel(threadId)?.id ?: DEFAULT_CHANNEL_ID
        }
        return DEFAULT_CHANNEL_ID
    }
    private fun getNotificationChannel(threadId: Long): NotificationChannel? {
        val channelId = buildNotificationChannelId(threadId)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            return notificationManager.notificationChannels
                .find { channel -> channel.id == channelId }
        }
        return null
    }
    private fun buildNotificationChannelId(threadId: Long): String {
        return when (threadId) {
            0L -> DEFAULT_CHANNEL_ID
            else -> "notifications_$threadId"
        }
    }
}