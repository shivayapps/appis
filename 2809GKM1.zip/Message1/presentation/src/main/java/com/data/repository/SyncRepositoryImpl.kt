package com.data.repository

import android.content.ContentResolver
import android.content.ContentUris
import android.net.Uri
import android.provider.Telephony
import android.util.Log
import com.f2prateek.rx.preferences2.RxSharedPreferences
import io.reactivex.subjects.BehaviorSubject
import io.reactivex.subjects.Subject
import io.realm.Realm
import io.realm.RealmList
import io.realm.Sort
import com.common.util.tryOrNull
import com.data.extensions.forEach
import com.data.extensions.insertOrUpdate
import com.data.extensions.map
import com.domain.manager.KeyManager
import com.data.util.PhoneNumberUtils
import com.data.util.ReConstant.amount_regex
import com.data.util.ReConstant.otp_regex
import com.data.util.ReConstant.parseCode
import com.data.util.ReConstant.promotion_regex
import com.data.util.ReConstant.transaction_regex
import com.domain.interactor.model.PhoneNumber
import com.domain.mapper.CursorToContact
import com.domain.mapper.CursorToContactGroup
import com.domain.mapper.CursorToContactGroupMember
import com.domain.mapper.CursorToConversation
import com.domain.mapper.CursorToMessage
import com.domain.mapper.CursorToPart
import com.domain.mapper.CursorToRecipient
import com.domain.model.*
import com.domain.repository.ConversationRepository
import com.domain.repository.SyncRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.util.regex.Pattern
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class SyncRepositoryImpl @Inject constructor(
    private val contentResolver: ContentResolver,
    private val conversationRepo: ConversationRepository,
    private val cursorToConversation: CursorToConversation,
    private val cursorToMessage: CursorToMessage,
    private val cursorToPart: CursorToPart,
    private val cursorToRecipient: CursorToRecipient,
    private val cursorToContact: CursorToContact,

    private val cursorToContactGroup: CursorToContactGroup,
    private val cursorToContactGroupMember: CursorToContactGroupMember,
    private val keys: KeyManager,
    private val phoneNumberUtils: PhoneNumberUtils,
    private val rxPrefs: RxSharedPreferences
) : SyncRepository {

    override val syncProgress: Subject<SyncRepository.SyncProgress> =
        BehaviorSubject.createDefault(SyncRepository.SyncProgress.Idle)

    fun syncMessagesOld() {

        // If the sync is already running, don't try to do another one
        if (syncProgress.blockingFirst() is SyncRepository.SyncProgress.Running) return
        syncProgress.onNext(SyncRepository.SyncProgress.Running(0, 0, true))

        val realm = Realm.getDefaultInstance()
        realm.beginTransaction()

        val persistedData = realm.copyFromRealm(
            realm.where(Conversation::class.java)
                .beginGroup()
                .equalTo("archived", true)
                .or()
                .equalTo("blocked", true)
                .or()
                .equalTo("pinned", true)
                .or()
                .isNotEmpty("name")
                .or()
//                .isNotNull("blockingClient")
//                .or()
                .isNotEmpty("blockReason")
                .endGroup()
                .findAll()
        )
            .associateBy { conversation -> conversation.id }
            .toMutableMap()

        val persistedMessages = realm.copyFromRealm(
            realm.where(Message::class.java)
                .equalTo("starred", true)
                .findAll()
        )
            .associateBy { message -> message.id }


        realm.delete(Contact::class.java)
        realm.delete(ContactGroup::class.java)
        realm.delete(Conversation::class.java)
        realm.delete(Message::class.java)
        realm.delete(MmsPart::class.java)
        realm.delete(Recipient::class.java)

        keys.reset()
        val partsCursor = cursorToPart.getPartsCursor()
        val messageCursor = cursorToMessage.getMessagesCursor()
        val conversationCursor = cursorToConversation.getConversationsCursor()
        val recipientCursor = cursorToRecipient.getRecipientCursor()

//        val max = 100
        val max = (partsCursor?.count ?: 0) +
                (messageCursor?.count ?: 0) +
                (conversationCursor?.count ?: 0) +
                (recipientCursor?.count ?: 0)

        var progress = 0

        // Sync messages
        messageCursor?.use {
            val messageColumns = CursorToMessage.MessageColumns(messageCursor)
            messageCursor.forEach { cursor ->
                tryOrNull {

                    progress++
                    syncProgress.onNext(SyncRepository.SyncProgress.Running(max, progress, false))
                    val message = cursorToMessage.map(Pair(cursor, messageColumns)).apply {
                        if (isSms()) {
                            val resultOtp =
                                Pattern.compile(otp_regex)
                                    .matcher(body.replace("\n", " ").trim()).find()
                            val resultTitle =
                                Pattern.compile(promotion_regex).matcher(address)
                                    .find()
                            val resultTransaction =
                                Pattern.compile(transaction_regex)
                                    .matcher(body.replace("\n", " ").trim()).find()
                            val resultTransactionAmount =
                                Pattern.compile(amount_regex)
                                    .matcher(body.replace("\n", " ").trim()).find()
                            if (resultOtp) {
                                messageCatType = 2
                                otpCode = parseCode(body)
                            } else if (resultTransaction && resultTransactionAmount) {
                                messageCatType = 1
                            } else if (resultTitle) {
                                messageCatType = 3
                            }
                        }
                        persistedMessages[id]?.let { persistedMessage ->
                            starred = persistedMessage.starred
                        }
                        if (isMms()) {
                            parts = RealmList<MmsPart>().apply {
                                addAll(
                                    realm.where(MmsPart::class.java)
                                        .equalTo("messageId", contentId)
                                        .findAll()
                                )
                            }
                            for (part in parts) {
                                Log.d("Sagar", "syncMessages: =====> ${part.getUri()}")
                            }
                        }
                    }
                    realm.insertOrUpdate(message)
                    /*if (message.type == "sms" && message.body.isNotEmpty()) {
                        realm.insertOrUpdate(message)
                    } else if (message.type == "mms" && message.parts.isNotEmpty()) {
                        realm.insertOrUpdate(message)
                    }*/
                }
            }
        }

        // Sync message parts
        partsCursor?.use {
            partsCursor.forEach {
                tryOrNull {
                    progress++
                    val part = cursorToPart.map(partsCursor)
                    realm.insertOrUpdate(part)
                }
            }
        }

        // Migrate blocked conversations from 2.7.3
        val oldBlockedSenders = rxPrefs.getStringSet("pref_key_blocked_senders")
        oldBlockedSenders.get()
            .map { threadIdString -> threadIdString.toLong() }
            .filter { threadId -> !persistedData.contains(threadId) }
            .forEach { threadId ->
                persistedData[threadId] = Conversation(id = threadId, blocked = true)
            }

        // Sync conversations
        conversationCursor?.use {
            val conversations = conversationCursor.map { cursor ->
                progress++
                syncProgress.onNext(SyncRepository.SyncProgress.Running(max, progress, false))
                val conversation = cursorToConversation.map(cursor).apply {
                    persistedData[id]?.let { persistedConversation ->
                        archived = persistedConversation.archived
                        blocked = persistedConversation.blocked
                        pinned = persistedConversation.pinned
                        name = persistedConversation.name
//                        blockingClient = persistedConversation.blockingClient
                        blockReason = persistedConversation.blockReason
                    }
                    lastMessage = realm.where(Message::class.java)
                        .sort("date", Sort.DESCENDING)
                        .equalTo("threadId", id)
                        .findFirst()

                }
                realm.insertOrUpdate(conversation)
            }
        }

        // Sync recipients
        recipientCursor?.use {
            val contacts = realm.copyToRealmOrUpdate(getContacts())
            val recipients = recipientCursor.map { cursor ->
                progress++
                syncProgress.onNext(SyncRepository.SyncProgress.Running(max, progress, false))
                cursorToRecipient.map(cursor).apply {
                    contact = contacts.firstOrNull { contact ->
                        contact.numbers.any { phoneNumberUtils.compare(address, it.address) }
                    }
                }
            }
            realm.insertOrUpdate(recipients)
        }

//        syncProgress.onNext(SyncRepository.SyncProgress.Running(0, 0, true))


        realm.insert(SyncLog())
        realm.commitTransaction()
        realm.close()

        // Only delete this after the sync has successfully completed
        oldBlockedSenders.delete()

        syncProgress.onNext(SyncRepository.SyncProgress.Idle)
    }

    override fun syncMessages() {
        Log.e("SyncRepository", "syncMessages")
        if (syncProgress.blockingFirst() is SyncRepository.SyncProgress.Running) return
        syncProgress.onNext(SyncRepository.SyncProgress.Running(0, 0, true))
        Log.e("TAGTAGTAGTAGTAG", "getContacts: ")
        val contacts = getContacts()
        keys.reset()
        var progress = 0

        val partsCursor = cursorToPart.getPartsCursor()
        val messageCursor = cursorToMessage.getMessagesCursor()
        val conversationCursor = cursorToConversation.getConversationsCursor()
        val recipientCursor = cursorToRecipient.getRecipientCursor()

        val max = (partsCursor?.count ?: 0) +
                (messageCursor?.count ?: 0) +
                (conversationCursor?.count ?: 0) +
                (recipientCursor?.count ?: 0)

        CoroutineScope(Dispatchers.IO).launch {
            val realm = Realm.getDefaultInstance()
            realm.beginTransaction()

            val persistedData = realm.copyFromRealm(
                realm.where(Conversation::class.java)
                    .beginGroup()
                    .equalTo("archived", true)
                    .or()
                    .equalTo("blocked", true)
                    .or()
                    .equalTo("pinned", true)
                    .or()
                    .isNotEmpty("name")
                    .or()
                    .isNotNull("blockingClient")
                    .or()
                    .isNotEmpty("blockReason")
                    .endGroup()
                    .findAll()
            ).associateBy { it.id }.toMutableMap()

            realm.delete(Conversation::class.java)
            realm.delete(Message::class.java)
            realm.delete(MmsPart::class.java)
            realm.delete(Recipient::class.java)

            val messageColumns = messageCursor?.let { CursorToMessage.MessageColumns(it) }
            val messages = mutableListOf<Message>()

            messageCursor?.use {
                messageCursor.forEach { cursor ->
                    progress++
                    syncProgress.onNext(SyncRepository.SyncProgress.Running(max, progress, false))

                    val message = cursorToMessage.map(Pair(cursor, messageColumns!!)).apply {
                        if (isSms()) {
                            val cleanedBody = body.replace("\n", " ").trim()
                            when {
                                Pattern.compile(otp_regex).matcher(cleanedBody).find() -> {
                                    messageCatType = 2
                                    otpCode = parseCode(cleanedBody)
                                }
                                Pattern.compile(transaction_regex).matcher(cleanedBody).find() &&
                                        Pattern.compile(amount_regex).matcher(cleanedBody).find() -> {
                                    messageCatType = 1
                                }
                                Pattern.compile(promotion_regex).matcher(address).find() -> {
                                    messageCatType = 3
                                }
                            }
                        }
                        if (isMms()) {
                            parts = RealmList<MmsPart>().apply {
                                addAll(
                                    realm.where(MmsPart::class.java)
                                        .equalTo("messageId", contentId)
                                        .findAll()
                                )
                            }
                        }
                    }

                    messages.add(message)
                }
            }
            realm.insertOrUpdate(messages)

            // 2️⃣ Sync MMS parts
            partsCursor?.use {
                val parts = mutableListOf<MmsPart>()
                partsCursor.forEach {
                    progress++
                    syncProgress.onNext(SyncRepository.SyncProgress.Running(max, progress, false))
                    cursorToPart.map(partsCursor)?.let { part -> parts.add(part) }
                }
                realm.insertOrUpdate(parts)
            }

            // 3️⃣ Legacy blocked senders
            val oldBlockedSenders = rxPrefs.getStringSet("pref_key_blocked_senders")
            oldBlockedSenders.get()
                .map { it.toLong() }
                .filterNot { persistedData.containsKey(it) }
                .forEach { threadId ->
                    persistedData[threadId] = Conversation(id = threadId, blocked = true)
                }

            // 4️⃣ Sync conversations
            val conversations = mutableListOf<Conversation>()
            conversationCursor?.use {
                conversationCursor.forEach { cursor ->
                    progress++
                    syncProgress.onNext(SyncRepository.SyncProgress.Running(max, progress, false))

                    val conversation = cursorToConversation.map(cursor).apply {
                        persistedData[id]?.let { persisted ->
                            archived = persisted.archived
                            blocked = persisted.blocked
                            pinned = persisted.pinned
                            name = persisted.name
                            blockingClient = persisted.blockingClient
                            blockReason = persisted.blockReason
                        }
                    }
                    conversations.add(conversation)
                }
            }

            realm.where(Message::class.java)
                .sort("date", Sort.DESCENDING)
                .distinct("threadId")
                .findAll()
                .forEach { msg ->
                    conversations.find { it.id == msg.threadId }?.lastMessage = msg
                }

            realm.insertOrUpdate(conversations)

            // 5️⃣ Sync recipients
            recipientCursor?.use {
                val recipients = recipientCursor.map { cursor ->
                    progress++
                    syncProgress.onNext(SyncRepository.SyncProgress.Running(max, progress, false))
                    cursorToRecipient.map(cursor).apply {
                        contact = contacts.firstOrNull { contact ->
                            contact.numbers.any { phoneNumberUtils.compare(address, it.address) }
                        }
                    }
                }
                realm.insertOrUpdate(recipients)
            }

            // Finalize
            Log.e("SyncRepository", "syncMessages.SyncProgress.Running")
            syncProgress.onNext(SyncRepository.SyncProgress.Running(0, 0, true))
            realm.insert(SyncLog())
            realm.commitTransaction()
            realm.close()
            oldBlockedSenders.delete()
            Log.e("SyncRepository", "syncMessages.SyncProgress.Idle")
            syncProgress.onNext(SyncRepository.SyncProgress.Idle)
        }
    }

    override fun syncMessage(uri: Uri): Message? {

        // If we don't have a valid type, return null
        val type = when {
            uri.toString().contains("mms") -> "mms"
            uri.toString().contains("sms") -> "sms"
            else -> return null
        }

        // If we don't have a valid id, return null
        val id = tryOrNull(false) { ContentUris.parseId(uri) } ?: return null

        // Check if the message already exists, so we can reuse the id
        val existingId = Realm.getDefaultInstance().use { realm ->
            realm.refresh()
            realm.where(Message::class.java)
                .equalTo("type", type)
                .equalTo("contentId", id)
                .findFirst()
                ?.id
        }

        // The uri might be something like content://mms/inbox/id
        // The box might change though, so we should just use the mms/id uri
        val stableUri = when (type) {
            "mms" -> ContentUris.withAppendedId(Telephony.Mms.CONTENT_URI, id)
            else -> ContentUris.withAppendedId(Telephony.Sms.CONTENT_URI, id)
        }

        return contentResolver.query(stableUri, null, null, null, null)?.use { cursor ->

            // If there are no rows, return null. Otherwise, we've moved to the first row
            if (!cursor.moveToFirst()) return null

            val columnsMap = CursorToMessage.MessageColumns(cursor)
            cursorToMessage.map(Pair(cursor, columnsMap)).apply {
                existingId?.let { this.id = it }

                if (isMms()) {
                    parts = RealmList<MmsPart>().apply {
                        addAll(cursorToPart.getPartsCursor(contentId)?.map { cursorToPart.map(it) }
                            .orEmpty())
                    }
                }

                conversationRepo.getOrCreateConversation(threadId)
                insertOrUpdate()
            }
        }
    }

    override fun syncContacts() {
        // Load all the contacts
        var contacts = getContacts()

        Realm.getDefaultInstance()?.use { realm ->
            val recipients = realm.where(Recipient::class.java).findAll()

            realm.executeTransaction {
                realm.delete(Contact::class.java)
//                realm.delete(ContactGroup::class.java)

                contacts = realm.copyToRealmOrUpdate(contacts)
//                realm.insertOrUpdate(getContactGroups(contacts))

                // Update all the recipients with the new contacts
                recipients.forEach { recipient ->
                    recipient.contact = contacts.find { contact ->
                        contact.numbers.any {
                            phoneNumberUtils.compare(
                                recipient.address,
                                it.address
                            )
                        }
                    }
                }
                realm.insertOrUpdate(recipients)
            }
        }
    }

    private fun getContacts(): List<Contact> {
        val defaultNumberIds = Realm.getDefaultInstance().use { realm ->
            realm.where(PhoneNumber::class.java)
                .equalTo("isDefault", true)
                .findAll()
                .map { number -> number.id }
        }
        cursorToContact.getContactsCursor()?.close()
        val contactsCursor = cursorToContact.getContactsCursor()
        val listContact = contactsCursor
            ?.map { cursor -> cursorToContact.map(cursor) }
            ?.groupBy { contact -> contact.lookupKey }
            ?.map { contacts ->
                // Sometimes, contacts providers on the phone will create duplicate phone number entries. This
                // commonly happens with Whatsapp. Let's try to detect these duplicate entries and filter them out
                val uniqueNumbers = mutableListOf<PhoneNumber>()
                contacts.value
                    .flatMap { it.numbers }
                    .sortedBy { it.accountType }
                    .forEach { number ->
                        number.isDefault = defaultNumberIds.any { id -> id == number.id }
                        val duplicate = uniqueNumbers.any { other ->
                            number.accountType != other.accountType
                                    && phoneNumberUtils.compare(number.address, other.address)
                        }

                        if (!duplicate) {
                            uniqueNumbers += number
                        }
                    }

                contacts.value.first().apply {
                    numbers.clear()
                    numbers.addAll(uniqueNumbers)
                }
            } ?: listOf()
//        contactsCursor?.close()

        return listContact
    }


    /*  private fun getContactGroups(contacts: List<Contact>): List<ContactGroup> {
           val groups = cursorToContactGroup.getContactGroupsCursor()
               ?.map(cursorToContactGroup::map)
               .orEmpty()

           groups.forEach { group ->
               group.contacts.addAll(cursorToContactGroupMember.getGroupMembersCursor()
                   ?.map(cursorToContactGroupMember::map)
                   .orEmpty()
                   .filter { member -> member.groupId == group.id }
                   .mapNotNull { member -> contacts.find { contact -> contact.lookupKey == member.lookupKey } })
           }

   //        membersCursor?.close()
   //        cursor?.close()
           return groups
       }
   */
}
