package com.data.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import dagger.android.AndroidInjection
import com.domain.interactor.DeleteMessages
import javax.inject.Inject

class DeleteMessagesReceiver : BroadcastReceiver() {

    @Inject
    lateinit var deleteMessages: DeleteMessages

    override fun onReceive(context: Context, intent: Intent) {
        AndroidInjection.inject(this, context)

        val pendingResult = goAsync()
        val threadId = intent.getLongExtra("threadId", 0)
        val messageIds = intent.getLongArrayExtra("messageIds")
        deleteMessages.execute(DeleteMessages.Params(messageIds!!.toList(), threadId)) {
            try {
                pendingResult.finish()
            } catch (e: IllegalStateException) {
                com.data.extensions.LogE(
                    "IllegalStateException: ",
                    e.message.toString()
                )
                e.printStackTrace()
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }
}