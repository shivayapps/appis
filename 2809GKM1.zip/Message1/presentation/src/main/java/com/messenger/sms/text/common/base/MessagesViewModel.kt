package com.messenger.sms.text.common.base

import androidx.annotation.CallSuper
import androidx.lifecycle.ViewModel
import com.uber.autodispose.android.lifecycle.scope
import com.uber.autodispose.autoDisposable
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.disposables.CompositeDisposable
import io.reactivex.rxkotlin.plusAssign
import io.reactivex.subjects.BehaviorSubject
import io.reactivex.subjects.PublishSubject
import io.reactivex.subjects.Subject
import com.messenger.sms.text.common.util.extensions.LogE

abstract class MessagesViewModel<in View : MessagesView<State>, State:Any>(initialState: State) :
    ViewModel() {

    protected val disposables = CompositeDisposable()
    protected val state: Subject<State> = BehaviorSubject.createDefault(initialState)

    private val stateReducer: Subject<State.() -> State> = PublishSubject.create()

    init {
        // If we accidentally push a realm object into the state on the wrong thread, switching
        // to mainThread right here should immediately alert us of the issue

        disposables += stateReducer
            .observeOn(AndroidSchedulers.mainThread())
            .scan(initialState) { state, reducer -> reducer(state) }
            .subscribe(state::onNext
            ) { t -> LogE("accept: ", t.message.toString()) }
    }

    @CallSuper
    open fun bindView(view: View) {
        state
            .observeOn(AndroidSchedulers.mainThread())
            .autoDisposable(view.scope())
            .subscribe(view::render
            ) { t -> LogE("accept: ", t?.message.toString()) }
    }

    public fun newState(reducer: State.() -> State) = stateReducer.onNext(reducer)

    override fun onCleared() = disposables.dispose()

}