package com.messenger.sms.text.common.base

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import androidx.viewbinding.ViewBinding

//class MessagesViewHolder(view: View) : RecyclerView.ViewHolder(view), LayoutContainer {
//    override val containerView: View = view
//}
class MessagesViewHolder<T : ViewBinding>(val binding: T) : RecyclerView.ViewHolder(binding.root) {

    constructor(
        parent: ViewGroup,
        bindingInflator: (LayoutInflater, ViewGroup, Boolean) -> T,
    ) : this(bindingInflator(LayoutInflater.from(parent.context), parent, false))

}

