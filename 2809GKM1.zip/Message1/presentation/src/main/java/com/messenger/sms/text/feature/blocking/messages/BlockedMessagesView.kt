package com.messenger.sms.text.feature.blocking.messages

import io.reactivex.Observable
import com.messenger.sms.text.common.base.MessagesViewContract

interface BlockedMessagesView : MessagesViewContract<BlockedMessagesState> {

    val menuReadyIntent: Observable<Unit>
    val optionsItemIntent: Observable<Int>
    val conversationClicks: Observable<Long>
    val selectionChanges: Observable<List<Long>>
    val confirmDeleteIntent: Observable<List<Long>>
    val dropClickedIntent: Observable<*>
    val unBlockUndoSubject:Observable<List<Long>>
    fun clearSelection()

    fun requestDefaultSms()
    fun showBlockingDialog(conversations: List<Long>, block: Boolean,isTrue:(Boolean)->Unit)
    fun showDeleteDialog(conversations: List<Long>)
//    fun startSubscriptionActivity()
    fun showUnBlockedSnackBar(conversations:List<Long>)

}
