package com.messenger.sms.text.feature.compose.editing

import android.content.Context
import android.view.ViewGroup
import io.reactivex.subjects.BehaviorSubject
import io.reactivex.subjects.Subject

import com.messenger.sms.text.R
import com.messenger.sms.text.common.base.MessagesAdapter
import com.messenger.sms.text.common.base.MessagesViewHolder
import com.messenger.sms.text.common.util.extensions.forwardTouches
import com.messenger.sms.text.databinding.PhoneNumberListItemBinding
import com.domain.extensions.Optional
import com.domain.interactor.model.PhoneNumber
import javax.inject.Inject

class PhoneNumberPickerAdapter @Inject constructor(
    private val context: Context
) : MessagesAdapter<PhoneNumber, PhoneNumberListItemBinding>() {

//    val selectedItemChanges: Subject<Long> = BehaviorSubject.create()
    val selectedItemChanges: Subject<Optional<Long>> = BehaviorSubject.create()

    private var selectedItem: Long? = null
        set(value) {
            data.indexOfFirst { number -> number.id == field }.takeIf { it != -1 }
                ?.run(::notifyItemChanged)
            field = value
            data.indexOfFirst { number -> number.id == field }.takeIf { it != -1 }
                ?.run(::notifyItemChanged)
            selectedItemChanges.onNext(Optional(value))
        }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MessagesViewHolder<PhoneNumberListItemBinding> {

        return MessagesViewHolder(parent, PhoneNumberListItemBinding::inflate).apply {
            binding.number.binding.radioButton.forwardTouches(itemView)

            binding.root.setOnClickListener {
                val phoneNumber = getItem(adapterPosition)
                selectedItem = phoneNumber.id
            }
        }
//        val inflater = LayoutInflater.from(parent.context)
//        val view = inflater.inflate(R.layout.phone_number_list_item, parent, false)
//        return MessagesViewHolder(view).apply {
//            view                  .setOnClickListener {
//                val phoneNumber = getItem(absoluteAdapterPosition)
//                setChecked(phoneNumber)
//            }
//
//            view.number.radioButton.setOnClickListener {
//                val phoneNumber = getItem(absoluteAdapterPosition)
//                setChecked(phoneNumber)
//            }
//        }
    }

//    private fun setChecked(phoneNumber: PhoneNumber) {
//        data.forEach { it.isSelected = false }
//        phoneNumber.isSelected = true
//        selectedItemChanges.onNext(phoneNumber.id)
//        notifyDataSetChanged()
//    }

    fun checkAnySelected(): Boolean {
        return data.any { it.isSelected }
    }

    override fun onBindViewHolder(holder: MessagesViewHolder<PhoneNumberListItemBinding>, position: Int) {
        val phoneNumber = getItem(position)

        holder.binding.number.binding.radioButton.isChecked = phoneNumber.isSelected
        holder.binding.number.binding.titleView.text = phoneNumber.address
        holder.binding.number.binding.summaryView.text = when (phoneNumber.isDefault) {
            true -> context.getString(R.string.compose_number_picker_default, phoneNumber.type)
            false -> phoneNumber.type
        }
    }

}
