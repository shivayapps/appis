package com.messenger.sms.text.feature.compose.editing

import android.view.ViewGroup
import com.messenger.sms.text.common.base.MessagesAdapter
import com.messenger.sms.text.common.base.MessagesViewHolder
import com.messenger.sms.text.databinding.ContactNumberListItemBinding
import com.domain.interactor.model.PhoneNumber

class PhoneNumberAdapter : MessagesAdapter<PhoneNumber, ContactNumberListItemBinding>() {

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int,
    ):MessagesViewHolder<ContactNumberListItemBinding> {
        return MessagesViewHolder(parent, ContactNumberListItemBinding::inflate).apply {
//            val textColorPrimary = parent.context.baseConfig.textColor
//            val colorWithAlpha = parent.context.baseConfig.textColor.addAlpha(0.3F)
//            binding.address.setTextColor(colorWithAlpha)
//            binding.type.setTextColor(colorWithAlpha)

        }
    }

    override fun onBindViewHolder(
        holder: MessagesViewHolder<ContactNumberListItemBinding>,
        position: Int,
    ) {
        val number = getItem(position)

        holder.binding.address.text = number.address
        holder.binding.type.text = number.type

//        val textColorPrimary = holder.binding.address.context.baseConfig.textColor
//        val colorWithAlpha = textColorPrimary.addAlpha(0.45F)
//        holder.binding.address.setTextColor(colorWithAlpha)
//        holder.binding.type.setTextColor(colorWithAlpha)
    }

    override fun areItemsTheSame(old: PhoneNumber, new: PhoneNumber): Boolean {
        return old.type == new.type && old.address == new.address
    }

    override fun areContentsTheSame(old: PhoneNumber, new: PhoneNumber): Boolean {
        return old.type == new.type && old.address == new.address
    }

}

