package com.messenger.sms.text.feature.compose.editing

enum class PhoneNumberAction {
    CANCEL,
    JUST_ONCE,
    ALWAYS
}
