package com.messenger.sms.text.common

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.content.pm.ActivityInfo
import android.content.res.Configuration
import android.os.Build
import android.os.Bundle
import androidx.core.provider.FontRequest
import androidx.emoji.text.EmojiCompat
import androidx.emoji.text.FontRequestEmojiCompatConfig
import com.adconfig.AdsConfig
import com.adconfig.adsutil.openad.AppOpenApplication
import com.adconfig.adsutil.openad.OpenAdHelper
import com.adconfig.adsutil.openad.WelcomeBackActivity
import com.google.android.gms.tasks.Task
import com.google.firebase.remoteconfig.FirebaseRemoteConfig
import com.google.firebase.remoteconfig.FirebaseRemoteConfigSettings

import io.realm.Realm
import io.realm.RealmConfiguration
import com.messenger.sms.text.R
import com.messenger.sms.text.common.util.AppUtils
import com.messenger.sms.text.common.util.FileLoggingTree
import com.messenger.sms.text.injection.AppComponentManager
import com.messenger.sms.text.injection.appComponent
import com.messenger.sms.text.common.preferance.PreferenceKeys

import dagger.android.AndroidInjector
import dagger.android.DispatchingAndroidInjector
import dagger.android.HasAndroidInjector
import com.messenger.sms.text.common.staticData.EventKeys

import com.messenger.sms.text.common.util.extensions.LogE
import com.messenger.sms.text.common.util.extensions.LogW
import com.messenger.sms.text.feature.main.SplashActivity
import com.messenger.sms.text.utils.*
import com.data.migration.MessagesRealmMigration
import com.data.util.NightModeManager
import com.messenger.sms.text.common.preferance.AppPreference
import timber.log.Timber
import javax.inject.Inject


@SuppressLint("All")
class MessagesApplication : AppOpenApplication(), HasAndroidInjector,AppOpenApplication.AppLifecycleListener,
    androidx.work.Configuration.Provider  {

    // WorkManager
//    override val workManagerConfiguration: Configuration by lazy {
//        val appWorkerFactory = EntryPoints
//            .get(this, HiltAppEntryPoint::class.java)
//            .workerFactory()
//
//        Configuration.Builder()
//            .setMinimumLoggingLevel(if (BuildConfig.DEBUG) Log.DEBUG else Log.INFO)
//            .setWorkerFactory(appWorkerFactory)
//            .build()
//    }

    override val workManagerConfiguration: androidx.work.Configuration
        get() = androidx.work.Configuration.Builder()
//            .setWorkerFactory(workerFactory)
            .build()

//    @Inject
//    lateinit var dispatchingActivityInjector: DispatchingAndroidInjector<Activity>
//
//    @Inject
//    lateinit var dispatchingBroadcastReceiverInjector: DispatchingAndroidInjector<BroadcastReceiver>
//
//    @Inject
//    lateinit var dispatchingServiceInjector: DispatchingAndroidInjector<Service>

    @Inject
    lateinit var fileLoggingTree: FileLoggingTree

    @Inject
    lateinit var realmMigration: MessagesRealmMigration

    @Inject
    lateinit var nightModeManager: NightModeManager

    private val TAG: String = "MessagesApplication"
    override fun onCreate() {
        super.onCreate()
        try {
//            openAdApplication = OpenAdApplication()
//            setAppLifeCycleListener(this) //For Open Ad
            AppComponentManager.init(this@MessagesApplication)
            appComponent.inject(this@MessagesApplication)
            Realm.init(this@MessagesApplication)

            nightModeManager.updateCurrentTheme()

            setRealmConfiguration()
            Timber.plant(Timber.DebugTree(), fileLoggingTree)
            val fontRequest = FontRequest(
                "com.google.android.gms.fonts",
                "com.google.android.gms",
                "Noto Color Emoji Compat",
                R.array.com_google_android_gms_fonts_certs
            )
            EmojiCompat.init(
                FontRequestEmojiCompatConfig(
                    this@MessagesApplication,
                    fontRequest
                )
            )

            fireBaseConfigGet()

            val appOpenId = if (AppPreference(this).isFirstTime) getString(R.string.open_resume) else getString(R.string.open_resume2)
            AdsConfig.builder()
                .setTestDeviceId("0")
                .setAdmobAppOpenId(appOpenId)
                .build(this)

            setAppLifecycleListener(this)
            initMobileAds()

        } catch (e: Exception) {
            AppUtils.logAdapterMessages(
                EventKeys.crash,
                EventKeys.main_application,
                e.message.orEmpty()
            )
            LogE(
                TAG,
                "Exceptions----- ${e.message}"
            )
        }
    }

    private fun setRealmConfiguration() {
        try {
            Realm.removeDefaultConfiguration()
            Realm.setDefaultConfiguration(
                RealmConfiguration.Builder()
                    .compactOnLaunch()
                    .schemaVersion(MessagesRealmMigration.SchemaVersion)
                    .deleteRealmIfMigrationNeeded()
                    .migration(realmMigration)
                    .build()

            )
        } catch (e: Exception) {
            LogE(TAG, "Exception:"+e.message.toString())
            Realm.getDefaultConfiguration()
        }
    }

    private fun fireBaseConfigGet() {
        try {
            remoteConfig = FirebaseRemoteConfig.getInstance()
            remoteConfig.setConfigSettingsAsync(
                FirebaseRemoteConfigSettings.Builder()
                    .setMinimumFetchIntervalInSeconds(0)
                    .setFetchTimeoutInSeconds(3)
                    .build()
            )
            LogE("TAG" + "fireBaseConfigGet: ", "send req")
            remoteConfig.setDefaultsAsync(R.xml.firebase_rc_defaults)
            remoteConfig.fetch(0)
                .addOnCompleteListener { task: Task<Void?> ->
                    var errorString = ""
                    if (task.isSuccessful) {
                        remoteConfig.fetchAndActivate()
                        //AppUtils.e("TAGmFirebaseRemoteConfigis_ +-$")

                        errorString = " task is successful  "
//                        for (key in remoteConfig.getKeysByPrefix("")) {
//                            val value = remoteConfig.getValue(key)
//                            if (value.asString() != null) {
//                                Log.i(TAG,"RemoteConfigList: Key::>>" + key + "<<::Value-String::>>" + remoteConfig.getString(key) + "<<::")
//                            } else if (value.asBoolean()) {
//                                Log.i(TAG,"RemoteConfigList: Key::>>" + key + "<<::Value-Boolean::>>" + remoteConfig.getBoolean(key) + "<<::")
//                            } else if (value.asDouble() != null) {
//                                Log.i(TAG,"RemoteConfigList: Key::>>" + key + "<<::Value-Double::>>" + remoteConfig.getDouble(key) + "<<::")
//                            } else if (value.asLong() != null) {
//                                Log.i(TAG,"RemoteConfigList: Key::>>" + key + "<<::Value-Long::>>" + remoteConfig.getLong(key) + "<<::")
//                            } else {
//                                Log.i(TAG,"RemoteConfigList: Key::>>" + key + "<<::Value-ELSE::>>" + remoteConfig.getValue(key) + "<<::")
//                            }
//                        }
                    } else {
                        errorString = "task is canceled"
                    }
                    LogE(TAG, "ErrorString:$errorString")
                    AppUtils.e(" mFirebaseRemoteConfigis_ errorString ---------$errorString")
                }
        } catch (e: java.lang.Exception) {
            LogE(TAG, "Exception:$e")
            e.printStackTrace()
        }
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        val nightModeFlags = resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK

        if (nightModeFlags == Configuration.UI_MODE_NIGHT_NO) {
            LogW(
                TAG,
                "MODE CHANGE-- WHTIE"
            )
            isOrientationChanged = true
            PreferenceManager.saveData(this, PreferenceKeys.IS_MODE_CHANGE, true)
        } else {
            LogW(
                TAG,
                "MODE CHANGE-- BLACK"
            )
            isOrientationChanged = true
            PreferenceManager.saveData(this, PreferenceKeys.IS_MODE_CHANGE, true)

        }
    }

//    override fun activityInjector(): AndroidInjector<Activity> {
//        return dispatchingActivityInjector
//    }
//
//    override fun broadcastReceiverInjector(): AndroidInjector<BroadcastReceiver> {
//        return dispatchingBroadcastReceiverInjector
//    }
//
//    override fun serviceInjector(): AndroidInjector<Service> {
//        return dispatchingServiceInjector
//    }

    companion object {
        var isOrientationChanged: Boolean = false
        lateinit var remoteConfig: FirebaseRemoteConfig
//        lateinit var mFirebaseAnalytics: FirebaseAnalytics
//        lateinit var openAdApplication: OpenAdApplication
//        fun isFirebaseAnalyticsInit() = ::mFirebaseAnalytics.isInitialized
        fun isRemoteConfigInit() = ::remoteConfig.isInitialized
    }

    override fun onResumeApp(fCurrentActivity: Activity): Boolean {
        if (Build.VERSION.SDK_INT != Build.VERSION_CODES.O) {
            fCurrentActivity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
        } else {
            fCurrentActivity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        }
        if (fCurrentActivity is SplashActivity) {
            return false
        } else if (AdsConfig.isSystemDialogOpen) {
            AdsConfig.isSystemDialogOpen=false
            return false
        }
        return true
    }

    override fun onActivityCreated(fCurrentActivity: Activity, savedInstanceState: Bundle?) {
    }

    override fun onAppOpenCreatedEvent(fCurrentActivity: Activity) {
        if (onResumeApp(fCurrentActivity))
            if (!fCurrentActivity.isDestroyed && !fCurrentActivity.isFinishing) {
                if (OpenAdHelper.isAdAvailable()) {
                    val intent = Intent(fCurrentActivity, WelcomeBackActivity::class.java)
                    intent.putExtra("isAdLoading", OpenAdHelper.isAdLoading)
                    fCurrentActivity.startActivity(intent)
                }
            }
    }

    override fun onAppOpenShownEvent(fCurrentActivity: Activity) {
    }

    override fun onAppOpenFailedEvent(fCurrentActivity: Activity) {
    }

//    override fun onAppOpenCreatedEvent(fCurrentActivity: Activity) {
//
//        if (onResumeApp(fCurrentActivity))
//            if (!fCurrentActivity.isDestroyed && !fCurrentActivity.isFinishing) {
////            if (!OpenAdHelper.isAdAvailable()) {
//                val intent = Intent(fCurrentActivity, WelcomeBackActivity::class.java)
//                intent.putExtra("isAdLoading", OpenAdHelper.isAdLoading)
//                fCurrentActivity.startActivity(intent)
////            }
////            else {
////                logMessages("app_appopen_created", fCurrentActivity.localClassName)
////            }
//            }
//    }
//
//    override fun onAppOpenShownEvent(fCurrentActivity: Activity) {
//    }
//
//    override fun onAppOpenFailedEvent(fCurrentActivity: Activity) {
//    }

    @Inject
    lateinit var androidInjector: DispatchingAndroidInjector<Any>
    override fun androidInjector(): AndroidInjector<Any> {
        return androidInjector
    }

}