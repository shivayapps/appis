package com.messenger.sms.text.feature.compose.editing

import android.content.Context
import android.view.View
import android.view.animation.AlphaAnimation
import android.widget.RelativeLayout
import com.messenger.sms.text.utils.gone
import com.messenger.sms.text.R
import com.messenger.sms.text.common.util.extensions.customViewBinding
import com.messenger.sms.text.databinding.ContactChipDetailedBinding
import com.messenger.sms.text.injection.appComponent
import com.domain.model.Recipient

class DetailedChipView(context: Context) : RelativeLayout(context) {

    val binding: ContactChipDetailedBinding = customViewBinding(ContactChipDetailedBinding::inflate)
    init {
        View.inflate(context, R.layout.contact_chip_detailed, this)

        appComponent.inject(this)

        setOnClickListener { hide() }

        gone()

        isFocusable = true
        isFocusableInTouchMode = true
    }

    fun setRecipient(recipient: Recipient) {
        binding.avatar.setRecipient(recipient)
        binding.name.text = recipient.contact?.name?.takeIf { it.isNotBlank() } ?: recipient.address
        binding.info.text = recipient.address

    }

    fun show() {
        startAnimation(AlphaAnimation(0f, 1f).apply { duration = 200 })

        visibility = View.VISIBLE
        requestFocus()
        isClickable = true
    }

    fun hide() {
        startAnimation(AlphaAnimation(1f, 0f).apply { duration = 200 })

        gone()
        clearFocus()
        isClickable = false
    }

    fun setOnDeleteListener(listener: (View) -> Unit) {
        binding.delete.setOnClickListener(listener)
    }

}
