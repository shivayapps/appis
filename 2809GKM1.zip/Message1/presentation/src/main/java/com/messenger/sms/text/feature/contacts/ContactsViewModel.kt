package com.messenger.sms.text.feature.contacts

import android.util.Log
import com.uber.autodispose.android.lifecycle.scope
import com.uber.autodispose.autoDisposable
import io.reactivex.Observable
import io.reactivex.Single
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.rxkotlin.Observables
import io.reactivex.schedulers.Schedulers
import io.realm.RealmList
import com.messenger.sms.text.common.base.MessagesViewModel
import com.messenger.sms.text.feature.compose.editing.ComposeItem
import com.messenger.sms.text.feature.compose.editing.PhoneNumberAction
import com.data.extensions.removeAccents
import com.data.filter.ContactFilter
import com.data.filter.ContactGroupFilter
import com.data.filter.ConversationFilter
import com.domain.repository.ConversationRepository
import com.data.util.PhoneNumberUtils
import com.domain.interactor.SetDefaultPhoneNumber
import com.domain.interactor.model.PhoneNumber
import com.domain.model.*
import com.domain.repository.ContactRepository
import kotlinx.coroutines.rx2.awaitFirst
import javax.inject.Inject

class ContactsViewModel @Inject constructor(
    val sharing: Boolean,
    serializedChips: HashMap<String, String?>,
    private val contactFilter: ContactFilter,
    private val conversationFilter: ConversationFilter,
    private val contactGroupFilter: ContactGroupFilter,
    private val contactsRepo: ContactRepository,
    private val conversationRepo: ConversationRepository,
    private val phoneNumberUtils: PhoneNumberUtils,
    private val setDefaultPhoneNumber: SetDefaultPhoneNumber
) : MessagesViewModel<ContactsContract, ContactsState>(ContactsState()) {
    private val TAG = "ContactsViewModel++"
    private val contactGroups: Observable<List<ContactGroup>> by lazy { contactsRepo.getUnmanagedContactGroups() }
    private val contacts: Observable<List<Contact>> by lazy { contactsRepo.getAllContacts() }
    private val recents: Observable<List<Conversation>> by lazy {
        if (sharing) conversationRepo.getUnmanagedConversations() else Observable.just(listOf())
    }
    /*private val starredContacts: Observable<List<Contact>> by lazy {
        contactsRepo.getUnmanagedContacts(
            true
        )
    }*/

    private val selectedChips = Observable.just(serializedChips)
        .observeOn(Schedulers.io())
        .map { hashmap ->
            hashmap.map { (address, lookupKey) ->
                Recipient(
                    address = address,
                    contact = lookupKey?.let(contactsRepo::getUnmanagedContact)
                )
            }
        }



    override fun bindView(view: ContactsContract) {
        super.bindView(view)

        // Update the state's query, so we know if we should show the cancel button
        view.queryChangedIntent
            .autoDisposable(view.scope())
            .subscribe { query -> newState { copy(query = query.toString()) } }

        // Clear the query
        view.queryClearedIntent
            .autoDisposable(view.scope())
            .subscribe { view.clearQuery() }

        // Update the list of contact suggestions based on the query input, while also filtering out any contacts
        // that have already been selected
        Observables
            .combineLatest(
                view.queryChangedIntent,
                recents,
//                starredContacts,
                contactGroups,
                contacts,
                selectedChips
            ) { query, recents, /*starredContacts,*/ contactGroups, contacts, selectedChips ->
                val composeItems = mutableListOf<ComposeItem>()
                if (query.isBlank()) {
                    composeItems += recents
                        .filter { conversation ->
                            conversation.recipients.any { recipient ->
                                selectedChips.none { chip ->
                                    if (recipient.contact == null) {
                                        chip.address == recipient.address
                                    } else {
                                        chip.contact?.lookupKey == recipient.contact?.lookupKey
                                    }
                                } && !isLetters(recipient.address.substring(0, 2))
                            }
                        }
                        .map(ComposeItem::Recent)

                    val list: ArrayList<Contact> = arrayListOf()
                    contacts.filter { contact -> contact.starred }.forEach {
                        it.name = "❤" + it.name
                        list.add(it)
                    }
                    composeItems += list
                        .filter { contact -> selectedChips.none { it.contact?.lookupKey == contact.lookupKey } }
                        .map(ComposeItem::Starred)

                    composeItems += contactGroups
                        .filter { group ->
                            group.contacts.any { contact ->
                                selectedChips.none { chip -> chip.contact?.lookupKey == contact.lookupKey }
                            }
                        }
                        .map(ComposeItem::Group)

                    composeItems += contacts
                        .filter { contact -> selectedChips.none { it.contact?.lookupKey == contact.lookupKey } && !contact.starred }
                        .map(ComposeItem::Person)
                } else {

                    val normalizedQuery = query.removeAccents()

                    composeItems += recents
                        .filter { conversation ->
                            conversation.recipients.any { recipient ->
                                selectedChips.none { chip ->
                                    if (recipient.contact == null) {
                                        chip.address == recipient.address
                                    } else {
                                        chip.contact?.lookupKey == recipient.contact?.lookupKey
                                    }
                                } && !isLetters(recipient.address.substring(0, 2))
                            }
                        }
                        .filter { conversation ->
                            conversationFilter.filter(
                                conversation,
                                normalizedQuery
                            )
                        }
                        .map(ComposeItem::Recent)

                    val list: ArrayList<Contact> = arrayListOf()
                    contacts.filter { contact -> contact.starred }.forEach {
                        it.name = "❤" + it.name
                        list.add(it)
                    }
                    composeItems += list
                        .filter { contact -> selectedChips.none { it.contact?.lookupKey == contact.lookupKey } }
                        .filter { contact -> contactFilter.filter(contact, normalizedQuery) }
                        .map(ComposeItem::Starred)

                    composeItems += contactGroups
                        .asSequence()
                        .filter { group ->
                            group.contacts.any { contact ->
                                selectedChips.none { chip -> chip.contact?.lookupKey == contact.lookupKey }
                            }
                        }
                        .filter { group -> contactGroupFilter.filter(group, normalizedQuery) }
                        .map(ComposeItem::Group)

                    composeItems += contacts
                        .asSequence()
                        .filter { contact -> selectedChips.none { it.contact?.lookupKey == contact.lookupKey } && !contact.starred }
                        .filter { contact -> contactFilter.filter(contact, normalizedQuery) }
                        .map(ComposeItem::Person)

                    if (phoneNumberUtils.isPossibleNumber(query.toString())) {
                        val newAddress = phoneNumberUtils.formatNumber(query)
                        val newContact =
                            Contact(
                                name = query.toString(),
                                numbers = RealmList(PhoneNumber(address = newAddress))
                            )
                        composeItems.add(0, ComposeItem.New(newContact))
                    }
                }
                composeItems
            }
            .subscribeOn(Schedulers.computation())
            .autoDisposable(view.scope())
            .subscribe { items ->
                newState { copy(composeItems = items) }
            }

        view.composeItemPressedIntent
            .map { composeItem -> composeItem to false }
            .mergeWith(view.composeItemLongPressedIntent.map { composeItem -> composeItem to true })
            .observeOn(Schedulers.io())
            .flatMapSingle { (composeItem, force) ->
                Single.fromCallable {
                    val resultMap = HashMap<String, String>()
                    composeItem.getContacts().forEach { contact ->
                        if (contact.numbers.size == 1 || contact.getDefaultNumber() != null && !force) {
                            val address = contact.getDefaultNumber()?.address ?: contact.numbers[0]?.address
                            address?.let { resultMap[it] = contact.lookupKey }
                        } else {
                            newState { copy(selectedContact = contact) }
                            val action = view.phoneNumberActionIntent.blockingFirst()
                            newState { copy(selectedContact = null) }

                            if (action == PhoneNumberAction.CANCEL) {
                                return@forEach
                            }
                            val numberId = view.phoneNumberSelectedIntent.blockingFirst()
                            val number = contact.numbers.find { number -> number.id == numberId.value }

                            if (number != null && action == PhoneNumberAction.ALWAYS) {
                                val params = SetDefaultPhoneNumber.Params(contact.lookupKey, number.id)
                                setDefaultPhoneNumber.execute(params)
                            }
                            number?.address?.let { resultMap[it] = contact.lookupKey }
                        }
                    }
                    resultMap
                }
            }
            .filter { result -> result.isNotEmpty() }
            .observeOn(AndroidSchedulers.mainThread())
            .autoDisposable(view.scope())
            .subscribe { result ->
                Log.e("JASH---", "bindView: ---------${result}")
                view.finish(result)
            }

        // Listen for ComposeItems being selected, and then send them off to the number picker dialog in case
        // the user needs to select a phone number
        /* view.composeItemPressedIntent
             .map { composeItem -> composeItem to false }
             .mergeWith(view.composeItemLongPressedIntent.map { composeItem -> composeItem to true })
             .observeOn(Schedulers.io())
             .map { (composeItem, force) ->
                 try {
                     view.finish(HashMap(composeItem.getContacts().associate { contact ->
                         if (contact.numbers.size == 1 || contact.getDefaultNumber() != null && !force) {
                             val address =
                                 contact.getDefaultNumber()?.address ?: contact.numbers[0]!!.address
                             address to contact.lookupKey
                         } else {
                             runBlocking {
                                 newState { copy(selectedContact = contact) }
                                 val action = view.phoneNumberActionIntent.awaitFirst()
                                 newState { copy(selectedContact = null) }

                                 if (action == PhoneNumberAction.CANCEL) {
                                     return@runBlocking null
                                 }
                                 val numberId = view.phoneNumberSelectedIntent.awaitFirst()
                                 val number =
                                     contact.numbers.find { number -> number.id == numberId }

                                 if (number == null) {
                                     return@runBlocking null
                                 }

                                 if (action == PhoneNumberAction.ALWAYS) {
                                     val params =
                                         SetDefaultPhoneNumber.Params(contact.lookupKey, number.id)
                                     setDefaultPhoneNumber.execute(params)
                                 }

                                 number.address to contact.lookupKey

                             } ?: return@map
                         }
                     }))
                 } catch (e: Exception) {
                     LogE(TAG, "bindView: " + e.message)
                 }
             }
             .observeOn(AndroidSchedulers.mainThread())
             .autoDisposable(view.scope())
             .subscribe()*/
    }

    private fun isLetters(string: String): Boolean {
        return string.filter { it in 'A'..'Z' || it in 'a'..'z' }.length == string.length
    }

}
