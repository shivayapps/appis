package com.messenger.sms.text.feature.conversationinfo.injection

import androidx.lifecycle.ViewModel
import dagger.Module
import dagger.Provides
import dagger.multibindings.IntoMap
import io.reactivex.disposables.CompositeDisposable
import com.messenger.sms.text.feature.conversationinfo.ConversationInfoActivity
import com.messenger.sms.text.feature.main.ConversationInfoViewModel
import com.messenger.sms.text.injection.ViewModelKey
import com.messenger.sms.text.injection.scope.ActivityScope
import javax.inject.Named

@Module
class ConversationInfoModule {

    @Provides
    @ActivityScope
    fun provideCompositeDiposableLifecycle(): CompositeDisposable = CompositeDisposable()

    @Provides
    @IntoMap
    @ViewModelKey(ConversationInfoViewModel::class)
    fun provideConversationInfoViewModel(viewModel: ConversationInfoViewModel): ViewModel = viewModel

    @Provides
    @Named("threadId")
    fun provideThreadId(activity: ConversationInfoActivity): Long =
        activity.intent.extras?.getLong("threadId") ?: 0L
}
