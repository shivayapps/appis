package com.messenger.sms.text.common.widget

import android.os.SystemClock
import android.view.View

class SafeClickListener(
    private val interval: Int = 1200,
    private val onSafeClick: (View) -> Unit
) : View.OnClickListener {

    companion object{
        var lastClickTime: Long = 0L
    }

    override fun onClick(v: View) {
        if (SystemClock.elapsedRealtime() - lastClickTime < interval) {
            return
        }
        lastClickTime = SystemClock.elapsedRealtime()
        onSafeClick(v)
    }
}

fun View.setOnSafeClickListener(
    onSafeClick: (View) -> Unit
) {
    setOnClickListener(SafeClickListener { v ->
        onSafeClick(v)
    })
}