package com.messenger.sms.text.feature.blocking

import android.app.Activity
import android.os.Handler
import android.os.Looper
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.schedulers.Schedulers
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import org.greenrobot.eventbus.EventBus
import com.domain.interactor.MarkBlocked
import com.domain.interactor.MarkUnblocked
import com.domain.repository.ConversationRepository
import com.domain.util.Preferences
import com.messenger.sms.text.event.UnreadEvent


import javax.inject.Inject

class BlockingDialog @Inject constructor(
    private val conversationRepo: ConversationRepository,
    private val prefs: Preferences,
    private val markBlocked: MarkBlocked,
    private val markUnblocked: MarkUnblocked
) {

    fun show(
        activity: Activity,
        conversationIds: List<Long>,
        block: Boolean,
        isTrue: (Boolean) -> Unit
    ) = CoroutineScope(Dispatchers.Main).launch {
        val addresses = conversationIds.toLongArray()
            .let { conversationRepo.getConversations(*it).first }
            .flatMap { conversation -> conversation.recipients }
            .map { it.address }
            .distinct()

        if (addresses.isEmpty()) {
            return@launch
        }

        if (block) {
            markBlocked.execute(
                MarkBlocked.Params(
                    conversationIds,
                    null
                )
            ) {
                conversationRepo.block(addresses).subscribeOn(Schedulers.io())
                    .observeOn(AndroidSchedulers.mainThread()).subscribe()
//                conversationRepo.block(addresses).subscribe()
                Handler(Looper.myLooper()!!).postDelayed({
                    EventBus.getDefault().post(UnreadEvent())
                }, 100)
            }
        } else {
            markUnblocked.execute(conversationIds) {
                conversationRepo.unblock(addresses).subscribeOn(Schedulers.io())
                    .observeOn(AndroidSchedulers.mainThread()).subscribe()
//                conversationRepo.unblock(addresses).subscribe()
                Handler(Looper.myLooper()!!).postDelayed({
                    EventBus.getDefault().post(UnreadEvent())
                }, 100)
            }

        }

        activity.runOnUiThread {

            isTrue.invoke(true)
        }

    }

}
