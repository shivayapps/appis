package com.messenger.sms.text.feature.adapter

import android.graphics.Typeface
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import com.messenger.sms.text.utils.gone
import com.messenger.sms.text.utils.inVisible
import com.messenger.sms.text.utils.visible
import com.messenger.sms.text.R
import com.messenger.sms.text.common.util.extensions.setTint
import com.messenger.sms.text.databinding.NavDrawerMenuBinding
import com.messenger.sms.text.databinding.NavDrawerOtherTitleBinding
import com.messenger.sms.text.feature.model.NavigationItemModel


var selectedItemPosition = 0
class NavMenuAdapter(
    private var items: ArrayList<NavigationItemModel>,
    private val messageSize: Int,
    private val archiveMessageSize: Int,
    var onItemClick: ((Boolean, Int) -> Unit)
) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {


    private val VIEW_TYPE_MENU = 0
    private val VIEW_TYPE_TITLE = 1

    class NavigationItemViewHolder(val binding: NavDrawerMenuBinding) :
        RecyclerView.ViewHolder(binding.root)

    class NavigationOtherItemTitleViewHolder(val binding: NavDrawerOtherTitleBinding) :
        RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        return when (viewType) {
            VIEW_TYPE_TITLE -> {
                val binding =
                    NavDrawerOtherTitleBinding.inflate(
                        LayoutInflater.from(parent.context),
                        parent,
                        false
                    )
                NavigationOtherItemTitleViewHolder(binding)
            }
            VIEW_TYPE_MENU -> {
                val binding = NavDrawerMenuBinding.inflate(
                    LayoutInflater.from(parent.context),
                    parent,
                    false
                )
                NavigationItemViewHolder(binding)
            }
            else -> throw java.lang.Exception("Not Supported layout")
        }
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        val menuItem = items[position]
        when (menuItem.type) {
            1 -> {
                with((holder as NavigationOtherItemTitleViewHolder).binding) {
                    tvNavOtherMenuTitle.text =
                        tvNavOtherMenuTitle.context.getString(R.string.more_option)
                }

            }
            else -> {
                with((holder as NavigationItemViewHolder).binding)
                {

                    if (menuItem.type == 0) {
                        dividerEnd.visible()
                    } else {
                        dividerEnd.inVisible()
                    }

                    if (selectedItemPosition == position) {
                        ivNavMenuIcon.setTint(
                            ContextCompat.getColor(
                                ivNavMenuArrow.context,
                                R.color.btn_copy_bg
                            )
                        )
                        tvNavMenuTitle.setTextColor(
                            ContextCompat.getColor(
                                tvNavMenuTitle.context,
                                R.color.btn_copy_bg
                            )
                        )
                        tvNavMenuTitle.setTypeface(null, Typeface.BOLD)
                        root.setBackgroundColor(
                            ContextCompat.getColor(
                                ivNavMenuArrow.context,
                                R.color.drawer_select_back
                            )
                        )
                    } else {
                        ivNavMenuIcon.setTint(
                            ContextCompat.getColor(
                                ivNavMenuIcon.context,
                                R.color.black_color
                            )
                        )
                        tvNavMenuTitle.setTextColor(
                            ContextCompat.getColor(
                                tvNavMenuTitle.context,
                                R.color.black_color
                            )
                        )
                        tvNavMenuTitle.setTypeface(null, Typeface.NORMAL)
                        root.setBackgroundColor(
                            ContextCompat.getColor(
                                ivNavMenuArrow.context,
                                R.color.app_background
                            )
                        )
                    }
                    tvNavMenuTitle.text = menuItem.title
                    ivNavMenuIcon.setImageResource(menuItem.menuIcon)


//                    if (menuItem.isVip == 1) {
//                        ivNavMenuItemPro.visible()
//                    } else {
//                        ivNavMenuItemPro.gone()
//                    }

                    when (menuItem.isArrowType) {
                        0 -> {
                            if (menuItem.isMessageType == 1) {
                                if (archiveMessageSize > 0) {
                                    tvNavMenuMessagesCount.visibility = View.VISIBLE
                                    ivNavMenuArrow.visibility = View.GONE
                                    tvNavMenuMessagesCount.text = archiveMessageSize.toString()
                                } else {
                                    tvNavMenuMessagesCount.visibility = View.GONE
                                    ivNavMenuArrow.visibility = View.GONE
                                }

                            } else {
                                if (messageSize > 0) {
                                    tvNavMenuMessagesCount.visibility = View.VISIBLE
                                    ivNavMenuArrow.visibility = View.GONE
                                    tvNavMenuMessagesCount.text = messageSize.toString()
                                } else {
                                    tvNavMenuMessagesCount.visibility = View.GONE
                                    ivNavMenuArrow.visibility = View.GONE
                                }

                            }

                        }
                        1 -> {
                            tvNavMenuMessagesCount.visibility = View.GONE
                            ivNavMenuArrow.visibility = View.VISIBLE
                        }
                        2 -> {
                            tvNavMenuMessagesCount.visibility = View.GONE
                            ivNavMenuArrow.visibility = View.GONE
                        }
                        else -> {
                            tvNavMenuMessagesCount.visibility = View.GONE
                            ivNavMenuArrow.visibility = View.VISIBLE
                        }
                    }

                    root.setOnClickListener {
                        setMenuPositions(position, holder,true)
                    }
                }
            }
        }
    }

    fun setMenuPositions(
        position: Int,
        viewHolder: NavigationItemViewHolder,
        fromDrawer: Boolean
    ) {
        Log.e("MSG", "onBindViewHolder: else---------------$position")
        //selectedItemPosition = position
        viewHolder.binding.ivNavMenuIcon.setTint(
            ContextCompat.getColor(
                viewHolder.binding.ivNavMenuArrow.context,
                R.color.btn_copy_bg
            )
        )
        viewHolder.binding.tvNavMenuTitle.setTypeface(null, Typeface.BOLD)
        viewHolder.binding.root.setBackgroundColor(
            ContextCompat.getColor(
                viewHolder.binding.ivNavMenuArrow.context,
                R.color.drawer_select_back
            )
        )
        onItemClick.invoke(fromDrawer, position)

        selectedItemPosition = if (position == 1) {
            1
        }else{
            0
        }
        notifyDataSetChanged()
    }



    override fun getItemViewType(position: Int): Int {
        val item = items[position]
        return when (item.type) {
            1 -> {
                VIEW_TYPE_TITLE
            }
            else -> {
                VIEW_TYPE_MENU
            }
        }
    }

    override fun getItemCount(): Int {
        return items.count()
    }


}