package com.messenger.sms.text.emoji_view_library.Helper;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.graphics.Color;
import android.os.Handler;
import android.os.SystemClock;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.WindowManager.LayoutParams;
import android.widget.LinearLayout;
import android.widget.PopupWindow;

import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.viewpager.widget.PagerAdapter;
import androidx.viewpager.widget.ViewPager;

import com.balysv.materialripple.MaterialRippleLayout;

import java.util.Arrays;
import java.util.List;

import com.messenger.sms.text.R;
import com.messenger.sms.text.emoji_view_library.emoji.EmojiIcon;

public class EmojiIconsPopup extends PopupWindow implements
        ViewPager.OnPageChangeListener, EmojiIconRecent {
    private int mEmojiTabLastSelectedIndex = -1;
    private View[] mEmojiTabs;
    private PagerAdapter mEmojisAdapter;
    public static EmojiIconRecentManager emojiIconRecentManager;
    private Boolean pendingOpen = false;
    private Boolean isOpened = false;
    public EmojiIconGridView.OnEmojiIconClickedListener onEmojiIconClickedListener;
    View rootView;
    Context mContext;
    boolean mUseSystemDefault;
    View view;
    int positionPager = 0;
    String backgroundColor = "#60000000";

    public static ViewPager emojisPager;
    public static LinearLayout tabs;
    EmojiIconRecent recents;

    public View getViewData() {
        return view;
    }

    /**
     * Constructor
     *
     * @param rootView         The top most layout in your view hierarchy. The difference of
     *                         this view and the screen height will be used to calculate the
     *                         keyboard height.
     * @param mContext         The context of current activity.
     * @param useSystemDefault .
     */
    @SuppressLint("NewApi")
    public EmojiIconsPopup(View rootView, Context mContext,
                           boolean useSystemDefault) {
        super(mContext);
        this.mUseSystemDefault = useSystemDefault;
        this.mContext = mContext;
        this.rootView = rootView;
        View customView = createCustomView();
        setContentView(customView);
        setSoftInputMode(LayoutParams.SOFT_INPUT_STATE_ALWAYS_VISIBLE);
        setSize(LayoutParams.MATCH_PARENT, 255);

    }


    /**
     * Set the listener for the event when any of the emojicon is clicked
     */
    public void setOnEmojiIconClickedListener(
            EmojiIconGridView.OnEmojiIconClickedListener listener) {
        this.onEmojiIconClickedListener = listener;
    }


    /**
     * Use this function to show the ic_showemoji popup. NOTE: Since, the soft keyboard
     * sizes are variable on different android devices, the library needs you to
     * open the soft keyboard atleast once before calling this function. If that
     * is not possible see showAtBottomPending() function.
     */
    public void showAtBottom() {
        showAtLocation(rootView, Gravity.BOTTOM, 0, 0);
    }

    /**
     * Use this function when the soft keyboard has not been opened yet. This
     * will show the ic_showemoji popup after the keyboard is up next time. Generally,
     * you will be calling InputMethodManager.showSoftInput function after
     * calling this function.
     */
    public void showAtBottomPending() {
        if (isKeyBoardOpen())
            showAtBottom();
        else
            pendingOpen = true;
    }

    /**
     * @return Returns true if the soft keyboard is open, false otherwise.
     */
    public Boolean isKeyBoardOpen() {
        return isOpened;
    }

    /**
     * Dismiss the popup
     */
    @Override
    public void dismiss() {
        super.dismiss();
        EmojiIconRecentManager.getInstance(mContext).saveRecent();
    }


    /**
     * Manually set the popup window size
     *
     * @param width  Width of the popup
     * @param height Height of the popup
     */
    public void setSize(int width, int height) {
        setWidth(width);
        setHeight(height);
    }

    public void updateUseSystemDefault(boolean mUseSystemDefault) {
        if (view != null) {
            mEmojisAdapter = null;
            positionPager = emojisPager.getCurrentItem();
            dismiss();
            this.mUseSystemDefault = mUseSystemDefault;
            setContentView(createCustomView());
            if (emojiIconRecentManager.size() == 0) {
                emojisPager.setCurrentItem(1);
            } else {
                emojisPager.setCurrentItem(positionPager);
            }
            onPageSelected(positionPager);
            if (!isShowing()) {
                // If keyboard is visible, simply show the ic_showemoji popup
                if (isKeyBoardOpen()) {
                    showAtBottom();
                } else {
                    showAtBottomPending();
                }
            }

        }
    }

    @SuppressLint("NewApi")
    private View createCustomView() {
        LayoutInflater inflater = (LayoutInflater) mContext
                .getSystemService(Activity.LAYOUT_INFLATER_SERVICE);
        view = inflater.inflate(R.layout.emojicons, null, false);
        emojisPager = view.findViewById(R.id.emojis_pager);
        tabs = view.findViewById(R.id.emojis_tab);
        emojisPager.setOnPageChangeListener(this);
        emojisPager.setBackgroundColor(ContextCompat.getColor(mContext,R.color.white_color));
        recents = this;
        try {
            new Handler().postDelayed(() -> {
                mEmojisAdapter = new EmojisPagerAdapter(Arrays.asList(
                        new EmojiIconRecentGridView(mContext, null, null, EmojiIconsPopup.this, mUseSystemDefault),
                        new EmojiIconGridView(mContext, "People", recents, EmojiIconsPopup.this, mUseSystemDefault),
                        new EmojiIconGridView(mContext, "Nature", recents, EmojiIconsPopup.this, mUseSystemDefault),
                        new EmojiIconGridView(mContext, "Food", recents, EmojiIconsPopup.this, mUseSystemDefault),
                        new EmojiIconGridView(mContext, "Sport", recents, EmojiIconsPopup.this, mUseSystemDefault),
                        new EmojiIconGridView(mContext, "Cars", recents, EmojiIconsPopup.this, mUseSystemDefault),
                        new EmojiIconGridView(mContext, "Electr", recents, EmojiIconsPopup.this, mUseSystemDefault),
                        new EmojiIconGridView(mContext, "Symbols", recents, EmojiIconsPopup.this, mUseSystemDefault),
                        new EmojiIconGridView(mContext, "Flags", recents, EmojiIconsPopup.this, mUseSystemDefault)
                ));
                emojisPager.setAdapter(mEmojisAdapter);
            }, 100);
        } catch (Exception | OutOfMemoryError e) {
            e.printStackTrace();
        }
        mEmojiTabs = new View[9];
        mEmojiTabs[0] = view.findViewById(R.id.emojis_tab_0_recents);
        mEmojiTabs[1] = view.findViewById(R.id.emojis_tab_1_people);
        mEmojiTabs[2] = view.findViewById(R.id.emojis_tab_2_nature);
        mEmojiTabs[3] = view.findViewById(R.id.emojis_tab_3_food);
        mEmojiTabs[4] = view.findViewById(R.id.emojis_tab_4_sport);
        mEmojiTabs[5] = view.findViewById(R.id.emojis_tab_5_cars);
        mEmojiTabs[6] = view.findViewById(R.id.emojis_tab_6_elec);
        mEmojiTabs[7] = view.findViewById(R.id.emojis_tab_7_sym);
        mEmojiTabs[8] = view.findViewById(R.id.emojis_tab_8_flags);
        for (int i = 0; i < mEmojiTabs.length; i++) {
            final int position = i;
            mEmojiTabs[i].setOnClickListener(v -> emojisPager.setCurrentItem(position));
        }

        emojisPager.setBackgroundColor(Color.parseColor(backgroundColor));
        for (View mEmojiTab : mEmojiTabs) {
            MaterialRippleLayout btn = (MaterialRippleLayout) mEmojiTab;
        }
        emojiIconRecentManager = EmojiIconRecentManager.getInstance(view.getContext());
        int page = emojiIconRecentManager.getRecentPage();
        if (page == 0) {
            emojisPager.setCurrentItem(1);
        } else {
            emojisPager.setCurrentItem(page, false);
        }
        return view;
    }

    @Override
    public void addRecentEmoji(Context context, EmojiIcon emojiIcon) {
        EmojiIconRecentGridView fragment = ((EmojisPagerAdapter) emojisPager
                .getAdapter()).getRecentFragment();
        fragment.addRecentEmoji(context, emojiIcon);
    }

    @Override
    public void onPageScrolled(int i, float v, int i2) {
    }

    @Override
    public void onPageSelected(int i) {
        if (mEmojiTabLastSelectedIndex == i) {
            return;
        }
        switch (i) {
            case 0:
            case 1:
            case 2:
            case 3:
            case 4:
            case 5:
            case 6:
            case 7:
            case 8:
                if (mEmojiTabLastSelectedIndex >= 0
                        && mEmojiTabLastSelectedIndex < mEmojiTabs.length) {
                    mEmojiTabs[mEmojiTabLastSelectedIndex].setSelected(false);
                }
                mEmojiTabs[i].setSelected(true);
                mEmojiTabLastSelectedIndex = i;
                emojiIconRecentManager.setRecentPage(i);
                break;
        }
    }

    @Override
    public void onPageScrollStateChanged(int i) {
    }

    public static class EmojisPagerAdapter extends PagerAdapter {
        private final List<EmojiIconGridView> views;

        public EmojiIconRecentGridView getRecentFragment() {
            for (EmojiIconGridView it : views) {
                if (it instanceof EmojiIconRecentGridView)
                    return (EmojiIconRecentGridView) it;
            }
            return null;
        }

        public EmojisPagerAdapter(List<EmojiIconGridView> views) {
            super();
            this.views = views;
        }

        @Override
        public int getCount() {
            return views.size();
        }

        @NonNull
        @Override
        public Object instantiateItem(@NonNull ViewGroup container, int position) {
            View v = views.get(position).rootView;
            container.addView(v, 0);
            return v;
        }

        @Override
        public void destroyItem(@NonNull ViewGroup container, int position, @NonNull Object view) {
            container.removeView((View) view);
        }

        @Override
        public boolean isViewFromObject(@NonNull View view, @NonNull Object key) {
            return key == view;
        }
    }

    /**
     * A class, that can be used as a TouchListener on any view (e.g. a Button).
     * It cyclically runs a clickListener, emulating keyboard-like behaviour.
     * First click is fired immediately, next before initialInterval, and
     * subsequent before normalInterval.
     * <p/>
     * <p>
     * Interval is scheduled before the onClick completes, so it has to run
     * fast. If it runs slow, it does not generate skipped onClicks.
     */
    public static class RepeatListener implements View.OnTouchListener {

        private final Handler handler = new Handler();

        private final int initialInterval;
        private final int normalInterval;
        private final OnClickListener clickListener;

        private final Runnable handlerRunnable = new Runnable() {
            @Override
            public void run() {
                if (downView == null) {
                    return;
                }
                handler.removeCallbacksAndMessages(downView);
                handler.postAtTime(this, downView, SystemClock.uptimeMillis()
                        + normalInterval);
                clickListener.onClick(downView);
            }
        };

        private View downView;

        /**
         * @param initialInterval The interval before first click event
         * @param normalInterval  The interval before second and subsequent click events
         * @param clickListener   The OnClickListener, that will be called periodically
         */
        public RepeatListener(int initialInterval, int normalInterval,
                              OnClickListener clickListener) {
            if (clickListener == null)
                throw new IllegalArgumentException("null runnable");
            if (initialInterval < 0 || normalInterval < 0)
                throw new IllegalArgumentException("negative interval");

            this.initialInterval = initialInterval;
            this.normalInterval = normalInterval;
            this.clickListener = clickListener;
        }

        public boolean onTouch(View view, MotionEvent motionEvent) {
            switch (motionEvent.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    downView = view;
                    handler.removeCallbacks(handlerRunnable);
                    handler.postAtTime(handlerRunnable, downView,
                            SystemClock.uptimeMillis() + initialInterval);
                    clickListener.onClick(view);
                    return true;
                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                case MotionEvent.ACTION_OUTSIDE:
                    handler.removeCallbacksAndMessages(downView);
                    downView = null;
                    return true;
            }
            return false;
        }
    }

}