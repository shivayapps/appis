package com.messenger.sms.text.feature.conversationinfo

import com.domain.feature.conversationinfo.ConversationInfoItem

data class ConversationInfoState(
    val threadId: Long = 0,
    val data: List<ConversationInfoItem> = listOf(),
    val hasError: Boolean = false
)
