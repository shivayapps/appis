package com.messenger.sms.text.feature.compose

import android.Manifest
import android.animation.LayoutTransition
import android.annotation.SuppressLint
import android.app.Activity
import android.app.AlarmManager
import android.app.DatePickerDialog
import android.app.TimePickerDialog
import androidx.core.view.ViewCompat
import androidx.activity.enableEdgeToEdge
import androidx.core.view.WindowInsetsCompat
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.pm.ActivityInfo
import android.content.pm.PackageManager
import android.database.Cursor
import android.graphics.Color
import android.graphics.PorterDuff
import android.graphics.Rect
import android.graphics.drawable.ColorDrawable
import android.location.Address
import android.location.Geocoder
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.ContactsContract
import android.provider.MediaStore
import android.provider.Settings
import android.text.InputFilter
import android.text.format.DateFormat
import android.util.Log
import android.util.TypedValue
import android.view.Gravity
import android.view.LayoutInflater
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.view.ViewGroup
import android.view.animation.AnimationUtils
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputConnection
import android.widget.PopupWindow
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.view.menu.MenuBuilder
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.view.isVisible
import androidx.core.view.size
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.adconfig.AdsConfig
import com.adconfig.adsutil.AdsParameters
import com.adconfig.adsutil.Config
import com.adconfig.adsutil.admob.AdmobIntersAdImpl
import com.adconfig.adsutil.admob.BannerAdHelper
import com.adconfig.adsutil.admob.BannerAds
import com.balysv.materialripple.MaterialRippleLayout
import com.messenger.sms.text.R
import com.messenger.sms.text.common.CommonDialog
import com.messenger.sms.text.common.Navigator
import com.messenger.sms.text.common.base.MessagesThemedActivity
import com.messenger.sms.text.common.staticData.EventKeys
import com.messenger.sms.text.common.util.AppUtils
import com.messenger.sms.text.common.util.BaseConfig
import com.messenger.sms.text.common.util.DateFormatter
import com.messenger.sms.text.common.util.extensions.LogE
import com.messenger.sms.text.common.util.extensions.LogW
import com.messenger.sms.text.common.util.extensions.autoScrollToStart
import com.messenger.sms.text.common.util.extensions.dpToPx
import com.messenger.sms.text.common.util.extensions.hideKeyboard
import com.messenger.sms.text.common.util.extensions.scrapViews
import com.messenger.sms.text.common.util.extensions.setBackgroundTint
import com.messenger.sms.text.common.util.extensions.setVisible
import com.messenger.sms.text.common.util.extensions.showKeyboard
import com.messenger.sms.text.emoji_view_library.Helper.EmojiIconsPopup
import com.messenger.sms.text.emoji_view_library.actions.EmojiIconActions
import com.messenger.sms.text.feature.compose.editing.ChipsAdapter
import com.messenger.sms.text.feature.contacts.ContactsActivity
import com.messenger.sms.text.feature.conversationinfo.ConversationInfoActivity
import com.messenger.sms.text.feature.main.DateRangePickerDialogActivity
import com.messenger.sms.text.utils.gone
import com.messenger.sms.text.utils.isKeyboardOpen
import com.messenger.sms.text.utils.visible
import com.google.android.flexbox.FlexboxLayoutManager
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationServices
import com.google.android.material.snackbar.Snackbar
import com.jakewharton.rxbinding2.view.clicks
import com.jakewharton.rxbinding2.widget.textChanges
import com.karumi.dexter.Dexter
import com.karumi.dexter.listener.PermissionDeniedResponse
import com.karumi.dexter.listener.PermissionGrantedResponse
import com.karumi.dexter.listener.single.BasePermissionListener
import com.karumi.dexter.listener.single.CompositePermissionListener
import com.karumi.dexter.listener.single.DialogOnDeniedPermissionListener
import com.messenger.sms.text.databinding.ComposeActivityBinding
import dagger.android.AndroidInjection
import io.reactivex.Observable
import io.reactivex.subjects.PublishSubject
import io.reactivex.subjects.Subject
import net.yslibrary.android.keyboardvisibilityevent.KeyboardVisibilityEvent
import net.yslibrary.android.keyboardvisibilityevent.KeyboardVisibilityEvent.setEventListener
import net.yslibrary.android.keyboardvisibilityevent.KeyboardVisibilityEventListener
import com.common.extensions.resolveThemeColor
import com.domain.model.Attachment
import com.domain.model.Recipient
import com.google.android.gms.ads.AdView
import com.google.android.material.datepicker.MaterialStyledDatePickerDialog
import com.google.android.material.timepicker.MaterialTimePicker
import com.messenger.sms.text.common.dialog.AlarmPermissionBottomSheetDialog
import com.messenger.sms.text.common.extensions.beGone
import com.messenger.sms.text.common.extensions.beVisible
import com.messenger.sms.text.common.util.extensions.viewBinding
import com.messenger.sms.text.utils.AdCache
import com.messenger.sms.text.utils.isOnline
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import javax.inject.Inject


@SuppressLint("All")
class ComposeActivity : MessagesThemedActivity(), ComposeView {

    companion object {
        private const val SelectContactRequestCode = 0
        private const val TakePhotoRequestCode = 1
        private const val AttachPhotoRequestCode = 2
        private const val AttachAudioRequestCode = 66
        private const val AttachLocationRequestCode = 77
        private const val AttachContactRequestCode = 3
        private const val detailRequestCode = 5
        private const val CameraDestinationKey = "camera_destination"


        var composeActivity: ComposeActivity? = null
    }

    private val binding by viewBinding(ComposeActivityBinding::inflate)
    fun isInitStat() = ::state1.isInitialized

    lateinit var state1: ComposeState
    val isState1Initialized get() = this::state1.isInitialized

    //    private var snackBar: Snackbar? = null
    private var emojiIcon: EmojiIconActions? = null

    @Inject
    lateinit var attachmentAdapter: AttachmentAdapter

    @Inject
    lateinit var chipsAdapter: ChipsAdapter

    @Inject
    lateinit var dateFormatter: DateFormatter

    @Inject
    lateinit var messageAdapter: MessagesAdapter

    @Inject
    lateinit var navigator: Navigator

    @Inject
    lateinit var viewModelFactory: ViewModelProvider.Factory

    private var isScheduleClick: Boolean = false


    override val activityVisibleIntent: Subject<Boolean> = PublishSubject.create()
    override val chipsSelectedIntent: Subject<HashMap<String, String?>> = PublishSubject.create()
    override val chipDeletedIntent: Subject<Recipient> by lazy { chipsAdapter.chipDeleted }
    override val menuReadyIntent: Observable<Unit> = menu.map { }
    override val optionsItemIntent: Subject<Int> = PublishSubject.create()
    override val sendAsGroupIntent by lazy { binding.sendAsGroupBackground.clicks() }
    override val messageClickIntent: Subject<Long> by lazy { messageAdapter.clicks }
    override val messagePartClickIntent: Subject<Long> by lazy { messageAdapter.partClicks }
    override val messagesSelectedIntent by lazy { messageAdapter.selectionChanges }
    override val cancelSendingIntent: Subject<Long> by lazy { messageAdapter.cancelSending }
    override val attachmentDeletedIntent: Subject<Attachment> by lazy { attachmentAdapter.attachmentDeleted }
    override val textChangedIntent by lazy { binding.message.textChanges() }
    override val copyOtpIntent: Subject<String> by lazy { messageAdapter.copyOtp }
    override val removeStarMessageSubject: Subject<Long> by lazy { messageAdapter.removeStarMessageSubject }
    override fun addOrRemoveStarred(): Observable<Long> = removeStarMessageSubject
    override val starMessageSubject: Subject<Long> = PublishSubject.create()
    override fun blockUndo(): Observable<Long> = blockUndoSubject
    override val blockUndoSubject: Subject<Long> = PublishSubject.create()

    override val unBlockUndoSubject: Subject<Long> = PublishSubject.create()
    override fun unBlockUndo(): Observable<Long> = unBlockUndoSubject

    override fun addStarred(): Observable<Long> = starMessageSubject

    override val cameraIntent by lazy {
        Observable.merge(
            binding.layCompose.cameraLayout.clicks(),
            binding.layCompose.cameraLayout.clicks()
        )
    }
    override val galleryIntent by lazy {
        Observable.merge(
            binding.layCompose.galleryLayout.clicks(),
            binding.layCompose.galleryLayout.clicks()
        )
    }
    override val audioIntent by lazy { binding.layCompose.recordingLayout.clicks() }
    override val locationIntent by lazy { binding.layCompose.locationLayout.clicks() }
    override val scheduleIntent by lazy {
        this.isScheduleClick = true
        Observable.merge(
            binding.layCompose.scheduleLayout.clicks(), binding.layCompose.scheduleLayout.clicks()
        )
    }
    override val attachContactIntent by lazy {
        Observable.merge(
            binding.layCompose.contactLayout.clicks(), binding.layCompose.contactLayout.clicks()
        )
    }
    override val attachmentSelectedIntent: Subject<Uri> = PublishSubject.create()
    override val contactSelectedIntent: Subject<Uri> = PublishSubject.create()
    override val inputContentIntent by lazy { binding.message.inputContentSelected }
    override val scheduleSelectedIntent: Subject<Long> = PublishSubject.create()
    override val changeSimIntent by lazy { binding.flSim.clicks() }
    override val scheduleCancelIntent by lazy { binding.scheduledCancel.clicks() }
    override val titleConversationIntent by lazy { binding.llConvClick.clicks() }
    override val sendIntent by lazy {
        binding.send.clicks()
    }
    override val unBlockIntent: Subject<Long> = PublishSubject.create()

    override val viewMessagesPlusIntent: Subject<Unit> = PublishSubject.create()
    override val backPressedIntent: Subject<Unit> = PublishSubject.create()
    private val viewModel by lazy {
        ViewModelProvider(this, viewModelFactory)[ComposeViewModel::class.java]
    }

    private var popupWindow: PopupWindow? = null
    private var llShareMenu: View? = null
    private var llForwardMenu: View? = null
    private var llViewDetailMenu: View? = null
    private var cameraDestination: Uri? = null
    var TAG = "ComposeActivity++++"

    override fun onCreate(savedInstanceState: Bundle?) {
        AndroidInjection.inject(this)
        super.onCreate(savedInstanceState)
        BubbleUtils.BLOCK_BACK = false
        enableEdgeToEdge()
        setContentView(binding.root)
        ViewCompat.setOnApplyWindowInsetsListener(binding.root) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
        setSupportActionBar(binding.toolbar)
        loadIntAds()
        requestedOrientation =
            if (Build.VERSION.SDK_INT == Build.VERSION_CODES.O) ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
            else ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
        showBackButton(true)
        composeActivity = this
        if (intent.hasExtra(ContactsActivity.ChipsKey)) {
            viewModel.shouldShowContacts = false
        }
        viewModel.bindView(this)
        if (intent.hasExtra(ContactsActivity.ChipsKey)) {
            chipsSelectedIntent.onNext(
                intent?.getSerializableExtra(ContactsActivity.ChipsKey)
                    ?.let { serializable -> serializable as? HashMap<String, String?> }
                    ?: hashMapOf())
        }
        messageAdapter.expandList.clear()

        binding.contentView.layoutTransition = LayoutTransition().apply {
            disableTransitionType(LayoutTransition.CHANGING)
        }

        chipsAdapter.view = binding.chips

        binding.chips.itemAnimator = null
        binding.chips.layoutManager = FlexboxLayoutManager(this)

        messageAdapter.autoScrollToStart(binding.messageList)
        messageAdapter.emptyView = binding.messagesEmpty

        binding.messageList.setHasFixedSize(true)
        binding.messageList.setItemViewCacheSize(binding.messageList.size)
        binding.messageList.adapter = messageAdapter
        binding.attachments.adapter = attachmentAdapter
        binding.message.supportsInputContent = true

        window.callback = ComposeWindowCallback(window.callback, this)

        if (Build.VERSION.SDK_INT <= 22) {
            binding.messageBackground.setBackgroundTint(resolveThemeColor(R.attr.bubbleColor))
        }

        var emojiKeyOpen = false
        val emojiKeyHeight = resources.getDimension(R.dimen._250sdp)

        binding.attach.setOnClickListener {
            if (EmojiIconsPopup.emojiIconRecentManager.size == 0) {
                EmojiIconsPopup.emojisPager.currentItem = 1
            } else {
                EmojiIconsPopup.emojisPager.currentItem = 0
            }
            if (binding.layCompose.clBottomMenu.visibility == View.GONE) {
                binding.attach.setImageResource(R.drawable.message_attach_fill)
                val loadAnimation6 =
                    AnimationUtils.loadAnimation(applicationContext, R.anim.slide_in_bottom)
                binding.layCompose.clBottomMenu.animation = loadAnimation6
                binding.layCompose.clBottomMenu.visible()
                binding.message.hideKeyboard()
                binding.rlEmojiView.gone()
                binding.rlEmojiView.translationY = emojiKeyHeight
            } else {
                binding.attach.setImageResource(R.drawable.message_attach)
                binding.layCompose.clBottomMenu.gone()
//                message.showKeyboard()
            }
        }

        initEmojiView()
        binding.rlEmojiView.translationY = emojiKeyHeight
        binding.emoji.setOnClickListener {
            AppUtils.logAdapterMessages(
                EventKeys.message_detail,
                EventKeys.click,
                EventKeys.emoji
            )
            if (EmojiIconsPopup.emojiIconRecentManager.size == 0) {
                EmojiIconsPopup.emojisPager.currentItem = 1
            } else {
                EmojiIconsPopup.emojisPager.currentItem = 0
            }
            if (binding.rlEmojiView.visibility == View.GONE) {
                if (KeyboardVisibilityEvent.isKeyboardVisible(this)) {
                    emojiKeyOpen = true
                    binding.message.hideKeyboard()
                } else {
                    binding.rlEmojiView.visibility = View.VISIBLE
                    binding.rlEmojiView.animate()
                        .translationY(0f)
                        .setDuration(300)
                        .setListener(null)
                    binding.layCompose.clBottomMenu.gone()
                    binding.attach.setImageResource(R.drawable.message_attach)
                }
            } else {
                binding.rlEmojiView.gone()
                binding.message.showKeyboard()
            }
            setEventListener(
                this,
                KeyboardVisibilityEventListener {
                    if (emojiKeyOpen && !it) {
                        Thread.sleep(300)
                        emojiKeyOpen = false
                        binding.rlEmojiView.visibility = View.VISIBLE
                        binding.rlEmojiView.animate()
                            .translationY(0f)
                            .setDuration(300)
                            .setListener(null)
                        binding.layCompose.clBottomMenu.gone()
                        binding.attach.setImageResource(R.drawable.message_attach)
                    } else {
                        binding.rlEmojiView.translationY = emojiKeyHeight
                    }
                })
        }


        binding.message.setOnClickListener {
            binding.rlEmojiView.gone()
            binding.layCompose.clBottomMenu.gone()
            binding.rlEmojiView.translationY = emojiKeyHeight
        }

        binding.btnUnblock.setOnClickListener {
            AppUtils.logAdapterMessages(
                EventKeys.message_detail,
                EventKeys.click,
                EventKeys.unblock
            )
            unBlockIntent.onNext(state1.threadId)
        }

        binding.cvUnblockAlert.gone()
        checkBlockedStatus()

        val filters: Array<InputFilter?> = arrayOfNulls(1)
        filters[0] = InputFilter.LengthFilter(3000)
        binding.message.filters = filters


        binding.messageList.addOnScrollListener(object : RecyclerView.OnScrollListener() {
            override fun onScrolled(recyclerView: RecyclerView, dx: Int, dy: Int) {
                super.onScrolled(recyclerView, dx, dy)
                try {
                    if (isState1Initialized && state1.scrollToPosition!! > 0)
                        viewModel.newState {
                            copy(
                                scrollToPosition = -1
                            )
                        }
                    if (isKeyboardOpen(binding.message)) {
                        binding.ivScrollDown.gone()
                    }
                    val firstVisibleItem =
                        (binding.messageList.layoutManager as LinearLayoutManager).findLastVisibleItemPosition()
                    if (firstVisibleItem == (messageAdapter.itemCount - 1)) {
                        binding.ivScrollDown.gone()
                    } else {
                        binding.ivScrollDown.visible()
                    }
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }

            override fun onScrollStateChanged(recyclerView: RecyclerView, newState: Int) {
                super.onScrollStateChanged(recyclerView, newState)
                if (newState == RecyclerView.SCROLL_STATE_DRAGGING) {
                    binding.message.hideKeyboard()
                } else if (newState == RecyclerView.SCROLL_STATE_IDLE) { // No scrolling
                    Handler(Looper.getMainLooper()).postDelayed(
                        { binding.ivScrollDown.gone() },
                        2000
                    )
                }
            }
        })


        binding.ivScrollDown.setOnClickListener {
            AppUtils.logAdapterMessages(
                EventKeys.message_detail,
                EventKeys.click,
                EventKeys.scroll_to_down
            )
            binding.message.hideKeyboard()
            binding.messageList.scrollToPosition(messageAdapter.itemCount - 1)
        }

//        if (messageAdapter.itemCount > 0) {
        loadBannerAd()
//        }
    }

    private fun initEmojiView() {
        val ic: InputConnection = binding.message.onCreateInputConnection(EditorInfo())
        emojiIcon =
            EmojiIconActions(
                this@ComposeActivity,
                binding.rlEmojiView,
                ic
            )
        emojiIcon!!.ShowEmojiIcon()
        emojiIcon!!.setUseSystemEmoji(true)
        try {
            binding.rlEmojiView.addView(emojiIcon!!.GetViews())
        } catch (e: Exception) {
            e.printStackTrace()
        }
        val clearEmoji =
            emojiIcon!!.GetViews().findViewById<MaterialRippleLayout>(R.id.emojis_backspace)


        clearEmoji.setOnTouchListener(
            EmojiIconsPopup.RepeatListener(
                400, 100
            ) {
                try {
                    val c: Char = ic.getTextBeforeCursor(1, 0)!![0]
                    if (Character.isLetter(c)) {
                    } else if (Character.isISOControl(c)) {
                    } else if (Character.isDigit(c)) {
                    } else if (Character.isHighSurrogate(c)) {
                    } else if (Character.isDefined(c)) {
                        if (Character.isHighSurrogate(
                                ic.getTextBeforeCursor(2, 0)!![0]
                            )
                        ) {
                            ic.deleteSurroundingText(2, 0)
                        }
                    }
                    ic.deleteSurroundingText(1, 0)
                } catch (ex: java.lang.Exception) {
                    ex.printStackTrace()
                }

            })
    }


    var mAdView: AdView? = null
    private fun loadBannerAd() {
        if (!BaseConfig(this@ComposeActivity).ads_free && isOnline
        ) {
//            if (!BannerAds.isRequestSend) {
//            BannerAds.loadAdmobBannerAds(
//                this@ComposeActivity,
//                binding.admobBanner, getString(R.string.banner_conversation)
//            )
//            }
            val bannerAdId =
                if (appPrefs.isFirstTime) getString(R.string.banner_compose)
                else getString(R.string.banner_compose2)
            BannerAdHelper.showBanner(
                this@ComposeActivity,
                binding.admobBanner,
                binding.admobBanner,
                bannerAdId,
                AdCache.composeAdView,
                { isLoaded, adView, message ->
                    mAdView = adView
                    AdCache.composeAdView = adView
                })
        } else {
            binding.admobBanner.gone()
        }
    }

    private fun loadIntAds() {
        val adId =
            if (appPrefs.isFirstTime) getString(R.string.inter_backpress)
            else getString(R.string.inter_backpress2)
        if (AdsParameters(this).isNeedInterAd && Config.checkInterAd()) {
            AdmobIntersAdImpl().load(this, adId)
        }
    }

    override fun onStart() {
        super.onStart()
        activityVisibleIntent.onNext(true)
    }

    override fun onPause() {
        super.onPause()
        activityVisibleIntent.onNext(false)
    }

    override fun render(state: ComposeState) {
        state1 = state

        if (state.hasError) {
            finish()
            return
        }
        threadId.onNext(state.threadId)
        title = when {
            state.selectedMessages > 0 -> {
                getString(
                    R.string.compose_title_selected, state.selectedMessages
                )
            }

            state.query.isNotEmpty() -> state.query
            else -> state.conversationTitle
        }

        binding.tvDescription.text =
            getString(R.string.to_move_this_conversation_out_of_blocking, title)

        if (state.selectedMessages > 0) {
            binding.toolbarTitle.setTextColor(
                ContextCompat.getColor(
                    this@ComposeActivity, R.color.color_app_theme
                )
            )
            binding.toolbar.setNavigationIcon(R.drawable.ic_close)
            binding.llConvClick.background = null
            binding.toolbar.menu.findItem(R.id.menuMenu)?.isVisible = true
        } else {
            state.conversationTitle
            binding.toolbarTitle.setTextColor(
                ContextCompat.getColor(
                    this@ComposeActivity,
                    R.color.black_color
                )
            )
            binding.toolbar.setNavigationIcon(R.drawable.ic_default_back)
            binding.llConvClick.apply {
                background = with(TypedValue()) {
                    context.theme.resolveAttribute(
                        R.attr.selectableItemBackground, this, true
                    )
                    ContextCompat.getDrawable(context, resourceId)
                }
            }

            binding.toolbar.menu.findItem(R.id.menuMenu)?.isVisible = false
        }


        binding.toolbarSubtitle.setVisible(state.query.isNotEmpty())
        binding.toolbarSubtitle.text = getString(
            R.string.compose_subtitle_results, state.searchSelectionPosition, state.searchResults
        )
        binding.toolbarTitle.setVisible(!state.editingMode)


        // Short code reply view visible/invisible
        state.messages?.first?.recipients?.forEach { it ->
            val s = it.address
            val ss = s.substring(0, 2)
            if (isLetters(ss)) {
                if (!(binding.snackBar.isVisible)) {
//                    binding.composeBar.visibility = View.INVISIBLE
                    binding.composeBar.beGone()
                    val layoutParams =
                        binding.ivScrollDown.layoutParams as ViewGroup.MarginLayoutParams
                    val bottomMargin = 5.dpToPx(this)
                    layoutParams.setMargins(0, 0, 0, bottomMargin)
                    binding.ivScrollDown.requestLayout()

                    val marginLayoutParams =
                        binding.messageList.layoutParams as ViewGroup.MarginLayoutParams
                    marginLayoutParams.setMargins(0, 0, 0, bottomMargin)
                    binding.messageList.layoutParams = marginLayoutParams
                    shortCodeReplyPreventView()
                }
            } else {
                binding.composeBar.setVisible(!state.loading)
            }
        }
        binding.chips.setVisible(state.editingMode)
        // Don't set the adapters unless needed
        if (state.editingMode && binding.chips.adapter == null) binding.chips.adapter = chipsAdapter

        binding.toolbar.menu.findItem(R.id.add)?.isVisible = state.editingMode


        binding.toolbar.menu.findItem(R.id.call)?.isVisible =
            !state.editingMode && state.selectedMessages == 0 && state.query.isEmpty() && binding.composeBar.isVisible

        binding.toolbar.menu.findItem(R.id.info)?.isVisible =
            !state.editingMode && state.selectedMessages == 0 && state.query.isEmpty()
        binding.toolbar.menu.findItem(R.id.star)?.isVisible =
            !state.editingMode && state.selectedMessages == 1


        binding.toolbar.menu.findItem(R.id.copy)?.isVisible =
            !state.editingMode && state.selectedMessages > 0

//        toolbar.menu.findItem(R.id.selectAll)?.isVisible =
//            !state.editingMode && state.selectedMessages > 0


        binding.toolbar.menu.findItem(R.id.star)?.isVisible =
            !messageAdapter.isStarred && !state.editingMode && state.selectedMessages == 1

        binding.toolbar.menu.findItem(R.id.un_star)?.isVisible =
            messageAdapter.isStarred && !state.editingMode && state.selectedMessages == 1


        binding.toolbar.menu.findItem(R.id.delete)?.isVisible =
            !state.editingMode && state.selectedMessages > 0

        binding.toolbar.menu.findItem(R.id.previous)?.isVisible =
            state.selectedMessages == 0 && state.query.isNotEmpty()
        binding.toolbar.menu.findItem(R.id.next)?.isVisible =
            state.selectedMessages == 0 && state.query.isNotEmpty()
        binding.toolbar.menu.findItem(R.id.clear)?.isVisible =
            state.selectedMessages == 0 && state.query.isNotEmpty()

        chipsAdapter.data = state.selectedChips

        binding.loading.setVisible(state.loading)

        binding.sendAsGroup.setVisible(state.editingMode && state.selectedChips.size >= 2)
        binding.sendAsGroupSwitch.isChecked = state.sendAsGroup


//        toolbar.menu.findItem(R.id.selectAll)?.isVisible =
//            messageAdapter.data?.second?.size != state.selectedMessages

//        messageList.setVisible(state.sendAsGroup)
        messageAdapter.data = state.messages
        messageAdapter.highlight = state.searchSelectionId
        messageAdapter.highlightQuery = state.query

        binding.scheduledGroup.isVisible = state.scheduled != 0L
        binding.scheduledTime.text = dateFormatter.getScheduledTimestamp(state.scheduled)

        binding.attachments.setVisible(state.attachments.isNotEmpty())
        attachmentAdapter.data = state.attachments
        binding.attaching.isVisible = state.attaching
        binding.counter.text = state.remaining
        binding.counter.setVisible(binding.counter.text.isNotBlank())
        binding.flSim.setVisible(state.subscription != null)
        binding.sim.contentDescription =
            getString(R.string.compose_sim_cd, state.subscription?.displayName)
        binding.simIndex.text = "${state.subscription?.simSlotIndex?.plus(1)}"
        binding.send.isEnabled = state.canSend
        binding.send.imageAlpha = if (state.canSend) 255 else 128

        if (isState1Initialized && state1.scrollToPosition!! > 0) {
            scrollToMessage(state1.scrollToPosition!!)
        }

        checkBlockedStatus()
        // These theme attributes don't apply themselves on API 21

        if (binding.ivScrollDown.isVisible) {
            try {
                val firstVisibleItem =
                    (binding.messageList.layoutManager as LinearLayoutManager).findLastVisibleItemPosition()
                if (firstVisibleItem == (messageAdapter.itemCount - 1)) {
                    binding.ivScrollDown.gone()
                } else {
                    binding.ivScrollDown.visible()
                }
            } catch (_: Exception) {

            }
        }
    }


    private fun isLetters(string: String): Boolean {
        return string.filter { it in 'A'..'Z' || it in 'a'..'z' }.length == string.length
    }

    fun isEdgeToEdgeEnabled(): Int {
        val resourceId: Int =
            resources.getIdentifier("config_navBarInteractionMode", "integer", "android")
        return if (resourceId > 0) {
            resources.getInteger(resourceId)
        } else 0
    }

    private fun shortCodeReplyPreventView() {

        binding.tvLearnMore.setOnClickListener {
            shortCodeReplyLearnMore()
            //binding.snackBar.beGone()
        }
//        snackBarLayout.addView(customSnackView, 0)
        binding.snackBar.beVisible()

    }

    private fun shortCodeReplyLearnMore() {
        CommonDialog(this).show(
            this,
            resources.getString(R.string.cannot_reply_short_code_title),
            resources.getString(R.string.cannot_reply_short_code_message) + "\n\n" + resources.getString(
                R.string.cannot_reply_short_code_message1
            ),
            resources.getString(R.string.ok),
            "",
            "",
            onPositive = {

            },
            cancelable = false
        )
    }


    override fun onResume() {
        super.onResume()
        checkBlockedStatus()
    }

    private fun checkBlockedStatus() {
        if (isInitStat() && state1.threadId != 0L) {
            binding.send.isEnabled = state1.canSend
            binding.cvUnblockAlert.gone()

            val convesations = conversationRepo.getConversation(state1.threadId)
            if (convesations != null && convesations.blocked) {
                binding.cvUnblockAlert.visible()
            } else {
                binding.cvUnblockAlert.gone()
            }
        } else {
            binding.cvUnblockAlert.gone()
        }
    }

    override fun clearSelection() = messageAdapter.clearSelection()

    override fun showDetails(details: String) {
        CommonDialog(this).show(
            this,
            getString(R.string.compose_details_title),
            details,
            getString(R.string.ok),
            "",
            ""
        )
    }

    override fun requestDefaultSms() {
        navigator.showDefaultSmsDialog(this@ComposeActivity)
    }

    override fun requestStoragePermission(reqFor: Int) {
        ActivityCompat.requestPermissions(
            this,
            arrayOf(
                Manifest.permission.READ_EXTERNAL_STORAGE,
                Manifest.permission.WRITE_EXTERNAL_STORAGE
            ),
            reqFor
        )
    }

    override fun requestSmsPermission() {
        ActivityCompat.requestPermissions(
            this, arrayOf(
                Manifest.permission.READ_SMS, Manifest.permission.SEND_SMS
            ), 0
        )
    }

    //    override fun requestDatePicker() {
//        val intent = Intent(this@ComposeActivity, DateRangePickerDialogActivity::class.java)
//        intent.putExtra("fromCompose", true)
//        resultLauncher.launch(intent)
//        binding.message.hideKeyboard()
//    }
    override fun requestDatePicker() {
        Log.e("requestDatePicker--------------", "requestDatePicker")
        if (!hasScheduleExactAlarmPermission(this)) {
            alarmPermissionDialog()
            return
        }


        val calendar = Calendar.getInstance()

        val datePicker = MaterialStyledDatePickerDialog(
            this, R.style.DateDialogTheme, { _, year, month, day ->
                val picker: MaterialTimePicker =
                    MaterialTimePicker.Builder()
                        .setHour(calendar.get(Calendar.HOUR_OF_DAY))
                        .setTitleText(null)
                        .setTheme(R.style.TimePickerTheme)
                        .setMinute(calendar.get(Calendar.MINUTE))
                        .build()
                picker.addOnCancelListener {
                    finish()
                }
                picker.addOnPositiveButtonClickListener {
                    val pickedHour: Int = picker.hour
                    val pickedMinute: Int = picker.minute
                    calendar.set(Calendar.YEAR, year)
                    calendar.set(Calendar.MONTH, month)
                    calendar.set(Calendar.DAY_OF_MONTH, day)
                    calendar.set(Calendar.HOUR_OF_DAY, pickedHour)
                    calendar.set(Calendar.MINUTE, pickedMinute)
//                    val returnedValue = Intent().apply {
//                        putExtra("dateandtime", calendar.timeInMillis)
//                    }
//                    setResult(Activity.RESULT_OK, returnedValue)
//                    finish()
                    scheduleSelectedIntent.onNext(calendar.timeInMillis)
                    picker.dismiss()
                }

                picker.addOnDismissListener {
                    picker.dismiss()
                }
                picker.show(supportFragmentManager, "frag")

            },
            calendar.get(Calendar.YEAR),
            calendar.get(Calendar.MONTH),
            calendar.get(Calendar.DAY_OF_MONTH)
        )

        datePicker.setOnCancelListener {
//            finish()
            datePicker.dismiss()
        }
        datePicker.show()

//        val calendar = Calendar.getInstance()
//        DatePickerDialog(
//            this, R.style.Theme_MaterialComponents_Light_Dialog,
//            DatePickerDialog.OnDateSetListener { _, year, month, day ->
//                TimePickerDialog(
//                    this, R.style.Theme_MaterialComponents_Light_Dialog,
//                    TimePickerDialog.OnTimeSetListener { _, hour, minute ->
//                        calendar.set(Calendar.YEAR, year)
//                        calendar.set(Calendar.MONTH, month)
//                        calendar.set(Calendar.DAY_OF_MONTH, day)
//                        calendar.set(Calendar.HOUR_OF_DAY, hour)
//                        calendar.set(Calendar.MINUTE, minute)
//                        scheduleSelectedIntent.onNext(calendar.timeInMillis)
//                    },
//                    calendar.get(Calendar.HOUR_OF_DAY),
//                    calendar.get(Calendar.MINUTE),
//                    DateFormat.is24HourFormat(this)
//                )
//                    .show()
//            },
//            calendar.get(Calendar.YEAR),
//            calendar.get(Calendar.MONTH),
//            calendar.get(Calendar.DAY_OF_MONTH)
//        ).show()
    }

    private fun alarmPermissionDialog() {
        val alarmPermissionBottomSheetDialog = AlarmPermissionBottomSheetDialog(this)
        alarmPermissionBottomSheetDialog.show()
        alarmPermissionBottomSheetDialog.btnClickListener = { action ->
            if (action == 0) {
                AdsConfig.isSystemDialogOpen = true
                requestScheduleExactAlarmPermission()
            }

        }

    }

    fun hasScheduleExactAlarmPermission(context: Context): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            alarmManager.canScheduleExactAlarms()
        } else {
            true
        }
    }

    fun requestScheduleExactAlarmPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val intent = Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM).apply {
                data = Uri.parse("package:$packageName")
            }
            scheduleExactAlarmLauncher.launch(intent)
        }
    }

    private val scheduleExactAlarmLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) {
        if (hasScheduleExactAlarmPermission(this)) {
            requestDatePicker()
        }
    }


    private var resultLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == Activity.RESULT_OK) {
                // There are no request codes
                val data: Intent? = result.data
                val s = data?.getLongExtra("dateandtime", 0)
                scheduleSelectedIntent.onNext(s!!)
            }
        }

    override fun requestContact() {
        val intent =
            Intent(Intent.ACTION_PICK).setType(ContactsContract.CommonDataKinds.Phone.CONTENT_TYPE)
        startActivityForResult(Intent.createChooser(intent, null), AttachContactRequestCode)
    }

    override fun showContacts(sharing: Boolean, chips: List<Recipient>) {
        ShowContactList(sharing, chips)
    }

    private fun ShowContactList(sharing: Boolean, chips: List<Recipient>) {
        binding.message.hideKeyboard()
        val serialized =
            HashMap(chips.associate { chip -> chip.address to chip.contact?.lookupKey })
        val intent = Intent(this, ContactsActivity::class.java).putExtra(
            ContactsActivity.SharingKey, sharing
        ).putExtra(ContactsActivity.ChipsKey, serialized)
        startActivityForResult(intent, SelectContactRequestCode)
    }

    override fun themeChanged() {
        binding.messageList.scrapViews()
    }

    override fun showKeyboard() {
        binding.message.postDelayed({
            binding.message.showKeyboard()
        }, 200)
    }

    override fun requestCamera() {
        LogW("ComposeActivity++++", "requestCamera : ")
        cameraDestination = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())
            .let { timestamp ->
                ContentValues().apply {
                    put(
                        MediaStore.Images.Media.TITLE, timestamp
                    )
                }
            }.let { cv -> contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cv) }

        val intent = Intent(MediaStore.ACTION_IMAGE_CAPTURE).putExtra(
            MediaStore.EXTRA_OUTPUT, cameraDestination
        )
        startActivityForResult(Intent.createChooser(intent, null), TakePhotoRequestCode)
    }

    override fun requestRecordAudio() {
        val intent = Intent(MediaStore.Audio.Media.RECORD_SOUND_ACTION)
        startActivityForResult(Intent.createChooser(intent, null), AttachAudioRequestCode)
    }

    private lateinit var fusedLocationClient: FusedLocationProviderClient
    override fun requestLocationString() {
        checkForLocationPermission(this, object : BasePermissionListener() {

            override fun onPermissionDenied(response: PermissionDeniedResponse?) {
//                isLocationPermissionGranted = false
                initLocation()
            }

            override fun onPermissionGranted(response: PermissionGrantedResponse?) {
//                isLocationPermissionGranted = true
                initLocation()
            }
        })
//        val intent = Intent(MediaStore.Audio.Media.RECORD_SOUND_ACTION)
//        startActivityForResult(Intent.createChooser(intent, null), AttachLocationRequestCode)
    }

    private fun checkForLocationPermission(activity: Activity, listener: BasePermissionListener?) {

        val dialogPermissionListener = DialogOnDeniedPermissionListener.Builder
            .withContext(activity)
            .withTitle("Location Permission")
            .withMessage("We only need your location to help you find relevant nearby places.")
            .withButtonText(android.R.string.ok)
//            .withIcon(R.drawable.ic_map_marker_radius_black_24dp)
            .build()

        val compositeListener =
            if (listener != null) {
                CompositePermissionListener(dialogPermissionListener, listener)
            } else {
                CompositePermissionListener(dialogPermissionListener)
            }

        Dexter.withContext(activity)
            .withPermission(Manifest.permission.ACCESS_FINE_LOCATION)
            .withListener(compositeListener)
            .check()
    }

    private fun initLocation() {
        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this@ComposeActivity)

        try {
            fusedLocationClient.lastLocation.addOnSuccessListener { location ->
                if (location != null) {
                    val latitude = location.latitude
                    val longitude = location.longitude
                    Log.w(
                        "msg",
                        "getLastKnownLocation: latitude: $latitude and longitude: $longitude"
                    )
                    // Do something with the latitude and longitude (e.g., show on map, send to server)
//                    val location = getLocationFromLatLng(LatLng(latitude, longitude))
                    val location = getLocationFromLatLng(latitude, longitude)
                    location?.let {
                        // Handle the location data here (e.g., display the address, place name, etc.)
                        val address = it.getAddressLine(0)
                        val city = it.locality
                        val country = it.countryName
                        Log.w(
                            "msg",
                            "getLastKnownLocation: address: $address and city: $city and country: $country"
                        )

                        var msg = binding.message.text.toString()
                        msg += address
                        msg += "\nhttps://maps.google.com/?q=$latitude,$longitude"

                        binding.message.setText(msg)

                    }
                } else {
                    Toast.makeText(this@ComposeActivity, "error_location", Toast.LENGTH_SHORT)
                        .show()
                    // Location is null, handle accordingly (e.g., show an error message, request location updates)
                }
            }.addOnFailureListener { exception ->
                // Handle failure, such as if the location services are disabled or the device doesn't have the necessary features
                Log.w("msg", "getLastKnownLocation: exception" + exception.message)
            }
        } catch (e: SecurityException) {
            // Handle exception (e.g., show a message to the user that location access is not granted)
            e.printStackTrace()
        }
    }

    //    private fun getLocationFromLatLng(latLng: LatLng): Address? {
    private fun getLocationFromLatLng(latitude: Double, longitude: Double): Address? {
        val geocoder = Geocoder(this, Locale.getDefault())
        val addresses: List<Address> = geocoder.getFromLocation(latitude, longitude, 1)!!
        return if (addresses.isNotEmpty()) addresses[0] else null
    }

    override fun requestGallery() {
        LogW(TAG, "requestGallery : ")
        val intent = Intent(Intent.ACTION_PICK).putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
            .addFlags(Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
            .putExtra(Intent.EXTRA_LOCAL_ONLY, false)
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION).setType("image/*")
        startActivityForResult(Intent.createChooser(intent, null), AttachPhotoRequestCode)
    }

    override fun setDraft(draft: String) {
        binding.message.setText(draft)
        binding.message.setSelection(draft.length)
    }

    override fun scrollToMessage(id: Long) {

        messageAdapter.data?.second?.indexOfLast { message -> message.id == id }
            ?.takeIf { position -> position != -1 }?.let(binding.messageList::scrollToPosition)
    }

    override fun showmessagesPlusSnackbar(message: Int) {
        Snackbar.make(binding.contentView, message, Snackbar.LENGTH_LONG).run {
            setAction(R.string.button_more) { viewMessagesPlusIntent.onNext(Unit) }
            setActionTextColor(
                ContextCompat.getColor(
                    this@ComposeActivity,
                    R.color.color_app_theme
                )
            )
            show()
        }
//        if (snackBar?.isShown ?: false) {
//            snackBar?.dismiss()
//        }
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.compose, menu)
        createMenuPopupWindow()
        LogW("ComposeActivity++++", "message onCreateOptionsMenu")

        if (menu is MenuBuilder) {
            menu.setOptionalIconsVisible(true)
        }
        val itemInfo = menu!!.findItem(R.id.info)
        val itemCall = menu.findItem(R.id.call)
        val itemAddTxt = menu.findItem(R.id.add)
        val itemPreviousTxt = menu.findItem(R.id.previous)
        val itemNextTxt = menu.findItem(R.id.next)
        val itemClearTxt = menu.findItem(R.id.clear)
        val iconInfo = itemInfo.icon
        val iconCall = itemCall.icon
        val itemAdd = itemAddTxt.icon
        val itemPrevious = itemPreviousTxt.icon
        val itemNext = itemNextTxt.icon
        val itemClear = itemClearTxt.icon

        LogW(TAG, "message onCreateOptionsMenu icon theme" + prefs.nightMode.get())
        iconInfo?.setColorFilter(resources.getColor(R.color.black_color), PorterDuff.Mode.SRC_IN)
        iconCall?.setColorFilter(resources.getColor(R.color.black_color), PorterDuff.Mode.SRC_IN)
        itemAdd?.setColorFilter(resources.getColor(R.color.black_color), PorterDuff.Mode.SRC_IN)
        itemPrevious?.setColorFilter(
            resources.getColor(R.color.black_color), PorterDuff.Mode.SRC_IN
        )
        itemNext?.setColorFilter(resources.getColor(R.color.black_color), PorterDuff.Mode.SRC_IN)
        itemClear?.setColorFilter(
            resources.getColor(R.color.black_color), PorterDuff.Mode.SRC_IN
        )

        return true
    }

    private fun createMenuPopupWindow() {
        val layoutInflater = getSystemService(Context.LAYOUT_INFLATER_SERVICE) as LayoutInflater
        val popupView: View = layoutInflater.inflate(R.layout.compose_page_menu, null)
        popupWindow = PopupWindow(
            popupView,
            ViewGroup.LayoutParams.WRAP_CONTENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        )
        popupWindow!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        popupWindow!!.isFocusable = true
        popupWindow!!.isOutsideTouchable = true

        llShareMenu = popupView.findViewById(R.id.menu_share)
        llForwardMenu = popupView.findViewById(R.id.menu_forward)
        llViewDetailMenu = popupView.findViewById(R.id.menu_view_details)

        llShareMenu?.setOnClickListener {
            optionsItemIntent.onNext(llShareMenu?.id!!)
            popupWindow!!.dismiss()
        }
        llForwardMenu?.setOnClickListener {
            optionsItemIntent.onNext(llForwardMenu?.id!!)
            popupWindow!!.dismiss()
        }
        llViewDetailMenu?.setOnClickListener {
            optionsItemIntent.onNext(llViewDetailMenu?.id!!)
            popupWindow!!.dismiss()
        }


    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        LogE("msg", "onOptionsItemSelected: " + item.itemId)
        when (item.itemId) {
            R.id.menuMenu -> {
                try {
                    val menuItemView: View = findViewById(R.id.menuMenu)
                    val anchorRect: Rect = locateViewRect(menuItemView)
                    val x: Int = (anchorRect.left)
                    val y: Int = anchorRect.top + 5
                    popupWindow!!.showAtLocation(menuItemView, Gravity.TOP, x, y)
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }

            R.id.call -> {
                optionsItemIntent.onNext(item.itemId)
            }

            R.id.info -> {
                optionsItemIntent.onNext(item.itemId)
            }

            R.id.star -> {
                optionsItemIntent.onNext(item.itemId)
            }

            R.id.un_star -> {
                optionsItemIntent.onNext(item.itemId)
            }
//            R.id.selectAll -> {
//                messageAdapter.selectAll()
//            }
            else -> optionsItemIntent.onNext(item.itemId)
        }
        return true
    }

    private fun locateViewRect(v: View): Rect {
        val locInt = IntArray(2)
        v.getLocationOnScreen(locInt)
        val location = Rect()
        location.left = locInt[0]
        location.top = locInt[1]
        location.right = location.left + v.width
        return location
    }

    override fun getColoredMenuItems(): List<Int> {
        return super.getColoredMenuItems() + R.id.call
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        when {
            requestCode == SelectContactRequestCode -> {
                chipsSelectedIntent.onNext(
                    data?.getSerializableExtra(ContactsActivity.ChipsKey)
                        ?.let { serializable -> serializable as? HashMap<String, String?> }
                        ?: hashMapOf())
                if (intent != null) {
                    val checkData = data?.getSerializableExtra(ContactsActivity.ChipsKey)
                        ?.let { serializable -> serializable as? HashMap<String, String?> }
                        ?: hashMapOf()
                    if (checkData.isNotEmpty()) {
                        isScheduleClick = intent.getBooleanExtra("isScheduleClicked", false)

                        if (isScheduleClick) requestDatePicker()

                        intent.putExtra("isScheduleClicked", false)
                    }
                }
            }

            requestCode == TakePhotoRequestCode && resultCode == Activity.RESULT_OK -> {
                LogW(
                    TAG, "requestCamera onActivityResult : $TakePhotoRequestCode"
                )
                cameraDestination?.let(attachmentSelectedIntent::onNext)
            }

            requestCode == AttachAudioRequestCode && resultCode == Activity.RESULT_OK -> {
                try {
                    val newUri = data?.data
                    newUri?.let(attachmentSelectedIntent::onNext)
                } catch (e: java.lang.Exception) {
                    e.printStackTrace()
//                    toast("Audio is corrupted or audio format not supported.")
                }
                LogW(TAG, "AttachAudioRequestCode :$AttachAudioRequestCode")
//                data?.clipData?.itemCount?.let { count -> 0 until count }
//                    ?.mapNotNull { i -> data.clipData?.getItemAt(i)?.uri }
//                    ?.forEach(attachmentSelectedIntent::onNext) ?: data?.data?.let(
//                    attachmentSelectedIntent::onNext
//                )
            }

            requestCode == AttachPhotoRequestCode && resultCode == Activity.RESULT_OK -> {
                LogW(TAG, "AttachPhotoRequestCode :$AttachPhotoRequestCode")
                data?.clipData?.itemCount?.let { count -> 0 until count }

                    ?.mapNotNull { i -> data.clipData?.getItemAt(i)?.uri }
                    ?.forEach(attachmentSelectedIntent::onNext) ?: data?.data?.let(
                    attachmentSelectedIntent::onNext
                )
            }

            requestCode == AttachContactRequestCode && resultCode == Activity.RESULT_OK -> {
                val contactData: Uri? = data?.data
                val c: Cursor = managedQuery(contactData, null, null, null, null)
                if (c.moveToFirst()) {
                    val text = binding.message.text.toString()
                    try {
                        val cNumber: String =
                            c.getString(c.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER))
                        LogW("ComposeActivity+++", "Msg_cNumber_= $cNumber")
                        val name: String =
                            c.getString(c.getColumnIndex(ContactsContract.Contacts.DISPLAY_NAME))
                        LogW("ComposeActivity+++", "Msg_name= $name")
                        binding.message.setText("$text \n[Name:] $name\n[Number:] $cNumber")
                        binding.message.setSelection(binding.message.text.length)
                    } catch (e: Exception) {
                        binding.message.setText("$text \n[Name:] \n[Number:] ")
                        binding.message.setSelection(text.length)
                    }
                }
            }

            requestCode == detailRequestCode && resultCode == Activity.RESULT_OK && binding.composeBar.isVisible -> {
                val title = data?.getStringExtra("title") ?: title.toString()
                if (title.isNotEmpty())
                    viewModel.newState { copy(conversationTitle = title) }
                if (ConversationInfoActivity.isMessageClicked) {
                    ConversationInfoActivity.isMessageClicked = false
                    showKeyboard()
                }
                /*if(data?.hasExtra(ContactsActivity.ChipsKey)?:false){
                    chipsSelectedIntent.onNext(data?.getSerializableExtra(ContactsActivity.ChipsKey)
                        ?.let { serializable -> serializable as? HashMap<String, String?> }
                        ?: hashMapOf())
                }*/
            }

            else -> super.onActivityResult(requestCode, resultCode, data)
        }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        outState.putParcelable(CameraDestinationKey, cameraDestination)
        super.onSaveInstanceState(outState)
    }

    override fun onRestoreInstanceState(savedInstanceState: Bundle) {
        cameraDestination = savedInstanceState.getParcelable(CameraDestinationKey)
        super.onRestoreInstanceState(savedInstanceState)
    }

    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<out String>, grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (ContextCompat.checkSelfPermission(
                this,
                android.Manifest.permission.READ_EXTERNAL_STORAGE
            ) == PackageManager.PERMISSION_GRANTED
        )
            when (requestCode) {
                0 -> {//camera
                    binding.layCompose.cameraLayout.performClick()
                }

                1 -> {//galllery
                    binding.layCompose.galleryLayout.performClick()
                }
            }
        else showDialog()

    }

    private fun showDialog() {
        CommonDialog(this@ComposeActivity).show(
            this@ComposeActivity,
            resources.getString(R.string.permission_dialog_title),
            resources.getString(R.string.permission_dialog_description1),
            resources.getString(R.string.ok),
            resources.getString(R.string.button_cancel),
            "", onPositive = {
                val i = Intent()
                i.action = Settings.ACTION_APPLICATION_DETAILS_SETTINGS
                i.addCategory(Intent.CATEGORY_DEFAULT)
                i.data = Uri.parse("package:$packageName")
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                i.addFlags(Intent.FLAG_ACTIVITY_NO_HISTORY)
                i.addFlags(Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS)
                startActivity(i)
            }, cancelable = false
        )
    }

    override fun showUnStarredSnackBar() {
        Snackbar.make(binding.contentView, getString(R.string.star_removed), Snackbar.LENGTH_LONG)
            .apply {
                setAction(getString(R.string.undo)) { starMessageSubject.onNext(messageAdapter.messageIdForUndoUnStar) }
                setActionTextColor(
                    ContextCompat.getColor(
                        this@ComposeActivity,
                        R.color.color_app_theme
                    )
                )
                show()
            }
//        if (snackBar?.isShown ?: false) {
//            snackBar?.dismiss()
//        }
    }

    override fun showBlockedSnackBar() {
        unBlockViewShow()
        Snackbar.make(
            binding.contentView,
            getString(R.string.blocked_messages_title),
            Snackbar.LENGTH_LONG
        )
            .apply {
                setAction(getString(R.string.undo)) {
                    blockUndoSubject.onNext(state1.threadId)
                }
                setActionTextColor(
                    ContextCompat.getColor(
                        this@ComposeActivity,
                        R.color.color_app_theme
                    )
                )
                show()
            }
//        if (snackBar?.isShown ?: false) {
//            snackBar?.dismiss()
//        }
    }

    override fun showUnBlockedSnackBar() {
        unBlockViewHide()
        Snackbar.make(
            binding.contentView,
            getString(R.string.unblocked_messages_title),
            Snackbar.LENGTH_LONG
        )
            .apply {
                setAction(getString(R.string.undo)) {
                    unBlockUndoSubject.onNext(state1.threadId)
                }
                setActionTextColor(
                    ContextCompat.getColor(
                        this@ComposeActivity,
                        R.color.color_app_theme
                    )
                )
                show()
            }
//        if (snackBar?.isShown ?: false) {
//            snackBar?.dismiss()
//        }
    }

    override fun unBlockViewShow() {
        binding.cvUnblockAlert.visible()
    }

    override fun unBlockViewHide() {
        binding.cvUnblockAlert.gone()
    }

    override fun onBackPressed() {
        if (messageAdapter.selection.isNotEmpty()) {
            clearSelection()
        } else {
            if (!BaseConfig(this@ComposeActivity).ads_free) {
                if (binding.rlEmojiView.isVisible) {
                    binding.rlEmojiView.gone()
                } else if (binding.layCompose.clBottomMenu.isVisible) {
                    binding.layCompose.clBottomMenu.gone()
                } else {
                    if (Config.checkInterAd()) {
                        AdsConfig.showInterstitialAd(this) {
                            binding.cvUnblockAlert.gone()
                            finish()
                        }
                    } else {
                        binding.cvUnblockAlert.gone()
                        finish()
                    }
                }
            } else {
                if (binding.rlEmojiView.isVisible) {
                    binding.rlEmojiView.gone()
                } else if (binding.layCompose.clBottomMenu.isVisible) {
                    binding.layCompose.clBottomMenu.gone()
                } else {
                    if (Config.checkInterAd()) {
                        AdsConfig.showInterstitialAd(this) {
                            binding.cvUnblockAlert.gone()
                            finish()
                        }
                    } else {
                        binding.cvUnblockAlert.gone()
                        finish()
                    }
                }
            }
        }
    }

    override fun showConversationInfo(threadId: Long) {
        AppUtils.logAdapterMessages(
            EventKeys.message_detail,
            EventKeys.click,
            EventKeys.details
        )
        val intent = Intent(this, ConversationInfoActivity::class.java)
        intent.putExtra("threadId", threadId)
        startActivityForResult(intent, detailRequestCode)
    }
}
