package com.messenger.sms.text.feature.main

import android.content.Context
import android.os.Handler
import android.os.Looper
import androidx.lifecycle.Lifecycle
import com.adconfig.AdsConfig
import com.uber.autodispose.android.lifecycle.scope
import com.uber.autodispose.autoDisposable
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.functions.Consumer
import io.reactivex.rxkotlin.plusAssign
import io.reactivex.subjects.BehaviorSubject
import io.reactivex.subjects.Subject
import com.messenger.sms.text.R
import com.messenger.sms.text.common.Navigator
import com.messenger.sms.text.common.base.MessagesViewModel
import com.messenger.sms.text.common.util.AppUtils
import com.common.extensions.makeToast
import com.data.extensions.asObservable
//import com.messenger.sms.text.extensions.mapNotNull
import com.messenger.sms.text.feature.conversationinfo.*
import com.domain.manager.PermissionManager
import com.domain.model.Conversation
import com.domain.repository.ConversationRepository
import com.domain.repository.MessageRepository
import com.messenger.sms.text.common.preferance.AppPreference
import com.messenger.sms.text.common.staticData.EventKeys
import com.messenger.sms.text.common.util.extensions.LogE
import com.messenger.sms.text.common.util.extensions.LogV
import com.messenger.sms.text.common.util.extensions.LogW
import com.domain.extensions.mapNotNull
import com.domain.feature.conversationinfo.ConversationInfoItem
import com.domain.interactor.DeleteConversations
import com.domain.interactor.MarkArchived
import com.domain.interactor.MarkUnarchived
import com.domain.interactor.SyncContacts
import javax.inject.Inject
import javax.inject.Named

class ConversationInfoViewModel @Inject constructor(
    @Named("threadId") threadId: Long,
    messageRepo: MessageRepository,
    private val context: Context,
    val conversationRepo: ConversationRepository,
    private val deleteConversations: DeleteConversations,
    private val markArchived: MarkArchived,
    private val markUnarchived: MarkUnarchived,
    private val navigator: Navigator,
    private val permissionManager: PermissionManager,
    private val syncContacts: SyncContacts,
    private val appPrefs: AppPreference
) : MessagesViewModel<ConversationInfoView, ConversationInfoState>(
    ConversationInfoState(
        threadId = threadId,
        data = conversationRepo.getConversationAsync2(threadId)!!

    )
) {

    val conversation: Subject<Conversation> = BehaviorSubject.create()

    init {
        LogW("messageApp : ", "Message ConversationInfoPresenter Composeelde-  ")
        try {
            disposables += conversation
                .observeOn(AndroidSchedulers.mainThread())
                .map {
                    val conversation = conversationRepo.getConversation(threadId)
                    if (conversation != null) {
                        val parts = messageRepo.getPartsForConversation(threadId)
                        val data2 = mutableListOf<ConversationInfoItem>()

                        data2 += conversation.recipients.map(ConversationInfoItem::ConversationInfoRecipient)

                        data2 += ConversationInfoItem.ConversationInfoSettings(
                            name = conversation.name,
                            recipients = conversation.recipients,
                            archived = conversation.archived,
                            blocked = conversation.blocked
                        )
                        data2 += parts.map(ConversationInfoItem::ConversationInfoMedia)
                        LogV("TAG", "New state................")
                        newState {
                            copy(
                                threadId = conversation.id,
                                data = data2
                            )
                        }
                    }
                    conversation
                }
                .switchMap { conversation -> conversation.asObservable() }
                .distinctUntilChanged().subscribe(
                    conversation::onNext
                ) { t -> LogE("accept: ", t.message.toString()) }

            disposables += conversationRepo.getConversationAsync(threadId)
                .asObservable()
                .filter { conversation -> conversation.isLoaded }
                .doOnNext { conversation ->
                    if (!conversation.isValid) {
                        newState { copy(hasError = true) }
                    }
                }
                .filter { conversation -> conversation.isValid }
                .filter { conversation -> conversation.id != 0L }
                .subscribe(conversation::onNext, object : Consumer<Throwable> {
                    override fun accept(t: Throwable?) {
                        LogE("error: ", "conversationRepo" + t?.message.toString())
                    }
                })

            disposables += markArchived
            disposables += markUnarchived
            disposables += deleteConversations

//            disposables += Observables
//                .combineLatest(
//                    conversationRepo.getConversation(threadId).asObservable(),
//                    messageRepo.getPartsForConversation(threadId).asObservable()
//                ) { conversation, parts ->
//                    val data = mutableListOf<ConversationInfoItem>()
//
//                    // If some data was deleted, this isn't the place to handle it
//                    if (!conversation.isLoaded || !conversation.isValid || !parts.isLoaded || !parts.isValid) {
//                        return@combineLatest
//                    }
//
//                    data += conversation.recipients.map(ConversationInfoItem::ConversationInfoRecipient)
//                    data += ConversationInfoItem.ConversationInfoSettings(
//                        name = conversation.name,
//                        recipients = conversation.recipients,
//                        archived = conversation.archived,
//                        blocked = conversation.blocked
//                    )
//                    data += parts.map(ConversationInfoItem::ConversationInfoMedia)
//
//                    newState { copy(data = data) }
//                }
//                .subscribe()
        } catch (e: Exception) {
            LogW("Exceptions+++", e.message.toString())
        }
    }


    override fun bindView(view: ConversationInfoView) {
        super.bindView(view)
        // Open Dialor
        view.callClicks()
            .mapNotNull(conversationRepo::getRecipient)
            .doOnNext { recipient ->
                AppUtils.logAdapterMessages(
                    EventKeys.message_detail,
                    EventKeys.click,
                    EventKeys.details_call
                )
                recipient.address.let(navigator::makePhoneCall)
            }
            .autoDisposable(view.scope(Lifecycle.Event.ON_DESTROY)) // ... this should be the default
            .subscribe()

        // Add or display the contact
        view.recipientClicks()
            .mapNotNull(conversationRepo::getRecipient)
            .doOnNext { recipient ->
                //added for prevent open ads
                AdsConfig.isSystemDialogOpen=true

                appPrefs.isContactChange=true
                recipient.contact?.lookupKey?.let(navigator::editContact)
                    ?: navigator.addContact(recipient.address)

            }
            .autoDisposable(view.scope(Lifecycle.Event.ON_DESTROY)) // ... this should be the default
            .subscribe()


        // Copy phone number
        view.copyClicks()
            .autoDisposable(view.scope())
            .subscribe({
                AppUtils.logAdapterMessages(
                    EventKeys.message_detail,
                    EventKeys.click,
                    EventKeys.details_phone_no_copy
                )
                AppUtils.copy(context, it)
                context.makeToast(R.string.info_copied_address)
            }
            ) { t -> LogE("error: ", t?.message.toString()) }

        // message click
        view.messageClicks()
            .filter { permissionManager.isDefaultSms().also { if (!it) view.requestDefaultSms() } }
            .doOnNext { recipient ->
                AppUtils.logAdapterMessages(
                    EventKeys.message_detail,
                    EventKeys.click,
                    EventKeys.details_message
                )
                ConversationInfoActivity.isMessageClicked = true
                val data = recipient.split(",")
                try {
                    if (data[1].toBoolean()) {
                        view.messageToThisNumber(data[0], true)
                    } else {
                        view.messageToThisNumber("", false)
                    }
                } catch (exp: Exception) {
                    view.messageToThisNumber("", false)
                }

            }
            .autoDisposable(view.scope(Lifecycle.Event.ON_DESTROY))
            .subscribe()

        // Copy phone number
        view.recipientLongClicks()
            .mapNotNull(conversationRepo::getRecipient)
            .map { recipient -> recipient.address }
            .observeOn(AndroidSchedulers.mainThread())
            .autoDisposable(view.scope())
            .subscribe { address ->
                AppUtils.copy(context, address)
                context.makeToast(R.string.info_copied_address)
            }


        // Show the conversation title dialog
        view.nameClicks()
            .withLatestFrom(conversation) { _, conversation -> conversation }
            .map { conversation -> conversation.name }
            .autoDisposable(view.scope())
            .subscribe(view::showNameDialog)

        // Set the conversation title
        view.nameChanges()
            .withLatestFrom(conversation) { name, conversation ->
                conversationRepo.setConversationName(conversation.id, name)
            }
            .autoDisposable(view.scope())
            .subscribe()

        // Show the notifications settings for the conversation
        view.notificationClicks()
            .withLatestFrom(conversation) { _, conversation -> conversation }
            .autoDisposable(view.scope())
            .subscribe { conversation ->
                    AppUtils.logAdapterMessages(
                        EventKeys.message_detail,
                        EventKeys.click,
                        EventKeys.details_notifications
                    )
                    navigator.showNotificationSettings(conversation.id, true)
            }

        // Toggle the archived state of the conversation
        view.archiveClicks()
            .withLatestFrom(conversation) { _, conversation -> conversation }
            .autoDisposable(view.scope())
            .subscribe { conversation ->
                when (conversation.archived) {
                    true -> {
                        AppUtils.logAdapterMessages(
                            EventKeys.message_detail,
                            EventKeys.click,
                            EventKeys.details_unarchive
                        )
                        markUnarchived.execute(listOf(conversation.id))
                        gotoHome()
                    }
                    false -> {
                        AppUtils.logAdapterMessages(
                            EventKeys.message_detail,
                            EventKeys.click,
                            EventKeys.details_archive
                        )
                        markArchived.execute(listOf(conversation.id))
                        gotoHome()
                    }
                }
            }

        view.archiveClicks()
            .withLatestFrom(conversation) { _, conversation -> conversation }
            .autoDisposable(view.scope())
            .subscribe { conversation ->
                when (conversation.archived) {
                    true -> markUnarchived.execute(listOf(conversation.id))
                    false -> markArchived.execute(listOf(conversation.id))
                }
            }

        // Toggle the blocked state of the conversation
        view.blockClicks()
            .withLatestFrom(conversation) { _, conversation -> conversation }
            .autoDisposable(view.scope())
            .subscribe({ conversation ->
                view.showBlockingDialog(
                    listOf(conversation.id),
                    !conversation.blocked
                ) {}

            }
            ) { t -> LogE("error: ", t?.message.toString()) }

        // Show the delete confirmation dialog
        view.deleteClicks()
            .filter { permissionManager.isDefaultSms().also { if (!it) view.requestDefaultSms() } }
            .autoDisposable(view.scope())
            .subscribe({

                view.showDeleteDialog()
            }) { t ->
                LogE("error on deleteClicks:", "${t.message}")
            }

        // Delete the conversation
        view.confirmDelete()
            .withLatestFrom(conversation) { _, conversation -> conversation }
            .autoDisposable(view.scope())
            .subscribe({ conversation -> deleteConversations.execute(listOf(conversation.id)) }
            ) { t -> LogE("error->delete: ", t.message.toString()) }

        // Media
        view.mediaClicks()
            .autoDisposable(view.scope())
            .subscribe(navigator::showMedia)
    }

    private fun gotoHome() {
        Handler(Looper.getMainLooper()).postDelayed({
            ConversationInfoActivity.conversationInfoActivity?.showHome()
        }, 500)
    }

    fun syncContacts() {
        syncContacts.execute(Unit)
    }
}