package com.messenger.sms.text.feature.conversationinfo

import android.content.Context
import android.view.ViewGroup
import android.widget.Toast
import androidx.core.content.ContextCompat
import androidx.core.view.isVisible
import androidx.viewbinding.ViewBinding
import com.jakewharton.rxbinding2.view.clicks
import com.messenger.sms.text.utils.gone
import com.messenger.sms.text.utils.visible
import io.reactivex.subjects.PublishSubject
import io.reactivex.subjects.Subject
import com.messenger.sms.text.R
import com.messenger.sms.text.common.base.MessagesAdapter
import com.messenger.sms.text.common.base.MessagesViewHolder
import com.messenger.sms.text.common.util.extensions.setTint
import com.data.extensions.isVideo
import com.messenger.sms.text.feature.conversationinfo.ConversationInfoActivity.Companion.conversationInfoActivity
import com.messenger.sms.text.feature.conversationinfo.ConversationInfoActivity.Companion.strTitle
import com.bumptech.glide.Glide
import com.messenger.sms.text.common.extensions.beGone
import com.messenger.sms.text.common.util.extensions.LogW
import com.messenger.sms.text.databinding.ConversationInfoSettingsBinding
import com.messenger.sms.text.databinding.ConversationMediaListItemBinding
import com.messenger.sms.text.databinding.ConversationRecipientGroupListItemBinding
import com.messenger.sms.text.databinding.ConversationRecipientListItemBinding
import com.messenger.sms.text.utils.isShortCode
import com.domain.feature.conversationinfo.ConversationInfoItem
import javax.inject.Inject

class ConversationInfoAdapter @Inject constructor(
    private val context: Context
) : MessagesAdapter<ConversationInfoItem, ViewBinding>() {

    var isPrivate = false
    private var isGroup: Boolean = false
    val callClicks: Subject<Long> = PublishSubject.create()
    val recipientClicks: Subject<Long> = PublishSubject.create()
    val recipientLongClicks: Subject<Long> = PublishSubject.create()
    val nameClicks: Subject<Unit> = PublishSubject.create()
    val notificationClicks: Subject<Unit> = PublishSubject.create()
    val archiveClicks: Subject<Unit> = PublishSubject.create()
    val blockClicks: Subject<Unit> = PublishSubject.create()
    val copyClicks: Subject<String> = PublishSubject.create()
    val messageClicks: Subject<String> = PublishSubject.create()
    val deleteClicks: Subject<Unit> = PublishSubject.create()
    val mediaClicks: Subject<Long> = PublishSubject.create()

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MessagesViewHolder<ViewBinding> {
        LogW("messageApp : ", "Check onCreateViewHolder---------")

        val holder: MessagesViewHolder<ViewBinding> = when (viewType) {
            0 -> MessagesViewHolder(parent, ConversationRecipientListItemBinding::inflate)
            1 -> MessagesViewHolder(parent, ConversationRecipientGroupListItemBinding::inflate)
            2 -> MessagesViewHolder(parent, ConversationInfoSettingsBinding::inflate)
            3 -> MessagesViewHolder(parent, ConversationMediaListItemBinding::inflate)
            else -> throw IllegalStateException()
        }
        return holder.apply {
            when (binding) {
                is ConversationRecipientGroupListItemBinding -> {
                    itemView.setOnClickListener {
                        val item = getItem(adapterPosition) as? ConversationInfoItem.ConversationInfoRecipient
                        item?.value?.id?.run(recipientClicks::onNext)
                    }

                    itemView.setOnLongClickListener {
                        val item = getItem(adapterPosition) as? ConversationInfoItem.ConversationInfoRecipient
                        item?.value?.id?.run(recipientLongClicks::onNext)
                        true
                    }

//                    binding.theme.setOnClickListener {
//                        val item = getItem(adapterPosition) as? ConversationInfoItem.ConversationInfoRecipient
//                        item?.value?.id?.run(themeClicks::onNext)
//                    }
                }

                is ConversationInfoSettingsBinding -> {
                    if (isPrivate) {
                        binding.archive.beGone()
                        binding.block.beGone()
                    }
                    binding.groupName.clicks().subscribe(nameClicks)
                    binding.notifications.clicks().subscribe(notificationClicks)
                    binding.archive.clicks().subscribe(archiveClicks)
                    binding.block.clicks().subscribe(blockClicks)
                    binding.delete.clicks().subscribe(deleteClicks)
                }

                is ConversationMediaListItemBinding -> {
                    itemView.setOnClickListener {
                        val item = getItem(adapterPosition) as? ConversationInfoItem.ConversationInfoMedia
                        item?.value?.id?.run(mediaClicks::onNext)
                    }
                }
            }
        }

    }

    override fun onBindViewHolder(holder: MessagesViewHolder<ViewBinding>, position: Int) {
        val item = getItem(position)
        if (itemCount > position) {
            when {
                item is ConversationInfoItem.ConversationInfoRecipient && holder.binding is ConversationRecipientGroupListItemBinding -> {
                    val recipient = item.value
                    holder.binding.avatar.setRecipient(recipient)
                    holder.binding.avatar.setMaxTextSize(22)

                    if (isGroup) {
                        if (!recipient.contact?.name.isNullOrEmpty()) {
                            holder.binding.number.visible()
                            holder.binding.name.text = recipient.contact?.name ?: ""
                            holder.binding.number.text = recipient.address
                        } else {
                            holder.binding.number.gone()
                            holder.binding.name.text = recipient.contact?.name ?: recipient.address
                            holder.binding.number.text = ""
                        }
                        strTitle = ""
                        if (getItem(position + 1) is ConversationInfoItem.ConversationInfoRecipient) {
                            holder.binding.divider1.visible()
                        } else {
                            holder.binding.divider1.gone()
                        }
                    } else {
                        holder.binding.name.text = recipient.contact?.name ?: recipient.address
                        strTitle = recipient.contact?.name ?: recipient.address
                    }

                }

                item is ConversationInfoItem.ConversationInfoRecipient && holder.binding is ConversationRecipientListItemBinding -> {
                    val recipient = item.value
                    holder.binding.avatar.setRecipient(recipient)
                    holder.binding.avatar.setMaxTextSize(22)

                    holder.binding.name.text = recipient.contact?.name ?: recipient.address
                    strTitle = recipient.contact?.name ?: recipient.address


                    if (!isGroup) {
                        if (recipient.address.length >= 2 && isShortCode(recipient.address.substring(0, 2))) {

                            val grayDisabled = ContextCompat.getColor(
                                conversationInfoActivity ?: context,
                                R.color.gray_bg_disabled
                            )
                            val btnDisabled = ContextCompat.getColor(
                                conversationInfoActivity ?: context,
                                R.color.btn_disabled
                            )

                            holder.binding.cvCall.isEnabled = false
                            holder.binding.llCAll.setBackgroundColor(grayDisabled)
                            holder.binding.ivCall.setTint(btnDisabled)
                            holder.binding.tvCall.setTextColor(btnDisabled)

                            holder.binding.cvMessage.isEnabled = false
                            holder.binding.llMessage.setBackgroundColor(grayDisabled)
                            holder.binding.ivMessage.setTint(btnDisabled)
                            holder.binding.tvMessage.setTextColor(btnDisabled)

                            holder.binding.cvAddEdit.isEnabled = false
                            holder.binding.llAdd.setBackgroundColor(grayDisabled)
                            holder.binding.ivAdd.setTint(btnDisabled)
                            holder.binding.tvAdd.setTextColor(btnDisabled)

                        } else {
                            val grayEnabled = ContextCompat.getColor(
                                conversationInfoActivity ?: context,
                                R.color.conversation_bg
                            )
                            val btnEnabled = ContextCompat.getColor(
                                conversationInfoActivity ?: context,
                                R.color.btn_copy_bg
                            )


                            holder.binding.cvCall.isEnabled = true
                            holder.binding.llCAll.setBackgroundColor(grayEnabled)
                            holder.binding.ivCall.setTint(btnEnabled)
                            holder.binding.tvCall.setTextColor(btnEnabled)

                            holder.binding.cvMessage.isEnabled = true
                            holder.binding.llMessage.setBackgroundColor(grayEnabled)
                            holder.binding.ivMessage.setTint(btnEnabled)
                            holder.binding.tvMessage.setTextColor(btnEnabled)

                            holder.binding.cvAddEdit.isEnabled = true
                            holder.binding.llAdd.setBackgroundColor(grayEnabled)
                            holder.binding.ivAdd.setTint(btnEnabled)
                            holder.binding.tvAdd.setTextColor(btnEnabled)
                        }
                        if (recipient.contact == null) {
                            holder.binding.ivAdd.visible()
                            holder.binding.tvAdd.visible()
                            holder.binding.ivEdit.gone()
                            holder.binding.tvEdit.gone()
                        } else {
                            holder.binding.ivAdd.gone()
                            holder.binding.tvAdd.gone()
                            holder.binding.ivEdit.visible()
                            holder.binding.tvEdit.visible()
                        }
                    }
                }

                item is ConversationInfoItem.ConversationInfoSettings && holder.binding is ConversationInfoSettingsBinding -> {
//                val broadcastListener
                    LogW("messageApp : ", "message conversation setting ")
                    holder.binding.groupName.isVisible = item.recipients.size > 1
                    holder.binding.groupName.summary = item.name
                    if (isGroup) {
                        holder.binding.contactLayout.gone()
                        holder.binding.notifications.gone()
                        holder.binding.block.gone()
                        holder.binding.archive.isEnabled = !item.blocked
                        holder.binding.archive.title = (conversationInfoActivity ?: context).getString(
                            when (item.archived) {
                                true -> R.string.info_unarchive
                                false -> R.string.info_archive
                            }
                        )
                    } else {
                        if ((item.recipients[0]?.address?.length ?: 0) >= 2 && isShortCode(
                                item.recipients[0]?.address?.substring(
                                    0,
                                    2
                                ) ?: ""
                            )
                        ) {
                            holder.binding.contactLayout.gone()
                        } else {
                            holder.binding.contactLayout.visible()
                            holder.binding.address.title = item.recipients[0]?.address
                        }
                        holder.binding.notifications.visible()
                        holder.binding.block.visible()
                        holder.binding.notifications.isEnabled = !item.blocked
                        holder.binding.archive.isEnabled = !item.blocked
                        holder.binding.archive.title = (conversationInfoActivity ?: context).getString(
                            when (item.archived) {
                                true -> R.string.info_unarchive
                                false -> R.string.info_archive
                            }
                        )
                        holder.binding.block.title = (conversationInfoActivity ?: context).getString(
                            when (item.blocked) {
                                true -> R.string.blocking_unblock_title
                                false -> R.string.info_block
                            }
                        )
                    }


                }

                item is ConversationInfoItem.ConversationInfoMedia && holder.binding is ConversationMediaListItemBinding -> {
                    val part = item.value

                    Glide.with(context)
                        .load(part.getUri())
                        .fitCenter()
                        .into(holder.binding.thumbnail)

                    holder.binding.video.isVisible = part.isVideo()
                }

                else -> {
                    Toast.makeText((conversationInfoActivity ?: context), context.getString(R.string.some_thing_wrong), Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    override fun getItemViewType(position: Int): Int {
        val temp = data.filterIsInstance<ConversationInfoItem.ConversationInfoRecipient>()
        isGroup = temp.size > 1
        return when (data[position]) {
            is ConversationInfoItem.ConversationInfoRecipient -> {
                if(isGroup) 0 else 1
            }
            is ConversationInfoItem.ConversationInfoSettings -> 2
            is ConversationInfoItem.ConversationInfoMedia -> 3
            else -> {
                0
            }
        }
    }

    override fun areItemsTheSame(old: ConversationInfoItem, new: ConversationInfoItem): Boolean {
        return when {
            old is ConversationInfoItem.ConversationInfoRecipient && new is ConversationInfoItem.ConversationInfoRecipient -> {
                old.value.id == new.value.id
            }

            old is ConversationInfoItem.ConversationInfoSettings && new is ConversationInfoItem.ConversationInfoSettings -> {
                true
            }

            old is ConversationInfoItem.ConversationInfoMedia && new is ConversationInfoItem.ConversationInfoMedia -> {
                old.value.id == new.value.id
            }

            else -> false
        }
    }

}
