package com.messenger.sms.text.feature.backup

import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.IBinder
import android.util.Log
import androidx.core.content.IntentCompat
import androidx.work.WorkManager
import com.messenger.sms.text.utils.LOG_TAG
import java.util.UUID

// This exists only so that the Cancel button in the ImportExportWorker's notification has something
// it can launch.
class CancelWorkerService : Service() {
    companion object {
        private const val EXTRA_UUID = "uuid"

        fun createIntent(context: Context, uuid: UUID) =
            Intent(context, CancelWorkerService::class.java).apply {
                putExtra(EXTRA_UUID, uuid)
            }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent, flags: Int, startId: Int): Int {
        val uuid = IntentCompat.getSerializableExtra(intent, EXTRA_UUID, UUID::class.java)!!
        Log.i(LOG_TAG, "Cancelling worker: $uuid")

        WorkManager.getInstance(this).cancelWorkById(uuid)
        stopSelf()

        return START_NOT_STICKY
    }
}
