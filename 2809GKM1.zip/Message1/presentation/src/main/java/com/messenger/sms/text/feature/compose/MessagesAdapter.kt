package com.messenger.sms.text.feature.compose

import android.animation.ObjectAnimator
import android.content.Context
import android.content.res.Resources
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.text.*
import android.text.style.BackgroundColorSpan
import android.text.style.ForegroundColorSpan
import android.text.style.StyleSpan
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.ProgressBar
import androidx.appcompat.widget.LinearLayoutCompat
import androidx.core.content.ContextCompat
import androidx.core.content.res.ResourcesCompat
import androidx.core.view.isVisible
import androidx.recyclerview.widget.RecyclerView
import com.jakewharton.rxbinding2.view.clicks
import com.messenger.sms.text.utils.gone
import com.messenger.sms.text.utils.toastMsg
import com.messenger.sms.text.utils.visible
import io.reactivex.subjects.PublishSubject
import io.reactivex.subjects.Subject
import io.realm.RealmResults

import com.messenger.sms.text.R
import com.messenger.sms.text.common.base.MessagesRealmAdapter
import com.messenger.sms.text.common.base.MessagesViewHolder
import com.messenger.sms.text.common.extensions.beGone
import com.messenger.sms.text.common.extensions.beGoneIf
import com.messenger.sms.text.common.extensions.beVisible
import com.messenger.sms.text.common.extensions.toast
import com.messenger.sms.text.common.util.AppUtils
import com.messenger.sms.text.common.util.DateFormatter
import com.messenger.sms.text.common.util.TextViewStyler
import com.messenger.sms.text.common.util.extensions.*
import com.data.compat.SubscriptionManagerCompat
import com.data.extensions.isText
import com.messenger.sms.text.feature.compose.BubbleUtils
import com.messenger.sms.text.feature.compose.BubbleUtils.canGroup
import com.messenger.sms.text.feature.compose.ComposeActivity.Companion.composeActivity
import com.domain.model.Conversation
import com.domain.model.Message
import com.domain.model.Recipient
import com.data.util.PhoneNumberUtils
import com.domain.util.Preferences
import com.messenger.sms.text.common.util.extensions.LogE
import com.messenger.sms.text.databinding.MessageListItemInBinding
import com.messenger.sms.text.feature.compose.part.PartsAdapter
import com.data.extensions.isSmil
import com.data.util.ReConstant
import com.data.util.ReConstant.account_regex
import com.data.util.ReConstant.amount_regex
import com.data.util.ReConstant.credit_regex
import com.data.util.ReConstant.debit_regex
import java.util.concurrent.TimeUnit
import java.util.regex.Matcher
import java.util.regex.Pattern
import javax.inject.Inject
import javax.inject.Provider


class MessagesAdapter @Inject constructor(
    subscriptionManager: SubscriptionManagerCompat,
    private val context: Context,
    private val dateFormatter: DateFormatter,
    private val partsAdapterProvider: Provider<PartsAdapter>,
    private val phoneNumberUtils: PhoneNumberUtils,
    private val prefs: Preferences,
    private val textViewStyler: TextViewStyler
) : MessagesRealmAdapter<Message, MessageListItemInBinding>() {


    companion object {
        private const val VIEW_TYPE_MESSAGE_IN = 0
        private const val VIEW_TYPE_MESSAGE_OUT = 1
        private val EMOJI_REGEX = Regex(
            "^[\\s\n\r]*(?:(?:[\u00a9\u00ae\u203c\u2049\u2122\u2139\u2194-\u2199\u21a9-\u21aa\u231a-\u231b\u2328\u23cf\u23e9-\u23f3\u23f8-\u23fa\u24c2\u25aa-\u25ab\u25b6\u25c0\u25fb-\u25fe\u2600-\u2604\u260e\u2611\u2614-\u2615\u2618\u261d\u2620\u2622-\u2623\u2626\u262a\u262e-\u262f\u2638-\u263a\u2648-\u2653\u2660\u2663\u2665-\u2666\u2668\u267b\u267f\u2692-\u2694\u2696-\u2697\u2699\u269b-\u269c\u26a0-\u26a1\u26aa-\u26ab\u26b0-\u26b1\u26bd-\u26be\u26c4-\u26c5\u26c8\u26ce-\u26cf\u26d1\u26d3-\u26d4\u26e9-\u26ea\u26f0-\u26f5\u26f7-\u26fa\u26fd\u2702\u2705\u2708-\u270d\u270f\u2712\u2714\u2716\u271d\u2721\u2728\u2733-\u2734\u2744\u2747\u274c\u274e\u2753-\u2755\u2757\u2763-\u2764\u2795-\u2797\u27a1\u27b0\u27bf\u2934-\u2935\u2b05-\u2b07\u2b1b-\u2b1c\u2b50\u2b55\u3030\u303d\u3297\u3299\ud83c\udc04\ud83c\udccf\ud83c\udd70-\ud83c\udd71\ud83c\udd7e-\ud83c\udd7f\ud83c\udd8e\ud83c\udd91-\ud83c\udd9a\ud83c\ude01-\ud83c\ude02\ud83c\ude1a\ud83c\ude2f\ud83c\ude32-\ud83c\ude3a\ud83c\ude50-\ud83c\ude51\u200d\ud83c\udf00-\ud83d\uddff\ud83d\ude00-\ud83d\ude4f\ud83d\ude80-\ud83d\udeff\ud83e\udd00-\ud83e\uddff\udb40\udc20-\udb40\udc7f]|\u200d[\u2640\u2642]|[\ud83c\udde6-\ud83c\uddff]{2}|.[\u20e0\u20e3\ufe0f]+)+[\\s\n\r]*)+$"
        )
//        private const val VIEW_TYPE_ADS = 2
//        private const val VIEW_TYPE_MESSAGE_IN = 0
//        private const val VIEW_TYPE_MESSAGE_OUT = 1
//        private const val VIEW_TYPE_MESSAGE_IN_TRANS = 2

    }

    var isStarred: Boolean = false
    var isScrollEnabled: Boolean = false
    var messageId: String = ""
    val clicks: Subject<Long> = PublishSubject.create()
    val clicksDelete: Subject<Long> = PublishSubject.create()
    val partClicks: Subject<Long> = PublishSubject.create()
    val cancelSending: Subject<Long> = PublishSubject.create()
    val copyOtp: Subject<String> = PublishSubject.create()
    val removeStarMessageSubject: Subject<Long> = PublishSubject.create()
    var messageIdForUndoUnStar: Long = 0
    var data: Pair<Conversation?, RealmResults<Message>>? = null
        set(value) {
            if (field === value) return

            field = value
            contactCache.clear()

            updateData(value?.second)
        }

    /**
     * Safely return the conversation, if available
     */
    val conversation: Conversation?
        get() = data?.first?.takeIf { it.isValid }

    /**
     * Mark this message as highlighted
     */
    var highlight: Long = -1L
        set(value) {
            if (field == value) return

            field = value
            notifyDataSetChanged()
        }

    /**
     * Mark this message as highlighted
     */
    var highlightQuery: String? = null
        set(value) {
            if (field == value) return

            field = value
            notifyDataSetChanged()
        }

    private val contactCache = ContactCache()
    private val expanded = HashMap<Long, Boolean>()
    private val partsViewPool = RecyclerView.RecycledViewPool()
    private val subs = subscriptionManager.activeSubscriptionInfoList

    /**
     * If the viewType is negative, then the viewHolder has an attachment. We'll consider
     * this a unique viewType even though it uses the same view, so that regular messages
     * don't need clipToOutline set to true, and they don't need to worry about images
     */
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MessagesViewHolder<MessageListItemInBinding> {

        // Use the parent's context to inflate the layout, otherwise link clicks will crash the app
        val layoutInflater = LayoutInflater.from(parent.context)
        val view: View
        val adview: View
//        if (viewType == VIEW_TYPE_ADS) {
//            view = layoutInflater.inflate(R.layout.message_list_item_in, parent, false)
////            val binding = MessageListItemInBinding.bind(adView)
////            return QkViewHolder(binding)
//        } else
        if (viewType == VIEW_TYPE_MESSAGE_OUT) {
            view = layoutInflater.inflate(R.layout.message_list_item_out, parent, false)
            view.findViewById<ImageView>(R.id.cancelIcon).setTint(ContextCompat.getColor(context, R.color.color_app_theme))
            view.findViewById<ProgressBar>(R.id.cancel).setTint(ContextCompat.getColor(context, R.color.color_app_theme))
        } else {
            view = layoutInflater.inflate(R.layout.message_list_item_in, parent, false)
        }

//        when (viewType) {
//            VIEW_TYPE_MESSAGE_OUT -> {
//                view = layoutInflater.inflate(R.layout.message_list_item_out, parent, false)
//                view.findViewById<ImageView>(R.id.cancelIcon)
//                    .setTint(ContextCompat.getColor(context, R.color.color_app_theme))
//                view.findViewById<ProgressBar>(R.id.cancel)
//                    .setTint(ContextCompat.getColor(context, R.color.color_app_theme))
//            }
//            VIEW_TYPE_MESSAGE_IN_TRANS -> {
//                view = layoutInflater.inflate(R.layout.message_list_item_in_trans, parent, false)
//            }
//            else -> {
//                view = layoutInflater.inflate(R.layout.message_list_item_in, parent, false)
//            }
//        }
        val binding = MessageListItemInBinding.bind(view)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            binding.body.hyphenationFrequency = Layout.HYPHENATION_FREQUENCY_NONE
        }

        if (viewType == VIEW_TYPE_MESSAGE_IN || viewType == VIEW_TYPE_MESSAGE_OUT) {
            val partsAdapter = partsAdapterProvider.get()
            partsAdapter.clicks.subscribe(partClicks)
            binding.attachments.adapter = partsAdapter
            binding.attachments.setRecycledViewPool(partsViewPool)
        } else {
            binding.body.forwardTouches(view)
        }
        binding.body.forwardTouches(view)
        return MessagesViewHolder(binding).apply {

            view.setOnClickListener {
                val message = getItem(adapterPosition) ?: return@setOnClickListener
                when (toggleSelection(message.id, false)) {
                    true -> {
                        view.isActivated = isSelected(message.id)
//                        binding.cbSelect.isChecked = selection.contains(message.id)
                    }

                    false -> {
                        clicks.onNext(message.id)
                        expanded[message.id] = binding.status.visibility != View.VISIBLE
                        notifyItemChanged(adapterPosition)
                    }
                }
//                binding.status.visibility = if (expanded[getItem(adapterPosition)?.id] == true) {
//                    View.VISIBLE
//                } else {
//                    View.GONE
//                }
            }
            view.setOnLongClickListener {
                val message = getItem(adapterPosition) ?: return@setOnLongClickListener true
                toggleSelection(message.id)
                view.isActivated = isSelected(message.id)
                isStarred = message.starred
                true
            }
        }


        // return MessagesViewHolder(view)
    }

    var htmlTagPattern = "<(\"[^\"]*\"|'[^']*'|[^'\">])*>"

    //    var pattern = Pattern.compile(htmlTagPattern)
    var pattern = Pattern.compile("\\<.*?\\>")

    //    override fun onBindViewHolder(holder: MessagesViewHolder<MessageListItemInBinding>, position: Int) {
////        try {
//        val message = getItem(position) ?: return
//        val previous = if (position == 0) null else getItem(position - 1)
//        val next = if (position == itemCount - 1) null else getItem(position + 1)
//
//        // Update the selected state
////        holder.containerView.isActivated = isSelected(message.id) || highlight == message.id
//        holder.binding.root.isActivated = isSelected(message.id) || highlight == message.id
//
//        // Bind the cancel view
//        holder.binding.cancel.let { cancel ->
//            val isCancellable = message.isSending() && message.date > System.currentTimeMillis()
//            cancel.setVisible(isCancellable)
//            cancel.clicks().subscribe { cancelSending.onNext(message.id) }
//            cancel.progress = 2
//
//            if (isCancellable) {
//                val delay = when (prefs.sendDelay.get()) {
//                    Preferences.SEND_DELAY_SHORT -> 3000
//                    Preferences.SEND_DELAY_MEDIUM -> 5000
//                    Preferences.SEND_DELAY_LONG -> 10000
//                    else -> 0
//                }
//                val progress =
//                    (1 - (message.date - System.currentTimeMillis()) / delay.toFloat()) * 100
//
//                ObjectAnimator.ofInt(cancel, "progress", progress.toInt(), 100)
//                    .setDuration(message.date - System.currentTimeMillis())
//                    .start()
//            }
//        }
//        // Bind the message status
//        bindStatus(holder, message, next)
//
//        // Bind the timestamp
//        val timeSincePrevious =
//            TimeUnit.MILLISECONDS.toMinutes(message.date - (previous?.date ?: 0))
//        val simIndex =
//            subs.takeIf { it.size > 1 }?.indexOfFirst { it.subscriptionId == message.subId }
//                ?: -1
//        val subscription = subs.find { sub -> sub.subscriptionId == message.subId }
//
//        holder.binding.timestamp.text = dateFormatter.getMessageTimestamp(message.date)
//        holder.binding.simIndex.text = subscription?.simSlotIndex?.plus(1)?.toString()
//
////        holder.timestamp.text = dateFormatter.getMessageTimestamp(message.date)
////        if (simIndex != -1) holder.simIndex.text = "${simIndex + 1}"
////        else if (subs.size > 1) holder.simIndex.text = "?"
//
//        holder.binding.timestamp.setVisible(
//            timeSincePrevious >= BubbleUtils.TIMESTAMP_THRESHOLD
//                    || message.subId != previous?.subId && subscription != null
//        )
////        holder.timestamp.setVisible(
////            timeSincePrevious >= BubbleUtils.TIMESTAMP_THRESHOLD
////                    || message.subId != previous?.subId // && simIndex != -1 || simIndex != prevSimIndex
////        )
////        holder.flSim.setVisible(holder.timestamp.isVisible && subs.size > 1)
//        holder.binding.sim.setVisible(message.subId != previous?.subId && subscription != null && subs.size > 1)
//        holder.binding.simIndex.setVisible(message.subId != previous?.subId && subscription != null && subs.size > 1)
//
////        if (message.starred)
////            holder.ivStar.visible()
////        else
////            holder.ivStar.gone()
//
//        if (message.starred) {
//            holder.binding.ivStar.beVisible()
////            holder.binding.ivStar.setTint(context.baseConfig.primaryColor)
//        } else {
//            holder.binding.ivStar.beGone()
//        }
//        // Bind the grouping
//        holder.binding.root.setPadding(
//            bottom = if (canGroup(message, next)) 0 else 16.dpToPx(context)
//        )
//
//        // Bind the avatar and bubble colour
//        if (!message.isMe()) {
//            //In message
//            if (getItemViewType(position) == VIEW_TYPE_MESSAGE_IN_TRANS) {
////                holder.avatar1.setRecipient(contactCache[message.address])
////                holder.avatar1.setVisible(!canGroup(message, next), View.INVISIBLE)
////                val params = LinearLayoutCompat.LayoutParams(
////                    LinearLayoutCompat.LayoutParams.WRAP_CONTENT,
////                    LinearLayoutCompat.LayoutParams.WRAP_CONTENT
////                )
////
////                val body = message.body.replace("\n", " ").trim()
////                if (Pattern.compile(debit_regex)
////                        .matcher(body)
////                        .find()
////                ) {
////                    holder.viewTransColor.setBackgroundTint(
////                        ContextCompat.getColor(composeActivity ?: context, R.color.yes_btn_color)
////                    )
////                    holder.tvTransType.text = context.getString(R.string.debit)
////                } else if (Pattern.compile(credit_regex).matcher(body)
////                        .find()
////                ) {
////                    holder.viewTransColor.setBackgroundTint(
////                        ContextCompat.getColor(composeActivity ?: context, R.color.no_btn_color)
////                    )
////                    holder.tvTransType.text = context.getString(R.string.credit)
////                }
//
//                val matcher =
//                    Pattern.compile(amount_regex)
//                        .matcher(body)
//                val acMatcher =
//                    Pattern.compile(account_regex)
//                        .matcher(body)
//                if (matcher.find()) {
//                    val amount = body.substring(
//                        matcher.start(),
//                        matcher.end()
//                    )
//                    val match = Pattern.compile("(?i)(?:(?:RS|INR|MRP|USD|\$|£|€|₹)\\.?\\s?)")
//                        .matcher(amount)
////                    if (match.find()) {
////                        try {
////                            val actAmount = amount.substring(match.end())
////                            if (actAmount.contains(",")) {
////                                holder.tvTransAmount.text = amount
////                                holder.constBody.visible()
////                                holder.body1.gone()
////                                holder.avatar1.gone()
////
////                                params.setMargins(
////                                    context.resources.getDimension(R.dimen._10sdp).toInt(),
////                                    0,
////                                    0,
////                                    context.resources.getDimension(R.dimen._2sdp).toInt()
////                                )
////                                holder.status.layoutParams = params
////                            } else {
////                                if (actAmount.contains(".")) {
////                                    val amt = actAmount.toDouble().toInt()
////                                    if (amt == 0) {
////                                        holder.constBody.gone()
////                                        holder.body1.visible()
////                                        holder.avatar1.visible()
////
////                                        params.setMargins(
////                                            context.resources.getDimension(R.dimen._60sdp).toInt(),
////                                            0,
////                                            0,
////                                            context.resources.getDimension(R.dimen._2sdp).toInt()
////                                        )
////                                        holder.status.layoutParams = params
////                                    } else {
////                                        holder.tvTransAmount.text = amount
////                                        holder.constBody.visible()
////                                        holder.body1.gone()
////                                        holder.avatar1.gone()
////
////                                        params.setMargins(
////                                            context.resources.getDimension(R.dimen._10sdp).toInt(),
////                                            0,
////                                            0,
////                                            context.resources.getDimension(R.dimen._2sdp).toInt()
////                                        )
////                                        holder.status.layoutParams = params
////                                    }
////                                } else {
////                                    val amt = actAmount.toInt()
////                                    if (amt == 0) {
////                                        holder.constBody.gone()
////                                        holder.body1.visible()
////                                        holder.avatar1.visible()
////
////                                        params.setMargins(
////                                            context.resources.getDimension(R.dimen._60sdp).toInt(),
////                                            0,
////                                            0,
////                                            context.resources.getDimension(R.dimen._2sdp).toInt()
////                                        )
////                                        holder.status.layoutParams = params
////                                    } else {
////                                        holder.tvTransAmount.text = amount
////                                        holder.constBody.visible()
////                                        holder.body1.gone()
////                                        holder.avatar1.gone()
////
////                                        params.setMargins(
////                                            context.resources.getDimension(R.dimen._10sdp).toInt(),
////                                            0,
////                                            0,
////                                            context.resources.getDimension(R.dimen._2sdp).toInt()
////                                        )
////                                        holder.status.layoutParams = params
////                                    }
////                                }
////                            }
////
////                        } catch (exp: Exception) {
////                            holder.tvTransAmount.text = amount
////                            holder.constBody.visible()
////                            holder.body1.gone()
////                        }
////                    } else {
////                        holder.tvTransAmount.text = amount
////                        holder.constBody.visible()
////                        holder.body1.gone()
////                    }
//                }
////                if (acMatcher.find()) {
////                    try {
////                        var result = body.split(" ")
////                        val find = body.substring(acMatcher.end() - 1).trim().split(" ")
////                        if (find.isNotEmpty()) {
////                            result = result.filter { it.contains(find[0]) }
////                            val accountNo = if (result.isNotEmpty()) result[0] else "-"
////                            holder.tvTransAc.text = accountNo
////                        } else {
////                            holder.tvTransAc.text = "-"
////                        }
////                    } catch (exp: Exception) {
////                        holder.tvTransAc.text = ""
////                    }
////
////                }
////                if (isExpand(message.id)) {
////                    holder.body.maxLines = 100
////                    holder.transArrow.rotation = 90f
////                } else {
////                    holder.body.maxLines = 2
////                    holder.transArrow.rotation = 0f
////                }
////                holder.transArrow.setOnClickListener {
////                    if (!isExpand(message.id)) {
////                        holder.body.maxLines = 100
////                        holder.transArrow.rotation = 90f
////                        expandList.add(message.id)
////                    } else {
////                        holder.binding.body.maxLines = 2
//////                        holder.binding.transArrow.rotation = 0f
////                        expandList.remove(message.id)
////                    }
////                }
//                holder.binding.body.setOnClickListener {
//                    try {
//                        when (toggleSelection(message.id, false)) {
//                            true -> {
//                                holder.itemView.isActivated = isSelected(message.id)
//                                notifyItemChanged(position)
//                            }
//                            false -> {
//                                if (!isExpand(message.id)) {
//                                    holder.binding.body.maxLines = 100
////                                    holder.transArrow.rotation = 90f
//                                    expandList.add(message.id)
//                                } else {
//                                    holder.binding.body.maxLines = 2
////                                    holder.transArrow.rotation = 0f
//                                    expandList.remove(message.id)
//                                }
//                            }
//                        }
//                    } catch (e: Exception) {
//                        LogE("onCreateViewHolder: ", "messageAdapter" + e.message.toString())
//                    }
//                }
//                if (isSelected(message.id)) {
//                    holder.constBody.setBackgroundTint(
//                        ContextCompat.getColor(
//                            composeActivity ?: context,
//                            R.color.message_body_selected
//                        )
//                    )
//                    holder.body1.setBackgroundTint(
//                        ContextCompat.getColor(
//                            composeActivity ?: context,
//                            R.color.message_body_selected
//                        )
//                    )
//                    holder.transArrow.setTint(
//                        ContextCompat.getColor(
//                            composeActivity ?: context,
//                            R.color.white
//                        )
//                    )
//                    holder.viewLine.setBackgroundColor(
//                        ContextCompat.getColor(
//                            composeActivity ?: context,
//                            R.color.divider_transaction_selected
//                        )
//                    )
//                    holder.tvTransType.setTextColor(
//                        ContextCompat.getColor(
//                            composeActivity ?: context, R.color.white
//                        )
//                    )
//                    holder.tvTransAc.setTextColor(
//                        ContextCompat.getColor(
//                            composeActivity ?: context,
//                            R.color.white
//                        )
//                    )
//                    holder.tvTransAmount.setTextColor(
//                        ContextCompat.getColor(
//                            composeActivity ?: context,
//                            R.color.white
//                        )
//                    )
//                    holder.body.setTextColor(
//                        ContextCompat.getColor(
//                            composeActivity ?: context,
//                            R.color.white
//                        )
//                    )
//                    holder.body1.setTextColor(
//                        ContextCompat.getColor(
//                            composeActivity ?: context,
//                            R.color.white
//                        )
//                    )
//                } else {
//                    holder.constBody.setBackgroundTint(
//                        ContextCompat.getColor(
//                            composeActivity ?: context,
//                            R.color.message_body_in_transaction
//                        )
//                    )
//                    holder.body1.setBackgroundTint(
//                        ContextCompat.getColor(
//                            composeActivity ?: context,
//                            R.color.message_body_in_transaction
//                        )
//                    )
//                    holder.transArrow.setTint(
//                        ContextCompat.getColor(
//                            composeActivity ?: context,
//                            R.color.transArrowColor
//                        )
//                    )
//                    holder.viewLine.setBackgroundColor(
//                        ContextCompat.getColor(
//                            composeActivity ?: context,
//                            R.color.divider_transaction
//                        )
//                    )
//                    holder.tvTransType.setTextColor(
//                        ContextCompat.getColor(
//                            composeActivity ?: context,
//                            R.color.black_color
//                        )
//                    )
//                    holder.tvTransAc.setTextColor(
//                        ContextCompat.getColor(
//                            composeActivity ?: context,
//                            R.color.black_color
//                        )
//                    )
//                    holder.tvTransAmount.setTextColor(
//                        ContextCompat.getColor(
//                            composeActivity ?: context,
//                            R.color.black_color
//                        )
//                    )
//                    holder.body.setTextColor(
//                        ContextCompat.getColor(
//                            composeActivity ?: context,
//                            R.color.transTextColor
//                        )
//                    )
//                    holder.body1.setTextColor(
//                        ContextCompat.getColor(
//                            composeActivity ?: context,
//                            R.color.transTextColor
//                        )
//                    )
//                }
//            } else {
//                holder.avatar.setRecipient(contactCache[message.address])
//                holder.avatar.setVisible(!canGroup(message, next), View.INVISIBLE)
//                if (isSelected(message.id)) {
//                    holder.body.setBackgroundTint(
//                        ContextCompat.getColor(
//                            composeActivity ?: context,
//                            R.color.message_body_selected
//                        )
//                    )
//                    holder.body.setTextColor(
//                        ContextCompat.getColor(
//                            composeActivity ?: context,
//                            R.color.onlyWhiteColor
//                        )
//                    )
//                } else {
//                    holder.body.setBackgroundTint(
//                        ContextCompat.getColor(
//                            composeActivity ?: context,
//                            R.color.message_body_in
//                        )
//                    )
//                    holder.body.setTextColor(
//                        ContextCompat.getColor(
//                            composeActivity ?: context,
//                            R.color.black_color
//                        )
//                    )
//                }
//                if (conversation?.lastMessage?.messageCatType == 2 && (data?.second?.size?.minus(1)) == position) {
//                    copyOtpView(position, holder)
//                } else {
//                    holder.cl_otp_view_lay.gone()
//                }
//            }
//
//
//        } else {
//            if (isSelected(message.id)) {
//                holder.body.setBackgroundTint(
//                    ContextCompat.getColor(
//                        context,
//                        R.color.message_body_selected
//                    )
//                )
//                holder.body.setTextColor(ContextCompat.getColor(context, R.color.onlyWhiteColor))
//            } else {
//                holder.body.setBackgroundTint(
//                    ContextCompat.getColor(
//                        composeActivity ?: context,
//                        R.color.message_body_out
//                    )
//                )
//                holder.body.setTextColor(
//                    ContextCompat.getColor(
//                        composeActivity ?: context,
//                        R.color.black_color
//                    )
//                )
//            }
//
//        }
//        // Bind the body text
//        var messageText = when (message.isSms()) {
//            true -> message.body
//            false -> {
//                val subject = message.getCleansedSubject()
//                val body = message.parts
//                    .filter { part -> part.isText() }
//                    .mapNotNull { part -> part.text }
//                    .filter { text -> text.isNotBlank() }
//                    .joinToString("\n")
//
//                when {
//                    subject.isNotBlank() -> {
//                        val spannable =
//                            SpannableString(if (body.isNotBlank()) "$subject\n$body" else subject)
//                        spannable.setSpan(
//                            StyleSpan(Typeface.BOLD), 0, subject.length,
//                            Spannable.SPAN_INCLUSIVE_EXCLUSIVE
//                        )
//                        spannable
//                    }
//                    else -> body
//                }
//            }
//        }
//        LogE("AppName", "Position : $position ---- Message : $messageText")
//
//        val emojiOnly = messageText.isBlank()
//        textViewStyler.setTextSize(
//            holder.body, when (emojiOnly) {
//                true -> TextViewStyler.SIZE_EMOJI
//                false -> TextViewStyler.SIZE_PRIMARY
//            }
//        )
//
//
//        if (highlightQuery?.isNotEmpty() == true) {
//
////            val str = messageText.toString().replace("(?i)$highlightQuery".toRegex(), "<span style=\"background-color: #1D6CFF;\"><font color=\"#FFFFFF\"><b>$highlightQuery</b></font></span>")
//            var str = ""
//
//            Log.e("highlightQuery", "highlightQuery:" + highlightQuery)
//            Log.e("highlightQuery", "messageText:" + messageText)
//
//            if (messageText.contains(highlightQuery!!, true)) {
//
//                val spannableString = SpannableString(messageText)
//
//                val startIndex = messageText.toString().indexOf(highlightQuery!!, 0, true)
//                val endIndex = startIndex + highlightQuery?.length!!
//
//                val foregroundColorSpan = ForegroundColorSpan(Color.parseColor("#FFFFFF"))
//                spannableString.setSpan(
//                    foregroundColorSpan,
//                    startIndex,
//                    endIndex,
//                    Spannable.SPAN_EXCLUSIVE_EXCLUSIVE
//                )
//                val backgroundColorSpan = BackgroundColorSpan(Color.parseColor("#1D6CFF"))
//                spannableString.setSpan(
//                    backgroundColorSpan,
//                    startIndex,
//                    endIndex,
//                    Spannable.SPAN_EXCLUSIVE_EXCLUSIVE
//                )
//                val styleSpan = StyleSpan(Typeface.BOLD)
//                spannableString.setSpan(
//                    styleSpan,
//                    startIndex,
//                    endIndex,
//                    Spannable.SPAN_EXCLUSIVE_EXCLUSIVE
//                )
//
//                Log.e("highlightQuery", "startPos:" + startIndex)
//                Log.e("highlightQuery", "endPos:" + endIndex)
//
//                messageText = spannableString
//            }
//
//            if (getItemViewType(position) == VIEW_TYPE_MESSAGE_IN_TRANS) {
//                holder.body.maxLines = 100
//                holder.transArrow.rotation = 90f
//            }
////            holder.body.text = Html.fromHtml(messageText.toString().replace("\n", "<br>"))
////            holder.body.text = messageText
//        }
//
//        messageText = getTagToSpan("i",messageText)
//
//        //messageText = getTagToSpan("b",messageText)
//
//        holder.body.text = messageText
//        if (getItemViewType(position) == VIEW_TYPE_MESSAGE_IN_TRANS) {
//            holder.body1.text = messageText
//        }
//
//        holder.body.setVisible(message.isSms() || messageText.isNotBlank())
//
//        try {
//            val partsAdapter = holder.attachments.adapter as PartsAdapter
//            partsAdapter.setData(message, previous, next, holder)
//        } catch (e: Exception) {
//            e.printStackTrace()
//        }
//
//
//        isScrollEnabled = data?.second?.size!! >= 10
//
//    }
    override fun onBindViewHolder(holder: MessagesViewHolder<MessageListItemInBinding>, position: Int) {


//        if (holder.itemViewType == VIEW_TYPE_ADS) {
//
//            holder.binding.clMessageView.visibility = View.GONE
//            holder.binding.inNative.cvRoot.visibility = View.VISIBLE
//            AdmobNative.populateChatNativeAd(
//                holder.binding.root.context,
//                holder.binding.inNative.cvRoot,
//            )
//            if (hideItem) {
//                holder.binding.root.visibility = View.INVISIBLE
//            } else {
//                holder.binding.root.visibility = View.VISIBLE
//            }
//            return
//        }

//        holder.binding.inNative.cvRoot.visibility = View.INVISIBLE

        val message = getItem(position) ?: return
        val previous = if (position == 0) null else getItem(position - 1)
        val next = if (position == itemCount - 1) null else getItem(position + 1)

//        val theme = when (message.isOutgoingMessage()) {
//            true -> colors.theme()
//            false -> colors.theme(contactCache[message.address])
//        }
        // Update the selected state
        holder.binding.root.isActivated = isSelected(message.id) || highlight == message.id

        if (message.starred) {
            holder.binding.ivStar.beVisible()
//            holder.binding.ivStar.setTint(context.baseConfig.primaryColor)
        } else {
            holder.binding.ivStar.beGone()
        }

        holder.binding.ivStar.setOnClickListener {
            val message = getItem(position)
            message?.id?.let { it1 ->
                messageIdForUndoUnStar = it1
                removeStarMessageSubject.onNext(it1)
            }
        }


        // Bind the cancel view
        holder.binding.cancel.let { cancel ->
            val isCancellable = message.isSending() && message.date > System.currentTimeMillis()
            cancel.setVisible(isCancellable)
            cancel.clicks().subscribe { cancelSending.onNext(message.id) }
            cancel.progress = 2

            if (isCancellable) {
                val delay = when (prefs.sendDelay.get()) {
                    Preferences.SEND_DELAY_SHORT -> 3000
                    Preferences.SEND_DELAY_MEDIUM -> 5000
                    Preferences.SEND_DELAY_LONG -> 10000
                    else -> 0
                }
                val progress =
                    (1 - (message.date - System.currentTimeMillis()) / delay.toFloat()) * 100

                ObjectAnimator.ofInt(cancel, "progress", progress.toInt(), 100)
                    .setDuration(message.date - System.currentTimeMillis())
                    .start()
            }
        }
        bindStatus(holder, message, next)

        // Bind the timestamp
        val timeSincePrevious =
            TimeUnit.MILLISECONDS.toMinutes(message.date - (previous?.date ?: 0))
        val subscription = subs.find { sub -> sub.subscriptionId == message.subId }

        holder.binding.timestamp.text = dateFormatter.getMessageTimestamp(message.date)
        holder.binding.simIndex.text = subscription?.simSlotIndex?.plus(1)?.toString()

        holder.binding.timestamp.setVisible(
            timeSincePrevious >= BubbleUtils.TIMESTAMP_THRESHOLD
                    || message.subId != previous?.subId && subscription != null
        )
        holder.binding.sim.setVisible(message.subId != previous?.subId && subscription != null && subs.size > 1)
        holder.binding.simIndex.setVisible(message.subId != previous?.subId && subscription != null && subs.size > 1)

        // Bind the grouping
        val media = message.parts.filter { !it.isSmil() && !it.isText() }
        holder.binding.root.setPadding(
            bottom = if (canGroup(message, next)) 0 else 16.dpToPx(
                context
            )
        )

        // Bind the avatar and bubble colour
        if (!message.isMe()) {
            try {
                holder.binding.avatar.setRecipient(contactCache[message.address])
            } catch (e: Exception) {
            }

            holder.binding.avatar.setVisible(!canGroup(message, next), View.INVISIBLE)

        }


//        val fontId = prefs.selectedFont.get()
//        val checkTypeface = try {
//            ResourcesCompat.getFont(holder.binding.body.context, fontId)
//        } catch (e: Resources.NotFoundException) {
//            Typeface.DEFAULT
//        }
//        holder.binding.body.setTypeface(checkTypeface, checkTypeface?.style ?: Typeface.NORMAL)
//        holder.binding.body.textSize = prefs.textSize.get().toFloat()

        // Bind the body text
        val messageText = when (message.isSms()) {
            true -> message.body
            false -> {
                val subject = message.getCleansedSubject()
                val body = message.parts
                    .filter { part -> part.isText() }
                    .mapNotNull { part -> part.text }
                    .filter { text -> text.isNotBlank() }
                    .joinToString("\n")

                when {
                    subject.isNotBlank() -> {
                        val spannable =
                            SpannableString(if (body.isNotBlank()) "$subject\n$body" else subject)
                        spannable.setSpan(
                            StyleSpan(Typeface.BOLD), 0, subject.length,
                            Spannable.SPAN_INCLUSIVE_EXCLUSIVE
                        )
                        spannable
                    }

                    else -> body
                }
            }
        }
        val emojiOnly = messageText.isNotBlank() && messageText.matches(EMOJI_REGEX)
        textViewStyler.setTextSize(
            holder.binding.body, when (emojiOnly) {
                true -> TextViewStyler.SIZE_EMOJI
                false -> TextViewStyler.SIZE_PRIMARY
            }, true
        )

//        try {
//            setDynamicDrawable(
//                holder.binding.clMessageView,
//                Color.parseColor(backgroundColorTwo.toString()),
//                Color.parseColor(stokeTwo.toString())
//            )
//        } catch (e: Exception) {
//        }

        if (!message.isMe()) {

            try {
//                holder.binding.body.background = null
//                val params = holder.binding.body.layoutParams as ConstraintLayout.LayoutParams
//                    params.setMargins(10, 5, 5, 0)
//                holder.binding.body.layoutParams = params

                /*  setDynamicDrawable(
                      holder.binding.clMessageView,
                      Color.parseColor("#F6F7F9"),
                      Color.parseColor("#ECEDEF")
                  )*/

                /* setDynamicDrawable(
                     holder.binding.body,
                     Color.parseColor("#F6F7F9"),
                     Color.parseColor("#ECEDEF")
                 )*/

                /* holder.binding.clMessageView.setBackgroundResource(
                     getBubble(
                         emojiOnly = emojiOnly,
                         canGroupWithPrevious = canGroup(
                             message,
                             previous
                         ) || media.isNotEmpty(),
                         canGroupWithNext = canGroup(message, next),
                         isMe = message.isMe(),
                         style = prefs.bubbleStyle.get()
                     )
                 )*/
//                    holder.binding.clMessageView.setPadding(10, 5, 10, 5)

            } catch (e: Exception) {
            }

            if ((data?.second?.size?.minus(1)) == position) {
                val resultOtp =
                    Pattern.compile(ReConstant.otp_regex.toString())
                        .matcher(message.body.replace("\n", " ").trim()).find()
                Log.e("resultOtp", "resultOtp:$resultOtp,body:${message.body}")
                if (resultOtp) {

                    copyOtpView(message, holder)
                    setDynamicDrawable(
                        holder.binding.clMessageView,
                        Color.parseColor("#F6F7F9"),
                        Color.parseColor("#ECEDEF")
                    )


                    Log.e("resultOtp", "001.width:${holder.binding.clMessageView.width},height:${holder.binding.clMessageView.height}")
//                    val layoutParams = holder.binding.clMessageView.layoutParams as ConstraintLayout.LayoutParams
//                    layoutParams.width = ConstraintLayout.LayoutParams.MATCH_PARENT
//                    layoutParams.width = 900
//                    layoutParams.width = 0
//                    layoutParams.height = ConstraintLayout.LayoutParams.WRAP_CONTENT
//                    layoutParams.endToEnd = ConstraintLayout.LayoutParams.PARENT_ID
//                    holder.binding.clMessageView.layoutParams = layoutParams
//                    holder.binding.clMessageView.updateLayoutParams<ConstraintLayout.LayoutParams> {
//                        width = 0
//                        height = ConstraintLayout.LayoutParams.WRAP_CONTENT
//                    }
//                    holder.binding.clMessageView.requestLayout()
                    Log.e("resultOtp", "002.width:${holder.binding.clMessageView.width},height:${holder.binding.clMessageView.height}")

                } else {
                    holder.binding.ivArrow.beGone()
                    holder.binding.layOtp.beGone()
                    setDynamicDrawable(
                        holder.binding.clMessageView,
                        Color.parseColor("#F6F7F9"),
                        Color.parseColor("#ECEDEF")
                    )
                }
            } else {
                holder.binding.ivArrow.beGone()
                holder.binding.layOtp.beGone()
                Log.e("MessagesAdapter", "001.layOtp.beGone")
                setDynamicDrawable(
                    holder.binding.clMessageView,
                    Color.parseColor("#F6F7F9"),
                    Color.parseColor("#ECEDEF")
                )
            }
        }
        if (selection.size > 0) holder.binding.cbSelect.beVisible()
        else holder.binding.cbSelect.beGone()
        holder.binding.cbSelect.isChecked = selection.contains(message.id)

        holder.binding.body.text = messageText
        //  holder.binding.body.text = Html.fromHtml(messageText.toString(), Html.FROM_HTML_MODE_LEGACY)
        holder.binding.body.setVisible(message.isSms() || messageText.isNotBlank())


        if (holder.binding.body.text.isNotBlank()) {
            holder.binding.rootLayout.post {
//                val constraintSet = ConstraintSet()
//                constraintSet.clone(holder.binding.rootLayout)

                // Set width based on message length
//                val width = if (messageText.length < 15) {
//                    ConstraintLayout.LayoutParams.WRAP_CONTENT
//                } else {
//                    ConstraintSet.MATCH_CONSTRAINT
//                }

                // Update constraints
//                constraintSet.constrainWidth(holder.binding.body.id, width)
//                constraintSet.applyTo(holder.binding.rootLayout)

                // Ensure visibility if hidden
                holder.binding.body.visibility = View.VISIBLE
            }
        } else {
            // Hide the message body if text is blank
            holder.binding.body.visibility = View.GONE
        }
//        try {
//            if (prefs.bubbleStyleType.get().equals(BubbleStyleType.AUTO.toString())) {
//
//                if (message.isMe()) {
//                    try {
//                        holder.binding.clMessageView.setBackgroundTint(backgroundColorTwo)
//                        holder.binding.body.setTextColor(backgroundTextColorTwo)
//                    } catch (e: Exception) {
//                        e.printStackTrace()
//                    }
//                } else {
//                    try {
//                        holder.binding.clMessageView.setBackgroundTint(backgroundColorOne)
//                        holder.binding.body.setTextColor(backgroundTextColorOne)
//                    } catch (e: Exception) {
//                        e.printStackTrace()
//                    }
//
//                }
//
//            } else {
//                if (message.isMe()) {
//                    try {
//                        holder.binding.clMessageView.setBackgroundTint(backgroundColorTwo)
//                        holder.binding.body.setTextColor(backgroundTextColorTwo)
//                    } catch (e: Exception) {
//                        e.printStackTrace()
//                    }
//
//                } else {
//                    try {
//                        holder.binding.clMessageView.setBackgroundTint(backgroundColorOne)
//                        holder.binding.body.setTextColor(backgroundTextColorOne)
//                        holder.binding.tvOtp.setTextColor(backgroundTextColorOne)
//                    } catch (e: Exception) {
//                        e.printStackTrace()
//                    }
//
//                }
//            }
//        } catch (e: Exception) {
//        }

        // Bind the attachments
        val partsAdapter = holder.binding.attachments.adapter as PartsAdapter
//        partsAdapter.theme = theme
        partsAdapter.setData(message, previous, next, holder)
    }

    fun setDynamicDrawable(view: View, bgColor: Int, strokeColor: Int) {
//        view.setBackgroundTint(bgColor)
//        val drawable =
//            view.context.getDrawable(R.drawable.message_simple_out_last) as GradientDrawable
//        drawable.setColor(bgColor)
//        drawable.setStroke(4, strokeColor)
//        view.background = drawable
    }

    private fun getTagToSpan(tagStr: String, messageText: CharSequence): SpannableString {
        Log.e("getTagToSpan", "getTagToSpan.tagStr:" + tagStr)
        Log.e("getTagToSpan", "getTagToSpan.messageText:" + messageText.length)

        var spannableString = SpannableString(messageText)
        if (messageText.contains("<$tagStr>", true)) {
            if (messageText.contains("</$tagStr>", true)) {

                val signature = messageText.substring(messageText.lastIndexOf("<$tagStr>", ignoreCase = true), messageText.lastIndexOf("</$tagStr>", ignoreCase = true) + "</$tagStr>".length)

                Log.e("getTagToSpan", "getTagToSpan.signature:" + signature)
                var signatureNew = signature.replace("<$tagStr>", "")

                signatureNew = signatureNew.replace("</$tagStr>", "")

                Log.e("getTagToSpan", "getTagToSpan.signatureNew:" + signatureNew)
                val str = messageText.toString().replace(signature, signatureNew)

                Log.e("getTagToSpan", "getTagToSpan.str:" + str)
                //val startIndex = messageText.indexOf("<$tagStr>", 0, true) + "<$tagStr>".length
                //val startIndex = messageText.lastIndexOf("<$tagStr>", ignoreCase = true) + "<$tagStr>".length
                val startIndex = str.lastIndexOf(signatureNew)
                //val endIndex = messageText.indexOf("</$tagStr>", 0, true)
                //val endIndex = messageText.lastIndexOf("</$tagStr>", ignoreCase = true)
                val endIndex = str.lastIndexOf(signatureNew) + signatureNew.length

                //val endIndex = startIndex + "</$tagStr>".length
                var styleSpan = StyleSpan(Typeface.NORMAL)
                if (tagStr.equals("i", true)) styleSpan = StyleSpan(Typeface.ITALIC)

                if (tagStr.equals("b", true)) styleSpan = StyleSpan(Typeface.BOLD)

                Log.e("getTagToSpan", "getTagToSpan.startIndex:" + startIndex)
                Log.e("getTagToSpan", "getTagToSpan.endIndex:" + endIndex)
                Log.e("getTagToSpan", "getTagToSpan.styleSpan:" + styleSpan.style)
                spannableString = SpannableString(str)
                spannableString.setSpan(
                    styleSpan,
                    startIndex,
                    endIndex,
                    Spannable.SPAN_EXCLUSIVE_EXCLUSIVE
                )
            }
        }
        return spannableString
    }

    private fun copyOtpView(message: Message, holder: MessagesViewHolder<MessageListItemInBinding>) {

        holder.binding.ivArrow.beVisible()
        holder.binding.layOtp.beVisible()
        Log.e("MessagesAdapter", "002.layOtp.beVisible")
        holder.binding.tvOtp.text = ReConstant.parseCode(message.body.replace("\n", " ").trim())
//        holder.binding.clMessageView.setBackgroundResource(
//            R.drawable.message_only
//        )
//        holder.binding.clMessageView.setBackgroundTint(backgroundColorOne)
        holder.binding.btnCopy.setOnClickListener {
            ReConstant.copy(context, holder.binding.tvOtp.text.toString())
            context.toast(context.resources.getString(R.string.toast_copied))
        }
//        holder.binding.ivArrow.setOnClickListener {
//            toggleSingleLine(holder.binding.body, holder.binding.ivArrow)
//        }
        holder.binding.ivDelete.setOnClickListener {
            selection = listOf<Long>()
            selection = selection + message.id
            selectionChanges.onNext(selection)
            //  ReConstant.copy(context, lastMessage?.otpCode ?: "")
            //  context.toast(context.resources.getString(R.string.toast_copied))
            clicksDelete.onNext(conversation?.id!!)
            //adapterItemDelete.onNext(conversation?.id)
        }

    }

    private fun bindStatus(
        holder: MessagesViewHolder<MessageListItemInBinding>,
        message: Message,
        next: Message?,
    ) {
        val age = TimeUnit.MILLISECONDS.toMinutes(System.currentTimeMillis() - message.date)

        holder.binding.status.text = when {
            message.isSending() -> {
                context.getString(R.string.message_status_sending)
            }

            message.isDelivered() -> {
                context.getString(
                    R.string.message_status_delivered,
                    dateFormatter.getTimestamp(message.dateSent)
                )
            }

            message.isFailedMessage() -> {
                context.getString(R.string.message_status_failed)
            }

            !message.isMe() && (conversation?.recipients?.size ?: 0) > 1 -> {
                "${contactCache[message.address]?.getDisplayName()} • ${
                    dateFormatter.getTimestamp(
                        message.date
                    )
                }"
            }

            else -> dateFormatter.getTimestamp(message.date)
        }

        holder.binding.status.setVisible(
            when {
                expanded[message.id] == true -> {
                    true
                }

                message.isSending() -> {
                    true
                }

                message.isFailedMessage() -> {
                    true
                }

                expanded[message.id] == false -> {
                    false
                }

                (conversation?.recipients?.size ?: 0) > 1 && !message.isMe() && next?.compareSender(
                    message
                ) != true -> {
                    true
                }

                message.isDelivered() && next?.isDelivered() != true && age <= BubbleUtils.TIMESTAMP_THRESHOLD -> {
                    true
                }

                else -> {
                    false
                }
            }
        )
    }


    override fun getItemViewType(position: Int): Int {
        try {
            val message = getItem(position) ?: return -1
            return when (message.isMe()) {
                true -> VIEW_TYPE_MESSAGE_OUT
                false -> VIEW_TYPE_MESSAGE_IN
            }
//            val message = getItem(position) ?: return -1
//            return if (message.isMe()) {
//                VIEW_TYPE_MESSAGE_OUT
//            } else {
//                when (message.messageCatType) {
//                    1 -> {
//                        VIEW_TYPE_MESSAGE_IN_TRANS
//                    }
//
//                    else -> {
//                        VIEW_TYPE_MESSAGE_IN
//                    }
//                }
//            }
        } catch (e: Exception) {
            return VIEW_TYPE_MESSAGE_OUT
        }
    }

    /**
     * Cache the contacts in a map by the address, because the messages we're binding don't have
     * a reference to the contact.
     */
    private inner class ContactCache : HashMap<String, Recipient?>() {

        override fun get(key: String): Recipient? {
            if (super.get(key)?.isValid != true) {
                set(
                    key, conversation?.recipients?.firstOrNull {
                        phoneNumberUtils.compare(
                            it.address, key
                        )
                    })
            }

            return super.get(key)?.takeIf { it.isValid }
        }

    }

    private fun getOnlyNumerics(str: String?): String? {
        if (str == null) {
            return null
        }
        var count = 0
        val strBuff = StringBuffer()
        var c: Char
        for (element in str) {
            c = element
            if (Character.isDigit(c)) {
                strBuff.append(c)
                count++
            }
        }
        return strBuff.toString()
    }

//    fun selectAll() {
//        selection.clear()
//        data?.second?.map { it.id }?.let { ArrayList(it) }?.let { selection.addAll(it) }
//        selectionChanges.onNext(selection)
//        notifyDataSetChanged()
//    }

}
