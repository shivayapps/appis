package com.messenger.sms.text.feature.compose

import android.annotation.SuppressLint
import android.content.Context
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.viewbinding.ViewBinding
import com.bumptech.glide.Glide
import ezvcard.Ezvcard
import io.reactivex.Observable
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.schedulers.Schedulers
import io.reactivex.subjects.PublishSubject
import io.reactivex.subjects.Subject
import com.messenger.sms.text.R
import com.messenger.sms.text.common.base.MessagesAdapter
import com.messenger.sms.text.common.base.MessagesViewHolder
import com.messenger.sms.text.databinding.AttachmentContactListItemBinding
import com.messenger.sms.text.databinding.AttachmentImageListItemBinding
import com.domain.extensions.mapNotNull
import com.domain.model.Attachment
import timber.log.Timber
import javax.inject.Inject

class AttachmentAdapter @Inject constructor(
    private val context: Context
) : MessagesAdapter<Attachment, ViewBinding>() {

    companion object {
        private const val VIEW_TYPE_IMAGE = 0
        private const val VIEW_TYPE_CONTACT = 1
    }

    val attachmentDeleted: Subject<Attachment> = PublishSubject.create()

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MessagesViewHolder<ViewBinding> {
//        val inflater = LayoutInflater.from(parent.context)
//        val view = when (viewType) {
//            VIEW_TYPE_IMAGE -> inflater.inflate(R.layout.attachment_image_list_item, parent, false)
//                    .apply { thumbnailBounds.clipToOutline = true }
//
//            VIEW_TYPE_CONTACT -> inflater.inflate(R.layout.attachment_contact_list_item, parent, false)
//
//            else -> null!! // Impossible
//        }
//
//        return MessagesViewHolder(view).apply {
//            view.setOnClickListener {
//                val attachment = getItem(adapterPosition)
//                attachmentDeleted.onNext(attachment)
//            }
//        }
        val holder: MessagesViewHolder<ViewBinding> = when (viewType) {
            VIEW_TYPE_IMAGE -> MessagesViewHolder(parent, AttachmentImageListItemBinding::inflate)
            VIEW_TYPE_CONTACT -> MessagesViewHolder(parent, AttachmentContactListItemBinding::inflate)
            else -> null!! // Impossible
        }

        return holder.apply {
            if (binding is AttachmentImageListItemBinding) {
                binding.thumbnailBounds.clipToOutline = true
            }

            binding.root.setOnClickListener {
                val attachment = getItem(adapterPosition)
                attachmentDeleted.onNext(attachment)
            }
        }
    }

    @SuppressLint("CheckResult")
    override fun onBindViewHolder(holder: MessagesViewHolder<ViewBinding>, position: Int) {
        val attachment = getItem(position)
        Timber.w("messageApp : ", "Attachment onBindViewHolder  " +attachment )


        when {

            attachment is Attachment.Image && holder.binding is AttachmentImageListItemBinding -> {
                Glide.with(context)
                    .load(attachment.getUri())
                    .into(holder.binding.thumbnail)

            }
            attachment is Attachment.Contact && holder.binding is AttachmentContactListItemBinding -> {
                Observable.just(attachment.vCard)
                    .mapNotNull { vCard -> Ezvcard.parse(vCard).first() }
                    .subscribeOn(Schedulers.computation())
                    .observeOn(AndroidSchedulers.mainThread())
                    .subscribe { vcard -> holder.binding.name.text = vcard.formattedName.value }

//                val darkMode = isDarkTheme(context)
//                if (darkMode) {
//                    holder.binding.name.setTextColor(context.getColor(R.color.black))
//                    holder.binding.label.setTextColor(context.getColor(R.color.gray))
//                    holder.binding.detach.setTint(context.getColor(R.color.black))
//                    holder.binding.vCardAvatar.setTint(context.getColor(R.color.black))
//                }
            }
//            is Attachment.Image -> Glide.with(context)
//                    .load(attachment.getUri())
//                .into(holder.binding.thumbnail)

//            is Attachment.Contact -> Observable.just(attachment.vCard)
//                    .mapNotNull { vCard -> Ezvcard.parse(vCard).first() }
//                    .subscribeOn(Schedulers.computation())
//                    .observeOn(AndroidSchedulers.mainThread())
//                    .subscribe { vcard -> holder.name?.text = if(vcard.formattedName!=null){vcard.formattedName.value} else{context.getString(R.string.name)} }
        }
    }



    override fun getItemViewType(position: Int) = when (getItem(position)) {
        is Attachment.Image -> VIEW_TYPE_IMAGE
        is Attachment.Contact -> VIEW_TYPE_CONTACT
    }

}