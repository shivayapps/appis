package com.messenger.sms.text.event

abstract class UpdateEvent : ConversationEvent

class UnreadEvent(
) : UpdateEvent()

class SubscribeEvent(
) : UpdateEvent()


