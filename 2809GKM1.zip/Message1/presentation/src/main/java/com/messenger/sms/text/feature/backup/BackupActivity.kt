package com.messenger.sms.text.feature.backup

//import com.messenger.sms.text.databinding.BackupControllerBinding
import android.app.AlertDialog
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Build.VERSION.SDK_INT
import android.os.Bundle
import android.os.Environment
import android.provider.DocumentsContract
import android.view.View
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.lifecycle.Observer
import androidx.work.WorkInfo
import androidx.work.WorkManager
import androidx.work.WorkQuery
import com.adconfig.AdsConfig
import com.adconfig.adsutil.AdsParameters
import com.adconfig.adsutil.Config
import com.adconfig.adsutil.admob.AdmobIntersAdImpl
import com.data.manager.PermissionManagerImpl
import com.messenger.sms.text.R
import com.messenger.sms.text.common.base.MessagesThemedActivity
import com.messenger.sms.text.common.util.extensions.viewBinding
import com.messenger.sms.text.databinding.BackupActivityBinding
import com.messenger.sms.text.utils.CHANNEL_ID_ALERTS
import com.messenger.sms.text.utils.CHANNEL_ID_PERSISTENT
import com.messenger.sms.text.utils.getCurrentDateTime
import com.messenger.sms.text.utils.toString
import dagger.android.AndroidInjection
import org.greenrobot.eventbus.EventBus

const val EXPORT_MESSAGES = 1
const val IMPORT_MESSAGES = 2

class BackupActivity : MessagesThemedActivity() {

    companion object {
        var backupActivity: BackupActivity? = null
    }

    var isBackupRunnig = false

    private val binding by viewBinding(BackupActivityBinding::inflate)

    //    private val binding by viewBinding(BackupControllerBinding::inflate)
    override fun onCreate(savedInstanceState: Bundle?) {
        AndroidInjection.inject(this)
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(binding.root)
        ViewCompat.setOnApplyWindowInsetsListener(binding.root) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
        setSupportActionBar(binding.toolbar)
        backupActivity = this
        setTitle(R.string.backup_title)

//        router = Conductor.attachRouter(this, binding.container, savedInstanceState)
//        backupController = BackupController()
//        if (!router.hasRootController()) {
//            router.setRoot(RouterTransaction.with(backupController))
//        }
//        backupController.fabLabel.isClickable = true

        initListener()
        backupListener()
        showBackButton(true)
        loadIntAds()
    }

    private fun initListener() {

        binding.settingsExportMessagesHolder.setOnClickListener {
            if (!isBackupRunnig) {
                AdsConfig.isSystemDialogOpen = true
                exportMessagesManual()
            }
        }
        binding.settingsImportMessagesHolder.setOnClickListener {
            if (!isBackupRunnig) {
                AdsConfig.isSystemDialogOpen = true
                importMessagesManual()
            }
        }

    }

    var alertDialog: AlertDialog? = null
    val REQUEST_DRAW_OVERLAYS_PERMISSION = 1002
    private fun importMessagesManual() {
        if (SDK_INT < 23) {
            setStatusReport(getString(R.string.message_import_api_23_requirement))
            return
        }

        pendingAction = Action.IMPORT_MESSAGES_MANUAL
        //see https://github.com/tmo1/sms-ie/issues/3#issuecomment-900518890
        requestExistingFile.launch(arrayOf(if (SDK_INT < 29) "*/*" else "application/zip"))
    }

    private val requestExistingFile =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            launchPendingAction(uri, false)
        }
    private val requestNewZipFile =
        registerForActivityResult(ActivityResultContracts.CreateDocument("application/zip")) { uri ->
            launchPendingAction(uri, false)
        }
    private var pendingAction: Action? = null
    private fun exportMessagesManual() {

        if (PermissionManagerImpl(this).isDefaultSms()) {

            pendingAction = Action.EXPORT_MESSAGES_MANUAL
            val date = getCurrentDateTime()
            val dateInString = date.toString("yyyy-MM-dd")
            requestNewZipFile.launch("messages-$dateInString.zip")
        } else {
            setStatusReport("Exporting messages requires permission to read SMSs and contacts.")
        }
    }


    private fun launchPendingAction(uri: Uri?, nullUriAllowed: Boolean) {
        if (uri != null || nullUriAllowed) {
            scheduleManualAction(this, pendingAction!!, uri)
        }

        // Always clear the pending action, even if we don't start anything (eg. if the user
        // cancelled the file selection).
        pendingAction = null
    }

    private fun setStatusReport(statusReport: String) {
//        val statusReportText: TextView = findViewById(R.id.status_report)
//        statusReportText.text = statusReport
    }

    private fun backupListener() {
        if (SDK_INT >= Build.VERSION_CODES.O) {
            val notificationManager = getSystemService(NOTIFICATION_SERVICE) as NotificationManager

            // Register the channel with the system; you can't change the importance
            // or other notification behaviors after this

            notificationManager.createNotificationChannel(
                NotificationChannel(
                    CHANNEL_ID_PERSISTENT,
                    getString(R.string.persistent_channel_name),
                    NotificationManager.IMPORTANCE_LOW
                ).apply {
                    description = getString(R.string.persistent_channel_description)
                }
            )

            notificationManager.createNotificationChannel(
                NotificationChannel(
                    CHANNEL_ID_ALERTS,
                    getString(R.string.alerts_channel_name),
                    NotificationManager.IMPORTANCE_DEFAULT
                ).apply {
                    description = getString(R.string.alerts_channel_description)
                }
            )

            // Remove legacy notification channels to accommodate upgrades
            notificationManager.deleteNotificationChannel("MYCHANNEL")
        }

        val workManager = WorkManager.getInstance(this@BackupActivity)
        workManager
            .getWorkInfosLiveData(
                WorkQuery.fromTags(
                    ImportExportWorker.Companion.TAG_MANUAL_ACTION,
                    ImportExportWorker.Companion.TAG_AUTOMATIC_EXPORT,
                )
            )
            .observe(this, Observer {
                var isRunning = false
                var canCancel = false

                // There should only be one active worker. The only other one would be the enqueued
                // work for the next scheduled export.
                for (workInfo in it) {
                    when (workInfo.state) {
                        WorkInfo.State.RUNNING -> {
                            isRunning = true

                            val progress = Progress(workInfo.progress)
                            binding.progressBar.isIndeterminate = progress.total == 0
                            binding.progressBar.max = progress.total
                            binding.progressBar.progress = progress.current
                            binding.statusReport.text = progress.message
                            canCancel = progress.canCancel

                            binding.cancelButton.setOnClickListener {
                                workManager.cancelWorkById(workInfo.id)
                            }
                        }

                        WorkInfo.State.SUCCEEDED -> {
                            val success = SuccessData(workInfo.outputData)
                            binding.statusReport.text = success.message
                            EventBus.getDefault().post("sync_message")
                        }

                        WorkInfo.State.FAILED -> {
                            val failure = FailureData(workInfo.outputData)
                            // Just show the general error from the title in the status. The more
                            // detailed message will be shown in the dialog box.
                            binding.statusReport.text = failure.title

                            errorDialog(
                                failure.title,
                                failure.message,
                                failure.savedLogcat,
                            )
                        }
                        // Cancelled work can occur when changing scheduled export settings or when
                        // the user explicitly cancels a running operation. We want both to be
                        // pruned below.
                        WorkInfo.State.CANCELLED -> {
                            binding.statusReport.text = getString(R.string.operation_cancelled)
                        }

                        else -> {
                            continue
                        }
                    }

                    // WorkManager keeps a history of completed jobs for a certain period of time.
                    // We want to get rid of this history once we've seen the result and updated the
                    // UI accordingly. It's a bit hacky, but this way, we'll only see new status
                    // updates without needing to separately keep track of which completed work IDs
                    // we've already observed.
                    if (workInfo.state.isFinished) {
                        workManager.pruneWork()
                    }
                }

                binding.llReportSync.visibility = if (isRunning) View.VISIBLE else View.INVISIBLE
                binding.progressBar.visibility = if (isRunning) View.VISIBLE else View.INVISIBLE
                binding.cancelButton.visibility = if (canCancel) View.VISIBLE else View.INVISIBLE
                isBackupRunnig = isRunning
//                listOf(
//                    exportMessagesButton,
//                    importMessagesButton,
//                    exportCallLogButton,
//                    importCallLogButton,
//                    exportContactsButton,
//                    importContactsButton,
//                    exportBlockedNumbersButton,
//                    importBlockedNumbersButton,
//                    wipeAllMessagesButton,
//                    setDefaultSMSAppButton
//                ).forEach { button -> button.isEnabled = !isRunning }

            })
    }

    fun errorDialog(title: String, message: String, savedLogcat: Boolean) {
        AlertDialog.Builder(this)
            .setTitle(title)
            .setMessage(message)
            .setPositiveButton(android.R.string.ok) { _, _ -> }
            .apply {
                if (savedLogcat) {
                    setNeutralButton(R.string.open_log_dir) { _, _ ->
                        // The external files directory (/sdcard/Android/data/<package>/files) is
                        // only readable via USB (adb or mtp) or via the system file manager
                        // (DocumentsUI) in recent versions of Android. This intent will open the
                        // system file manager to the proper directory. Unfortunately, passing it a
                        // file:// URI directly will fail with FileUriExposedException. We need to
                        // manually construct a SAF content:// URI. While these constants are not
                        // documented, since they are part of content:// URIs, Android realistically
                        // can't ever change them without revoking permissions to files that apps
                        // have already been granted access to. Android's own tests also hardcode
                        // them.
                        val intent = Intent(Intent.ACTION_VIEW).apply {
                            val appExternalDir = getExternalFilesDir(null)!!
                            val globalExternalDir = Environment.getExternalStorageDirectory()
                            val relPath = appExternalDir.relativeTo(globalExternalDir)

                            setDataAndType(
                                DocumentsContract.buildDocumentUri(
                                    "com.android.externalstorage.documents",
                                    "primary:$relPath",
                                ),
                                "vnd.android.document/directory",
                            )
                        }

                        startActivity(intent)
                    }
                }
            }
            .create().show()
    }

    private fun loadIntAds() {

        val adId =
            if (appPrefs.isFirstTime) getString(R.string.inter_backpress)
            else getString(R.string.inter_backpress2)
        if (AdsParameters(this).isNeedInterAd && Config.checkInterAd()) {
            AdmobIntersAdImpl().load(this, adId)
        }
    }

    override fun onBackPressed() {
        if (Config.checkInterAd()) {
            AdsConfig.showInterstitialAd(this) {
                finish()
            }
        } else {
            finish()
        }

    }

//    override fun onActivityResult(requestCode: Int, resultCode: Int, resultData: Intent?) {
//        super.onActivityResult(requestCode, resultCode, resultData)
////        if (requestCode == MAKE_DEFAULT_APP_REQUEST) {
////            EventBus.getDefault().post(MessageEvent(REFRESH_MESSAGE))
////        }
//
//        var total: MessageTotal
//        val startTime = System.nanoTime()
//
//        if (requestCode == EXPORT_MESSAGES && resultCode == Activity.RESULT_OK) {
//            resultData?.data?.let {
//                //statusReportText.text = getString(R.string.begin_exporting_messages)
//                CoroutineScope(Dispatchers.Main).launch {
//                    binding.llExportSync.beVisible()
//                    total = exportMessages(
//                        this@BackupActivity,
//                        it,
//                        binding.progressBarExport,
//                        binding.reportExport
//                    )
//                    try {
//                        binding.reportExport.text = getString(
//                            R.string.export_messages_results,
//                            total.sms,
//                            total.mms,
//                            formatElapsedTime(
//                                TimeUnit.SECONDS.convert(
//                                    System.nanoTime() - startTime, TimeUnit.NANOSECONDS
//                                )
//                            )
//                        )
//                    } catch (e: Exception) {
//                        binding.reportExport.text = getString(
//                            R.string.export_messages_results,
//                            total.sms,
//                            total.mms,
//                            formatElapsedTime(
//                                TimeUnit.SECONDS.convert(
//                                    System.nanoTime() - startTime, TimeUnit.NANOSECONDS
//                                )
//                            )
//                        )
//                    }
////                    logElapsedTime(startTime)
////                    Handler(Looper.getMainLooper()).postDelayed({
////                        binding.llExportSync.beGone()
////                    }, 1500)
//                }
//            }
//        }
//
//        if (requestCode == IMPORT_MESSAGES && resultCode == Activity.RESULT_OK) {
//            resultData?.data?.let {
//                CoroutineScope(Dispatchers.Main).launch {
//                    binding.llImportSync.beVisible()
//                    // importMessages() requires API level 23, but we check for that back in importMessagesManual()
//                    total = importMessages(
//                        this@BackupActivity,
//                        it,
//                        binding.progressBarImport,
//                        binding.reportImport
//                    )
//                    binding.reportImport.text = getString(
//                        R.string.import_messages_results, total.sms, total.mms, formatElapsedTime(
//                            TimeUnit.SECONDS.convert(
//                                System.nanoTime() - startTime, TimeUnit.NANOSECONDS
//                            )
//                        )
//                    )
//                    (this@BackupActivity).runOnUiThread {
////                        syncMessages.execute(Unit)
//                        EventBus.getDefault().post("sync_message")
//                        Handler(Looper.getMainLooper()).postDelayed({
//                            binding.llImportSync.beGone()
//                        }, 1500)
//                    }
////                    logElapsedTime(startTime)
//                }
//            }
//        }
////        if (requestCode == 100 && resultCode == RESULT_OK && data != null) {
////            val uri = data.data
////            val takeFlags: Int = (data.flags
////                    and (Intent.FLAG_GRANT_READ_URI_PERMISSION
////                    or Intent.FLAG_GRANT_WRITE_URI_PERMISSION))
////            contentResolver.takePersistableUriPermission(uri!!, takeFlags)
////            val documentFile: DocumentFile? = DocumentFile.fromTreeUri(this, uri)
////            if (documentFile != null) {
////                if(documentFile.name == "Backups" && uri.toString().contains("Messages") ){
////                    prefs.downloadUri.set(uri.toString())
////                    backupController.permissionGivenSubject.onNext(Unit)
////                } else {
////                    toastMsg(getString(R.string.select_correct_restore_folder))
////                }
////            } else {
////                toastMsg(getString(R.string.some_thing_wrong))
////            }
////        }
//    }
}