package com.messenger.sms.text.emoji_view_library.actions;

import android.content.Context;
import android.view.View;
import android.view.inputmethod.InputConnection;

import com.messenger.sms.text.emoji_view_library.Helper.EmojiIconsPopup;


public class EmojiIconActions {

    private boolean useSystemEmoji = false;
    private final EmojiIconsPopup popup;
    private final InputConnection inputConnection;
    Context context;
    View rootView;


    /**
     * Constructor
     *
     * @param ctx             The context of current activity.
     * @param rootView        The top most layout in your view hierarchy. The difference of
     *                        this view and the screen height will be used to calculate the
     *                        keyboard height.
     * @param inputConnection The Id of EditText.
     */
    public EmojiIconActions(Context ctx, View rootView, InputConnection inputConnection) {
        this.inputConnection = inputConnection;
        this.context = ctx;
        this.rootView = rootView;
        this.popup = new EmojiIconsPopup(rootView, ctx, useSystemEmoji);
    }

    public View GetViews() {
        return this.popup.getViewData();
    }

    public void setUseSystemEmoji(boolean useSystemEmoji) {
        this.useSystemEmoji = useSystemEmoji;
        refresh();
    }

    private void refresh() {
        popup.updateUseSystemDefault(useSystemEmoji);

    }

    public void ShowEmojiIcon() {
        popup.setOnEmojiIconClickedListener(emojiIcon -> {
            if (inputConnection == null || emojiIcon == null) {
                return;
            }
            inputConnection.commitText(emojiIcon.getEmoji(), 1);
        });
    }


}
