package com.messenger.sms.text.common.widget

import android.content.Context
import android.util.AttributeSet
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.core.view.isVisible
import androidx.core.view.updateLayoutParams
import com.domain.model.Recipient
import com.messenger.sms.text.common.util.extensions.LogE
import com.messenger.sms.text.common.util.extensions.customViewBinding
import com.messenger.sms.text.databinding.GroupAvatarViewBinding

class GroupAvatarView @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null
) : ConstraintLayout(context, attrs) {
    var recipients: List<Recipient> = ArrayList()
        set(value) {
            field = value.sortedWith(compareByDescending { contact -> contact.contact?.lookupKey })
            updateView()
        }

    val binding: GroupAvatarViewBinding = customViewBinding(GroupAvatarViewBinding::inflate)
//    init {
//        View.inflate(context, R.layout.group_avatar_view, this)
//    }

    private var TAG = "GroupAvatarView+++"

    override fun onFinishInflate() {
        super.onFinishInflate()

        if (!isInEditMode) {
            try {
                updateView()
            } catch (e: Exception) {
                LogE(TAG, "onFinishInflate: " + e.message.toString())
            }
        }
    }

    private fun updateView() {
        /* avatar1Frame.setBackgroundTint(when (recipients.size > 1) {
             true -> context.resolveThemeColor(android.R.attr.windowBackground)
             false -> context.getColorCompat(android.R.color.transparent)
         })*/

        try {
            if (recipients.size > 1) {
                binding.avatar2.isVisible = true
                recipients.getOrNull(1).run(binding.avatar2::setRecipient)
                binding.avatar1Frame.updateLayoutParams<LayoutParams> {
                    matchConstraintPercentWidth = 0.75f
                }
            } else {
                binding.avatar2.isVisible = false
                binding.avatar1Frame.updateLayoutParams<LayoutParams> {
                    matchConstraintPercentWidth = 1.0f
                }
            }
            recipients.getOrNull(0).run(binding.avatar1::setRecipient)

        } catch (e: Exception) {
            LogE(TAG, "updateView:-- " + e.message)
        }
    }

}
