package com.messenger.sms.text.feature.conversationinfo

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import androidx.core.view.ViewCompat
import androidx.activity.enableEdgeToEdge
import androidx.core.view.WindowInsetsCompat
import androidx.activity.OnBackPressedCallback
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.adconfig.adsutil.admob.BannerAdHelper
import com.messenger.sms.text.utils.gone
import dagger.android.AndroidInjection
import io.reactivex.Observable
import io.reactivex.subjects.PublishSubject
import io.reactivex.subjects.Subject
import io.realm.RealmList
import org.greenrobot.eventbus.EventBus
import org.greenrobot.eventbus.Subscribe
import org.greenrobot.eventbus.ThreadMode
import com.messenger.sms.text.R
import com.messenger.sms.text.common.Navigator
import com.messenger.sms.text.common.base.MessagesThemedActivity
import com.messenger.sms.text.common.util.AppUtils
import com.messenger.sms.text.common.widget.FieldDialog
import com.messenger.sms.text.feature.blocking.BlockingDialog
import com.messenger.sms.text.feature.compose.BubbleUtils
import com.messenger.sms.text.feature.compose.ComposeActivity
import com.messenger.sms.text.feature.contacts.ContactsActivity
import com.messenger.sms.text.feature.main.ConversationInfoViewModel
import com.messenger.sms.text.feature.main.MainActivity
import com.domain.interactor.model.PhoneNumber
import com.messenger.sms.text.common.CommonDialog
import com.adconfig.adsutil.admob.BannerAds
import com.messenger.sms.text.common.staticData.EventKeys
import com.messenger.sms.text.common.util.BaseConfig
import com.messenger.sms.text.common.util.extensions.LogW
import com.messenger.sms.text.common.util.extensions.viewBinding
import com.messenger.sms.text.databinding.ConversationInfoActivityBinding
import com.messenger.sms.text.event.ConversationEvent
import com.messenger.sms.text.event.SubscribeEvent

import com.domain.model.Contact
import com.google.android.gms.ads.AdView
import com.messenger.sms.text.utils.AdCache
import javax.inject.Inject

class ConversationInfoActivity : MessagesThemedActivity(), ConversationInfoView {


    @Inject
    lateinit var viewModelFactory: ViewModelProvider.Factory

    private val viewModel by lazy {
        ViewModelProvider(this, viewModelFactory)[ConversationInfoViewModel::class.java]
    }

    @Inject
    lateinit var blockingDialog: BlockingDialog

    @Inject
    lateinit var navigator: Navigator

    @Inject
    lateinit var adapter: ConversationInfoAdapter
    private val ARCHIVE_FROM_CONV_INFO: Int = 123456


    private val nameDialog: FieldDialog by lazy {
        FieldDialog(
            this, this.getString(R.string.info_name),
            this.getString(R.string.info_name), nameChangeSubject::onNext
        )
    }
    private val binding by viewBinding(ConversationInfoActivityBinding::inflate)
    override fun onCreate(savedInstanceState: Bundle?) {
        AndroidInjection.inject(this)
        super.onCreate(savedInstanceState)
        EventBus.getDefault().register(this)
        enableEdgeToEdge()
        setContentView(binding.root)
        ViewCompat.setOnApplyWindowInsetsListener(binding.root) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
        setSupportActionBar(binding.toolbar)
        loadBannerAd()
        conversationInfoActivity = this
        viewModel.bindView(this)
        BubbleUtils.BLOCK_BACK = false
        setTitle(R.string.info_title)
        showBackButton(true)
        initRecyclerView()
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                val intent = Intent()
                intent.putExtra("title", strTitle)
                setResult(Activity.RESULT_OK, intent)
                finish()
            }
        })
    }

    @Subscribe(sticky = true, threadMode = ThreadMode.MAIN)
    fun handleEvents(event: ConversationEvent) {
        when (event) {
            is SubscribeEvent -> {
                if (BaseConfig(this).ads_free) {
                    binding.admobBanner.gone()
                }
            }
        }
    }

    var mAdView: AdView?=null
    private fun loadBannerAd() {
        if (!BaseConfig(this@ConversationInfoActivity).ads_free
//            && MessagesApplication.remoteConfig.getBoolean(UtilsStaticData.isEnableAllPageBannerAds)
        ) {
//            if (!BannerAds.isRequestSend) {
//                BannerAds.loadAdmobBannerAds(
//                    this@ConversationInfoActivity,
//                    binding.admobBanner, getString(R.string.banner_conversation)
//                )
//            }
            val bannerAdId =
                if (appPrefs.isFirstTime) getString(R.string.banner_conversation)
                else getString(R.string.banner_conversation2)
            BannerAdHelper.showBanner(
                this@ConversationInfoActivity,
                binding.admobBanner,
                binding.admobBanner,
                bannerAdId,
                AdCache.conInfoAdView,
                { isLoaded, adView, message ->
                    mAdView = adView
                    AdCache.conInfoAdView = adView
                })
        }
    }

    override fun onPause() {
        super.onPause()
        mAdView?.pause()
        BannerAds.pauseAd()
    }

    override fun onDestroy() {
        super.onDestroy()
        EventBus.getDefault().unregister(this)
        BannerAds.destroyAd()
    }


    private fun initRecyclerView() {
        binding.recyclerView.adapter = adapter
        binding.recyclerView.layoutManager = LinearLayoutManager(this@ConversationInfoActivity, RecyclerView.HORIZONTAL, false)
//                .apply {
//                spanSizeLookup = object : GridLayoutManager.SpanSizeLookup() {
//                    override fun getSpanSize(position: Int): Int =
//                        if (adapter?.getItemViewType(position) == 2) 1 else 3
//                }

//        recyclerView.addItemDecoration(GridSpacingItemDecoration(adapter, this))
//        recyclerView.layoutManager = GridLayoutManager(this, 3).apply {
//            spanSizeLookup = object : GridLayoutManager.SpanSizeLookup() {
//                override fun getSpanSize(position: Int): Int =
//                    if (adapter.getItemViewType(position) == 2) 1 else 3
//            }
//        }
//
//        themedthis?.theme
//            ?.autoDisposable(scope())
//            ?.subscribe { recyclerView.scrapViews() }
    }

    companion object {
        var isMessageClicked: Boolean = false
        var strTitle: String = ""
        var conversationInfoActivity: ConversationInfoActivity? = null
    }

    override fun render(state: ConversationInfoState) {
        if (state.hasError) {
            this.finish()
            return
        }

        adapter.data = state.data

    }


    override fun callClicks(): Observable<Long> = adapter.callClicks
    override fun recipientClicks(): Observable<Long> = adapter.recipientClicks
    override fun recipientLongClicks(): Observable<Long> = adapter.recipientLongClicks
    override fun nameClicks(): Observable<*> = adapter.nameClicks

    private val nameChangeSubject: Subject<String> = PublishSubject.create()

    private val confirmDeleteSubject: Subject<Unit> = PublishSubject.create()
    override fun nameChanges(): Observable<String> = nameChangeSubject
    override fun notificationClicks(): Observable<*> = adapter.notificationClicks
    override fun archiveClicks(): Observable<*> = adapter.archiveClicks
    override fun copyClicks(): Observable<String> = adapter.copyClicks
    override fun messageClicks(): Observable<String> = adapter.messageClicks
    override fun blockClicks(): Observable<*> = adapter.blockClicks
    override fun deleteClicks(): Observable<*> = adapter.deleteClicks
    override fun confirmDelete(): Observable<*> = confirmDeleteSubject
    override fun mediaClicks(): Observable<Long> = adapter.mediaClicks

    override fun showNameDialog(name: String) = nameDialog.setText(name).show()

    override fun onResume() {
        super.onResume()
        mAdView?.resume()
        BannerAds.resumeAd()
        if (appPrefs.isContactChange) {
            appPrefs.isContactChange = false
            viewModel.syncContacts()
            Handler(Looper.getMainLooper()).postDelayed(
                {
                    adapter.notifyItemChanged(0)
                }, 2000
            )

        }
    }

    private fun loadAds() {
//        if (!BaseConfig(this).ads_free && isOnline && MessagesApplication.remoteConfig.getBoolean(
//                UtilsStaticData.isEnableBlockDialogIntAds
//            )
//        ) {
//            AdmobIntersAdImpl().load(this,getString(R.string.ads_inter))
//        }
    }

    override fun showBlockingDialog(
        conversations: List<Long>,
        block: Boolean,
        isTrue: (Boolean) -> Unit
    ) {
        var title = 0
        val btnText: Int
        var msgText = ""
        if (block) {
            title = R.string.blocking_block_title
            btnText = R.string.blocking_block_title
            msgText = resources!!.getString(R.string.blocked_messages_are)
        } else {
            title = R.string.blocking_unblock_title
            btnText = R.string.blocking_unblock_title
            msgText = resources!!.getString(R.string.unblocked_messages_are)
        }
        loadAds()
        CommonDialog(this).show(this, getString(title), msgText, getString(btnText), getString(R.string.button_cancel), "", onPositive = {
            if (block) {
                AppUtils.logAdapterMessages(
                    EventKeys.message_detail,
                    EventKeys.click,
                    EventKeys.details_block
                )
                BubbleUtils.BLOCK_BACK = true
            } else {
                AppUtils.logAdapterMessages(
                    EventKeys.message_detail,
                    EventKeys.click,
                    EventKeys.details_unblock
                )
            }
            blockingDialog.show(this@ConversationInfoActivity, conversations, block, isTrue)
        })
    }

    override fun requestDefaultSms() {
        navigator.showDefaultSmsDialog(this@ConversationInfoActivity)
    }

    @SuppressLint("LongLogTag")
    override fun showDeleteDialog() {
        try {
            CommonDialog(this).show(
                this, getString(R.string.dialog_delete_title), resources?.getQuantityString(R.plurals.dialog_delete_message, 1) ?: "", getString(R.string.button_delete),
                getString(R.string.button_cancel), "", onPositive = {
                    AppUtils.logAdapterMessages(
                        EventKeys.message_detail,
                        EventKeys.click,
                        EventKeys.details_delete_conversations
                    )
                    confirmDeleteSubject.onNext(Unit)
                })
        } catch (e: Exception) {
            LogW("ConversationaInfoController+++", e.message.toString())
        }
    }

    override fun messageToThisNumber(number: String, isGroup: Boolean) {
        if (isGroup) {
            val threadId = viewModel.conversationRepo.getThreadId(number)
            if (threadId != null) {
                val intent = Intent(this, ComposeActivity::class.java)
                    .putExtra("threadId", threadId)
                startActivity(intent)
            } else {
                val newContact =
                    Contact(name = number, numbers = RealmList(PhoneNumber(address = number)))
                val address =
                    newContact.getDefaultNumber()?.address ?: newContact.numbers[0]!!.address
                val hashMap = HashMap<String, String>().apply {
                    put(address, newContact.lookupKey)
                }
                val intent = Intent(this, ComposeActivity::class.java)
                    .putExtra(ContactsActivity.ChipsKey, hashMap)
                startActivity(intent)
                /* val intent = Intent().putExtra(ContactsActivity.ChipsKey, hashMap)
                 setResult(Activity.RESULT_OK, intent)
                 finish()*/
            }

        } else {
            onBackPressedDispatcher.onBackPressed()
        }
    }

//    override fun setReceipentName(conversationName: String?) {
//        adapter.notifyItemChanged(0)
//    }

    override fun onBackPressed() {
        finish()
    }

    fun showHome() {
        val intent = Intent(this@ConversationInfoActivity, MainActivity::class.java)
        startActivityForResult(intent, ARCHIVE_FROM_CONV_INFO)
        finish()
    }

}