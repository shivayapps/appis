package com.messenger.sms.text.common.util.extensions

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.appcompat.app.AppCompatActivity
import androidx.viewbinding.ViewBinding


inline fun <T : ViewBinding> AppCompatActivity.viewBinding(crossinline bindingInflater: (LayoutInflater) -> T, ): Lazy<T> = lazy(LazyThreadSafetyMode.NONE) {
    bindingInflater(layoutInflater)
}

inline fun <T : ViewBinding> ViewGroup.customViewBinding(crossinline bindingInflater: (LayoutInflater, ViewGroup) -> T): T {
    return bindingInflater(LayoutInflater.from(context), this)
}