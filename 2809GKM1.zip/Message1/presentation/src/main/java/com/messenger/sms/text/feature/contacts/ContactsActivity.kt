package com.messenger.sms.text.feature.contacts

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.util.Log
import androidx.core.view.ViewCompat
import androidx.activity.enableEdgeToEdge
import androidx.core.view.WindowInsetsCompat
import androidx.core.content.ContextCompat
import androidx.core.view.isVisible
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import com.adconfig.AdsConfig
import com.adconfig.adsutil.AdsParameters
import com.adconfig.adsutil.Config
import com.adconfig.adsutil.admob.AdmobIntersAdImpl
import com.jakewharton.rxbinding2.view.clicks
import com.jakewharton.rxbinding2.widget.textChanges
import com.messenger.sms.text.utils.gone
import com.messenger.sms.text.utils.toastMsg
import com.messenger.sms.text.utils.visible
import dagger.android.AndroidInjection
import io.reactivex.Observable
import io.reactivex.subjects.PublishSubject
import io.reactivex.subjects.Subject
import com.messenger.sms.text.R
import com.messenger.sms.text.common.Navigator
import com.messenger.sms.text.common.ViewModelFactory
import com.messenger.sms.text.common.base.MessagesThemedActivity
import com.messenger.sms.text.common.util.extensions.*
import com.messenger.sms.text.common.widget.MessagesDialog
import com.messenger.sms.text.feature.compose.editing.ComposeItem
import com.messenger.sms.text.feature.compose.editing.ComposeItemAdapter
import com.messenger.sms.text.feature.compose.editing.PhoneNumberAction
import com.messenger.sms.text.feature.compose.editing.PhoneNumberPickerAdapter
import com.messenger.sms.text.common.util.extensions.LogW
import com.messenger.sms.text.databinding.ContactsActivityBinding
import com.messenger.sms.text.utils.loadListAds
import com.common.extensions.resolveThemeColor
import com.domain.extensions.Optional
import java.util.HashMap
import javax.inject.Inject

open class ContactsActivity : MessagesThemedActivity(), ContactsContract {

    companion object {
        const val SharingKey = "sharing"
        const val ChipsKey = "chips"
    }

    @Inject
    lateinit var contactsAdapter: ComposeItemAdapter

    @Inject
    lateinit var phoneNumberAdapter: PhoneNumberPickerAdapter

    @Inject
    lateinit var viewModelFactory: ViewModelFactory

    @Inject
    lateinit var navigator: Navigator

    override val queryChangedIntent: Observable<CharSequence> by lazy { binding.search.textChanges() }
    override val queryClearedIntent: Observable<*> by lazy { binding.cancel.clicks() }

    //    override val queryEditorActionIntent: Observable<Int> by lazy { search.editorActions() }
    override val composeItemPressedIntent: Subject<ComposeItem> by lazy { contactsAdapter.clicks }
    override val composeItemLongPressedIntent: Subject<ComposeItem> by lazy { contactsAdapter.longClicks }
    override val phoneNumberSelectedIntent: Subject<Optional<Long>> by lazy { phoneNumberAdapter.selectedItemChanges }
    override val phoneNumberActionIntent: Subject<PhoneNumberAction> = PublishSubject.create()


    private val viewModel by lazy {
        ViewModelProvider(
            this,
            viewModelFactory
        )[ContactsViewModel::class.java]
    }

    private val phoneNumberDialog by lazy {
        MessagesDialog(this@ContactsActivity).apply {
            titleRes = R.string.compose_number_picker_title
            adapter = phoneNumberAdapter
            positiveButton = R.string.compose_number_picker_always
            positiveButtonListener = {
                if (phoneNumberAdapter.checkAnySelected()) {
                    phoneNumberActionIntent.onNext(PhoneNumberAction.ALWAYS)
                } else {
                    toastMsg(resources.getString(R.string.compose_number_picker_title))
                }
            }
            negativeButton = R.string.compose_number_picker_once
            negativeButtonListener = {
                if (phoneNumberAdapter.checkAnySelected()) {
                    phoneNumberActionIntent.onNext(PhoneNumberAction.JUST_ONCE)
                } else {
                    toastMsg(resources.getString(R.string.compose_number_picker_title))
                }
            }
            cancelListener = {
                Log.e("JASH---", "cancelListener-------------: ")
                phoneNumberActionIntent.onNext(PhoneNumberAction.CANCEL)
            }
        }
    }
    private val binding by viewBinding(ContactsActivityBinding::inflate)
    @SuppressLint("ResourceType")
    override fun onCreate(savedInstanceState: Bundle?) {
        AndroidInjection.inject(this)
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(binding.root)
        ViewCompat.setOnApplyWindowInsetsListener(binding.root) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
        setSupportActionBar(binding.toolbar)
        showBackButton(true)
        viewModel.bindView(this)
        val nativeAdId =
            if (appPrefs.isFirstTime) getString(R.string.native_contact)
            else getString(R.string.native_contact2)
        loadListAds(binding.flListAds, nativeAdId,false)
        loadAds()
        binding.contacts.adapter = contactsAdapter
        binding.contacts.layoutManager = LinearLayoutManager(this@ContactsActivity)

        binding.contacts.setPreviewTextColor(R.color.text_theme_color)
        binding.contacts.setPreviewColor(R.color.contactSelectBack)
        binding.contacts.setIndexBarColor(R.color.contactSliderBack)
        binding.contacts.setIndexBarCornerRadius(10)
        binding.contacts.setPreviewVisibility(true)
//        contacts.setIndexbarMargin(15F)
        binding.contacts.setIndexbarHorizontalMargin(15F)
        binding.contacts.setIndexbarTopMargin(5F)
        binding.contacts.setIndexbarBottomMargin(95F)
        binding.contacts.setIndexTextSize(11)
        binding.contacts.setIndexBarHighLightTextVisibility(true)
        binding.contacts.setIndexbarHighLightTextColor(R.color.color_app_theme)
        binding.contacts.setIndexBarTextColor(R.color.contactSubtitle)
        binding.contacts.setIndexBarTransparentValue(0.5.toFloat())
        binding.contacts.layoutManager!!.scrollToPosition(0)
        toolbar.background = ContextCompat.getDrawable(this, R.drawable.grey_bg_light)


        // These theme attributes don't apply themselves on API 21
        if (Build.VERSION.SDK_INT <= 22) {
            binding.search.setBackgroundTint(resolveThemeColor(R.attr.bubbleColor))
        }
        binding.ivDial.setOnClickListener {
            binding.ivDial.gone()
            binding.ivKeyboard.visible()
            openNumericKeyboard()
        }
        binding.ivKeyboard.setOnClickListener {
            binding.ivDial.visible()
            binding.ivKeyboard.gone()
            openKeyboard()
        }
        binding.search.setOnClickListener {
            if (binding.ivDial.isVisible)
                openKeyboard()
            else
                openNumericKeyboard()
        }
        binding.contacts.setIndexBarVisibility(true)
    }

    override fun render(state: ContactsState) {
        binding.cancel.isVisible = state.query.length > 1

        LogW("messageApp : ", "render :" + state.composeItems.size)
        if (state.composeItems.isEmpty()) {
            binding.tvContactNoData.visible()
            binding.flListAds.gone()
        } else {
            binding.tvContactNoData.gone()
            binding.flListAds.visible()
        }
        contactsAdapter.data = state.composeItems
//        contactsAdapter.data1 = state.composeItems

        if (state.selectedContact != null && !phoneNumberDialog.isShowing) {
            phoneNumberAdapter.data = state.selectedContact.numbers
            phoneNumberDialog.subtitle = state.selectedContact.name
            phoneNumberDialog.show()
        } else if (state.selectedContact == null && phoneNumberDialog.isShowing) {
            phoneNumberDialog.dismiss()
        }
        contactsAdapter.notifyDataSetChanged()
    }


    override fun clearQuery() {
        binding.search.setText("")
    }

    override fun openNumericKeyboard() {
        binding.search.postDelayed({
            binding.search.openNumericKeyboard()
        }, 200)
    }

    override fun openKeyboard() {
        binding.search.postDelayed({
            binding.search.showKeyboard()
        }, 200)
    }

    override fun finish(result: HashMap<String, String>) {
        Log.e("JASh---", "finish: ---------")
        binding.search.hideKeyboard()
        val intent = Intent().putExtra(ChipsKey, result)
        setResult(Activity.RESULT_OK, intent)
        finish()
    }

    private fun loadAds() {
        val adId =
            if (appPrefs.isFirstTime) getString(R.string.inter_backpress)
            else getString(R.string.inter_backpress2)
        if(AdsParameters(this).isNeedInterAd && Config.checkInterAd()) {
            AdmobIntersAdImpl().load(this, adId)
        }
    }
    override fun onBackPressed() {
        binding.search.hideKeyboard()
        if (binding.search.text.toString().isNotEmpty()) {
            binding.search.setText("")
        } else {

            if (Config.checkInterAd()) {
                AdsConfig.showInterstitialAd(this) {
                    navigator.showHome()
                    finish()
                    overridePendingTransition(
                        R.anim.slide_down_reverse,
                        R.anim.slide_up_reverse
                    )
                }
            } else {
                navigator.showHome()
                finish()
            }

        }
    }

}
