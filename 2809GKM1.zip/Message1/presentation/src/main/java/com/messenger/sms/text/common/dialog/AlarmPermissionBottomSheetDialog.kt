package com.messenger.sms.text.common.dialog

import android.app.Dialog
import android.content.Context
import android.content.DialogInterface
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.view.WindowManager
import androidx.core.content.ContextCompat
import androidx.fragment.app.DialogFragment
import com.messenger.sms.text.databinding.BottomDialogAlarmPermissionBinding

class AlarmPermissionBottomSheetDialog(
    context: Context
) : Dialog(context) {
    var btnClickListener: ((Int) -> Unit?)? = null


    lateinit var bindingDialog: BottomDialogAlarmPermissionBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestWindowFeature(Window.FEATURE_NO_TITLE)
        window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        window?.addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND)
        window?.setDimAmount(0.8f)

        window?.setGravity(Gravity.BOTTOM)
        bindingDialog = BottomDialogAlarmPermissionBinding.inflate(layoutInflater)
        setContentView(bindingDialog.root)
        window?.setLayout(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.WRAP_CONTENT
        )
        initListener() // Ensure listeners are set up properly
    }


    private fun initListener() {
        bindingDialog.llAllow.setOnClickListener {
            btnClickListener?.invoke(0)
            dismiss()
        }
        bindingDialog.llDeny.setOnClickListener {
//            btnClickListener?.invoke(1)
            dismiss()
        }
    }
}