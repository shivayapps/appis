package com.messenger.sms.text.feature.backup

import android.content.Context
import android.content.SharedPreferences
import android.preference.PreferenceManager
import android.util.Log
import android.view.View
import androidx.core.graphics.Insets
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.messenger.sms.text.utils.LOG_TAG

import com.google.gson.Gson
import com.google.gson.JsonSyntaxException
import com.google.gson.reflect.TypeToken
//import kotlinx.serialization.SerializationException
//import kotlinx.serialization.json.Json

const val SMS = 0
const val MMS = 1

// Helper function for implementing insets callbacks to change the view's margins or padding to
// avoid obstructions, like the status bar, navigation bar, or physical notches.
fun View.avoidObstructions(block: View.(Insets) -> Unit) {
    ViewCompat.setOnApplyWindowInsetsListener(this) { v, windowInsets ->
        val insets = windowInsets.getInsets(
            WindowInsetsCompat.Type.systemBars()
                    or WindowInsetsCompat.Type.displayCutout()
        )

        block(insets)

        windowInsets
    }
}


data class MessageFilter(
    val column: String, val operator: String, val value: String, val active: Boolean
) {
    override fun toString(): String {
        return "$column $operator \"$value\" [${if (active) "Active" else "Inactive"}]"
    }
}

private fun getMessageFilters(prefs: SharedPreferences, list: ArrayList<MessageFilter>) {
    val messageFilters = prefs.getString("message_filters", "[]")
//    if (messageFilters != null) {
//        try {
//            list.addAll(Json.decodeFromString<ArrayList<MessageFilter>>(messageFilters))
//        } catch (e: SerializationException) {
//            Log.e(LOG_TAG, "Deserialization error\n$e")
//        }
//    }
    if (messageFilters != null) {
        try {
            val type = object : TypeToken<ArrayList<MessageFilter>>() {}.type
            val parsedList: ArrayList<MessageFilter> = Gson().fromJson(messageFilters, type)
            list.addAll(parsedList)
        } catch (e: JsonSyntaxException) {
            Log.e(LOG_TAG, "Deserialization error\n$e")
        }
    }
}

fun messageSelection(appContext: Context, messageType: Int): String? {
    val prefs = PreferenceManager.getDefaultSharedPreferences(appContext)
    val selection = if (prefs.getBoolean("message_filtering", false)) {
        val list = arrayListOf<MessageFilter>()
        getMessageFilters(prefs, list)
        Log.d(LOG_TAG, list.toString())
        list.filter {
            it.active && ((messageType == SMS && !it.column.startsWith("mms.")) || (messageType == MMS && !it.column.startsWith(
                "sms."
            )))
        }.joinToString(separator = " AND ") {
            var value = it.value
            if (it.column == "date" || it.column == "date_sent") {
                if (messageType == SMS && value.length <= 11) value = value + "000"
                else if (messageType == MMS && value.length > 11) value = value.dropLast(3)
            }
            "${it.column.substringAfter('.')} ${it.operator} $value"
        }
    } else null
    Log.d(LOG_TAG, "${if (messageType == SMS) "SMS" else "MMS"} selection: $selection")
    return selection
}