package com.messenger.sms.text.common.widget

import android.app.Activity
import android.content.DialogInterface
import android.util.Log
import android.view.LayoutInflater
import androidx.appcompat.app.AlertDialog
import androidx.core.content.ContextCompat
import com.messenger.sms.text.R
import com.messenger.sms.text.common.util.AppUtils
import com.messenger.sms.text.common.staticData.EventKeys
import com.messenger.sms.text.common.util.extensions.LogE
import com.messenger.sms.text.databinding.FieldDialogBinding

class FieldDialog(context: Activity, title: String, hint: String, listener: (String) -> Unit) :
    AlertDialog(context, R.style.FieldTheme) {

//    private val layout = LayoutInflater.from(context).inflate(R.layout.field_dialog, null)
    val layout: FieldDialogBinding = FieldDialogBinding.inflate(LayoutInflater.from(context))

    init {
        layout.field.hint = hint
        setView(layout.root)
        setTitle(title)
//        val titleTextView: TextView = layout.findViewById(R.id.title) as TextView
//        titleTextView.setTextColor(ContextCompat.getColor(context, R.color.red))
        setButton(
            DialogInterface.BUTTON_NEUTRAL, context.getString(R.string.button_cancel)
        ) { _, _ ->
            LogE("FieldDialog:", "-------------: button_cancel---${hint}")
        }

        setButton(
            DialogInterface.BUTTON_NEGATIVE, context.getString(R.string.button_delete)
        ) { _, _ -> listener("")
            if(context.resources.getString(R.string.settings_signature_hint) == hint){
                AppUtils.logAdapterMessages(
                    EventKeys.settings,
                    EventKeys.delete,
                    EventKeys.general_sign
                )
            }
        }

        setButton(
            DialogInterface.BUTTON_POSITIVE, context.getString(R.string.button_save)
        ) { _, _ ->
            listener(layout.field.text.toString())
            if(context.resources.getString(R.string.settings_signature_hint) == hint){
                AppUtils.logAdapterMessages(
                    EventKeys.settings,
                    EventKeys.save,
                    EventKeys.general_sign
                )
            }

        }

        setOnShowListener {
            getButton(BUTTON_POSITIVE).setTextColor(
                ContextCompat.getColor(
                    context,
                    R.color.color_app_theme
                )
            )
            getButton(BUTTON_NEGATIVE).setTextColor(
                ContextCompat.getColor(
                    context,
                    R.color.color_app_theme
                )
            )
            getButton(BUTTON_NEUTRAL).setTextColor(
                ContextCompat.getColor(
                    context,
                    R.color.color_app_theme
                )
            )
        }
    }

    fun setText(text: String): FieldDialog {
        try {
            layout.field.setText(text)
            layout.field.setSelection(text.length)
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return this
    }

}
