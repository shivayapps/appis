package com.messenger.sms.text.common.widget

import android.content.Context
import android.content.res.ColorStateList
import android.util.AttributeSet
import androidx.appcompat.widget.SwitchCompat
import androidx.core.content.ContextCompat
import com.messenger.sms.text.R
import com.messenger.sms.text.injection.appComponent
import com.domain.util.Preferences
import javax.inject.Inject

class MessagesSwitch @JvmOverloads constructor(context: Context, attrs: AttributeSet? = null) :
    SwitchCompat(context, attrs) {

    @Inject
    lateinit var prefs: Preferences

    init {
        if (!isInEditMode) {
            appComponent.inject(this)
        }
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()

        if (!isInEditMode) {
            val states = arrayOf(
                intArrayOf(-android.R.attr.state_checked),
                intArrayOf(android.R.attr.state_checked),
            )

            val colors = intArrayOf(
                ContextCompat.getColor(context,R.color.switchThumbDisabledLight),
                ContextCompat.getColor(context,R.color.tools_theme),
            )

            val colorsTrack = intArrayOf(
                ContextCompat.getColor(context,R.color.switchTrackDisabledLight),
                ContextCompat.getColor(context,R.color.tools_theme_trans),
            )

            thumbTintList = ColorStateList(
                states, colors
            )

            trackTintList = ColorStateList(
                states, colorsTrack
            )
        }
    }
}