package com.messenger.sms.text.common.widget

import android.content.Context
import android.graphics.Color
import android.util.AttributeSet
import android.util.TypedValue
import android.view.View
import android.widget.FrameLayout
import androidx.core.content.ContextCompat
import com.messenger.sms.text.R
import com.messenger.sms.text.common.Navigator
import com.messenger.sms.text.common.util.extensions.setBackgroundTint
import com.messenger.sms.text.injection.appComponent
import com.domain.model.Recipient
import com.bumptech.glide.Glide
import com.domain.util.Preferences
import com.messenger.sms.text.common.util.extensions.LogV
import com.messenger.sms.text.common.util.extensions.customViewBinding
import com.messenger.sms.text.databinding.AvatarViewBinding

import javax.inject.Inject

class AvatarView @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null
) : FrameLayout(context, attrs) {

    @Inject
    lateinit var preferences: Preferences

    @Inject
    lateinit var navigator: Navigator

    private var lookupKey: String? = null
    private var name: String? = null
    private var photoUri: String? = null
    private var lastUpdated: Long? = null

    val binding: AvatarViewBinding = customViewBinding(AvatarViewBinding::inflate)

    init {
        if (!isInEditMode) {
            appComponent.inject(this)
        }


        View.inflate(context, R.layout.avatar_view, this)
        setBackgroundResource(R.drawable.circle)
        clipToOutline = true
    }

    fun setMaxTextSize(size: Int) {
//        binding.initial.setAutoSizeTextTypeUniformWithConfiguration(
//            18,
//            size,
//            1,
//            TypedValue.COMPLEX_UNIT_DIP
//        )
    }

    /**
     * Use the [contact] information to display the avatar.
     */
    fun setRecipient(recipient: Recipient?) {
        lookupKey = recipient?.contact?.lookupKey
        name = recipient?.getDisplayName()
        photoUri = recipient?.contact?.photoUri
        lastUpdated = recipient?.contact?.lastUpdate
        updateView()
    }

    override fun onFinishInflate() {
        super.onFinishInflate()

        if (!isInEditMode) {
            updateView()
        }
    }

    private fun updateView() {
        val darkColors = context.resources.getStringArray(R.array.colors_dark)
        var choice: Double = (0.1 * darkColors.size)

        if (name?.isNotEmpty() == true) {
            val initials = name
                ?.substringBefore(',')
                ?.split(" ").orEmpty()
                .filter { name -> name.isNotEmpty() }
                .map { name -> name[0] }
                .filter { initial -> initial.isLetter() }
                .map { initial -> initial.toString() }

            try {
                if (initials.isNotEmpty()) {
                    LogV("TAG", "$name initials: $initials")
                    val char =
                        if (initials.size > 1) initials.first() /*+ initials.last()*/ else initials.first()
                    choice = char[0].uppercaseChar().code.toDouble().mod(5F)
                    binding.initial.text = char
                    binding.icon.visibility = GONE
                } else {
                    binding.initial.text = null
                    binding.icon.visibility = VISIBLE
                }
            } catch (e: Exception) {
                e.printStackTrace()
                LogV("TAG", "Name: $name ")
                binding.initial.text = null
                binding.icon.visibility = VISIBLE
            }
        } else {
            LogV("TAG", "$name initials:")
            binding.initial.text = null
            binding.icon.visibility = VISIBLE
        }

        if (preferences.autoColor.get()) {
            setBackgroundTint(Color.parseColor(darkColors[choice.toInt()]))
        } else {
            setBackgroundTint(ContextCompat.getColor(context, R.color.color_app_theme))
        }


        binding.photo.setImageDrawable(null)
        if (photoUri != null && photoUri!!.isNotEmpty()) {
            photoUri?.let { photoUri ->
                Glide.with(binding.photo)
                    .load(photoUri)
                    .into(binding.photo)
            }
            binding.icon.visibility = GONE
            binding.initial.visibility = GONE
        } else {
            binding.initial.visibility = VISIBLE
        }
    }

}
