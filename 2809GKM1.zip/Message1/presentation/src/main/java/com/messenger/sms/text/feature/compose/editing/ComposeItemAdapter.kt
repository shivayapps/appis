package com.messenger.sms.text.feature.compose.editing

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.core.text.TextUtilsCompat
import androidx.core.view.ViewCompat
import androidx.core.view.isVisible
import androidx.recyclerview.widget.RecyclerView
import io.reactivex.disposables.CompositeDisposable
import io.reactivex.rxkotlin.plusAssign
import io.reactivex.subjects.PublishSubject
import io.reactivex.subjects.Subject

import com.messenger.sms.text.R
import com.messenger.sms.text.common.base.MessagesAdapter
import com.messenger.sms.text.common.base.MessagesViewHolder
import com.messenger.sms.text.common.util.extensions.forwardTouches
import com.messenger.sms.text.common.util.extensions.setTint
//import com.messenger.sms.text.extensions.associateByNotNull
//import com.messenger.sms.text.model.Contact
//import com.messenger.sms.text.model.ContactGroup
import com.domain.model.Conversation
import com.domain.model.Recipient
import com.domain.repository.ConversationRepository
import com.domain.util.Preferences
import com.messenger.sms.text.common.util.extensions.LogE
import com.messenger.sms.text.common.util.extensions.LogW
import com.messenger.sms.text.databinding.ContactListItemBinding
import com.data.extensions.associateByNotNull
import com.domain.model.Contact
import com.domain.model.ContactGroup
import java.util.*
import javax.inject.Inject

class ComposeItemAdapter @Inject constructor(
    private val conversationRepo: ConversationRepository
) : MessagesAdapter<ComposeItem, ContactListItemBinding>() {
    private val TAG = "ComposeItemAdapter++"
    val clicks: Subject<ComposeItem> = PublishSubject.create()
    val longClicks: Subject<ComposeItem> = PublishSubject.create()

    private val numbersViewPool = RecyclerView.RecycledViewPool()
    private val disposables = CompositeDisposable()

    @Inject
    lateinit var prefs: Preferences

    var recipients: Map<String, Recipient> = mapOf()
        set(value) {
            field = value
            notifyDataSetChanged()
        }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MessagesViewHolder<ContactListItemBinding> {
        return MessagesViewHolder(parent, ContactListItemBinding::inflate).apply {
            binding.numbers.setRecycledViewPool(numbersViewPool)
            binding.numbers.adapter = PhoneNumberAdapter()
            binding.numbers.forwardTouches(binding.root)

            binding.root.setOnClickListener {
                val item = getItem(adapterPosition)
                clicks.onNext(item)
            }
            binding.root.setOnLongClickListener {
                val item = getItem(adapterPosition)
                longClicks.onNext(item)
                true
            }
        }
    }

    override fun onBindViewHolder(holder: MessagesViewHolder<ContactListItemBinding>, position: Int) {
        val prevItem = if (position > 0) getItem(position - 1) else null

        when (val item = getItem(position)) {
            is ComposeItem.New -> bindNew(holder, item.value)
            is ComposeItem.Recent -> bindRecent(holder, item.value, prevItem)
            is ComposeItem.Starred -> bindStarred(holder, item.value, prevItem)
            is ComposeItem.Person -> bindPerson(holder, item.value, prevItem)
            is ComposeItem.Group -> bindGroup(holder, item.value, prevItem)
            else -> {
                return
            }
        }
    }

    private fun bindNew(holder: MessagesViewHolder<ContactListItemBinding>, contact: Contact) {
        holder.binding.index.isVisible = false

        holder.binding.icon.isVisible = false

        holder.binding.avatar.recipients = listOf(createRecipient(contact))

        holder.binding.title.text = contact.numbers.joinToString { it.address }

        holder.binding.subtitle.isVisible = false

        holder.binding.numbers.isVisible = false
    }

    private fun bindRecent(
        holder: MessagesViewHolder<ContactListItemBinding>,
        conversation: Conversation,
        prev: ComposeItem?,
    ) {
        holder.binding.index.isVisible = false

        holder.binding.icon.isVisible = prev !is ComposeItem.Recent
        holder.binding.icon.setImageResource(R.drawable.ic_history_black_24dp)

        holder.binding.avatar.recipients = conversation.recipients

        holder.binding.title.text = conversation.getTitle()

        holder.binding.subtitle.isVisible =
            conversation.recipients.size > 1 && conversation.name.isBlank()
        holder.binding.subtitle.text = conversation.recipients.joinToString(", ") { recipient ->
            recipient.contact?.name ?: recipient.address
        }
        holder.binding.subtitle.collapseEnabled = conversation.recipients.size > 1

        holder.binding.numbers.isVisible = conversation.recipients.size == 1
        (holder.binding.numbers.adapter as PhoneNumberAdapter).data = conversation.recipients
            .mapNotNull { recipient -> recipient.contact }
            .flatMap { contact -> contact.numbers }
    }
    private fun bindStarred(
        holder: MessagesViewHolder<ContactListItemBinding>,
        contact: Contact,
        prev: ComposeItem?,
    ) {
        holder.binding.index.isVisible = false

        holder.binding.icon.isVisible = prev !is ComposeItem.Starred
        holder.binding.icon.setImageResource(R.drawable.ic_star_black_24dp)

        holder.binding.avatar.recipients = listOf(createRecipient(contact))

        holder.binding.title.text = contact.name

        holder.binding.subtitle.isVisible = false

        holder.binding.numbers.isVisible = true
        (holder.binding.numbers.adapter as PhoneNumberAdapter).data = contact.numbers
    }

    private fun bindGroup(
        holder: MessagesViewHolder<ContactListItemBinding>,
        group: ContactGroup,
        prev: ComposeItem?,
    ) {
        holder.binding.index.isVisible = false

        holder.binding.icon.isVisible = prev !is ComposeItem.Group
        holder.binding.icon.setImageResource(R.drawable.ic_people_black_24dp)

        holder.binding.avatar.recipients = group.contacts.map(::createRecipient)

        holder.binding.title.text = group.title

        holder.binding.subtitle.isVisible = true
        holder.binding.subtitle.text = group.contacts.joinToString(", ") { it.name }
        holder.binding.subtitle.collapseEnabled = group.contacts.size > 1

        holder.binding.numbers.isVisible = false
    }

    private fun bindPerson(
        holder: MessagesViewHolder<ContactListItemBinding>,
        contact: Contact,
        prev: ComposeItem?,
    ) {
        holder.binding.index.isVisible = true
        holder.binding.index.text =
            if (contact.name.getOrNull(0)?.isLetter() == true) contact.name[0].toString() else "#"
        holder.binding.index.isVisible = prev !is ComposeItem.Person ||
                (contact.name[0].isLetter() && !contact.name[0].equals(
                    prev.value.name[0],
                    ignoreCase = true
                )) ||
                (!contact.name[0].isLetter() && prev.value.name[0].isLetter())

        holder.binding.icon.isVisible = false

        holder.binding.avatar.recipients = listOf(createRecipient(contact))

        holder.binding.title.text = contact.name

        holder.binding.subtitle.isVisible = false

        holder.binding.numbers.isVisible = true
        (holder.binding.numbers.adapter as PhoneNumberAdapter).data = contact.numbers
    }

    private fun createRecipient(contact: Contact): Recipient {
        return recipients[contact.lookupKey] ?: Recipient(
            address = contact.numbers.firstOrNull()?.address ?: "",
            contact = contact
        )
    }

    override fun onAttachedToRecyclerView(recyclerView: RecyclerView) {
        disposables += conversationRepo.getUnmanagedRecipients()
            .map { recipients -> recipients.associateByNotNull { recipient -> recipient.contact?.lookupKey } }
            .subscribe { recipients -> this@ComposeItemAdapter.recipients = recipients }
    }

    override fun onDetachedFromRecyclerView(recyclerView: RecyclerView) {
        disposables.clear()
    }

    override fun areItemsTheSame(old: ComposeItem, new: ComposeItem): Boolean {
        return if (old !is ComposeItem.Recent && new !is ComposeItem.Recent) {
            val oldIds = old.getContacts().map { contact -> contact.lookupKey }
            val newIds = new.getContacts().map { contact -> contact.lookupKey }
            oldIds == newIds
        } else {
            false
        }
    }

    override fun areContentsTheSame(old: ComposeItem, new: ComposeItem): Boolean {
        return false
    }

}
