package com.messenger.sms.text.emoji_view_library.Helper;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.res.TypedArray;
import android.text.style.DynamicDrawableSpan;
import android.util.AttributeSet;

import com.messenger.sms.text.R;


public class EmojiIconMultiAutoCompleteTextView extends androidx.appcompat.widget.AppCompatMultiAutoCompleteTextView {
    private int mEmojiIconSize;
    private int mEmojiIconAlignment;
    private int mEmojiIconTextSize;
    private boolean mUseSystemDefault = false;

    public EmojiIconMultiAutoCompleteTextView(Context context) {
        super(context);
        mEmojiIconSize = (int) getTextSize();
        mEmojiIconTextSize = (int) getTextSize();
    }

    public EmojiIconMultiAutoCompleteTextView(Context context, AttributeSet attrs) {
        super(context, attrs);
        init(attrs);
    }

    public EmojiIconMultiAutoCompleteTextView(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
        init(attrs);
    }

    private void init(AttributeSet attrs) {
        @SuppressLint("CustomViewStyleable") TypedArray a = getContext().obtainStyledAttributes(attrs, R.styleable.Emojicon);
        mEmojiIconSize = (int) a.getDimension(R.styleable.Emojicon_emojiconSize, getTextSize());
        mEmojiIconAlignment = a.getInt(R.styleable.Emojicon_emojiconAlignment, DynamicDrawableSpan.ALIGN_BASELINE);
        mUseSystemDefault = a.getBoolean(R.styleable.Emojicon_emojiconUseSystemDefault, false);
        a.recycle();
        mEmojiIconTextSize = (int) getTextSize();
        setText(getText());
    }

    @Override
    protected void onTextChanged(CharSequence text, int start, int lengthBefore, int lengthAfter) {
        updateText();
    }

    private void updateText() {
        EmojiIconHandler.addEmojis(getContext(), getText(), mEmojiIconSize, mEmojiIconAlignment, mEmojiIconTextSize, mUseSystemDefault);
    }

}
