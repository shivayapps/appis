package com.messenger.sms.text.feature.compose.part

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.viewbinding.ViewBinding
import io.reactivex.Observable

import com.messenger.sms.text.common.base.MessagesAdapter
import com.messenger.sms.text.common.base.MessagesViewHolder
import com.messenger.sms.text.common.util.extensions.forwardTouches
import com.messenger.sms.text.databinding.MessageListItemInBinding
import com.data.extensions.isSmil
import com.data.extensions.isText
import com.messenger.sms.text.feature.compose.BubbleUtils.canGroup
import com.messenger.sms.text.feature.compose.part.FileBinder
import com.messenger.sms.text.feature.compose.part.MediaBinder
import com.messenger.sms.text.feature.compose.part.VCardBinder
import com.domain.model.Message
import com.domain.model.MmsPart
import javax.inject.Inject

class PartsAdapter @Inject constructor(
    fileBinder: FileBinder,
    mediaBinder: MediaBinder,
    vCardBinder: VCardBinder
) : MessagesAdapter<MmsPart, ViewBinding>() {

    private val partBinders = listOf(mediaBinder, vCardBinder, fileBinder)

   /* var theme: Colors.Theme = colors.theme()
        set(value) {
            field = value
            partBinders.forEach { binder -> binder.theme = value }
        }*/

    val clicks: Observable<Long> = Observable.merge(partBinders.map { it.clicks })

    private lateinit var message: Message
    private var previous: Message? = null
    private var next: Message? = null
    private var holder: MessagesViewHolder<MessageListItemInBinding>? = null
    private var bodyVisible: Boolean = true

    fun setData(message: Message, previous: Message?, next: Message?, holder: MessagesViewHolder<MessageListItemInBinding>) {
        this.message = message
        this.previous = previous
        this.next = next
        this.holder = holder
        this.bodyVisible = holder.binding.body.visibility == View.VISIBLE
        this.data = message.parts.filter { !it.isSmil() && !it.isText() }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MessagesViewHolder<ViewBinding> {
//    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MessagesViewHolder<MessageListItemInBinding> {
        return MessagesViewHolder(parent, partBinders[viewType].bindingInflater).apply {
            holder?.binding?.root?.let(binding.root::forwardTouches)
        }
//        val layout = partBinders.getOrNull(viewType)?.partLayout ?: 0
//        val view = LayoutInflater.from(parent.context).inflate(layout, parent, false)
//        holder?.binding.containerView?.let(view::forwardTouches)
//        holder?.binding?.root?.let(binding.root::forwardTouches)
//        return MessagesViewHolder(view)
    }

    override fun onBindViewHolder(holder: MessagesViewHolder<ViewBinding>, position: Int) {
//    override fun onBindViewHolder(holder: MessagesViewHolder<MessageListItemInBinding>, position: Int) {
        val part = data[position]

        val canGroupWithPrevious = canGroup(message, previous) || position > 0
        val canGroupWithNext = canGroup(message, next) || position < itemCount - 1 || bodyVisible

        partBinders
            .firstOrNull { it.canBindPart(part) }
            ?.bindPart(holder, part, message, canGroupWithPrevious, canGroupWithNext)
    }

    override fun getItemViewType(position: Int): Int {
        val part = data[position]
        return partBinders.indexOfFirst { it.canBindPart(part) }
    }

}