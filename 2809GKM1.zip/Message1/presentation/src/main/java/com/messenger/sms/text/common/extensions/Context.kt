package com.messenger.sms.text.common.extensions

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.app.ActivityManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.telecom.TelecomManager
import android.text.TextUtils
import android.view.View
import android.view.ViewGroup
import android.widget.RemoteViews
import android.widget.Toast
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.bumptech.glide.util.Util.isOnMainThread
import com.messenger.sms.text.R
import com.messenger.sms.text.common.util.BaseConfig
import com.messenger.sms.text.feature.compose.ComposeActivity
import com.messenger.sms.text.feature.main.LauncherRedirectActivity
import com.messenger.sms.text.utils.PERMISSION_ACCESS_COARSE_LOCATION
import com.messenger.sms.text.utils.PERMISSION_ACCESS_FINE_LOCATION
import com.messenger.sms.text.utils.PERMISSION_CALL_PHONE
import com.messenger.sms.text.utils.PERMISSION_CAMERA
import com.messenger.sms.text.utils.PERMISSION_GET_ACCOUNTS
import com.messenger.sms.text.utils.PERMISSION_MEDIA_LOCATION
import com.messenger.sms.text.utils.PERMISSION_POST_NOTIFICATIONS
import com.messenger.sms.text.utils.PERMISSION_READ_CALENDAR
import com.messenger.sms.text.utils.PERMISSION_READ_CALL_LOG
import com.messenger.sms.text.utils.PERMISSION_READ_CONTACTS
import com.messenger.sms.text.utils.PERMISSION_READ_MEDIA_AUDIO
import com.messenger.sms.text.utils.PERMISSION_READ_MEDIA_IMAGES
import com.messenger.sms.text.utils.PERMISSION_READ_MEDIA_VIDEO
import com.messenger.sms.text.utils.PERMISSION_READ_MEDIA_VISUAL_USER_SELECTED
import com.messenger.sms.text.utils.PERMISSION_READ_PHONE_STATE
import com.messenger.sms.text.utils.PERMISSION_READ_SMS
import com.messenger.sms.text.utils.PERMISSION_READ_STORAGE
import com.messenger.sms.text.utils.PERMISSION_READ_SYNC_SETTINGS
import com.messenger.sms.text.utils.PERMISSION_RECORD_AUDIO
import com.messenger.sms.text.utils.PERMISSION_SEND_SMS
import com.messenger.sms.text.utils.PERMISSION_WRITE_CALENDAR
import com.messenger.sms.text.utils.PERMISSION_WRITE_CALL_LOG
import com.messenger.sms.text.utils.PERMISSION_WRITE_CONTACTS
import com.messenger.sms.text.utils.PERMISSION_WRITE_STORAGE
import com.messenger.sms.text.utils.isQPlus

import java.io.BufferedReader
import java.io.IOException
import java.io.InputStreamReader





//fun Context.getSharedPrefs() = getSharedPreferences(PREFS_KEY, Context.MODE_PRIVATE)
//val Context.baseConfig: BaseConfig get() = BaseConfig.newInstance(this)
//val Context.telecomManager: TelecomManager get() = getSystemService(Context.TELECOM_SERVICE) as TelecomManager
//fun Context.getTimeFormat() = if (baseConfig.use24HourFormat) TIME_FORMAT_24 else TIME_FORMAT_12
//fun Context.getProperTextColor() = baseConfig.textColor

//fun Context.getProperBackgroundColor() = baseConfig.backgroundColor
//fun Context.getProperPrimaryColor() = baseConfig.primaryColor
//fun Context.getProperTextCursorColor() = baseConfig.textCursorColor


fun isMiUi(): Boolean {
    return !TextUtils.isEmpty(getSystemProperty("ro.miui.ui.version.name"))
}

val Context.isRTLLayout: Boolean get() = resources.configuration.layoutDirection == View.LAYOUT_DIRECTION_RTL

fun getSystemProperty(propName: String): String? {
    val line: String
    var input: BufferedReader? = null
    try {
        val p = Runtime.getRuntime().exec("getprop $propName")
        input = BufferedReader(InputStreamReader(p.inputStream), 1024)
        line = input.readLine()
        input.close()
    } catch (ex: IOException) {
        return null
    } finally {
        if (input != null) {
            try {
                input.close()
            } catch (e: IOException) {
                e.printStackTrace()
            }
        }
    }
    return line
}

fun Context.toast(id: Int, length: Int = Toast.LENGTH_SHORT) {
    toast(getString(id), length)
}

fun Context.toast(msg: String, length: Int = Toast.LENGTH_SHORT) {
    try {
        if (isOnMainThread()) {
            doToast(this, msg, length)
        } else {
            Handler(Looper.getMainLooper()).post {
                doToast(this, msg, length)
            }
        }
    } catch (e: Exception) {

    }
}

private fun doToast(context: Context, message: String, length: Int) {
    if (context is Activity) {
        if (!context.isFinishing && !context.isDestroyed) {
            Toast.makeText(context, message, length).show()
        }
    } else {
        Toast.makeText(context, message, length).show()
    }
}

fun Context.showErrorToast(msg: String, length: Int = Toast.LENGTH_LONG) {
//    toast(String.format(getString(R.string.error), msg), length)
}

fun Context.showErrorToast(exception: Exception, length: Int = Toast.LENGTH_LONG) {
    showErrorToast(exception.toString(), length)
}



fun isServiceRunning(context: Context, serviceClass: Class<*>): Boolean {
    val activityManager = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
    @Suppress("DEPRECATION") // For older API levels
    for (service in activityManager.getRunningServices(Int.MAX_VALUE)) {
        if (serviceClass.name == service.service.className) {
            return true
        }
    }
    return false
}

fun Context.hasPermission(permId: Int) = ContextCompat.checkSelfPermission(
    this,
    getPermissionString(permId)
) == PackageManager.PERMISSION_GRANTED

fun Context.hasAllPermissions(permIds: Collection<Int>) = permIds.all(this::hasPermission)

fun Context.getPermissionString(id: Int) = when (id) {
    PERMISSION_READ_STORAGE -> Manifest.permission.READ_EXTERNAL_STORAGE
    PERMISSION_WRITE_STORAGE -> Manifest.permission.WRITE_EXTERNAL_STORAGE
    PERMISSION_CAMERA -> Manifest.permission.CAMERA
    PERMISSION_RECORD_AUDIO -> Manifest.permission.RECORD_AUDIO
    PERMISSION_READ_CONTACTS -> Manifest.permission.READ_CONTACTS
    PERMISSION_WRITE_CONTACTS -> Manifest.permission.WRITE_CONTACTS
    PERMISSION_READ_CALENDAR -> Manifest.permission.READ_CALENDAR
    PERMISSION_WRITE_CALENDAR -> Manifest.permission.WRITE_CALENDAR
    PERMISSION_CALL_PHONE -> Manifest.permission.CALL_PHONE
    PERMISSION_READ_CALL_LOG -> Manifest.permission.READ_CALL_LOG
    PERMISSION_WRITE_CALL_LOG -> Manifest.permission.WRITE_CALL_LOG
    PERMISSION_GET_ACCOUNTS -> Manifest.permission.GET_ACCOUNTS
    PERMISSION_READ_SMS -> Manifest.permission.READ_SMS
    PERMISSION_SEND_SMS -> Manifest.permission.SEND_SMS
    PERMISSION_READ_PHONE_STATE -> Manifest.permission.READ_PHONE_STATE
    PERMISSION_MEDIA_LOCATION -> if (isQPlus()) Manifest.permission.ACCESS_MEDIA_LOCATION else ""
    PERMISSION_POST_NOTIFICATIONS -> Manifest.permission.POST_NOTIFICATIONS
    PERMISSION_READ_MEDIA_IMAGES -> Manifest.permission.READ_MEDIA_IMAGES
    PERMISSION_READ_MEDIA_VIDEO -> Manifest.permission.READ_MEDIA_VIDEO
    PERMISSION_READ_MEDIA_AUDIO -> Manifest.permission.READ_MEDIA_AUDIO
    PERMISSION_ACCESS_COARSE_LOCATION -> Manifest.permission.ACCESS_COARSE_LOCATION
    PERMISSION_ACCESS_FINE_LOCATION -> Manifest.permission.ACCESS_FINE_LOCATION
    PERMISSION_READ_MEDIA_VISUAL_USER_SELECTED -> Manifest.permission.READ_MEDIA_VISUAL_USER_SELECTED
    PERMISSION_READ_SYNC_SETTINGS -> Manifest.permission.READ_SYNC_SETTINGS
    else -> ""
}

fun Context.showHomeNotification() {
    if (ContextCompat.checkSelfPermission(
            this,
            Manifest.permission.POST_NOTIFICATIONS
        ) == PackageManager.PERMISSION_GRANTED
    ) {

        val notificationManager =
            getSystemService(NotificationManager::class.java) as NotificationManager

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                "MessageHomeNotification",
                "Channel Name",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Channel Description"
            }
            notificationManager.createNotificationChannel(channel)
        }

        val remoteViews = RemoteViews(packageName, R.layout.noti_collapse)
        val bigRemoteViews = RemoteViews(packageName, R.layout.noti_expand)

//        val inboxIntent = Intent(this, MainActivity::class.java).apply {
//            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
//            putExtra("ACTION_TYPE", "notification_inbox")
//        }
//        val newMessageIntent = Intent(this, MainActivity::class.java).apply {
//            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
//            putExtra("ACTION_TYPE", "notification_new_message")
//        }
//        val manageAppsIntent = Intent(this, MainActivity::class.java).apply {
//            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
//            putExtra("ACTION_TYPE", "notification_manage_apps")
//        }
//        "button1" -> {
//            requstcount = 101
            val intent1 =Intent(this, LauncherRedirectActivity::class.java)
//        }

//        "button2" -> {
//            requstcount = 102
            val intent2 = Intent(this, ComposeActivity::class.java)
        intent2.putExtra(Intent.EXTRA_TEXT, "")
        intent2.putExtra("isScheduleClicked", false)
//                images?.takeIf { it.isNotEmpty() }?.let {
//                    intent.putParcelableArrayListExtra(Intent.EXTRA_STREAM, ArrayList(images))
//                }
//        }

//        "button3" -> {
//            requstcount = 103
            val intent3 = Intent(this, ComposeActivity::class.java)
            intent3.putExtra(Intent.EXTRA_TEXT, "")
            intent3.putExtra("isScheduleClicked", true)
//        }

//        // Create PendingIntent for each button
        val pendingIntent1 = PendingIntent.getActivity(
            this, 1, intent1, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val pendingIntent2 = PendingIntent.getActivity(
            this, 2, intent2, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val pendingIntent3 = PendingIntent.getActivity(
            this, 3, intent3, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
//        val newMessagePendingIntent = PendingIntent.getActivity(
//            this,
//            2,
//            newMessageIntent,
//            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
//        )
//        val manageAppsPendingIntent = PendingIntent.getActivity(
//            this,
//            3,
//            manageAppsIntent,
//            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
//        )

        // Set PendingIntents on buttons

        remoteViews.setOnClickPendingIntent(R.id.btn1, pendingIntent1)
        remoteViews.setOnClickPendingIntent(R.id.btn2, pendingIntent2)
        remoteViews.setOnClickPendingIntent(R.id.btn3, pendingIntent3)
        bigRemoteViews.setOnClickPendingIntent(R.id.btn1, pendingIntent1)
        bigRemoteViews.setOnClickPendingIntent(R.id.btn2, pendingIntent2)
        bigRemoteViews.setOnClickPendingIntent(R.id.btn3, pendingIntent3)


        val notification = NotificationCompat.Builder(this, "MessageHomeNotification")
            .setSmallIcon(R.drawable.ic_message_notification)
            .setCustomBigContentView(bigRemoteViews)
            .setCustomContentView(remoteViews)
            .setStyle(NotificationCompat.DecoratedCustomViewStyle())
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setOnlyAlertOnce(true)
            .setSound(null).setSilent(true)
            .setDefaults(Notification.DEFAULT_LIGHTS)
            .setCategory(Notification.CATEGORY_EVENT)
            .setOngoing(true)
            .build()

        notificationManager.notify(4488, notification)
    }
//    if (ContextCompat.checkSelfPermission(
//            this,
//            Manifest.permission.POST_NOTIFICATIONS
//        ) == PackageManager.PERMISSION_GRANTED
//    ) {
//
//        val notificationManager =
//            getSystemService(NotificationManager::class.java) as NotificationManager
//
//        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
//            val channel = NotificationChannel(
//                "MessageHomeNotification",
//                "Channel Name",
//                NotificationManager.IMPORTANCE_HIGH
//            ).apply {
//                description = "Channel Description"
//            }
//            notificationManager.createNotificationChannel(channel)
//        }
//
//        val remoteViews = RemoteViews(packageName, R.layout.custom_notification)
//        val bigRemoteViews = RemoteViews(packageName, R.layout.custom_notification_big)
//
//        val inboxIntent = Intent(this, MainActivity::class.java).apply {
//            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
//            putExtra("ACTION_TYPE", "notification_inbox")
//        }
//        val newMessageIntent = Intent(this, MainActivity::class.java).apply {
//            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
//            putExtra("ACTION_TYPE", "notification_new_message")
//        }
//        val manageAppsIntent = Intent(this, MainActivity::class.java).apply {
//            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
//            putExtra("ACTION_TYPE", "notification_manage_apps")
//        }
//
//        // Create PendingIntent for each button
//        val inboxPendingIntent = PendingIntent.getActivity(
//            this, 1, inboxIntent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
//        )
//        val newMessagePendingIntent = PendingIntent.getActivity(
//            this,
//            2,
//            newMessageIntent,
//            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
//        )
//        val manageAppsPendingIntent = PendingIntent.getActivity(
//            this,
//            3,
//            manageAppsIntent,
//            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
//        )
//
//        // Set PendingIntents on buttons
//        remoteViews.setOnClickPendingIntent(R.id.inboxButton, inboxPendingIntent)
//        remoteViews.setOnClickPendingIntent(R.id.newMessageButton, newMessagePendingIntent)
//        remoteViews.setOnClickPendingIntent(R.id.manageAppsButton, manageAppsPendingIntent)
//
//        bigRemoteViews.setOnClickPendingIntent(R.id.inboxButton, inboxPendingIntent)
//        bigRemoteViews.setOnClickPendingIntent(R.id.newMessageButton, newMessagePendingIntent)
//        bigRemoteViews.setOnClickPendingIntent(R.id.manageAppsButton, manageAppsPendingIntent)
//
//        val notification = NotificationCompat.Builder(this, "MessageHomeNotification")
//            .setSmallIcon(R.drawable.ic_message_notification)
//            .setCustomBigContentView(bigRemoteViews)
//            .setCustomContentView(remoteViews)
//            .setColor(ContextCompat.getColor(this, R.color.primary))
//            .setStyle(NotificationCompat.DecoratedCustomViewStyle())
//            .setPriority(NotificationCompat.PRIORITY_HIGH)
//            .setOnlyAlertOnce(true)
//            .setSound(null).setSilent(true)
//            .setDefaults(Notification.DEFAULT_LIGHTS)
//            .setCategory(Notification.CATEGORY_EVENT)
//            .setOngoing(true)
//            .build()
//
//        notificationManager.notify(4488, notification)
//    }
}


fun Context.copyToClipboard(text: String) {
    val clip = ClipData.newPlainText(getString(R.string.app_name), text)
    (getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(clip)
//    val toastText = String.format(getString(R.string.value_copied_to_clipboard_show), text)
//    val toastText = getString(R.string.value_copied_to_clipboard_new)
//    toast(toastText)
}

fun isAndroid12OrUp(): Boolean {
    return Build.VERSION.SDK_INT >= Build.VERSION_CODES.S
}

//fun Context.hasAllPermissions(permIds: Collection<Int>) = permIds.all(this::hasPermission)

fun Context.isPackageInstalled(packageName: String?): Boolean {
    val packageManager = packageManager
    val intent = packageManager.getLaunchIntentForPackage(packageName!!) ?: return false
    val list = packageManager.queryIntentActivities(intent, PackageManager.MATCH_DEFAULT_ONLY)
    return !list.isEmpty()
}