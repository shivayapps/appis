package com.messenger.sms.text.common.widget

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Typeface
import android.util.AttributeSet
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.widget.TextView
import androidx.appcompat.widget.LinearLayoutCompat
import androidx.core.content.ContextCompat
import com.messenger.sms.text.utils.gone
import com.messenger.sms.text.utils.resolveColorAttr
import com.messenger.sms.text.utils.visible
import com.messenger.sms.text.R
import com.common.extensions.resolveThemeAttribute
import com.common.extensions.resolveThemeColorStateList
import com.messenger.sms.text.common.util.extensions.setVisible
import com.messenger.sms.text.common.util.extensions.customViewBinding
import com.messenger.sms.text.databinding.PreferenceViewBinding
import com.messenger.sms.text.injection.appComponent
import com.domain.util.Preferences
import javax.inject.Inject

class PreferenceView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : LinearLayoutCompat(context, attrs) {

    @Inject
    lateinit var prefs: Preferences

    private val binding: PreferenceViewBinding =
        customViewBinding(PreferenceViewBinding::inflate)

    var title: String? = null
        set(value) {
            field = value
            if (isInEditMode) {
                findViewById<TextView>(R.id.titleView)?.text = value
            } else {
                binding.titleView.text = value
            }
        }

    var summary: String? = null
        set(value) {
            field = value

            val textSizePref = if (::prefs.isInitialized) prefs.textSize.get() else Preferences.TEXT_SIZE_NORMAL
            val summaryView = if (isInEditMode) {
                findViewById<TextView>(R.id.summaryView)
            } else {
                binding.summaryView
            }

            summaryView?.apply {
                text = value
                textSize = when (textSizePref) {
                    Preferences.TEXT_SIZE_SMALL -> 10f
                    Preferences.TEXT_SIZE_NORMAL -> 12f
                    Preferences.TEXT_SIZE_LARGE -> 14f
                    Preferences.TEXT_SIZE_LARGER -> 16f
                    else -> 12f
                }
                setVisible(!value.isNullOrEmpty())
            }
        }

    var proIcon: Boolean = false
        set(value) {
            field = value
            if (value) binding.icon2.visible() else binding.icon2.gone()
        }
    var colorSummery: Int = R.color.light_text_color
        set(value) {
            field = value

            binding.summaryView.setTextColor(colorSummery)
        }

    //    var colorTitle: Int = 0
    var colorTitle: Int = R.color.dark_text_color
        set(value) {
            field = value

            binding.titleView.setTextColor(colorTitle)
        }

    var isBoldTitle: Boolean = false
        set(value) {
            field = value
            if (isBoldTitle)
                binding.titleView.setTypeface(null, Typeface.BOLD)
            else
                binding.titleView.setTypeface(null, Typeface.NORMAL)
        }


    init {
        if (!isInEditMode) {
            appComponent.inject(this)
        }

//        LayoutInflater.from(context).inflate(R.layout.preference_view, this, true)
//        View.inflate(context, R.layout.preference_view, this)

        setBackgroundResource(context.resolveThemeAttribute(R.attr.selectableItemBackground))
        orientation = HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL

        binding.icon.imageTintList = context.resolveThemeColorStateList(android.R.attr.textColorSecondary)

        context.obtainStyledAttributes(attrs, R.styleable.PreferenceView).apply {
            try {
                title = getString(R.styleable.PreferenceView_title)
                summary = getString(R.styleable.PreferenceView_summary)

                getResourceId(R.styleable.PreferenceView_widget, -1).takeIf { it != -1 }?.let { id ->
                    View.inflate(context, id, binding.widgetFrame)
                }

                getResourceId(R.styleable.PreferenceView_icon, -1).takeIf { it != -1 }?.let { id ->
                    binding.icon.setVisible(true)
                    binding.icon.setImageResource(id)
                }
            } finally {
                recycle()
            }
        }
    }

    fun hideIcon() {
        binding.icon.gone()
    }

    fun <T : View> widget(): T {
        return binding.widgetFrame.getChildAt(0) as T
    }
}
