package com.messenger.sms.text.feature.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.messenger.sms.text.common.model.MoreAppsModel
import com.messenger.sms.text.databinding.ItemAppsBinding


class MoreAppsAdapter(var context: Context, var list: ArrayList<MoreAppsModel>, val clickListener: (pos: Int) -> Unit) : RecyclerView.Adapter<MoreAppsAdapter.ViewHolder>() {

//    var selectPos = 0

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding =
            ItemAppsBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(binding)
    }

    override fun getItemCount(): Int {
        return list.size
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val model = list[position]
        holder.binding.tvTitle.text = model.appName
        holder.binding.tvDesc.text = model.shortDescription
        Glide.with(holder.binding.imgLogo.context)
            .load(model.appImageLink)
            .into(holder.binding.imgLogo)

        holder.itemView.setOnClickListener {
            clickListener(position)
        }

    }

    class ViewHolder(var binding: ItemAppsBinding) : RecyclerView.ViewHolder(binding.root) {

    }
}