package com.messenger.sms.text.common.base

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toolbar
import androidx.annotation.LayoutRes
import androidx.annotation.StringRes
import androidx.appcompat.app.AppCompatActivity
import androidx.viewbinding.ViewBinding
import com.bluelinelabs.conductor.archlifecycle.LifecycleController
import com.messenger.sms.text.R
import com.messenger.sms.text.common.widget.MessagesTextView

abstract class MessagesController<ViewContract : MessagesViewContract<State>, State:Any, Presenter : MessagesPresenter<ViewContract, State>, Binding : ViewBinding>
    (private val bindingInflater: (LayoutInflater, ViewGroup, Boolean) -> Binding, )
    : LifecycleController() {

    abstract var presenter: Presenter

    private val appCompatActivity: AppCompatActivity?
        get() = activity as? AppCompatActivity

    protected val themedActivity: MessagesThemedActivity?
        get() = activity as? MessagesThemedActivity

    private val toolbar by lazy { view?.findViewById<Toolbar>(R.id.toolbar) }
    private val toolbarTitle by lazy { view?.findViewById<MessagesTextView>(R.id.toolbarTitle) }
//    override var containerView: View? = null

    lateinit var binding: Binding
    @LayoutRes
    var layoutRes: Int = 0

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup): View {

        binding = bindingInflater(inflater, container, false)
        onViewCreated()
        return binding.root
//        return inflater.inflate(layoutRes, container, false).also {
//            containerView = it
//            onViewCreated()
//        }
    }

    open fun onViewCreated() {
    }

    fun setTitle(@StringRes titleId: Int) {
        setTitle(activity?.getString(titleId))
    }

    fun setTitle(title: CharSequence?) {
        activity?.title = title
        toolbarTitle?.text = title
    }

    fun showBackButton(show: Boolean) {
        appCompatActivity?.supportActionBar?.setDisplayHomeAsUpEnabled(show)
    }

//    override fun onDestroyView(view: View) {
////        containerView = null
//        clearFindViewByIdCache()
//    }

    override fun onDestroy() {
        super.onDestroy()
        presenter.onCleared()
    }

}
