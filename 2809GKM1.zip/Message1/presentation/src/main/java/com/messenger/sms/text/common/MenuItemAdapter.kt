package com.messenger.sms.text.common

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.util.Log
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.annotation.ArrayRes
import androidx.recyclerview.widget.RecyclerView
import com.messenger.sms.text.utils.gone
import com.messenger.sms.text.utils.visible
import io.reactivex.disposables.CompositeDisposable
import io.reactivex.subjects.PublishSubject
import io.reactivex.subjects.Subject
import com.messenger.sms.text.R
import com.messenger.sms.text.common.base.MessagesAdapter
import com.messenger.sms.text.common.base.MessagesViewHolder
import com.messenger.sms.text.common.util.extensions.setVisible
import com.messenger.sms.text.databinding.MenuListItemBinding
import com.messenger.sms.text.feature.notificationprefs.NotificationPrefsActivity
import com.messenger.sms.text.feature.settings.SettingsActivity
import javax.inject.Inject

data class MenuItem(val title: String, val actionId: Int)

class MenuItemAdapter @Inject constructor(
    private val context: Context
) : MessagesAdapter<MenuItem, MenuListItemBinding>() {


    val menuItemClicks: Subject<Int> = PublishSubject.create()
    val menuItemClicks1: Subject<Int> = PublishSubject.create()

    private val disposables = CompositeDisposable()

    var fromActions: Boolean = false
    public var actionId1 = 0
    public var old = 0
    public var new = 0

    val msgDelayTimings = context.resources.getStringArray(R.array.delayed_sending_timing)

    var fromDelaySending: Boolean = false
    var selectedItem: Int? = null
        set(value) {
            old = data.map { it.actionId }.indexOfFirst { it == field }
            new = data.map { it.actionId }.indexOfFirst { it == value }

            field = value

            old.let { notifyItemChanged(it) }
            new.let { notifyItemChanged(it) }

            actionId1 = new
        }

    fun setData(@ArrayRes titles: Int, @ArrayRes values: Int = -1) {
        val valueInts = if (values != -1){
            if(SettingsActivity.settingsActivity != null){
                SettingsActivity.settingsActivity?.resources!!.getIntArray(values)
            } else if(NotificationPrefsActivity.notActivity != null){
                NotificationPrefsActivity.notActivity?.resources!!.getIntArray(values)
            } else {
                null
            }
        } else {
            null
        }

        data =  if(SettingsActivity.settingsActivity != null){
            SettingsActivity.settingsActivity?.resources!!.getStringArray(titles)
                .mapIndexed { index, title ->
                    MenuItem(title, valueInts?.getOrNull(index) ?: index)
                }
        } else if(NotificationPrefsActivity.notActivity != null){
            NotificationPrefsActivity.notActivity?.resources!!.getStringArray(titles)
                .mapIndexed { index, title ->
                    MenuItem(title, valueInts?.getOrNull(index) ?: index)
                }
        } else {
            ArrayList()
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MessagesViewHolder<MenuListItemBinding> {
        val layoutInflater = LayoutInflater.from(parent.context)

        val view = layoutInflater.inflate(R.layout.menu_list_item, parent, false)

        return MessagesViewHolder(parent, MenuListItemBinding::inflate).apply {
//            val states = arrayOf(
//                intArrayOf(android.R.attr.state_activated),    // Selected state
//                intArrayOf(-android.R.attr.state_activated)    // Unselected state
//            )

//            val selectedColor = colors.theme().theme // Use your theme color for selected state
//            val unselectedColor = Color.GRAY          // Gray for unselected state

//            binding.check.imageTintList = ColorStateList(states, intArrayOf(selectedColor, unselectedColor))

            binding.root.setOnClickListener {
                val menuItem = getItem(adapterPosition)
                menuItemClicks.onNext(menuItem.actionId)
            }
        }
    }

    @SuppressLint("CheckResult")
    override fun onBindViewHolder(holder: MessagesViewHolder<MenuListItemBinding>, position: Int) {
        val menuItem = getItem(position)

        holder.binding.title.text = menuItem.title
        holder.binding.check.isActivated = (menuItem.actionId == selectedItem)
        holder.binding.check.setVisible(selectedItem != null)

//        if (fromDelaySending) {
//            holder.description.visible()
//            holder.description.text = msgDelayTimings[position]
//        } else {
//            holder.description.gone()
//        }
//        holder.title.text = menuItem.title
//        holder.check.isActivated = (menuItem.actionId == selectedItem)
//        holder.check.setVisible(selectedItem != null)
//
//        holder.check.isActivated = selectedItem == position
//
//        holder.item.setOnClickListener {
//            if (fromActions && getItem(position).actionId == 3) {
//                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
//                    if (!Settings.canDrawOverlays(NotificationPrefsActivity.notActivity)) {
//                        val intent = Intent(
//                            Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
//                            Uri.parse("package:${NotificationPrefsActivity.notActivity?.packageName}")
//                        )
//                        NotificationPrefsActivity.notActivity?.startActivityForResult(intent, 101)
//                    } else {
//                        selectedItem(position, holder)
//                    }
//                } else {
//                    selectedItem(position, holder)
//                }
//            } else {
//                selectedItem(position, holder)
//            }
//        }
//        menuItemClicks1.subscribe {
//            selectedItem(it, holder)
//        }
    }

//    private fun selectedItem(
//        position: Int,
//        holder: MessagesViewHolder
//    ) {
//        selectedItem = position
//        holder.check.isActivated = true
//        actionId1 = getItem(position).actionId
//        notifyDataSetChanged()
//    }



    override fun onDetachedFromRecyclerView(recyclerView: RecyclerView) {
        super.onDetachedFromRecyclerView(recyclerView)
        disposables.clear()
    }

}