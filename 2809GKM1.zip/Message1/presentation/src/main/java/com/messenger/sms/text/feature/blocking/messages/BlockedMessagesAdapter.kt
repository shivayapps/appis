package com.messenger.sms.text.feature.blocking.messages

import android.content.Context
import android.graphics.Typeface
import android.view.ViewGroup
import androidx.core.view.isVisible
import io.reactivex.subjects.PublishSubject
import com.messenger.sms.text.R
import com.messenger.sms.text.common.base.MessagesRealmAdapter
import com.messenger.sms.text.common.base.MessagesViewHolder
import com.messenger.sms.text.common.util.DateFormatter
import com.common.extensions.resolveThemeColor
import com.messenger.sms.text.databinding.BlockedListItemBinding
import com.data.compat.SubscriptionManagerCompat
import com.domain.model.Conversation
import com.domain.util.Preferences
import javax.inject.Inject

class BlockedMessagesAdapter @Inject constructor(
    subscriptionManager: SubscriptionManagerCompat,
    private val context: Context,
    private val dateFormatter: DateFormatter
) : MessagesRealmAdapter<Conversation, BlockedListItemBinding>() {

    private val subs = subscriptionManager.activeSubscriptionInfoList
    val clicks: PublishSubject<Long> = PublishSubject.create()

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MessagesViewHolder<BlockedListItemBinding> {

        return MessagesViewHolder(parent, BlockedListItemBinding::inflate).apply {
            if (viewType == 0) {
                binding.title.setTypeface(binding.title.typeface, Typeface.BOLD)
                binding.date.setTypeface(binding.date.typeface, Typeface.BOLD)
                binding.date.setTextColor(parent.context.resolveThemeColor(android.R.attr.textColorPrimary))
            }

            binding.root.setOnClickListener {
                val conversation = getItem(adapterPosition) ?: return@setOnClickListener
                when (toggleSelection(conversation.id, false)) {
                    true -> binding.root.isActivated = isSelected(conversation.id)
                    false -> clicks.onNext(conversation.id)
                }
            }

            binding.root.setOnLongClickListener {
                val conversation = getItem(adapterPosition) ?: return@setOnLongClickListener true
                toggleSelection(conversation.id)
                binding.root.isActivated = isSelected(conversation.id)
                true
            }
        }
    }

    override fun onBindViewHolder(holder: MessagesViewHolder<BlockedListItemBinding>, position: Int) {
        val conversation = getItem(position) ?: return
        holder.binding.root.isActivated = isSelected(conversation.id)

//        holder.binding.avatars.recipients = conversation.recipients
        holder.binding.title.collapseEnabled = conversation.recipients.size > 1
        holder.binding.title.text = conversation.getTitle()
        holder.binding.date.text = dateFormatter.getConversationTimestamp(conversation.date)
        holder.binding.blocker.text = when (conversation.blockingClient) {
            Preferences.BLOCKING_MANAGER_CC -> context.getString(R.string.blocking_manager_call_control_title)
            Preferences.BLOCKING_MANAGER_SIA -> context.getString(R.string.blocking_manager_sia_title)
            else -> null
        }

//        holder.binding.title.setTextColor(holder.binding.title.context.getColor(R.color.black))
//        holder.binding.date.setTextColor(holder.binding.date.context.getColor(R.color.black))

        holder.binding.reason.text = conversation.blockReason
        holder.binding.blocker.isVisible = holder.binding.blocker.text.isNotEmpty()
        holder.binding.reason.isVisible = holder.binding.blocker.text.isNotEmpty()

//        holder.containerView.isActivated = isSelected(conversation.id)
//        if (isSelected(conversation.id)) {
//            holder.ic_selected.visible()
//        } else {
//            holder.ic_selected.gone()
//        }
////        holder.avatars.recipients = conversation.recipients
//        holder.title.collapseEnabled = conversation.recipients.size > 1
//        holder.title.text = conversation.getTitle()
//        holder.date.text = dateFormatter.getConversationTimestamp(conversation.date)
//
//        val simIndex =
//            subs.takeIf { it.size > 1 }?.indexOfFirst { it.subscriptionId == conversation.lastMessage?.subId }
//                ?: -1
//
//        holder.simIndex.text = "${simIndex + 1}"
//
//        holder.flSim.setVisible(simIndex != -1)
////        holder.simIndex.setVisible(simIndex != -1)
//
//        holder.reason.text = when {
//            conversation.draft.isNotEmpty() -> context.getString(R.string.main_draft,conversation.draft)
//            conversation.me -> context.getString(R.string.main_sender_you, conversation.snippet)
//            else -> conversation.snippet
//        }

//        holder.blocker.text = when (conversation.blockingClient) {
//            Preferences.BLOCKING_MANAGER_CC -> context.getString(R.string.blocking_manager_call_control_title)
////            Preferences.BLOCKING_MANAGER_SIA -> context.getString(R.string.blocking_manager_sia_title)
//            else -> null
//        }

//        holder.reason.text = conversation.blockReason
//        holder.blocker.isVisible = holder.blocker.text.isNotEmpty()
//        holder.reason.isVisible = holder.blocker.text.isNotEmpty()
    }

    override fun getItemViewType(position: Int): Int {
        val conversation = getItem(position)
        return if (conversation?.unread == false) 1 else 0
    }

}
