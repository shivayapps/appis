package com.messenger.sms.text.feature.compose.part

import android.content.Context
import android.view.Gravity
import android.widget.FrameLayout
import ezvcard.Ezvcard
import io.reactivex.Observable
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.schedulers.Schedulers
import com.messenger.sms.text.R
import com.messenger.sms.text.common.base.MessagesViewHolder
import com.common.extensions.resolveThemeColor
import com.messenger.sms.text.common.util.extensions.setBackgroundTint
import com.messenger.sms.text.common.util.extensions.setTint
import com.messenger.sms.text.databinding.MmsVcardListItemBinding
import com.data.extensions.isVCard
import com.messenger.sms.text.feature.compose.BubbleUtils
import com.domain.extensions.mapNotNull
import com.domain.model.Message
import com.domain.model.MmsPart
import javax.inject.Inject

class VCardBinder @Inject constructor( private val context: Context) : PartBinder<MmsVcardListItemBinding>(MmsVcardListItemBinding::inflate) {

//    override val partLayout = R.layout.mms_vcard_list_item
    override fun canBindPart(part: MmsPart) = part.isVCard()

    override fun bindPartInternal(
        holder: MessagesViewHolder<MmsVcardListItemBinding>,
        part: MmsPart,
        message: Message,
        canGroupWithPrevious: Boolean,
        canGroupWithNext: Boolean,
    ) {
        BubbleUtils.getBubble(false, canGroupWithPrevious, canGroupWithNext, message.isMe())
            .let(holder.binding.vCardBackground::setBackgroundResource)

        holder.binding.root.setOnClickListener { clicks.onNext(part.id) }

        Observable.just(part.getUri())
            .map(context.contentResolver::openInputStream)
            .mapNotNull { inputStream -> inputStream.use { Ezvcard.parse(it).first() } }
            .subscribeOn(Schedulers.computation())
            .observeOn(AndroidSchedulers.mainThread())
            .subscribe { vcard -> holder.binding.name?.text = vcard.formattedName.value }

        val params = holder.binding.vCardBackground.layoutParams as FrameLayout.LayoutParams
        if (!message.isMe()) {
            holder.binding.vCardBackground.layoutParams = params.apply { gravity = Gravity.START }
//            holder.binding.vCardBackground.setBackgroundTint(theme.theme)
//            holder.binding.vCardAvatar.setTint(theme.textPrimary)
//            holder.binding.name.setTextColor(theme.textPrimary)
//            holder.binding.label.setTextColor(theme.textTertiary)
        } else {
            holder.binding.vCardBackground.layoutParams = params.apply { gravity = Gravity.END }
            holder.binding.vCardBackground.setBackgroundTint(
                holder.binding.root.context.resolveThemeColor(
                    R.attr.bubbleColor
                )
            )
            holder.binding.vCardAvatar.setTint(holder.binding.root.context.resolveThemeColor(android.R.attr.textColorSecondary))
            holder.binding.name.setTextColor(holder.binding.root.context.resolveThemeColor(android.R.attr.textColorPrimary))
            holder.binding.label.setTextColor(holder.binding.root.context.resolveThemeColor(android.R.attr.textColorTertiary))
        }
    }



}