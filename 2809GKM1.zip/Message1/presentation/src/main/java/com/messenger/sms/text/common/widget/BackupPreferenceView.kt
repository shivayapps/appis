package com.messenger.sms.text.common.widget

import android.annotation.SuppressLint
import android.content.Context
import android.util.AttributeSet
import android.view.Gravity
import android.view.View
import android.widget.TextView
import androidx.appcompat.widget.LinearLayoutCompat
import androidx.core.content.ContextCompat
import com.messenger.sms.text.utils.resolveColorAttr
import com.messenger.sms.text.R
import com.common.extensions.resolveThemeAttribute
import com.common.extensions.resolveThemeColorStateList
import com.messenger.sms.text.common.util.extensions.setVisible
import com.messenger.sms.text.common.util.extensions.customViewBinding
import com.messenger.sms.text.databinding.PreferenceViewBinding
import com.messenger.sms.text.injection.appComponent

class BackupPreferenceView @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null
) : LinearLayoutCompat(context, attrs) {

    val binding: PreferenceViewBinding = customViewBinding(PreferenceViewBinding::inflate)
    var title: String? = null
        set(value) {
            field = value

            if (isInEditMode) {
                findViewById<TextView>(R.id.titleView).text = value
            } else {
                binding.titleView.text = value
            }
        }

    var summary: String? = null
        @SuppressLint("ResourceAsColor")
        set(value) {
            field = value

            if (isInEditMode) {
                findViewById<TextView>(R.id.summaryView).run {
                    text = value
                    setVisible(value?.isNotEmpty() == true)
                }
            } else {
                binding.summaryView.text = value
                binding.summaryView.setVisible(value?.isNotEmpty() == true)
            }
        }

//    var colorSummery: Int = 0
//        set(value) {
//            field = value
//
//            binding.summaryView.setTextColor(colorSummery)
//        }
//
//    var colorTitle: Int = 0
//        set(value) {
//            field = value
//
//            binding.titleView.setTextColor(colorTitle)
//        }

    init {
        if (!isInEditMode) {
            appComponent.inject(this)
        }

        View.inflate(context, R.layout.backup_preference_view, this)
        setBackgroundResource(context.resolveThemeAttribute(R.attr.selectableItemBackground))
        orientation = HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL

        binding.icon.imageTintList = context.resolveThemeColorStateList(android.R.attr.textColorSecondary)

        context.obtainStyledAttributes(attrs, R.styleable.PreferenceView).run {
            title = getString(R.styleable.PreferenceView_title)
            summary = getString(R.styleable.PreferenceView_summary)
//            colorTitle = getInt(
//                R.styleable.PreferenceView_colorTitle,
//                context.resolveColorAttr(android.R.attr.textColorPrimary)
//            )
//            colorSummery = getInt(
//                R.styleable.PreferenceView_colorSummary,
//                ContextCompat.getColor(context, R.color.textGray)
//            )

            // If there's a custom view used for the preference's widget, inflate it
            getResourceId(R.styleable.PreferenceView_widget, -1).takeIf { it != -1 }?.let { id ->
                View.inflate(context, id, binding.widgetFrame)
            }

            // If an icon is being used, set up the icon view
            getResourceId(R.styleable.PreferenceView_icon, -1).takeIf { it != -1 }?.let { id ->
                binding.icon.setVisible(true)
                binding.icon.setImageResource(id)
            }

            recycle()
        }
    }

}