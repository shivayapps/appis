package com.messenger.sms.text.feature.blocking

import android.content.Context
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import androidx.core.content.ContextCompat
import androidx.core.view.isVisible
import com.adconfig.AdsConfig
import androidx.core.view.ViewCompat
import androidx.activity.enableEdgeToEdge
import androidx.core.view.WindowInsetsCompat
import com.adconfig.adsutil.AdsParameters
import com.adconfig.adsutil.Config
import com.adconfig.adsutil.admob.AdmobIntersAdImpl
import com.adconfig.adsutil.admob.BannerAdHelper
import com.adconfig.adsutil.admob.BannerAds
import com.google.android.gms.ads.AdView
import com.google.android.material.snackbar.Snackbar
import com.jakewharton.rxbinding2.view.clicks
import com.messenger.sms.text.utils.gone
import com.messenger.sms.text.utils.visible
import dagger.android.AndroidInjection
import io.reactivex.subjects.PublishSubject
import io.reactivex.subjects.Subject
import org.greenrobot.eventbus.EventBus
import org.greenrobot.eventbus.Subscribe
import org.greenrobot.eventbus.ThreadMode
import com.messenger.sms.text.R
import com.messenger.sms.text.common.Navigator
import com.messenger.sms.text.common.base.MessagesThemedActivity
import com.messenger.sms.text.databinding.BlockedMessagesControllerBinding
import com.messenger.sms.text.feature.blocking.messages.BlockedMessagesAdapter
import com.messenger.sms.text.feature.blocking.messages.BlockedMessagesPresenter
import com.messenger.sms.text.feature.blocking.messages.BlockedMessagesState
import com.messenger.sms.text.feature.blocking.messages.BlockedMessagesView
import com.messenger.sms.text.common.CommonDialog
import com.messenger.sms.text.common.util.BaseConfig
import com.messenger.sms.text.common.util.extensions.LogW
import com.messenger.sms.text.common.util.extensions.viewBinding
import com.messenger.sms.text.common.widget.MessagesSwitch
import com.messenger.sms.text.event.ConversationEvent
import com.messenger.sms.text.event.SubscribeEvent
import com.messenger.sms.text.utils.AdCache

import com.messenger.sms.text.utils.isOnline
import com.messenger.sms.text.utils.loadListAds
import javax.inject.Inject

class BlockingActivity : MessagesThemedActivity(),
    BlockedMessagesView {

    override val menuReadyIntent: Subject<Unit> = PublishSubject.create()
    override val optionsItemIntent: Subject<Int> = PublishSubject.create()
    override val conversationClicks by lazy { blockedMessagesAdapter.clicks }
    override val selectionChanges by lazy { blockedMessagesAdapter.selectionChanges }
    override val confirmDeleteIntent: Subject<List<Long>> = PublishSubject.create()
    override val dropClickedIntent by lazy { binding.drop.clicks() }
    override val unBlockUndoSubject: Subject<List<Long>> = PublishSubject.create()

    @Inject
    lateinit var blockedMessagesAdapter: BlockedMessagesAdapter

    @Inject
    lateinit var blockingDialog: BlockingDialog

    @Inject
    lateinit var context: Context

    @Inject
    lateinit var presenter: BlockedMessagesPresenter

    @Inject
    lateinit var navigator: Navigator


    companion object {
        var blockingActivity: BlockingActivity? = null
    }

    private val binding by viewBinding(BlockedMessagesControllerBinding::inflate)
    override fun onCreate(savedInstanceState: Bundle?) {
        AndroidInjection.inject(this)
        super.onCreate(savedInstanceState)
        EventBus.getDefault().register(this)
//        mBind = DataBindingUtil.setContentView(this, R.layout.blocked_messages_controller)
        enableEdgeToEdge()
        setContentView(binding.root)
        ViewCompat.setOnApplyWindowInsetsListener(binding.root) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
        setSupportActionBar(binding.toolbar)
        blockingActivity = this

        presenter.bindIntents(this)
        title = (blockingActivity ?: context).getString(R.string.blocked_messages_title)
        showBackButton(true)
        loadIntAds()
        loadBannerAd()
        val nativeAdId =
            if (appPrefs.isFirstTime) getString(R.string.native_blocking)
            else getString(R.string.native_blocking2)
        with(binding) {
            drop.hideIcon()
            setAdapter()
            loadListAds(flListAds, nativeAdId)
            if (BaseConfig(context).ads_free) {
                drop.proIcon = true
                ivPro.gone()
                divider.visible()
                clDrop.setBackgroundColor(
                    ContextCompat.getColor(
                        blockingActivity ?: context,
                        R.color.white_color
                    )
                )
                drop.colorSummery = ContextCompat.getColor(
                    blockingActivity ?: context,
                    R.color.contactSubtitle
                )
                drop.colorTitle = ContextCompat.getColor(
                    blockingActivity ?: context,
                    R.color.black_color
                )
                drop.isBoldTitle = false
            } else {
                ivPro.visible()
                divider.gone()
                drop.proIcon = false

                clDrop.setBackgroundResource(R.drawable.rect_blue_drop)
                drop.colorSummery =
                    ContextCompat.getColor(blockingActivity ?: context, R.color.white)
                drop.colorTitle =
                    ContextCompat.getColor(blockingActivity ?: context, R.color.white)
                drop.isBoldTitle = true
            }
        }


    }

    @Subscribe(sticky = true, threadMode = ThreadMode.MAIN)
    fun handleEvents(event: ConversationEvent) {
        when (event) {
            is SubscribeEvent -> {
                if (BaseConfig(this).ads_free) {
                    with(binding) {
                        flListAds.gone()
                        ivPro.gone()
                        divider.visible()
                        clDrop.setBackgroundColor(
                            ContextCompat.getColor(
                                blockingActivity ?: context,
                                R.color.white_color
                            )
                        )
                        drop.colorSummery = ContextCompat.getColor(
                            blockingActivity ?: context,
                            R.color.contactSubtitle
                        )
                        drop.colorTitle = ContextCompat.getColor(
                            blockingActivity ?: context,
                            R.color.black_color
                        )
                        drop.isBoldTitle = false
                    }
                }
            }
        }
    }

    override fun onDestroy() {
        EventBus.getDefault().unregister(this)
        BannerAds.destroyAd()
        super.onDestroy()
    }

    private fun loadIntAds() {
        val adId =
            if (appPrefs.isFirstTime) getString(R.string.inter_backpress)
            else getString(R.string.inter_backpress2)
        if (AdsParameters(this).isNeedInterAd && Config.checkInterAd()) {
            AdmobIntersAdImpl().load(this, adId)
        }
    }

    var mAdView: AdView? = null
    private fun loadBannerAd() {
        if (!BaseConfig(this@BlockingActivity).ads_free
//            && MessagesApplication.remoteConfig.getBoolean(UtilsStaticData.isEnableAllPageBannerAds)
        ) {
//            if (!BannerAds.isRequestSend) {
//                BannerAds.loadAdmobBannerAds(
//                    this@BlockingActivity,
//                    binding.admobBanner2, getString(R.string.banner_blocking)
//                )
//            }
            val bannerAdId =
                if (appPrefs.isFirstTime) getString(R.string.banner_blocking)
                else getString(R.string.banner_blocking2)
            BannerAdHelper.showBanner(
                this@BlockingActivity,
                binding.admobBanner2,
                binding.admobBanner2,
                bannerAdId,
                AdCache.blockingAdView,
                { isLoaded, adView, message ->
                    mAdView = adView
                    AdCache.blockingAdView = adView
                })

        }
    }


    override fun onResume() {
        super.onResume()
        mAdView?.resume()
        BannerAds.resumeAd()
        if (binding.empty.isVisible) {
            binding.flListAds.gone()
        }
//        if (binding.admobBanner2.childCount == 0) {
//            if (!BaseConfig(this@BlockingActivity).ads_free && isOnline
//            ) {
//                loadBannerAd()
//            }
//        } else {
//            if (binding.admobBanner2.visibility != 0) {
//                if (!BaseConfig(this@BlockingActivity).ads_free && isOnline
//                ) {
//                    loadBannerAd()
//                }
//            }
//        }
    }

    override fun onPause() {
        mAdView?.pause()
        BannerAds.pauseAd()
        super.onPause()
    }


    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.blocked_messages, menu)
        menuReadyIntent.onNext(Unit)
        return super.onCreateOptionsMenu(menu)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        optionsItemIntent.onNext(item.itemId)
        when (item.itemId) {
            android.R.id.home -> {
                onBackPressed()
            }
        }
        return true
    }

    private fun setAdapter() {
        blockedMessagesAdapter.emptyView = binding.empty
        binding.conversations.adapter = blockedMessagesAdapter
    }

    override fun onBackPressed() {
        if (blockedMessagesAdapter.selection.isNotEmpty()) {
            blockedMessagesAdapter.clearSelection()
        } else {
            if (Config.checkInterAd()) {
                AdsConfig.showInterstitialAd(this) {
                    finish()
                }
            } else {
                finish()
            }
        }

    }

    override fun render(state: BlockedMessagesState) {
        with(binding) {
//            binding.drop.checkbox.isChecked = state.dropEnabled
            binding.drop.widget<MessagesSwitch>().isChecked = state.dropEnabled
            blockedMessagesAdapter.updateData(state.data)
            toolbar.menu?.findItem(R.id.block)?.isVisible = state.selected > 0
            toolbar.menu?.findItem(R.id.delete)?.isVisible = state.selected > 0
            title = when (state.selected) {
                0 -> (blockingActivity ?: context).getString(R.string.blocked_messages_title)
                else -> (blockingActivity ?: context).getString(
                    R.string.main_title_selected,
                    state.selected
                )
            }
            if (state.data!!.isNotEmpty()) {
                empty.gone()
                if (!BaseConfig(this@BlockingActivity).ads_free) {
                    flListAds.visible()
                } else {
                    flListAds.gone()
                }
            } else {
                empty.visible()
                flListAds.gone()
            }
        }
    }

    override fun clearSelection() = blockedMessagesAdapter.clearSelection()
    override fun requestDefaultSms() {
        AdsConfig.isSystemDialogOpen = true
        navigator.showDefaultSmsDialog(this@BlockingActivity)
    }

    override fun showBlockingDialog(
        conversations: List<Long>,
        block: Boolean,
        isTrue: (Boolean) -> Unit
    ) {
        LogW("messageApp : ", "message showBlockingDialog  ")
        var title: Int = 0
        var btnText: Int = 0
        var msgText: String = ""
        if (block) {
            title = R.string.blocking_block_title
            btnText = R.string.blocking_block_title
            msgText = resources!!.getString(R.string.blocked_messages_are)
        } else {
            title = R.string.blocking_unblock_title
            btnText = R.string.blocking_unblock_title
            msgText = resources!!.getString(R.string.unblocked_messages_are)
        }

        CommonDialog(this).show(
            this,
            title = this.getString(title),
            message = msgText,
            positive = this.getString(btnText),
            this.getString(R.string.button_cancel),
            "",
            onPositive = {
                blockingDialog.show(this@BlockingActivity, conversations, block, isTrue)
            })
    }

    override fun showDeleteDialog(conversations: List<Long>) {
        val count = conversations.size
        CommonDialog(this).show(
            this,
            title = this.getString(R.string.dialog_delete_title),
            message = this.resources.getQuantityString(
                R.plurals.dialog_delete_message,
                count,
                count
            ),
            positive = this.getString(R.string.button_delete),
            this.getString(R.string.button_cancel),
            "",
            onPositive = {
                confirmDeleteIntent.onNext(
                    conversations
                )
            })
    }

    override fun showUnBlockedSnackBar(conversationIds: List<Long>) {
        Snackbar.make(
            binding.clDrop,
            (blockingActivity ?: context).getString(R.string.blocked_messages_title),
            Snackbar.LENGTH_LONG
        )
            .apply {
                setAction((blockingActivity ?: context).getString(R.string.undo)) {
                    unBlockUndoSubject.onNext(conversationIds)
                }
                setActionTextColor(ContextCompat.getColor(context, R.color.color_app_theme))
                show()
            }
    }
}