package com.messenger.sms.text.common.util

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.ContentUris
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.media.AudioAttributes
import android.net.Uri
import android.os.Build
import android.os.PowerManager
import android.provider.ContactsContract
import android.text.Html
import android.util.Log
import androidx.core.app.*
import androidx.core.content.ContextCompat
import androidx.core.content.getSystemService
import androidx.core.graphics.drawable.IconCompat
import com.messenger.sms.text.R
import com.messenger.sms.text.common.util.extensions.dpToPx
import com.messenger.sms.text.feature.smsreply.MessagesReplyActivity
import com.messenger.sms.text.feature.compose.ComposeActivity
import com.messenger.sms.text.common.staticData.EventKeys
import com.common.util.tryOrNull
import com.data.extensions.isImage
import com.data.mapper.CursorToPartImpl
import com.data.receiver.ActionCallReceiver
import com.data.receiver.DeleteMessagesReceiver
import com.data.receiver.MarkReadReceiver
import com.data.receiver.MarkSeenReceiver
import com.data.receiver.RemoteMessagingReceiver
import com.bumptech.glide.Glide
import com.data.util.PhoneNumberUtils
import com.data.util.ReConstant
import com.domain.manager.PermissionManager
import com.domain.repository.ConversationRepository
import com.domain.repository.MessageRepository
import com.domain.util.Preferences
import java.util.regex.Pattern
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class NotificationManagerImpl @Inject constructor(
    private val context: Context,
    private val conversationRepo: ConversationRepository,
    private val prefs: Preferences,
    private val messageRepo: MessageRepository,
    private val permissions: PermissionManager,
    private val phoneNumberUtils: PhoneNumberUtils
) : com.domain.manager.NotificationManager {

    companion object {
        const val DEFAULT_CHANNEL_ID = "notifications_default"
        const val BACKUP_RESTORE_CHANNEL_ID = "notifications_backup_restore"

        val VIBRATE_PATTERN = longArrayOf(0, 200, 0, 200)
    }

    private val notificationManager =
        context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

    init {
        // Make sure the default channel has been initialized
        createNotificationChannel()
    }

    /**
     * Updates the notification for a particular conversation
     */
    override fun update(threadId: Long) {
        // If notifications are disabled, don't do anything
        if (!prefs.notifications(threadId).get()) {
            return
        }

        val messages = messageRepo.getUnreadUnseenMessages(threadId)

        // If there are no messages to be displayed, make sure that the notification is dismissed
        if (messages.isEmpty()) {
            notificationManager.cancel(threadId.toInt())
            return
        }

        val conversation = conversationRepo.getConversation(threadId) ?: return
        val lastRecipient = conversation.lastMessage?.let { lastMessage ->
            conversation.recipients.find { recipient ->
                phoneNumberUtils.compare(recipient.address, lastMessage.address)
            }
        } ?: conversation.recipients.firstOrNull()

        val contentIntent =
            Intent(context, ComposeActivity::class.java).putExtra("threadId", threadId)
        val taskStackBuilder = TaskStackBuilder.create(context)
            .addParentStack(ComposeActivity::class.java)
            .addNextIntent(contentIntent)
        val contentPI = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            taskStackBuilder.getPendingIntent(threadId.toInt() + 10000, PendingIntent.FLAG_MUTABLE)
        } else {
            taskStackBuilder.getPendingIntent(
                threadId.toInt() + 10000,
                PendingIntent.FLAG_UPDATE_CURRENT
            )
        }

        val seenIntent =
            Intent(context, MarkSeenReceiver::class.java).putExtra("threadId", threadId)
        val seenPI = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            PendingIntent.getBroadcast(
                context, threadId.toInt() + 20000, seenIntent,
                PendingIntent.FLAG_MUTABLE
            )
        } else {
            PendingIntent.getBroadcast(
                context, threadId.toInt() + 20000, seenIntent,
                PendingIntent.FLAG_UPDATE_CURRENT
            )
        }

        // We can't store a null preference, so map it to a null Uri if the pref string is empty
        val ringtone = prefs.ringtone(threadId).get()
            .takeIf { it.isNotEmpty() }
            ?.let(Uri::parse)
            ?.also { uri ->
                // https://commonsware.com/blog/2016/09/07/notifications-sounds-android-7p0-aggravation.html
                context.grantUriPermission(
                    "com.android.systemui",
                    uri,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
            }

        val notification =
            NotificationCompat.Builder(context, getChannelIdForNotification(threadId))
                .setCategory(NotificationCompat.CATEGORY_MESSAGE)
//                .setColor(colors.theme(lastRecipient).theme)
                .setColor(ContextCompat.getColor(context, R.color.color_app_theme))
                .setPriority(NotificationCompat.PRIORITY_MAX)
                .setSmallIcon(R.drawable.ic_notifications)
                .setNumber(messages.size)
                .setAutoCancel(true)
                .setContentIntent(contentPI)
                .setDeleteIntent(seenPI)
                .setSound(ringtone)
                .setLights(Color.WHITE, 500, 2000)
                .setWhen(conversation.lastMessage?.date ?: System.currentTimeMillis())
                .setVibrate(
                    if (prefs.vibration(threadId).get()) VIBRATE_PATTERN else longArrayOf(0)
                )

        // Tell the notification if it's a group message
        val messagingStyle = NotificationCompat.MessagingStyle("Me")
        if (conversation.recipients.size >= 2) {
            messagingStyle.isGroupConversation = true
            messagingStyle.conversationTitle = conversation.getTitle()
        }
        val resultTitle =
            Pattern.compile(ReConstant.promotion_regex).matcher(conversation.getTitle())
                .find()
        // Add the messages to the notification
        messages.forEach { message ->
            val person = Person.Builder()

            if (!message.isMe()) {
                val recipient = conversation.recipients.find { recipient ->
                    phoneNumberUtils.compare(recipient.address, message.address)
                }

                person.setName(recipient?.getDisplayName() ?: message.address)
                person.setIcon(
                    Glide.with(context)
                        .asBitmap()
                        .circleCrop()
                        .load(recipient?.contact?.photoUri)
                        .submit(64.dpToPx(context), 64.dpToPx(context))
                        .let { futureGet -> tryOrNull(false) { futureGet.get() } }
                        ?.let(IconCompat::createWithBitmap))

                recipient?.contact
                    ?.let { contact -> "${ContactsContract.Contacts.CONTENT_LOOKUP_URI}/${contact.lookupKey}" }
                    ?.let(person::setUri)
            }

            NotificationCompat.MessagingStyle.Message(
                Html.fromHtml(message.getSummary().replace("\n", "<br>")),
                message.date,
                person.build()
            ).apply {
                message.parts.firstOrNull { it.isImage() }?.let { part ->
                    setData(
                        part.type,
                        ContentUris.withAppendedId(CursorToPartImpl.CONTENT_URI, part.id)
                    )
                }
                messagingStyle.addMessage(this)
            }
        }

        // Set the large icon
        val avatar = conversation.recipients.takeIf { it.size == 1 }
            ?.first()?.contact?.photoUri
            ?.let { photoUri ->
                Glide.with(context)
                    .asBitmap()
                    .circleCrop()
                    .load(photoUri)
                    .submit(64.dpToPx(context), 64.dpToPx(context))
            }
            ?.let { futureGet -> tryOrNull(false) { futureGet.get() } }

        // Bind the notification contents based on the notification preview mode
        when (prefs.notificationPreviews(threadId).get()) {
            Preferences.NOTIFICATION_PREVIEWS_ALL -> {
                notification
                    .setLargeIcon(avatar)
                    .setStyle(messagingStyle)
            }

            Preferences.NOTIFICATION_PREVIEWS_NAME -> {
                notification
                    .setLargeIcon(avatar)
                    .setContentTitle(conversation.getTitle())
                    .setContentText(
                        context.resources.getQuantityString(
                            R.plurals.notification_new_messages, messages.size, messages.size
                        )
                    )
            }

            Preferences.NOTIFICATION_PREVIEWS_NONE -> {
                notification
                    .setContentTitle(context.getString(R.string.app_name_message))
                    .setContentText(
                        context.resources.getQuantityString(
                            R.plurals.notification_new_messages, messages.size, messages.size
                        )
                    )
            }
        }

        // Add all of the people from this conversation to the notification, so that the system can
        // appropriately bypass DND mode
        conversation.recipients.forEach { recipient ->
            notification.addPerson("tel:${recipient.address}")
        }

        // Add the action buttons
        val actionLabels = context.resources.getStringArray(R.array.notification_actions)
        listOf(prefs.notifAction1, prefs.notifAction2, prefs.notifAction3)
            .map { preference -> preference.get() }
            .distinct()
            .mapNotNull { action ->
                when (action) {
                    Preferences.NOTIFICATION_ACTION_READ -> {
                        val intent = Intent(context, MarkReadReceiver::class.java).putExtra(
                            "threadId",
                            threadId
                        )

                        val pi = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                            PendingIntent.getBroadcast(
                                context, threadId.toInt() + 30000,
                                intent,
                                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                            )
                        } else {
                            PendingIntent.getBroadcast(
                                context, threadId.toInt() + 30000,
                                intent,
                                PendingIntent.FLAG_UPDATE_CURRENT
                            )
                        }

                        NotificationCompat.Action.Builder(
                            R.drawable.ic_check_white_24dp,
                            actionLabels[action],
                            pi
                        )
                            .setSemanticAction(NotificationCompat.Action.SEMANTIC_ACTION_MARK_AS_READ)
                            .build()
                    }

                    Preferences.NOTIFICATION_ACTION_REPLY -> {
                        if (!resultTitle) {
                            if (Build.VERSION.SDK_INT >= 24) {
                                getReplyAction(threadId)
                            } else {
                                val intent = Intent(
                                    context,
                                    MessagesReplyActivity::class.java
                                ).putExtra("threadId", threadId)

                                val pi = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                                    PendingIntent.getActivity(
                                        context, threadId.toInt() + 40000, intent,
                                        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                                    )
                                } else {
                                    PendingIntent.getActivity(
                                        context, threadId.toInt() + 40000, intent,
                                        PendingIntent.FLAG_UPDATE_CURRENT
                                    )
                                }
                                NotificationCompat.Action
                                    .Builder(
                                        R.drawable.ic_reply_white_24dp,
                                        actionLabels[action],
                                        pi
                                    )
                                    .setSemanticAction(NotificationCompat.Action.SEMANTIC_ACTION_REPLY)
                                    .build()
                            }
                        } else {

                        }

                    }

                    Preferences.NOTIFICATION_ACTION_CALL -> {
                        Log.e("TAG", "getReplyAction.update:NOTIFICATION_ACTION_CALL:$resultTitle")
                        if (!resultTitle) {
                            val address = conversation.recipients[0]?.address
                            val overlayPermission = permissions.hasSystemOverlay()
                            val intentAction =
                                if (permissions.hasCalling()) Intent.ACTION_CALL else Intent.ACTION_DIAL

                            Log.e(
                                "TAG",
                                "getReplyAction.update:overlayPermission:$overlayPermission"
                            )

                            //Mark as read, remove notification
                            val intentRead = Intent(context, ActionCallReceiver::class.java)
                                .putExtra("threadId", threadId)
                                .putExtra("address", address)
                                .putExtra("intentAction", intentAction)
                                .putExtra("overlayPermission", overlayPermission)

                            val piRead = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                                PendingIntent.getBroadcast(
                                    context, threadId.toInt() + 30000,
                                    intentRead,
                                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                                )
                            } else {
                                PendingIntent.getBroadcast(
                                    context, threadId.toInt() + 30000,
                                    intentRead,
                                    PendingIntent.FLAG_UPDATE_CURRENT
                                )
                            }

                            NotificationCompat.Action.Builder(
                                R.drawable.ic_check_white_24dp,
                                actionLabels[action],
                                piRead
                            )
                                .setSemanticAction(NotificationCompat.Action.SEMANTIC_ACTION_MARK_AS_READ)
                                .build()
                        } else {

                        }
                    }

                    Preferences.NOTIFICATION_ACTION_DELETE -> {
                        val messageIds = messages.map { it.id }.toLongArray()
                        val intent = Intent(context, DeleteMessagesReceiver::class.java).putExtra(
                            "threadId",
                            threadId
                        ).putExtra("messageIds", messageIds)
                        val pi = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                            PendingIntent.getBroadcast(
                                context, threadId.toInt() + 60000,
                                intent,
                                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                            )
                        } else {
                            PendingIntent.getBroadcast(
                                context, threadId.toInt() + 60000,
                                intent,
                                PendingIntent.FLAG_UPDATE_CURRENT
                            )
                        }

                        NotificationCompat.Action.Builder(
                            R.drawable.main_menu_delete,
                            actionLabels[action],
                            pi
                        ).setSemanticAction(NotificationCompat.Action.SEMANTIC_ACTION_DELETE)
                            .build()
                    }

                    else -> null
                }
            }
            .forEach {
                if (it != null && it is NotificationCompat.Action) {
                    notification.addAction(it)
                }
            }

        if (prefs.reply.get() && !resultTitle) {
            notification.priority = NotificationCompat.PRIORITY_DEFAULT
            val intent = Intent(context, MessagesReplyActivity::class.java)
                .putExtra("threadId", threadId)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(intent)
        }

        notificationManager.notify(threadId.toInt(), notification.build())

        // Wake screen
        if (prefs.wakeScreen(threadId).get()) {
            context.getSystemService<PowerManager>()?.let { powerManager ->
                if (!powerManager.isInteractive) {
                    val flags =
                        PowerManager.SCREEN_DIM_WAKE_LOCK or PowerManager.ACQUIRE_CAUSES_WAKEUP
                    val wakeLock = powerManager.newWakeLock(flags, context.packageName)
                    wakeLock.acquire(5000)
                }
            }
        }
    }

    override fun logSent(threadId: Long) {
        AppUtils.logAdapterMessages(
            EventKeys.message_detail,
            EventKeys.send,
            EventKeys.success
        )
    }

    private fun getReplyAction(threadId: Long): NotificationCompat.Action {
        val replyIntent =
            Intent(context, RemoteMessagingReceiver::class.java).putExtra("threadId", threadId)
        val replyPI = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            PendingIntent.getBroadcast(
                context, threadId.toInt() + 40000, replyIntent, PendingIntent.FLAG_MUTABLE
            )
        } else {
            PendingIntent.getBroadcast(
                context, threadId.toInt() + 40000, replyIntent, PendingIntent.FLAG_UPDATE_CURRENT
            )
        }

        val title =
            context.resources.getStringArray(R.array.notification_actions)[Preferences.NOTIFICATION_ACTION_REPLY]
        val responseSet = context.resources.getStringArray(R.array._responses)
        val remoteInput = RemoteInput.Builder("body")
            .setLabel(title)

        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.P) {
            remoteInput.setChoices(responseSet)
        }

        return NotificationCompat.Action.Builder(R.drawable.ic_reply_white_24dp, title, replyPI)
            .setSemanticAction(NotificationCompat.Action.SEMANTIC_ACTION_REPLY)
            .addRemoteInput(remoteInput.build())
            .build()
    }

    override fun notifyFailed(msgId: Long, resultCode: Int) {
        val message = messageRepo.getMessage(msgId)

        if (message == null || !message.isFailedMessage()) {
            return
        }

        AppUtils.logAdapterMessages(
            EventKeys.message_detail,
            EventKeys.send,
            EventKeys.failed + "_" + resultCode
        )

        val conversation = conversationRepo.getConversation(message.threadId) ?: return
        val lastRecipient = conversation.lastMessage?.let { lastMessage ->
            conversation.recipients.find { recipient ->
                phoneNumberUtils.compare(recipient.address, lastMessage.address)
            }
        } ?: conversation.recipients.firstOrNull()

        val threadId = conversation.id

        val contentIntent =
            Intent(context, ComposeActivity::class.java).putExtra("threadId", threadId)
        val taskStackBuilder = TaskStackBuilder.create(context)
        taskStackBuilder.addParentStack(ComposeActivity::class.java)
        taskStackBuilder.addNextIntent(contentIntent)


        val contentPI = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            taskStackBuilder.getPendingIntent(threadId.toInt() + 40000, PendingIntent.FLAG_MUTABLE)
        } else {
            taskStackBuilder.getPendingIntent(
                threadId.toInt() + 40000,
                PendingIntent.FLAG_UPDATE_CURRENT
            )
        }
        val notification =
            NotificationCompat.Builder(context, getChannelIdForNotification(threadId))
                .setContentTitle(context.getString(R.string.notification_message_failed_title))
                .setContentText(
                    context.getString(
                        R.string.notification_message_failed_text,
                        conversation.getTitle()
                    )
                )
//                .setColor(colors.theme(lastRecipient).theme)
                .setColor(ContextCompat.getColor(context, R.color.color_app_theme))
                .setPriority(NotificationManagerCompat.IMPORTANCE_MAX)
                .setSmallIcon(R.drawable.ic_notification_failed)
                .setAutoCancel(true)
                .setContentIntent(contentPI)
                .setSound(Uri.parse(prefs.ringtone(threadId).get()))
                .setLights(Color.WHITE, 500, 2000)
                .setVibrate(
                    if (prefs.vibration(threadId).get()) VIBRATE_PATTERN else longArrayOf(0)
                )
        notificationManager.notify(threadId.toInt() + 50000, notification.build())
    }

    /**
     * Creates a notification channel for the given conversation
     */
    override fun createNotificationChannel(threadId: Long) {

        // Only proceed if the android version supports notification channels, and the channel hasn't
        // already been created
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O || getNotificationChannel(threadId) != null) {
            return
        }

        val channel = when (threadId) {
            0L -> NotificationChannel(
                DEFAULT_CHANNEL_ID,
                "Default",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                enableLights(true)
                lightColor = Color.WHITE
                enableVibration(true)
                vibrationPattern = VIBRATE_PATTERN
            }

            else -> {
                val conversation = conversationRepo.getConversation(threadId) ?: return
                val channelId = buildNotificationChannelId(threadId)
                val title = conversation.getTitle()
                NotificationChannel(channelId, title, NotificationManager.IMPORTANCE_HIGH).apply {
                    enableLights(true)
                    lightColor = Color.WHITE
                    enableVibration(true)
                    vibrationPattern = VIBRATE_PATTERN
                    lockscreenVisibility = Notification.VISIBILITY_PUBLIC
                    setSound(
                        prefs.ringtone().get().let(Uri::parse), AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_NOTIFICATION)
                            .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                            .build()
                    )
                }
            }
        }

        notificationManager.createNotificationChannel(channel)
    }

    /**
     * Returns the notification channel for the given conversation, or null if it doesn't exist
     */
    private fun getNotificationChannel(threadId: Long): NotificationChannel? {
        val channelId = buildNotificationChannelId(threadId)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            return notificationManager.notificationChannels
                .find { channel -> channel.id == channelId }
        }

        return null
    }

    /**
     * Returns the channel id that should be used for a notification based on the threadId
     *
     * If a notification channel for the conversation exists, use the id for that. Otherwise return
     * the default channel id
     */
    private fun getChannelIdForNotification(threadId: Long): String {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            return getNotificationChannel(threadId)?.id ?: DEFAULT_CHANNEL_ID
        }

        return DEFAULT_CHANNEL_ID
    }

    /**
     * Formats a notification channel id for a given thread id, whether the channel exists or not
     */
    override fun buildNotificationChannelId(threadId: Long): String {
        return when (threadId) {
            0L -> DEFAULT_CHANNEL_ID
            else -> "notifications_$threadId"
        }
    }

    override fun getNotificationForBackup(): NotificationCompat.Builder {
        if (Build.VERSION.SDK_INT >= 26) {
            val name = context.getString(R.string.backup_notification_channel_name)
            val importance = NotificationManager.IMPORTANCE_LOW
            val channel = NotificationChannel(BACKUP_RESTORE_CHANNEL_ID, name, importance)
            val notificationManager = context.getSystemService(NotificationManager::class.java)
            notificationManager.createNotificationChannel(channel)
        }

        return NotificationCompat.Builder(context, BACKUP_RESTORE_CHANNEL_ID)
            .setContentTitle(context.getString(R.string.backup_restoring))
            .setShowWhen(false)
            .setWhen(System.currentTimeMillis()) // Set this anyway in case it's shown
            .setSmallIcon(R.drawable.ic_file_download_black_24dp)
//            .setColor(colors.theme().theme)
            .setColor(ContextCompat.getColor(context, R.color.color_app_theme))
            .setCategory(NotificationCompat.CATEGORY_PROGRESS)
            .setPriority(NotificationCompat.PRIORITY_MIN)
            .setProgress(0, 0, true)
            .setOngoing(true)
    }

    override fun sendEvent(event: String, param_name: String, param_val: String) {
        AppUtils.logAdapterMessages(
            event,
            param_name,
            param_val
        )
    }

}