package com.messenger.sms.text.common.widget

import android.app.Activity
import android.view.LayoutInflater
import androidx.annotation.StringRes
import androidx.appcompat.app.AlertDialog
import androidx.core.content.ContextCompat
import androidx.core.view.isVisible
import com.messenger.sms.text.R
import com.messenger.sms.text.common.base.MessagesAdapter
import com.messenger.sms.text.databinding.DialogBinding

class MessagesDialog(private val context: Activity) : AlertDialog(context) {

//    private val view = LayoutInflater.from(context).inflate(R.layout.dialog, null)
//    val binding: DialogBinding = customViewBinding(DialogBinding::inflate)
    val binding: DialogBinding = DialogBinding.inflate(LayoutInflater.from(context))

    @StringRes
    var titleRes: Int? = null
        set(value) {
            field = value
            title = value?.let(context::getString)
        }

    var title: String? = null
        set(value) {
            field = value
            binding.title.text = value
            binding.title.isVisible = !value.isNullOrBlank()
        }

    @StringRes
    var subtitleRes: Int? = null
        set(value) {
            field = value
            subtitle = value?.let(context::getString)
        }

    var subtitle: String? = null
        set(value) {
            field = value
            binding.subtitle.text = value
            binding.subtitle.isVisible = !value.isNullOrBlank()
        }

    var adapter: MessagesAdapter<*, *>? = null
        set(value) {
            field = value
            binding.list.isVisible = value != null
            binding.list.adapter = value
        }

    var positiveButtonListener: (() -> Unit)? = null

    @StringRes
    var positiveButton: Int? = null
        set(value) {
            field = value
            value?.run(binding.positiveButton::setText)
            binding.positiveButton.setTextColor(
                ContextCompat.getColor(
                    context,
                    R.color.color_app_theme
                )
            )
            binding.positiveButton.isVisible = value != null
            binding.positiveButton.setOnClickListener {
                positiveButtonListener?.invoke() ?: dismiss()
            }
        }

    var negativeButtonListener: (() -> Unit)? = null

    @StringRes
    var negativeButton: Int? = null
        set(value) {
            field = value
            value?.run(binding.negativeButton::setText)
            binding.negativeButton.setTextColor(
                ContextCompat.getColor(
                    context,
                    R.color.color_app_theme
                )
            )
            binding.negativeButton.isVisible = value != null
            binding.negativeButton.setOnClickListener {
                negativeButtonListener?.invoke() ?: dismiss()
            }
        }

    var cancelListener: (() -> Unit)? = null
        set(value) {
            field = value
            setOnCancelListener { value?.invoke() }
        }

    init {
        setView(binding.root)
    }

}
