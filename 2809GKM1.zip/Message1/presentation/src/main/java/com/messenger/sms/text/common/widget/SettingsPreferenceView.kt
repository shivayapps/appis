package com.messenger.sms.text.common.widget

import android.annotation.SuppressLint
import android.content.Context
import android.util.AttributeSet
import android.view.Gravity
import android.view.View
import android.widget.TextView
import androidx.appcompat.widget.LinearLayoutCompat
import androidx.core.content.ContextCompat
import com.messenger.sms.text.utils.resolveColorAttr
import com.messenger.sms.text.R
import com.common.extensions.resolveThemeAttribute
import com.common.extensions.resolveThemeColorStateList
import com.messenger.sms.text.common.util.extensions.setVisible
import com.messenger.sms.text.common.util.extensions.customViewBinding
import com.messenger.sms.text.databinding.SettingsPreferenceViewBinding
import com.messenger.sms.text.injection.appComponent

class SettingsPreferenceView @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null
) : LinearLayoutCompat(context, attrs) {

    val binding: SettingsPreferenceViewBinding =
        customViewBinding(SettingsPreferenceViewBinding::inflate)

    var title: String? = null
        set(value) {
            field = value
            binding.titleView.text = value
        }

    fun <T : View> widget(): T {
        return binding.widgetFrame.getChildAt(0) as T
    }

    var summary: String? = null
        set(value) {
            field = value
            binding.summaryView.run {
                text = value
                setVisible(!value.isNullOrEmpty(), View.GONE)
            }
        }

    var summaryItalic: String? = null
        set(value) {
            field = value
            binding.summaryViewItalic.run {
                text = value
                setVisible(!value.isNullOrEmpty(), View.GONE)
            }
        }

    init {
        if (!isInEditMode) {
            appComponent.inject(this)
        }

        setBackgroundResource(context.resolveThemeAttribute(R.attr.selectableItemBackground))
        orientation = HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL

        binding.icon.imageTintList =
            context.resolveThemeColorStateList(android.R.attr.textColorSecondary)

        context.obtainStyledAttributes(attrs, R.styleable.PreferenceView).apply {
            title = getString(R.styleable.PreferenceView_title)
            summary = getString(R.styleable.PreferenceView_summary)

            getResourceId(R.styleable.PreferenceView_widget, -1).takeIf { it != -1 }?.let { id ->
                View.inflate(context, id, binding.widgetFrame)
            }

            getResourceId(R.styleable.PreferenceView_icon, -1).takeIf { it != -1 }?.let { id ->
                binding.icon.setVisible(true)
                binding.icon.setImageResource(id)
            }

            recycle()
        }
    }
}
