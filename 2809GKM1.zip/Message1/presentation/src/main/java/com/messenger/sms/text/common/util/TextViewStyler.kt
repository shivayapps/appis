package com.messenger.sms.text.common.util

import android.graphics.Typeface
import android.os.Build
import android.util.AttributeSet
import android.widget.EditText
import android.widget.TextView
import androidx.core.content.ContextCompat
import com.messenger.sms.text.R
import com.messenger.sms.text.common.util.TextViewStyler.Companion.SIZE_PRIMARY
import com.messenger.sms.text.common.util.TextViewStyler.Companion.SIZE_SECONDARY
import com.messenger.sms.text.common.util.TextViewStyler.Companion.SIZE_TERTIARY
import com.messenger.sms.text.common.util.TextViewStyler.Companion.SIZE_TOOLBAR
import com.messenger.sms.text.common.widget.MessagesEditText
import com.messenger.sms.text.common.widget.MessagesTextView
import com.common.extensions.getColorCompat
import com.domain.util.Preferences
import javax.inject.Inject

class TextViewStyler @Inject constructor(
    private val prefs: Preferences,
    private val fontProvider: FontProvider
) {
    companion object {
        const val COLOR_THEME = 0
        const val COLOR_PRIMARY_ON_THEME = 1
        const val COLOR_SECONDARY_ON_THEME = 2
        const val COLOR_TERTIARY_ON_THEME = 3

        const val SIZE_PRIMARY = 0
        const val SIZE_SECONDARY = 1
        const val SIZE_TERTIARY = 2
        const val SIZE_TOOLBAR = 3
        const val SIZE_DIALOG = 4
        const val SIZE_EMOJI = 5

        fun applyEditModeAttributes(textView: TextView, attrs: AttributeSet?) {
            textView.run {
                var colorAttr = 0
                var textSizeAttr = 0

                when (this) {
                    is MessagesTextView -> context.obtainStyledAttributes(attrs, R.styleable.MessagesTextView)?.run {
                        colorAttr = getInt(R.styleable.MessagesTextView_textColor, -1)
                        textSizeAttr = getInt(R.styleable.MessagesTextView_textSize, -1)
                        recycle()
                    }

                    is MessagesEditText -> context.obtainStyledAttributes(attrs, R.styleable.MessagesEditText)?.run {
                        colorAttr = getInt(R.styleable.MessagesEditText_textColor, -1)
                        textSizeAttr = getInt(R.styleable.MessagesEditText_textSize, -1)
                        recycle()
                    }

                    else -> return
                }
                setTextColor(when (colorAttr) {
                    COLOR_PRIMARY_ON_THEME -> context.getColorCompat(R.color.textPrimaryDark)
                    COLOR_SECONDARY_ON_THEME -> context.getColorCompat(R.color.textSecondaryDark)
                    COLOR_TERTIARY_ON_THEME -> context.getColorCompat(R.color.textTertiaryDark)
                    COLOR_THEME -> context.getColorCompat(R.color.tools_theme)
                    else -> currentTextColor
                })

                textSize = when (textSizeAttr) {
                    SIZE_PRIMARY -> 14f
                    SIZE_SECONDARY -> 12f
                    SIZE_TERTIARY -> 10f
                    SIZE_TOOLBAR -> 20f
                    SIZE_DIALOG -> 18f
                    SIZE_EMOJI -> 32f
                    else -> textSize / paint.density
                }
            }
        }
    }

    fun applyAttributes(textView: TextView, attrs: AttributeSet?) {
        var colorAttr = 0
        var textSizeAttr = 0

        if (!prefs.systemFont.get()) {
            fontProvider.getLato { lato ->
                textView.setTypeface(lato, textView.typeface?.style ?: Typeface.NORMAL)
            }
        }

        when (textView) {
            is MessagesTextView -> textView.context.obtainStyledAttributes(attrs, R.styleable.MessagesTextView).run {
                colorAttr = getInt(R.styleable.MessagesTextView_textColor, -1)
                textSizeAttr = getInt(R.styleable.MessagesTextView_textSize, -1)
                recycle()
            }

            is MessagesEditText -> textView.context.obtainStyledAttributes(attrs, R.styleable.MessagesEditText).run {
                colorAttr = getInt(R.styleable.MessagesEditText_textColor, -1)
                textSizeAttr = getInt(R.styleable.MessagesEditText_textSize, -1)
                recycle()
            }

            else -> return
        }

        when (colorAttr) {
            COLOR_THEME -> textView.setTextColor(ContextCompat.getColor(textView.context,R.color.color_app_theme))
            COLOR_PRIMARY_ON_THEME -> textView.setTextColor(ContextCompat.getColor(textView.context,R.color.color_app_theme))
            COLOR_SECONDARY_ON_THEME -> textView.setTextColor(ContextCompat.getColor(textView.context,R.color.color_app_theme))
            COLOR_TERTIARY_ON_THEME -> textView.setTextColor(ContextCompat.getColor(textView.context,R.color.color_app_theme))
        }

        setTextSize(textView, textSizeAttr,false)

        if (textView is EditText) {
            val drawable = textView.resources.getDrawable(R.drawable.cursor).apply { setTint(
                textView.resources.getColor(R.color.color_app_theme)) }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                textView.textCursorDrawable = drawable
            }

        }
    }

    /**
     * @see SIZE_PRIMARY
     * @see SIZE_SECONDARY
     * @see SIZE_TERTIARY
     * @see SIZE_TOOLBAR
     */
    fun setTextSize(textView: TextView, textSizeAttr: Int, isMessage: Boolean) {
        val textSizePref = prefs.textSize.get()
        when (textSizeAttr) {
            SIZE_PRIMARY -> textView.textSize = when (textSizePref) {
                Preferences.TEXT_SIZE_SMALL -> 14f
                Preferences.TEXT_SIZE_NORMAL -> 16f
                Preferences.TEXT_SIZE_LARGE -> 18f
                Preferences.TEXT_SIZE_LARGER -> 20f
                else -> 16f
            }

            SIZE_SECONDARY -> textView.textSize = when (textSizePref) {
                Preferences.TEXT_SIZE_SMALL -> 12f
                Preferences.TEXT_SIZE_NORMAL -> 14f
                Preferences.TEXT_SIZE_LARGE -> 16f
                Preferences.TEXT_SIZE_LARGER -> 18f
                else -> 14f
            }

            SIZE_TERTIARY -> textView.textSize = when (textSizePref) {
                Preferences.TEXT_SIZE_SMALL -> 10f
                Preferences.TEXT_SIZE_NORMAL -> 12f
                Preferences.TEXT_SIZE_LARGE -> 14f
                Preferences.TEXT_SIZE_LARGER -> 16f
                else -> 12f
            }

            SIZE_TOOLBAR -> textView.textSize = when (textSizePref) {
                Preferences.TEXT_SIZE_SMALL -> 18f
                Preferences.TEXT_SIZE_NORMAL -> 20f
                Preferences.TEXT_SIZE_LARGE -> 22f
                Preferences.TEXT_SIZE_LARGER -> 26f
                else -> 20f
            }

            SIZE_DIALOG -> textView.textSize = when (textSizePref) {
                Preferences.TEXT_SIZE_SMALL -> 16f
                Preferences.TEXT_SIZE_NORMAL -> 18f
                Preferences.TEXT_SIZE_LARGE -> 20f
                Preferences.TEXT_SIZE_LARGER -> 24f
                else -> 18f
            }

            SIZE_EMOJI -> textView.textSize = when (textSizePref) {
                Preferences.TEXT_SIZE_SMALL -> 28f
                Preferences.TEXT_SIZE_NORMAL -> 32f
                Preferences.TEXT_SIZE_LARGE -> 36f
                Preferences.TEXT_SIZE_LARGER -> 40f
                else -> 32f
            }
        }
    }
}