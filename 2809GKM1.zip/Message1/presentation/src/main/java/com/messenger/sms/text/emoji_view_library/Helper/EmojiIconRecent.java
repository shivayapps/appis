package com.messenger.sms.text.emoji_view_library.Helper;

import android.content.Context;

import com.messenger.sms.text.emoji_view_library.emoji.EmojiIcon;

public interface EmojiIconRecent {
    void addRecentEmoji(Context context, EmojiIcon emojiIcon);
}