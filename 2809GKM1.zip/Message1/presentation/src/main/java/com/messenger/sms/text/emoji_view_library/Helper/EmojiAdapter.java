package com.messenger.sms.text.emoji_view_library.Helper;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;

import java.util.List;

import com.messenger.sms.text.R;
import com.messenger.sms.text.emoji_view_library.emoji.EmojiIcon;

class EmojiAdapter extends ArrayAdapter<EmojiIcon> {
    private final boolean mUseSystemDefault;
    EmojiIconGridView.OnEmojiIconClickedListener emojiClickListener;


    public EmojiAdapter(Context context, List<EmojiIcon> data, boolean useSystemDefault) {
        super(context, R.layout.emojicon_item, data);
        mUseSystemDefault = useSystemDefault;
    }

    public void setEmojiClickListener(EmojiIconGridView.OnEmojiIconClickedListener listener) {
        this.emojiClickListener = listener;
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        View v = convertView;
        if (v == null) {
            v = View.inflate(getContext(), R.layout.emojicon_item, null);
            ViewHolder holder = new ViewHolder();
            holder.icon = v.findViewById(R.id.emojicon_icon);
            holder.icon.setUseSystemDefault(mUseSystemDefault);
            v.setTag(holder);
        }
        EmojiIcon emoji = getItem(position);
        ViewHolder holder = (ViewHolder) v.getTag();
        holder.icon.setText(emoji.getEmoji());
        holder.icon.setOnClickListener(v1 -> emojiClickListener.onEmojiIconClicked(getItem(position)));

        return v;
    }

    static class ViewHolder {
        EmojiIconTextView icon;
    }
}