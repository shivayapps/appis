package com.messenger.sms.text.emoji_view_library.emoji;

import android.os.Parcel;
import android.os.Parcelable;


public class EmojiIcon implements Parcelable {

    public static final Creator<EmojiIcon> CREATOR = new Creator<EmojiIcon>() {
        @Override
        public EmojiIcon createFromParcel(Parcel in) {
            return new EmojiIcon(in);
        }

        @Override
        public EmojiIcon[] newArray(int size) {
            return new EmojiIcon[size];
        }
    };

    private int icon;

    private char value;

    private String emoji;

    public EmojiIcon(int icon, char value, String emoji) {
        this.icon = icon;
        this.value = value;
        this.emoji = emoji;
    }

    public EmojiIcon(Parcel in) {
        this.icon = in.readInt();
        this.value = (char) in.readInt();
        this.emoji = in.readString();
    }

    private EmojiIcon() {
    }

    public EmojiIcon(String emoji) {
        this.emoji = emoji;
    }

    public static EmojiIcon fromCodePoint(int codePoint) {
        EmojiIcon emoji = new EmojiIcon();
        emoji.emoji = newString(codePoint);
        return emoji;
    }

    public static EmojiIcon fromDoubleCodePoint(int codePoint, int codePoint1) {
        EmojiIcon emoji = new EmojiIcon();
        String s = newString(codePoint);
        emoji.emoji = s.trim() + newString(codePoint1).trim();
        return emoji;
    }

    public static EmojiIcon fromChar(char ch) {
        EmojiIcon emoji = new EmojiIcon();
        emoji.emoji = Character.toString(ch);
        return emoji;
    }

    public static String newString(int codePoint) {
        if (Character.charCount(codePoint) == 1) {
            return String.valueOf(codePoint);
        } else {
            return new String(Character.toChars(codePoint));
        }
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeInt(icon);
        dest.writeInt(value);
        dest.writeString(emoji);
    }

    public char getValue() {
        return value;
    }

    public int getIcon() {
        return icon;
    }

    public String getEmoji() {
        return emoji;
    }

    @Override
    public boolean equals(Object o) {
        return o instanceof EmojiIcon && emoji.equals(((EmojiIcon) o).emoji);
    }

    @Override
    public int hashCode() {
        return emoji.hashCode();
    }

}
