package com.messenger.sms.text.common.widget

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Typeface
import android.util.AttributeSet
import android.view.Gravity
import android.view.View
import android.widget.TextView
import androidx.appcompat.widget.LinearLayoutCompat
import androidx.core.content.ContextCompat
import com.messenger.sms.text.utils.resolveColorAttr
import com.messenger.sms.text.R
import com.messenger.sms.text.common.util.extensions.customViewBinding
//import com.common.extensions.resolveThemeAttribute
//import com.common.extensions.resolveThemeColorStateList
import com.messenger.sms.text.common.util.extensions.setTint
import com.messenger.sms.text.common.util.extensions.setVisible
import com.messenger.sms.text.databinding.FilterPrefrenceViewBinding
import com.messenger.sms.text.feature.main.MainActivity
import com.messenger.sms.text.injection.appComponent
import com.common.extensions.resolveThemeAttribute

class FilterPreferenceView @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null
) : LinearLayoutCompat(context, attrs) {

    val binding: FilterPrefrenceViewBinding = customViewBinding(FilterPrefrenceViewBinding::inflate)
    var title: String? = null
        set(value) {
            field = value

            if (isInEditMode) {
                findViewById<TextView>(R.id.titleView).text = value
            } else {
                binding.titleView.text = value
            }
        }

    var summary: String? = null
        @SuppressLint("ResourceAsColor")
        set(value) {
            field = value

            if (isInEditMode) {
                findViewById<TextView>(R.id.summaryView).run {
                    text = value
                    setVisible(value?.isNotEmpty() == true, View.GONE)
                }
            } else {
                binding.summaryView.text = value
                binding.summaryView.setVisible(value?.isNotEmpty() == true, View.GONE)
            }
        }

//    var isBoldTitle: Boolean = false
//        set(value) {
//            field = value
//            if (isBoldTitle)
//                binding.titleView.setTypeface(null, Typeface.BOLD)
//            else
//                binding.titleView.setTypeface(null, Typeface.NORMAL)
//        }
//
//    var colorSummery: Int = 0
//        set(value) {
//            field = value
//
//            binding.summaryView.setTextColor(colorSummery)
//        }
//
//
//    var iconTint: Int = 0
//        set(value) {
//            field = value
//
//            binding.icon.setTint(iconTint)
//        }

//    var colorTitle: Int = 0
//        set(value) {
//            field = value
//
//            binding.titleView.setTextColor(colorTitle)
//        }

    init {
        if (!isInEditMode) {
            appComponent.inject(this)
        }
        View.inflate(context, R.layout.filter_prefrence_view, this)
        setBackgroundResource(context.resolveThemeAttribute(R.attr.selectableItemBackground))
        orientation = HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL

//        icon.imageTintList = context.resolveThemeColorStateList(android.R.attr.textColorSecondary)

        context.obtainStyledAttributes(attrs, R.styleable.PreferenceView).run {
            title = getString(R.styleable.PreferenceView_title)
            summary = getString(R.styleable.PreferenceView_summary)
//            colorTitle = getInt(
//                R.styleable.PreferenceView_colorTitle,
//                context.resolveColorAttr(android.R.attr.textColorPrimary)
//            )
//            colorSummery = getInt(
//                R.styleable.PreferenceView_colorSummary,
//                ContextCompat.getColor(MainActivity.mainActivity ?:context, R.color.textGray)
//            )
//
//            iconTint = getInt(
//                R.styleable.PreferenceView_iconTint,
//                ContextCompat.getColor(MainActivity.mainActivity ?:context, R.color.textGray)
//            )
//
//            isBoldTitle = getBoolean(R.styleable.PreferenceView_isBoldTitle, false)

            // If an icon is being used, set up the icon view
            getResourceId(R.styleable.PreferenceView_icon, -1).takeIf { it != -1 }?.let { id ->
                binding.icon.setVisible(true)
                binding.icon.setImageResource(id)
            }

            recycle()
        }
    }
}