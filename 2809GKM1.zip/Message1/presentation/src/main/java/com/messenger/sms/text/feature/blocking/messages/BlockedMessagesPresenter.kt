package com.messenger.sms.text.feature.blocking.messages

import android.content.Context
import com.uber.autodispose.android.lifecycle.scope
import com.uber.autodispose.autoDisposable
import com.uber.autodispose.autoDisposable
import io.reactivex.rxkotlin.plusAssign
import io.reactivex.rxkotlin.withLatestFrom
import com.messenger.sms.text.R
import com.messenger.sms.text.common.Navigator
import com.messenger.sms.text.common.base.MessagesPresenter
import com.messenger.sms.text.common.util.AppUtils
import com.messenger.sms.text.feature.blocking.BlockingActivity
import com.domain.interactor.MarkBlocked
import com.domain.manager.PermissionManager
import com.domain.repository.ConversationRepository
import com.domain.util.Preferences
import com.messenger.sms.text.common.staticData.EventKeys
import com.messenger.sms.text.common.util.BaseConfig
import com.messenger.sms.text.common.util.extensions.LogE
import com.messenger.sms.text.common.util.extensions.LogW
import com.domain.interactor.DeleteConversations
import javax.inject.Inject

class BlockedMessagesPresenter @Inject constructor(
    private val context: Context,
    private val conversationRepo: ConversationRepository,
//    private val blockingClient: BlockingClient,
    private val markBlocked: MarkBlocked,
    private val deleteConversations: DeleteConversations,
    private val navigator: Navigator,
    private val prefs: Preferences,
    private val permissionManager: PermissionManager
) : MessagesPresenter<BlockedMessagesView, BlockedMessagesState>(
    BlockedMessagesState(
        data = conversationRepo.getBlockedConversationsAsync()
    )
) {
    init {
        disposables += prefs.drop.asObservable()
            .subscribe { enabled -> newState { copy(dropEnabled = enabled) } }
    }

    override fun bindIntents(view: BlockedMessagesView) {
        super.bindIntents(view)

        view.menuReadyIntent
            .autoDisposable(view.scope())
            .subscribe { newState { copy() } }

        view.optionsItemIntent
            .filter { permissionManager.isDefaultSms().also { if (!it) view.requestDefaultSms() } }
            .withLatestFrom(view.selectionChanges) { itemId, conversations ->
                when (itemId) {
                    R.id.block -> {
                        LogW("messageApp : ", "message bloock dialog ")

                        view.showBlockingDialog(conversations, false) {
                            view.clearSelection()
                            view.showUnBlockedSnackBar(conversations)
                        }
                    }
                    R.id.delete -> {
                        LogW("messageApp : ", "message delete dialog ")
                        view.showDeleteDialog(conversations)
                    }
                }

            }
            .autoDisposable(view.scope())
            .subscribe()

        view.confirmDeleteIntent
            .autoDisposable(view.scope())
            .subscribe { conversations ->
                deleteConversations.execute(conversations)
                view.clearSelection()
            }

        view.conversationClicks
            .filter { permissionManager.isDefaultSms().also { if (!it) view.requestDefaultSms() } }
            .autoDisposable(view.scope())
            .subscribe { threadId ->
                AppUtils.logAdapterMessages(
                    EventKeys.block_list,
                    EventKeys.click,
                    EventKeys.blocked_message
                )
                navigator.showConversation(threadId)
            }

        view.selectionChanges
            .autoDisposable(view.scope())
            .subscribe { selection -> newState { copy(selected = selection.size) } }


        view.dropClickedIntent
            .filter { permissionManager.isDefaultSms().also { if (!it) view.requestDefaultSms() } }
            .autoDisposable(view.scope())
            .subscribe {
//                if (BaseConfig(BlockingActivity.blockingActivity ?: context).ads_free) {
                    prefs.drop.set(!prefs.drop.get())
                    val strDropEnabled = if (prefs.drop.get())
                        EventKeys.enable
                    else
                        EventKeys.disable
                    AppUtils.logAdapterMessages(
                        EventKeys.block_list,
                        strDropEnabled,
                        EventKeys.drop_message
                    )
//                } else {
//                    view.startSubscriptionActivity()
//                }
            }

        view.unBlockUndoSubject
            .autoDisposable(view.scope())
            .subscribe({ conversationsIds ->
                markBlocked.execute(
                    MarkBlocked.Params(
                        conversationsIds,
                        null
                    )
                )
                val addresses = conversationsIds.toLongArray()
                    .let { conversationRepo.getConversations(*it).first }
                    .flatMap { conversation -> conversation.recipients }
                    .map { it.address }
                    .distinct()

                if (addresses.isNotEmpty()) {
                    conversationRepo.block(addresses).subscribe()
                }

            }) { t -> LogE("accept: ", t?.message.toString()) }
    }

}
