package com.messenger.sms.text.common.dialog

import android.app.Activity
import android.app.AlertDialog
import com.messenger.sms.text.R
import com.messenger.sms.text.databinding.DialogMessageBinding

class PermissionRequiredDialog(
    val activity: Activity,
    textId: Int,
    private val positiveActionCallback: () -> Unit,
    private val negativeActionCallback: (() -> Unit)? = null,
) {
    private var dialog: AlertDialog? = null

    init {
        // Load interstitial ad if needed

        val view = DialogMessageBinding.inflate(activity.layoutInflater, null, false)
        view.message.text = activity.getString(textId)

        // Create and show the AlertDialog
        dialog = AlertDialog.Builder(activity, )
            .setTitle(activity.getString(R.string.permission_required))
            .setView(view.root)
            .setPositiveButton(R.string.grant_permission) { _, _ ->
                // Show interstitial ad before proceeding
                positiveActionCallback()
            }
            .setNegativeButton(R.string.button_cancel) { _, _ ->
                negativeActionCallback?.invoke()
            }
            .create()
        dialog?.show()
    }
}
