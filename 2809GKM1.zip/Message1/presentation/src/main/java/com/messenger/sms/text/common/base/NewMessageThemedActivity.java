package com.messenger.sms.text.common.base;

import android.view.Menu;

import io.reactivex.subjects.BehaviorSubject;
import io.reactivex.subjects.Subject;
import kotlin.jvm.internal.Intrinsics;
import com.domain.repository.ConversationRepository;
import com.domain.repository.MessageRepository;
import com.data.util.PhoneNumberUtils;
import com.domain.util.Preferences;

public class NewMessageThemedActivity extends MessagesActivity {

    public ConversationRepository conversationRepo;
    private final Subject<Menu> menu;
    public MessageRepository messageRepo;
    public PhoneNumberUtils phoneNumberUtils;
    public Preferences prefs;
    private final Subject<Long> threadId;

    NewMessageThemedActivity(){
        BehaviorSubject create = BehaviorSubject.create();
        Intrinsics.checkExpressionValueIsNotNull(create, "BehaviorSubject.create()");
        this.menu = create;
        BehaviorSubject createDefault = BehaviorSubject.createDefault(0L);
        Intrinsics.checkExpressionValueIsNotNull(createDefault, "BehaviorSubject.createDefault(0)");
        this.threadId = createDefault;
    }
}
