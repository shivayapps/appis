package com.messenger.sms.text.emoji_view_library.Helper;

import android.content.Context;
import android.widget.GridView;

import com.messenger.sms.text.R;
import com.messenger.sms.text.emoji_view_library.emoji.EmojiIcon;

public class EmojiIconRecentGridView extends EmojiIconGridView implements EmojiIconRecent {
    EmojiAdapter mAdapter;
    boolean mUseSystemDefault;

    public EmojiIconRecentGridView(Context context, String emojiIcons,
                                   EmojiIconRecent emojiIconRecent, EmojiIconsPopup emojiIconsPopup, boolean useSystemDefault) {
        super(context, emojiIcons, emojiIconRecent, emojiIconsPopup, useSystemDefault);
        this.mUseSystemDefault = useSystemDefault;
        EmojiIconRecentManager recent = EmojiIconRecentManager
                .getInstance(rootView.getContext());

        mAdapter = new EmojiAdapter(rootView.getContext(), recent, mUseSystemDefault);
        mAdapter.setEmojiClickListener(emojiIcon -> {
            if (this.emojiIconsPopup.onEmojiIconClickedListener != null) {
                this.emojiIconsPopup.onEmojiIconClickedListener.onEmojiIconClicked(emojiIcon);
            }
        });
        GridView gridView = rootView.findViewById(R.id.Emoji_GridView);
        gridView.setAdapter(mAdapter);
        if (mAdapter != null)
            mAdapter.notifyDataSetChanged();
    }

    @Override
    public void addRecentEmoji(Context context, EmojiIcon emojiIcon) {
        EmojiIconRecentManager recent = EmojiIconRecentManager
                .getInstance(context);
        recent.push(emojiIcon);
        // notify dataset changed
        if (mAdapter != null)
            mAdapter.notifyDataSetChanged();
    }

}