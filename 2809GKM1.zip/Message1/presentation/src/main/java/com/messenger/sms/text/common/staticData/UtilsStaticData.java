package com.messenger.sms.text.common.staticData;

import static com.messenger.sms.text.common.util.extensions.LogExtensionsKt.LogE;

import android.content.Context;
import android.content.pm.PackageInfo;
import android.util.Log;


public class UtilsStaticData {

//    public static String isEnableSettingOnBackIntAds = "isEnableSettingOnBackIntAds";
//    public static String isEnableContactBackIntAds = "isEnableContactBackIntAds";
//    public static String isEnableScheduledBackIntAds = "isEnableScheduledBackIntAds";
//    public static String isEnableStarredBackIntAds = "isEnableStarredBackIntAds";
//    public static String isEnableBackUpBackIntAds = "isEnableBackUpBackIntAds";
//    public static String isEnableBlockBackIntAds = "isEnableBlockBackIntAds";
//    public static String isEnableMessageBackIntAds = "isEnableMessageBackIntAds";

    public static String messageLimit = "messageLimit";

//    public static final String isEnableSwipeActionBackIntAds = "isEnableSwipeActionBackIntAds";
//    public static final String isEnableThemeModeBackIntAds = "isEnableThemeModeBackIntAds";
//    public static final String isEnableScreenWidgetBackIntAds = "isEnableScreenWidgetBackIntAds";

    public static boolean verifyForTest(Context context) {
        try {
            PackageInfo pInfo = context.getPackageManager().getPackageInfo(context.getPackageName(), 0);
            return pInfo.versionName.matches("[0-9][0-9.]*[0-9]");

        } catch (Exception e) {
            LogE("verifyForTest", "verifyForTest: Error" + e.getMessage());
            return false;
        }
    }
}
