package com.messenger.sms.text.feature.contacts

import com.domain.extensions.Optional
import com.messenger.sms.text.common.base.MessagesView
import com.messenger.sms.text.feature.compose.editing.ComposeItem
import com.messenger.sms.text.feature.compose.editing.PhoneNumberAction
import io.reactivex.Observable
import io.reactivex.subjects.Subject
import java.util.HashMap

interface ContactsContract : MessagesView<ContactsState> {

    val queryChangedIntent: Observable<CharSequence>
    val queryClearedIntent: Observable<*>
//    val queryEditorActionIntent: Observable<Int>
    val composeItemPressedIntent: Subject<ComposeItem>
    val composeItemLongPressedIntent: Subject<ComposeItem>
//    val phoneNumberSelectedIntent: Subject<Long>
    val phoneNumberSelectedIntent: Subject<Optional<Long>>
    val phoneNumberActionIntent: Subject<PhoneNumberAction>

    fun clearQuery()
    fun openKeyboard()
    fun openNumericKeyboard()
    fun finish(result: HashMap<String, String>)

}
