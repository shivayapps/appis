package com.messenger.sms.text.feature.blocking

import io.reactivex.Observable
import com.messenger.sms.text.common.base.MessagesViewContract

interface BlockingView : MessagesViewContract<BlockingState> {

//    val blockingManagerIntent: Observable<*>
//    val blockedNumbersIntent: Observable<*>
    val blockedMessagesIntent: Observable<*>
    val dropClickedIntent: Observable<*>

//    fun openBlockingManager()
    fun openBlockedNumbers()
    fun openBlockedMessages()
}
