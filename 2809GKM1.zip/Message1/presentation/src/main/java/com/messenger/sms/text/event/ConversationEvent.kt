package com.messenger.sms.text.event

interface ConversationEvent