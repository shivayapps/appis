package com.messenger.sms.text.feature.compose.editing

import android.content.Context
import android.os.Build
import android.view.ViewGroup
import android.widget.RelativeLayout
import androidx.recyclerview.widget.RecyclerView
import io.reactivex.subjects.PublishSubject
import com.messenger.sms.text.R
import com.messenger.sms.text.common.base.MessagesAdapter
import com.messenger.sms.text.common.base.MessagesViewHolder
import com.messenger.sms.text.common.util.extensions.dpToPx
import com.common.extensions.resolveThemeColor
import com.messenger.sms.text.common.util.extensions.setBackgroundTint
import com.domain.model.Recipient
import com.messenger.sms.text.common.util.extensions.LogE
import com.messenger.sms.text.databinding.ContactChipBinding
import javax.inject.Inject

class ChipsAdapter @Inject constructor() : MessagesAdapter<Recipient, ContactChipBinding>() {

    var view: RecyclerView? = null
    val chipDeleted: PublishSubject<Recipient> = PublishSubject.create<Recipient>()

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MessagesViewHolder<ContactChipBinding> {
//        val inflater = LayoutInflater.from(parent.context)
//        val view = inflater.inflate(R.layout.contact_chip, parent, false)
        return MessagesViewHolder(parent, ContactChipBinding::inflate).apply {
            // These theme attributes don't apply themselves on API 21
            if (Build.VERSION.SDK_INT <= 22) {
                binding.content.setBackgroundTint(parent.context.resolveThemeColor(R.attr.bubbleColor))
            }

            binding.root.setOnClickListener {
                val chip = getItem(adapterPosition)
                showDetailedChip(parent.context, chip)
            }
        }
    }

    override fun onBindViewHolder(holder: MessagesViewHolder<ContactChipBinding>, position: Int) {
        val recipient = getItem(position)

        holder.binding.avatar.setRecipient(recipient)
        holder.binding.name.text =
            recipient.contact?.name?.takeIf { it.isNotBlank() } ?: recipient.address

//        holder.binding.name.setTextColor(holder.binding.name.context.getColor(R.color.black))

        recipient.contact?.name?.apply {
            LogE("onBindViewHolder: ", this)
        }
    }

    /**
     * The [context] has to come from a view, because we're inflating a view that used themed attrs
     */
    private fun showDetailedChip(context: Context, recipient: Recipient) {
        val detailedChipView = DetailedChipView(context)
        detailedChipView.setRecipient(recipient)

        val rootView = view?.rootView as ViewGroup

        val layoutParams = RelativeLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        )

        layoutParams.topMargin = 24.dpToPx(context)
        layoutParams.marginStart = 56.dpToPx(context)

        rootView.addView(detailedChipView, layoutParams)
        detailedChipView.show()

        detailedChipView.setOnDeleteListener {
            chipDeleted.onNext(recipient)
            detailedChipView.hide()
        }
    }
}
