package com.messenger.sms.text.feature.compose

import android.net.Uri
import androidx.annotation.StringRes
import androidx.core.view.inputmethod.InputContentInfoCompat
import io.reactivex.Observable
import io.reactivex.subjects.Subject
import com.messenger.sms.text.common.base.MessagesView
import com.domain.model.Attachment
import com.domain.model.Recipient


interface ComposeView : MessagesView<ComposeState> {

    val activityVisibleIntent: Observable<Boolean>
    val chipsSelectedIntent: Subject<HashMap<String, String?>>
    val chipDeletedIntent: Subject<Recipient>
    val menuReadyIntent: Observable<Unit>
    val optionsItemIntent: Observable<Int>
    val removeStarMessageSubject: Observable<Long>
    val starMessageSubject: Observable<Long>
    val sendAsGroupIntent: Observable<*>
    val messageClickIntent: Subject<Long>
    val messagePartClickIntent: Subject<Long>
    val messagesSelectedIntent: Observable<List<Long>>
    val cancelSendingIntent: Subject<Long>
    val attachmentDeletedIntent: Subject<Attachment>
    val textChangedIntent: Observable<CharSequence>
//    val attachIntent: Observable<Unit>
    val cameraIntent: Observable<*>
    val galleryIntent: Observable<*>
    val audioIntent: Observable<*>
    val locationIntent: Observable<*>
    val scheduleIntent: Observable<*>
    val attachContactIntent: Observable<*>
    val attachmentSelectedIntent: Observable<Uri>
    val contactSelectedIntent: Observable<Uri>
    val inputContentIntent: Observable<InputContentInfoCompat>
    val scheduleSelectedIntent: Observable<Long>
    val scheduleCancelIntent: Observable<*>
    val titleConversationIntent: Observable<*>
    val changeSimIntent: Observable<*>
    val sendIntent: Observable<Unit>
    val viewMessagesPlusIntent: Subject<Unit>
    val backPressedIntent: Observable<Unit>
    val copyOtpIntent: Subject<String>
    val blockUndoSubject: Observable<Long>
    val unBlockUndoSubject: Observable<Long>
    val unBlockIntent: Observable<Long>


    fun clearSelection()
    fun showDetails(details: String)
    fun requestDefaultSms()
    fun requestStoragePermission(reqFor: Int)
    fun requestSmsPermission()
    fun showContacts(sharing: Boolean, chips: List<Recipient>)
    fun themeChanged()
    fun showKeyboard()
    fun requestCamera()
    fun requestGallery()
    fun requestRecordAudio()
    fun requestLocationString()
    fun requestDatePicker()
    fun requestContact()
    fun setDraft(draft: String)
    fun scrollToMessage(id: Long)
    fun showmessagesPlusSnackbar(@StringRes message: Int)
    fun addOrRemoveStarred(): Observable<Long>
    fun addStarred(): Observable<Long>
    fun showUnStarredSnackBar()
    fun blockUndo(): Observable<Long>
    fun showBlockedSnackBar()
    fun unBlockUndo(): Observable<Long>
    fun showUnBlockedSnackBar()
    fun unBlockViewShow()
    fun unBlockViewHide()
    fun showConversationInfo(id: Long)
//    fun startSubscriptionActivity()
}