package com.messenger.sms.text.feature.blocking

data class BlockingState(
    val blockingManager: String = "",
    val dropEnabled: Boolean = false
)
