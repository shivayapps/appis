package com.messenger.sms.text.feature.compose.part

import android.content.Context
import com.messenger.sms.text.R
import com.messenger.sms.text.common.base.MessagesViewHolder
import com.messenger.sms.text.common.util.extensions.setVisible
import com.domain.model.Message
import com.domain.model.MmsPart
import com.bumptech.glide.Glide
import com.messenger.sms.text.common.widget.BubbleImageView
import com.messenger.sms.text.databinding.MmsPreviewListItemBinding
import com.data.extensions.isImage
import com.data.extensions.isVideo
import javax.inject.Inject

class MediaBinder @Inject constructor( private val context: Context) :PartBinder<MmsPreviewListItemBinding>(MmsPreviewListItemBinding::inflate) {


    override fun canBindPart(part: MmsPart) = part.isImage() || part.isVideo()

    override fun bindPartInternal(
        holder: MessagesViewHolder<MmsPreviewListItemBinding>,
        part: MmsPart,
        message: Message,
        canGroupWithPrevious: Boolean,
        canGroupWithNext: Boolean,
    ) {
        holder.binding.video.setVisible(part.isVideo())
        holder.binding.root.setOnClickListener { clicks.onNext(part.id) }

        holder.binding.thumbnail.bubbleStyle = when {
            !canGroupWithPrevious && canGroupWithNext -> if (message.isMe()) BubbleImageView.Style.OUT_FIRST else BubbleImageView.Style.IN_FIRST
            canGroupWithPrevious && canGroupWithNext -> if (message.isMe()) BubbleImageView.Style.OUT_MIDDLE else BubbleImageView.Style.IN_MIDDLE
            canGroupWithPrevious && !canGroupWithNext -> if (message.isMe()) BubbleImageView.Style.OUT_LAST else BubbleImageView.Style.IN_LAST
            else -> BubbleImageView.Style.ONLY
        }

        Glide.with(context).load(part.getUri()).fitCenter().into(holder.binding.thumbnail)
    }



}