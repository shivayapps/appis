package com.messenger.sms.text.feature.blocking.messages

import io.realm.RealmResults
import com.domain.model.Conversation

data class BlockedMessagesState(
    val data: RealmResults<Conversation>? = null,
    val selected: Int = 0,
    val dropEnabled: Boolean = false
)
