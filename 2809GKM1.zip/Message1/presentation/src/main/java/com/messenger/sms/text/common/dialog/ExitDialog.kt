package com.messenger.sms.text.common.dialog

import android.app.Activity
import android.app.Dialog
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.util.Log
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.Window
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.TextView
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.core.content.ContextCompat
import com.adconfig.AdsConfig
import com.adconfig.adsutil.admob.AdmobNative
import com.facebook.shimmer.ShimmerFrameLayout
import com.google.android.gms.ads.nativead.NativeAd
import com.messenger.sms.text.R
import com.messenger.sms.text.utils.AdCache


class ExitDialog(
    val activity: Activity,
//    val mNativeAd: NativeAd?,
    val clickListener: (isExit: Boolean) -> Unit
) : Dialog(activity) {

//    private lateinit var mAdmobNative: AdmobNative

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestWindowFeature(Window.FEATURE_NO_TITLE)
        window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        window?.addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND)
        window?.setDimAmount(0.8f)
//        window?.navigationBarColor = ContextCompat.getColor(activity, R.color.dialogBg)
        window?.setGravity(Gravity.BOTTOM)

        setContentView(R.layout.dialog_exit)
        window?.setLayout(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.WRAP_CONTENT
        )

        AdsConfig.isSystemDialogOpen = true

        findViewById<TextView>(R.id.btnExit).setOnClickListener {
            dismiss()
            clickListener.invoke(true)
        }
        loadNativeAd()
    }

    private fun loadNativeAd() {
//        val layoutInt: Int = com.adconfig.R.layout.layout_shimmer_google_native_ad_big
//        val mShimmerLayout = LayoutInflater.from(activity).inflate(layoutInt, null) as ConstraintLayout
//        val mShimmerView: ShimmerFrameLayout = mShimmerLayout.findViewById(com.adconfig.R.id.shimmerView)
//
//        val nativeTemplate = findViewById<FrameLayout>(R.id.nativeTemplate)
//        nativeTemplate.addView(mShimmerLayout)
//        mShimmerView.startShimmer()

//        mAdmobNative = AdmobNative()
//        val adId = activity.getString(R.string.native_main)
//        if (mNativeAd != null) mAdmobNative.showNativeAd(activity, nativeTemplate, mNativeAd, adId)
//        else {
//            mAdmobNative.preLoad(activity, mNativeAd, { isLoaded, nativeAd ->
//                Log.e("native_exit", "native_exit.preLoad:$isLoaded")
//                if (isLoaded) {
//                    AdCache.exitNative = nativeAd
//                    mAdmobNative.showNativeAd(activity, nativeTemplate, mNativeAd, adId)
//                } else {
//                    nativeTemplate.visibility = View.GONE
//                }
//            }, { onImpression ->
//                //AdCache.exitNative = null
//            }, adId)
//        }
    }
}



