package com.messenger.sms.text.common.model

data class MoreAppsModel(
    val appName: String,
    val shortDescription: String,
    val appImageLink: String,
    val appPackageName: String,
    val appPlayStoreLink: String
)