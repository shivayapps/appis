package com.messenger.sms.text.emoji_view_library.Helper;

import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.GridView;

import java.util.ArrayList;
import java.util.Collections;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import com.messenger.sms.text.R;
import com.messenger.sms.text.emoji_view_library.emoji.Cars;
import com.messenger.sms.text.emoji_view_library.emoji.Electronics;
import com.messenger.sms.text.emoji_view_library.emoji.EmojiIcon;
import com.messenger.sms.text.emoji_view_library.emoji.Flags;
import com.messenger.sms.text.emoji_view_library.emoji.Food;
import com.messenger.sms.text.emoji_view_library.emoji.Nature;
import com.messenger.sms.text.emoji_view_library.emoji.People;
import com.messenger.sms.text.emoji_view_library.emoji.Sport;
import com.messenger.sms.text.emoji_view_library.emoji.Symbols;

public class EmojiIconGridView {
    public View rootView;
    EmojiIconsPopup emojiIconsPopup;
    EmojiIconRecent emojiIconRecent;
    ArrayList<EmojiIcon> mData = new ArrayList<>();
    String emojiIcons;
    EmojiAdapter mAdapter;
    ExecutorService executor = Executors.newSingleThreadExecutor();


    public EmojiIconGridView(Context context, String emojiIcons, EmojiIconRecent iconRecent, EmojiIconsPopup emojiIconsPopup, boolean useSystemDefault) {
        LayoutInflater inflater = (LayoutInflater) context.getSystemService(Activity.LAYOUT_INFLATER_SERVICE);
        this.emojiIconsPopup = emojiIconsPopup;
        rootView = inflater.inflate(R.layout.emojicon_grid, null);
        setRecents(iconRecent);
        this.emojiIcons = emojiIcons;
        GridView gridView = rootView.findViewById(R.id.Emoji_GridView);

        if (emojiIcons != null) {
            EmojiAdd();
        }
        mAdapter = new EmojiAdapter(rootView.getContext(), mData, useSystemDefault);
        try {
            mAdapter.setEmojiClickListener(emojiIcon -> {
                if (this.emojiIconsPopup.onEmojiIconClickedListener != null) {
                    this.emojiIconsPopup.onEmojiIconClickedListener.onEmojiIconClicked(emojiIcon);
                }
                if (emojiIconRecent != null) {
                    emojiIconRecent.addRecentEmoji(rootView.getContext(), emojiIcon);
                }
            });
            gridView.setAdapter(mAdapter);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void setRecents(EmojiIconRecent recent) {
        emojiIconRecent = recent;
    }

    public interface OnEmojiIconClickedListener {
        void onEmojiIconClicked(EmojiIcon emojiIcon);
    }

    private void EmojiAdd() {
        executor.execute(() -> {
            //Background work here
            switch (emojiIcons) {
                case "People":
                    Collections.addAll(mData, People.DATA);
                    break;
                case "Nature":
                    Collections.addAll(mData, Nature.DATA);
                    break;
                case "Food":
                    Collections.addAll(mData, Food.DATA);
                    break;
                case "Sport":
                    Collections.addAll(mData, Sport.DATA);
                    break;
                case "Cars":
                    Collections.addAll(mData, Cars.DATA);
                    break;
                case "Electr":
                    Collections.addAll(mData, Electronics.DATA);
                    break;
                case "Symbols":
                    Collections.addAll(mData, Symbols.DATA);
                    break;
                case "Flags":
                    Collections.addAll(mData, Flags.DATA);
                    break;
            }

        });
    }
}