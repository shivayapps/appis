package com.messenger.sms.text.common

import android.app.Activity
import android.content.Context
import androidx.annotation.StringRes
import androidx.appcompat.app.AlertDialog
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.messenger.sms.text.R
import com.messenger.sms.text.common.util.extensions.dpToPx
import com.messenger.sms.text.common.util.extensions.setPadding
import com.messenger.sms.text.injection.appComponent
import com.domain.util.Preferences
import javax.inject.Inject

/**
 * Wrapper around AlertDialog which makes it easier to display lists that use our UI
 */
class ScheduleMessagesDialog @Inject constructor(
    private val context: Context,
    val adapter: ScheduleMenuItemAdapter
) {

    var title: String? = null

    init {
        appComponent.inject(this)
    }

    @Inject
    lateinit var prefs: Preferences

    fun show(activity: Activity) {
        val recyclerView = RecyclerView(activity)
        recyclerView.layoutManager = LinearLayoutManager(context)
        recyclerView.adapter = adapter
        recyclerView.setPadding(top = 8.dpToPx(context), bottom = 8.dpToPx(context))

        val dialog = AlertDialog.Builder(activity, R.style.MyOptionDialogTheme)
            .setView(recyclerView)
            .create()

        val clicks = adapter.menuItemClicks
            .subscribe {
                dialog.dismiss()
            }

        dialog.setOnDismissListener {
            clicks.dispose()
        }
        dialog.setTitle(title)
        dialog.show()

    }

    fun setTitle(@StringRes title: Int) {
        this.title = context.getString(title)
    }

}