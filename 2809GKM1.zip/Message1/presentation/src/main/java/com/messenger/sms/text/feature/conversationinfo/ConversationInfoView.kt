package com.messenger.sms.text.feature.conversationinfo

import io.reactivex.Observable
import com.messenger.sms.text.common.base.MessagesView

interface ConversationInfoView : MessagesView<ConversationInfoState> {
    //MessagesViewContract<ConversationInfoState> {
    fun callClicks(): Observable<Long>
    fun recipientClicks(): Observable<Long>
    fun recipientLongClicks(): Observable<Long>
    fun nameClicks(): Observable<*>
    fun nameChanges(): Observable<String>
    fun notificationClicks(): Observable<*>
    fun archiveClicks(): Observable<*>
    fun copyClicks(): Observable<String>
    fun messageClicks(): Observable<String>
    fun blockClicks(): Observable<*>
    fun deleteClicks(): Observable<*>
    fun confirmDelete(): Observable<*>
    fun mediaClicks(): Observable<Long>

    fun showNameDialog(name: String)
    fun showBlockingDialog(conversations: List<Long>, block: Boolean, isTrue: (Boolean) -> Unit)
    fun requestDefaultSms()
    fun showDeleteDialog()
    fun messageToThisNumber(number: String, isGroup: Boolean)
    fun onBackPressed()
}
