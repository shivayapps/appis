package com.messenger.sms.text.common.widget

import android.content.Context
import android.content.res.ColorStateList
import android.util.AttributeSet
import android.view.View
import android.widget.TextView
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.core.content.ContextCompat
import com.messenger.sms.text.R
import com.messenger.sms.text.common.util.extensions.forwardTouches
import com.common.extensions.resolveThemeAttribute
import com.messenger.sms.text.common.util.extensions.setVisible
import com.messenger.sms.text.common.util.extensions.customViewBinding
import com.messenger.sms.text.databinding.RadioPreferenceViewBinding
import com.messenger.sms.text.injection.appComponent
import com.common.extensions.resolveThemeColor

class RadioPreferenceView @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null
) : ConstraintLayout(context, attrs) {

    val binding: RadioPreferenceViewBinding = customViewBinding(RadioPreferenceViewBinding::inflate)
//    val binding: RadioPreferenceViewBinding = customViewBinding(RadioPreferenceViewBinding::inflate)
    var title: String? = null
        set(value) {
            field = value

            if (isInEditMode) {
                findViewById<TextView>(R.id.titleView).text = value
            } else {
                binding.titleView.text = value
            }
        }

    var summary: String? = null
        set(value) {
            field = value


            if (isInEditMode) {
                findViewById<TextView>(R.id.summaryView).run {
                    text = value
                    setVisible(value?.isNotEmpty() == true)
                }
            } else {
                binding.summaryView.text = value
                binding.summaryView.setVisible(value?.isNotEmpty() == true)
            }
        }

    init {
        if (!isInEditMode) {
            appComponent.inject(this)
        }

        View.inflate(context, R.layout.radio_preference_view, this)
        setBackgroundResource(context.resolveThemeAttribute(R.attr.selectableItemBackground))

        val states = arrayOf(
                intArrayOf(android.R.attr.state_checked),
                intArrayOf(-android.R.attr.state_checked))

        /*val themeColor = when (isInEditMode) {
            true -> ContextCompat.getColor(context, R.color.tools_theme)
            false -> colors.theme().theme
        }*/
        val themeColor =  ContextCompat.getColor(context, R.color.color_app_theme)
        val textSecondary = context.resolveThemeColor(android.R.attr.textColorTertiary)
        binding.radioButton.buttonTintList = ColorStateList(states, intArrayOf(themeColor, textSecondary))
        binding.radioButton.forwardTouches(this)

        context.obtainStyledAttributes(attrs, R.styleable.RadioPreferenceView)?.run {
            title = getString(R.styleable.RadioPreferenceView_title)
            summary = getString(R.styleable.RadioPreferenceView_summary)

            // If there's a custom view used for the preference's widget, inflate it
            getResourceId(R.styleable.RadioPreferenceView_widget, -1).takeIf { it != -1 }?.let { id ->
                View.inflate(context, id, binding.widgetFrame)
            }

            recycle()
        }
    }

}