package com.messenger.sms.text.common.util

import android.content.Context
import android.content.pm.PackageInfo
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.os.Build
import com.messenger.sms.text.R
import java.io.File
import java.lang.Math.sqrt
import java.util.*


fun Context.getAllDeviceInfo(): String {
    val stringBuilder = StringBuilder("*** BASIC-INFO ***")
    stringBuilder.append("\nDevice: " + getDeviceInfo(Device.DEVICE_SYSTEM_VERSION))
    stringBuilder.append("\nSDK Version: " + Build.VERSION.SDK_INT + "\n" + getDeviceInfo(Device.DEVICE_VERSION))
    stringBuilder.append("\nApp Name:  " + getDeviceInfo(Device.APP_NAME) + "\n")
    stringBuilder.append("""App Version: ${getAppVersion()}""")
    stringBuilder.append("\nLanguage: " + getDeviceInfo(Device.DEVICE_LANGUAGE))
    stringBuilder.append("\nTimeZone: " + getDeviceInfo(Device.DEVICE_TIME_ZONE))
    stringBuilder.append("\nDevice Type: " + getDeviceInfo(Device.DEVICE_TYPE))
    stringBuilder.append("\n" + getDeviceInfo(Device.DEVICE_ROOTED_OR_NOT))
    return stringBuilder.toString()
}

fun Context.getDeviceInfo(device: Device?): String {
    try {
        when (device) {
            Device.DEVICE_LANGUAGE -> return Locale.getDefault().country + " " + Locale.getDefault().displayLanguage
            Device.DEVICE_TIME_ZONE -> return TimeZone.getDefault().id //(false, TimeZone.SHORT);
            Device.DEVICE_SYSTEM_VERSION -> return deviceName
            Device.APP_NAME -> return resources.getString(R.string.app_name_message)
            Device.DEVICE_VERSION -> return "Android: " + Build.VERSION.RELEASE
            Device.DEVICE_ROOTED_OR_NOT -> return "Rooted: " + if (isRooted()) {
                "Rooted"
            } else {
                "Not Rooted"
            }
            Device.DEVICE_TYPE -> return if (isTablet()) {
                if (getDeviceMoreThan7Inch()) {
                    "Tablet"
                } else "Mobile"
            } else {
                "Mobile"
            }
            else -> {

            }
        }
    } catch (e: Exception) {
        e.printStackTrace()
    }
    return ""
}

private val deviceName: String
    get() {
        val manufacturer = Build.MANUFACTURER
        val model = Build.MODEL
        return if (model.startsWith(manufacturer)) {
            capitalize(model)
        } else {
            capitalize(manufacturer) + " " + model
        }
    }

private fun capitalize(s: String?): String {
    if (s == null || s.isEmpty()) {
        return ""
    }
    val first = s[0]
    return if (Character.isUpperCase(first)) {
        s
    } else {
        Character.toUpperCase(first).toString() + s.substring(1)
    }
}


private fun Context.isTablet(): Boolean {
    return resources.configuration.screenLayout and Configuration.SCREENLAYOUT_SIZE_MASK >= Configuration.SCREENLAYOUT_SIZE_LARGE
}

private fun Context.getDeviceMoreThan7Inch(): Boolean {
    return try {
        val displayMetrics = resources.displayMetrics
        val yInches = displayMetrics.heightPixels / displayMetrics.ydpi
        val xInches = displayMetrics.widthPixels / displayMetrics.xdpi
        val diagonalInches = sqrt(xInches * xInches + yInches * yInches.toDouble())
        diagonalInches >= 7
    } catch (e: Exception) {
        false
    }
}

private fun Context.getAppVersion(): String {
    val pInfo: PackageInfo?
    var version = " "
    try {
        pInfo = packageManager.getPackageInfo(packageName, 0)
        version = pInfo.versionName!!
    } catch (e: PackageManager.NameNotFoundException) {
        e.printStackTrace()
    }
    return version
}

private fun isRooted(): Boolean {

    // get from build info
    val buildTags = Build.TAGS
    if (buildTags != null && buildTags.contains("test-keys")) {
        return true
    }

    // check if /system/app/Superuser.apk is present
    try {
        val file = File("/system/app/Superuser.apk")
        if (file.exists()) {
            return true
        }
    } catch (e1: java.lang.Exception) {
        // ignore
    }

    // try executing commands
    //return canExecuteCommand("/system/xbin/which su")|| canExecuteCommand("/system/bin/which su") || canExecuteCommand("which su");
    if (!canExecuteCommand("su")) if (findBinary("su")) return true
    return false
}

private fun findBinary(binaryName: String): Boolean {
    var found = false
    if (!found) {
        val places = arrayOf(
            "/sbin/",
            "/system/bin/",
            "/system/xbin/",
            "/data/local/xbin/",
            "/data/local/bin/",
            "/system/sd/xbin/",
            "/system/bin/failsafe/",
            "/data/local/"
        )
        for (where in places) {
            if (File(where + binaryName).exists()) {
                found = true
                break
            }
        }
    }
    return found
}

private fun canExecuteCommand(command: String): Boolean {
    val executedSuccessfully: Boolean = try {
        Runtime.getRuntime().exec(command)
        true
    } catch (e: Exception) {
        false
    }
    return executedSuccessfully
}

enum class Device {
    DEVICE_TYPE, DEVICE_VERSION, APP_NAME, DEVICE_SYSTEM_VERSION, DEVICE_LANGUAGE, DEVICE_TIME_ZONE, DEVICE_ROOTED_OR_NOT
}

