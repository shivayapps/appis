package com.messenger.sms.text

interface Dailogresponse {
    fun onResponseYes()
    fun onResponseNo()
}