package com.messenger.sms.text.feature.contacts

import com.messenger.sms.text.feature.compose.editing.ComposeItem
import com.domain.model.Contact


data class ContactsState(
    val query: String = "",
    val composeItems: List<ComposeItem> = ArrayList(),
    val selectedContact: Contact? = null // For phone number picker
)
