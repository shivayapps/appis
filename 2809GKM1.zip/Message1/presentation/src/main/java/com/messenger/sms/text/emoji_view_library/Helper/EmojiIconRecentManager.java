package com.messenger.sms.text.emoji_view_library.Helper;

import android.content.Context;
import android.content.SharedPreferences;

import java.util.ArrayList;
import java.util.StringTokenizer;

import com.messenger.sms.text.emoji_view_library.emoji.EmojiIcon;

public class EmojiIconRecentManager extends ArrayList<EmojiIcon> {

    private static final String PREFERENCE_NAME = "emojicon";
    private static final String PREF_RECENTS = "recent_emojis";
    private static final String PREF_PAGE = "recent_page";

    private static final Object LOCK = new Object();
    private static volatile EmojiIconRecentManager sInstance;

    private final Context mContext;

    private EmojiIconRecentManager(Context context) {
        mContext = context.getApplicationContext();
        loadRecent();
    }

    public static EmojiIconRecentManager getInstance(Context context) {
        if (sInstance == null) {
            synchronized (LOCK) {
                if (sInstance == null) {
                    sInstance = new EmojiIconRecentManager(context);
                }
            }
        }
        return sInstance;
    }

    public int getRecentPage() {
        return getPreferences().getInt(PREF_PAGE, 0);
    }

    public void setRecentPage(int page) {
        getPreferences().edit().putInt(PREF_PAGE, page).apply();
    }

    public void push(EmojiIcon object) {
        if (contains(object)) {
            super.remove(object);
        }
        add(0, object);
    }

    @Override
    public boolean add(EmojiIcon object) {
        return super.add(object);
    }

    @Override
    public void add(int index, EmojiIcon object) {
        super.add(index, object);
    }

    @Override
    public boolean remove(Object object) {
        return super.remove(object);
    }

    private SharedPreferences getPreferences() {
        return mContext.getSharedPreferences(PREFERENCE_NAME, Context.MODE_PRIVATE);
    }

    private void loadRecent() {
        SharedPreferences prefs = getPreferences();
        String str = prefs.getString(PREF_RECENTS, "");
        StringTokenizer tokenizer = new StringTokenizer(str, "~");
        while (tokenizer.hasMoreTokens()) {
            try {
                add(new EmojiIcon(tokenizer.nextToken()));
            } catch (NumberFormatException e) {
                e.printStackTrace();
            }
        }
    }

    public void saveRecent() {
        StringBuilder str = new StringBuilder();
        int c = size();
        for (int i = 0; i < c; i++) {
            EmojiIcon e = get(i);
            str.append(e.getEmoji());
            if (i < (c - 1)) {
                str.append('~');
            }
        }
        SharedPreferences prefs = getPreferences();
        prefs.edit().putString(PREF_RECENTS, str.toString()).apply();
    }

}
