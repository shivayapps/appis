plugins {
    id("com.android.application")
    id("realm-android") // Realm must be before Kotlin
    id("org.jetbrains.kotlin.android")
    id("kotlin-kapt")
//    id("com.google.devtools.ksp")
    id("com.google.gms.google-services")
    id("com.google.firebase.crashlytics")
    id("org.jetbrains.kotlin.plugin.serialization") version "2.0.21"
}

android {
    namespace = "com.messenger.sms.text"
    compileSdk = 35

    useLibrary("org.apache.http.legacy")

    defaultConfig {
        applicationId = "com.msgzy.inboxly.sms.text"
        minSdk = 26
        targetSdk = 35
        versionCode = 13
        versionName = "1.0.3"
        multiDexEnabled = true

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
        setProperty("archivesBaseName", "messages-v$versionName")
    }

    buildFeatures {
        buildConfig = true
        viewBinding = true
        dataBinding = true
    }

    bundle {
        density {
            enableSplit = true
        }
        abi {
            enableSplit = true
        }
        language {
            enableSplit = false
        }
    }

    signingConfigs {
        create("release") {
            storeFile = rootProject.file("app/com.msgzy.inboxly.sms.text.jks")
            storePassword = "com.msgzy.inboxly.sms.text"
            keyAlias = "com.msgzy.inboxly.sms.text"
            keyPassword = "com.msgzy.inboxly.sms.text"
        }
    }


    buildTypes {
        debug {
            signingConfig = signingConfigs.getByName("release")
            isMinifyEnabled = false
            isShrinkResources = false
            proguardFiles(
                getDefaultProguardFile("proguard-android.txt"),
                "proguard-rules.pro"
            )
        }
        release {
            signingConfig = signingConfigs.getByName("release")
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(
                getDefaultProguardFile("proguard-android.txt"),
                "proguard-rules.pro"
            )
        }
    }


    flavorDimensions += "default"
    productFlavors {
        create("TestAd") {
            isDefault = true
            resValue("string", "ads_application_id", "ca-app-pub-3940256099942544~3347511713")

            resValue("string", "open_resume", "ca-app-pub-3940256099942544/9257395921")
            resValue("string", "open_splash", "ca-app-pub-3940256099942544/9257395921")
            resValue("string", "inter_backpress", "ca-app-pub-3940256099942544/1033173712")
            resValue("string", "banner_main", "ca-app-pub-3940256099942544/9214589741")
            resValue("string", "banner_blocking", "ca-app-pub-3940256099942544/9214589741")
            resValue("string", "banner_notification", "ca-app-pub-3940256099942544/9214589741")
            resValue("string", "banner_localization", "ca-app-pub-3940256099942544/9214589741")
            resValue("string", "banner_swipeaction", "ca-app-pub-3940256099942544/9214589741")
            resValue("string", "banner_compose", "ca-app-pub-3940256099942544/9214589741")
            resValue("string", "banner_conversation", "ca-app-pub-3940256099942544/9214589741")
            resValue("string", "banner_starred", "ca-app-pub-3940256099942544/9214589741")
            resValue("string", "banner_schedule", "ca-app-pub-3940256099942544/9214589741")
            resValue("string", "banner_search", "ca-app-pub-3940256099942544/9214589741")
            resValue("string", "native_blocking", "ca-app-pub-3940256099942544/2247696110")
            resValue("string", "native_contact", "ca-app-pub-3940256099942544/2247696110")
            resValue("string", "native_main", "ca-app-pub-3940256099942544/2247696110")
            resValue("string", "native_schedule", "ca-app-pub-3940256099942544/2247696110")
            resValue("string", "native_starred", "ca-app-pub-3940256099942544/2247696110")

            resValue("string", "open_resume2", "ca-app-pub-3940256099942544/9257395921")
            resValue("string", "open_splash2", "ca-app-pub-3940256099942544/9257395921")
            resValue("string", "inter_backpress2", "ca-app-pub-3940256099942544/1033173712")
            resValue("string", "banner_main2", "ca-app-pub-3940256099942544/9214589741")
            resValue("string", "banner_blocking2", "ca-app-pub-3940256099942544/9214589741")
            resValue("string", "banner_notification2", "ca-app-pub-3940256099942544/9214589741")
            resValue("string", "banner_localization2", "ca-app-pub-3940256099942544/9214589741")
            resValue("string", "banner_swipeaction2", "ca-app-pub-3940256099942544/9214589741")
            resValue("string", "banner_compose2", "ca-app-pub-3940256099942544/9214589741")
            resValue("string", "banner_conversation2", "ca-app-pub-3940256099942544/9214589741")
            resValue("string", "banner_starred2", "ca-app-pub-3940256099942544/9214589741")
            resValue("string", "banner_schedule2", "ca-app-pub-3940256099942544/9214589741")
            resValue("string", "banner_search2", "ca-app-pub-3940256099942544/9214589741")
            resValue("string", "native_blocking2", "ca-app-pub-3940256099942544/2247696110")
            resValue("string", "native_contact2", "ca-app-pub-3940256099942544/2247696110")
            resValue("string", "native_main2", "ca-app-pub-3940256099942544/2247696110")
            resValue("string", "native_schedule2", "ca-app-pub-3940256099942544/2247696110")
            resValue("string", "native_starred2", "ca-app-pub-3940256099942544/2247696110")

        }
        create("LiveAd") {

            resValue("string", "ads_application_id", "ca-app-pub-8220543496759402~7622084462")
            resValue("string", "open_resume", "ca-app-pub-8220543496759402/8656583080")
            resValue("string", "open_splash", "ca-app-pub-8220543496759402/1148277089")
            resValue("string", "inter_backpress", "ca-app-pub-8220543496759402/6165811803")
            resValue("string", "banner_main", "ca-app-pub-8220543496759402/9242389526")

            resValue("string", "banner_blocking", "ca-app-pub-8220543496759402/4692948035")
            resValue("string", "banner_notification", "ca-app-pub-8220543496759402/5507675566")
            resValue("string", "banner_localization", "ca-app-pub-8220543496759402/3355815637")
            resValue("string", "banner_swipeaction", "ca-app-pub-8220543496759402/7326850231")
            resValue("string", "banner_compose", "ca-app-pub-8220543496759402/9729652292")
            resValue("string", "banner_conversation", "ca-app-pub-8220543496759402/3539648465")
            resValue("string", "banner_starred", "ca-app-pub-8220543496759402/9913485122")
            resValue("string", "banner_schedule", "ca-app-pub-8220543496759402/8600403458")
            resValue("string", "banner_search", "ca-app-pub-8220543496759402/9629402332")
            resValue("string", "native_blocking", "ca-app-pub-8220543496759402/5974240119")
            resValue("string", "native_contact", "ca-app-pub-8220543496759402/6616226187")
            resValue("string", "native_main", "ca-app-pub-8220543496759402/2091174732")
            resValue("string", "native_schedule", "ca-app-pub-8220543496759402/8416570620")
            resValue("string", "native_starred", "ca-app-pub-8220543496759402/3348076770")

            resValue("string", "open_resume2", "ca-app-pub-8220543496759402/9778093060")
            resValue("string", "open_splash2", "ca-app-pub-8220543496759402/9721913437")
            resValue("string", "inter_backpress2", "ca-app-pub-8220543496759402/5782668427")
            resValue("string", "banner_main2", "ca-app-pub-8220543496759402/4637107714")
            resValue("string", "banner_blocking2", "ca-app-pub-8220543496759402/9420431032")
            resValue("string", "banner_notification2", "ca-app-pub-8220543496759402/2120525518")
            resValue("string", "banner_localization2", "ca-app-pub-8220543496759402/7125440186")
            resValue("string", "banner_swipeaction2", "ca-app-pub-8220543496759402/2265648134")
            resValue("string", "banner_compose2", "ca-app-pub-8220543496759402/6969527519")
            resValue("string", "banner_conversation2", "ca-app-pub-8220543496759402/3627024785")
            resValue("string", "banner_starred2", "ca-app-pub-8220543496759402/1828881474")
            resValue("string", "banner_schedule2", "ca-app-pub-8220543496759402/2313943119")
            resValue("string", "banner_search2", "ca-app-pub-8220543496759402/9515799801")
            resValue("string", "native_blocking2", "ca-app-pub-8220543496759402/5656445847")
            resValue("string", "native_contact2", "ca-app-pub-8220543496759402/6889636466")
            resValue("string", "native_main2", "ca-app-pub-8220543496759402/8639484790")
            resValue("string", "native_schedule2", "ca-app-pub-8220543496759402/1541941019")
            resValue("string", "native_starred2", "ca-app-pub-8220543496759402/9539850539")
        }
    }

    kapt {
        correctErrorTypes = true
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }

    lint {
        abortOnError = false
    }
}

dependencies {
    implementation(project(":android-smsmms"))

    implementation("androidx.appcompat:appcompat:1.3.0")
    implementation("androidx.core:core-ktx:1.12.0")
    implementation("androidx.exifinterface:exifinterface:1.0.0")
    implementation("androidx.activity:activity:1.9.2")
    implementation("com.google.android.gms:play-services-measurement-api:22.1.2")
    implementation("com.google.code.gson:gson:2.13.2")
//    implementation("org.jetbrains.kotlinx:kotlinx-serialization-json:1.9.0")
    implementation("androidx.browser:browser:1.8.0")

    implementation("androidx.emoji:emoji-appcompat:1.1.0")
    implementation("com.google.code.gson:gson:2.10.1")

    implementation("com.bluelinelabs:conductor:2.1.5")
    implementation("com.bluelinelabs:conductor-archlifecycle:2.1.5")

    implementation("com.github.bumptech.glide:glide:4.16.0")
    kapt("com.github.bumptech.glide:compiler:4.12.0")

    implementation("com.google.android.exoplayer:exoplayer-core:2.16.1")
    implementation("com.google.android.exoplayer:exoplayer-ui:2.16.1") {
        exclude(group = "com.android.support", module = "support-media-compat")
    }

    implementation("com.jakewharton.rxbinding2:rxbinding-kotlin:2.0.0")
    implementation("com.jakewharton.rxbinding2:rxbinding-support-v4-kotlin:2.0.0")

    implementation("com.uber.autodispose:autodispose-android-archcomponents:1.3.0")
    implementation("com.uber.autodispose:autodispose-android:1.3.0")
    implementation("com.uber.autodispose:autodispose:1.3.0")
    implementation("com.uber.autodispose:autodispose-lifecycle:1.3.0")

    implementation("com.google.dagger:dagger:2.51.1")
    implementation("com.google.dagger:dagger-android-support:2.51.1")
    kapt("com.google.dagger:dagger-compiler:2.51.1")
    kapt("com.google.dagger:dagger-android-processor:2.51.1")

    implementation("androidx.lifecycle:lifecycle-viewmodel-ktx:2.5.1")
//    implementation("androidx.work:work-runtime-ktx:2.6.0")
    implementation("androidx.work:work-runtime-ktx:2.9.0")
    implementation("androidx.lifecycle:lifecycle-extensions:2.2.0")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.5.1")
    kapt("androidx.lifecycle:lifecycle-compiler:2.5.1")

    kapt("io.realm:realm-annotations:10.19.0")
    kapt("io.realm:realm-annotations-processor:10.19.0")

    implementation("io.reactivex.rxjava2:rxandroid:2.0.1")
    implementation("io.reactivex.rxjava2:rxjava:2.2.18")
    implementation("io.reactivex.rxjava2:rxkotlin:2.1.0")

    androidTestImplementation("androidx.test.espresso:espresso-core:3.1.0-alpha3") {
        exclude(group = "com.android.support", module = "support-annotations")
    }
    testImplementation("org.mockito:mockito-core:2.18.3")
    androidTestImplementation("org.mockito:mockito-android:2.18.3")
    testImplementation("androidx.test:runner:1.1.0-alpha3")
    testImplementation("junit:junit:4.12")

    implementation("com.squareup.moshi:moshi:1.15.0")
    implementation("com.squareup.moshi:moshi-kotlin:1.15.0")
    kapt("com.squareup.moshi:moshi-kotlin-codegen:1.15.0")

    implementation("com.android.installreferrer:installreferrer:1.1")

    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-core:1.2.2")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.2.2")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-rx2:1.2.2")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-reactive:1.2.2")

    implementation("com.f2prateek.rx.preferences2:rx-preferences:2.0.0-RC3")
    implementation("com.google.android.flexbox:flexbox:3.0.0")
    implementation("com.jakewharton.timber:timber:4.5.1")
    implementation("me.leolin:ShortcutBadger:1.1.21")

    implementation("com.intuit.sdp:sdp-android:1.1.1")
    implementation("com.android.support:support-annotations:28.0.0")
    implementation("com.balysv:material-ripple:1.0.2")
    implementation("com.squareup.okhttp3:okhttp:4.7.2")
    implementation("io.michaelrocks:libphonenumber-android:8.13.35")
    implementation("com.airbnb.android:lottie:4.1.0")

    implementation("com.google.android.play:review-ktx:2.0.1")
    implementation("com.google.android.play:app-update:2.1.0")

    implementation("com.google.android.gms:play-services-location:21.0.1")
    implementation(platform("com.google.firebase:firebase-bom:33.7.0"))
    implementation("com.google.firebase:firebase-inappmessaging-display-ktx")
    implementation("com.google.firebase:firebase-messaging")
    implementation("com.google.firebase:firebase-config")
    implementation("com.google.firebase:firebase-crashlytics")
    implementation("com.google.firebase:firebase-crashlytics-ktx")
    implementation("com.google.firebase:firebase-analytics")
    implementation("com.google.firebase:firebase-perf-ktx")

    implementation("androidx.multidex:multidex:2.0.1")
    implementation("com.karumi:dexter:6.2.3")

    implementation("com.googlecode.ez-vcard:ez-vcard:0.10.4") {
        exclude(group = "org.jsoup", module = "jsoup")
        exclude(group = "org.freemarker", module = "freemarker")
        exclude(group = "com.fasterxml.jackson.core", module = "jackson-core")
    }

    implementation("net.yslibrary.keyboardvisibilityevent:keyboardvisibilityevent:3.0.0-RC3")
    implementation("com.github.simonebortolin:FlowLayoutManager:1.8.0")
    implementation("org.greenrobot:eventbus:3.3.1")
    implementation("com.alexvasilkov:gesture-views:2.8.3")
    implementation("androidx.core:core-splashscreen:1.0.1")
    implementation("com.github.zhpanvip:viewpagerindicator:1.2.2")
    implementation("com.google.android.gms:play-services-ads:23.0.0")
    implementation(project(":ads"))
}




