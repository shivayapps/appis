package messages.text.sms.feature.startup

import android.os.Bundle
import dagger.android.AndroidInjection
import messages.text.sms.adhelper.BannerAdHelper
import messages.text.sms.common.base.MainBaseThemedActivity
import messages.text.sms.databinding.ActivityAllSetBinding
import messages.text.sms.extensions.baseConfig
import messages.text.sms.util.AdsConfig

class AllSetActivity :
    MainBaseThemedActivity<ActivityAllSetBinding>(ActivityAllSetBinding::inflate) {

    override fun onCreate(savedInstanceState: Bundle?) {
        AndroidInjection.inject(this)
        super.onCreate(savedInstanceState)
        setContentView(binding.root)

        binding.btnNext.setOnClickListener {
            baseConfig.onboardingCompleted = true
            StartupFlow.continueAfter(this, StartupFlow.Step.ALL_SET)
        }
        loadAds()
    }

    private fun loadAds() {
        BannerAdHelper.showBanner(
            this,
            binding.adsView,
            AdsConfig.banner_splash,
            { _, _ -> }
        )
    }
}
