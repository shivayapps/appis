package messages.text.sms.feature.startup

import android.app.role.RoleManager
import android.content.ComponentName
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.os.CountDownTimer
import android.os.Handler
import android.os.Looper
import android.provider.Telephony
import android.text.SpannableString
import android.text.Spanned
import android.text.TextPaint
import android.text.method.LinkMovementMethod
import android.text.style.ClickableSpan
import android.text.style.ForegroundColorSpan
import android.util.Log
import android.view.View
import androidx.core.content.ContextCompat
import dagger.android.AndroidInjection
import messages.text.sms.R
import messages.text.sms.adhelper.BannerAdHelper
import messages.text.sms.common.base.MainBaseThemedActivity
import messages.text.sms.databinding.ActivityPermissionBinding
import messages.text.sms.extensions.MiuiHelperUtils
import messages.text.sms.extensions.isQPlus
import messages.text.sms.extensions.launchUrl
import messages.text.sms.util.AdsConfig


class PermissionActivity :
    MainBaseThemedActivity<ActivityPermissionBinding>(ActivityPermissionBinding::inflate) {

    private val MAKE_DEFAULT_APP_REQUEST = 1001
    private var isAutoStartGranted = false
    private var isReturningFromAutoStart = false

    val TAG = "PermissionActivity"

    override fun onCreate(savedInstanceState: Bundle?) {
        AndroidInjection.inject(this)
        super.onCreate(savedInstanceState)
        setContentView(binding.root)

        refreshDefaultSmsState()
        binding.btnNext.setOnClickListener {
            requestDefaultSms()
        }
        binding.cardSmsPermission.setOnClickListener {
            requestDefaultSms()
        }
        loadAds()
        setupPrivacyPolicy()
    }

    override fun onResume() {
        super.onResume()
        refreshDefaultSmsState()
        if (isReturningFromAutoStart) {
            isReturningFromAutoStart = false
            checkAutoStartAfterReturn()
        }
    }

    fun loadAds() {
        BannerAdHelper.showBanner(
            this,
            binding.adsView,
            AdsConfig.banner_splash,
            { isLoaded, message ->

            })
    }

    private fun setupPrivacyPolicy() {
        val text = "By allowing, you agree to our Privacy Policy."
        val clickableText = "Privacy Policy"
        val spannable = SpannableString(text)
        val start = text.indexOf(clickableText)
        val end = start + clickableText.length
        spannable.setSpan(
            ForegroundColorSpan(ContextCompat.getColor(this, R.color.md_theme_primary)),
            start,
            end,
            Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
        )
        spannable.setSpan(object : ClickableSpan() {
            override fun onClick(widget: View) {
                launchUrl(getString(R.string.privacy_policy_url))
            }

            override fun updateDrawState(ds: TextPaint) {
                super.updateDrawState(ds)
                ds.color = ContextCompat.getColor(this@PermissionActivity, R.color.md_theme_primary)
                ds.isUnderlineText = false
            }
        }, start, end, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        binding.tvPolicy.text = spannable
        binding.tvPolicy.movementMethod = LinkMovementMethod.getInstance()
        binding.tvPolicy.highlightColor = Color.TRANSPARENT
    }

    private fun refreshDefaultSmsState() {
        val isDefault = isDefaultSms()
        binding.ivCheckSms.setImageResource(
            if (isDefault) R.drawable.ic_radio_button_checked
            else R.drawable.ic_radio_button_unchecked
        )
        binding.btnNext.setText(
            if (isDefault) R.string.agree_amp_continue
            else R.string.label_set_default_sms
        )
    }

    private fun isDefaultSms(): Boolean {
        return if (isQPlus()) {
            val roleManager = getSystemService(RoleManager::class.java)
            roleManager.isRoleHeld(RoleManager.ROLE_SMS)
        } else {
            Telephony.Sms.getDefaultSmsPackage(this) == packageName
        }
    }

    private fun checkAutoStartPermission() {
        Log.e(TAG, "checkAutoStartPermission >>")
        isAutoStartGranted = MiuiHelperUtils.isAutoStartEnabled(this)
        if (isAutoStartGranted) {
            moveNext()
        } else {
            openAutoStartSettings()
        }
    }


    var countDownTimerAutoStart: CountDownTimer? = null
    private fun openAutoStartSettings() {
        Log.e(TAG, "openAutoStartSettings >>")
        val intentAutoStart = openAutoStartIntent()
        if (intentAutoStart != null) {
            startActivity(intentAutoStart)
            isReturningFromAutoStart = true
            Handler(Looper.myLooper()!!).postDelayed({
                startActivity(Intent(this, PermissionHintActivity::class.java))
            }, 500)
        } else {
            MiuiHelperUtils.openBgStartSettings(this)
            isReturningFromAutoStart = true
            Handler(Looper.myLooper()!!).postDelayed({
                startActivity(Intent(this, PermissionHintActivity::class.java))
            }, 500)
        }
        countDownTimerAutoStart?.cancel()
        countDownTimerAutoStart = object : CountDownTimer(1000000L, 500) {
            override fun onTick(l: Long) {
                isAutoStartGranted = MiuiHelperUtils.isAutoStartEnabled(this@PermissionActivity)
                Log.e(TAG, "countDownTimerAutoStart.isAutoStartGranted:$isAutoStartGranted")
                if (isAutoStartGranted) {
                    countDownTimerAutoStart?.cancel()
                    Log.e(TAG, "countDownTimerAutoStart.moveNext")
                    moveNext()

                }
            }

            override fun onFinish() {}
        }
        countDownTimerAutoStart!!.start()
    }

    fun openAutoStartIntent(): Intent? {
        Log.e("MiuiHelper", "openAutoStartSettings")
        val autoStartIntent = Intent().apply {
            component = ComponentName(
                "com.miui.securitycenter",
                "com.miui.permcenter.autostart.AutoStartManagementActivity"
            )
            putExtra("package", packageName)
            putExtra("package_name", packageName)
            putExtra("extra_pkgname", packageName)
            addFlags(Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS)
        }

        try {
            return autoStartIntent
        } catch (e: Exception) {
            Log.e("MiuiHelper", "openAutoStartSettings.Exception:$e")
            return null
        }
    }

    private fun checkAutoStartAfterReturn() {
        isAutoStartGranted = MiuiHelperUtils.isAutoStartEnabled(this)
        if (isAutoStartGranted) {
            moveNext()
        }

    }

    private fun moveNext() {
        Log.e(TAG, "moveNext >>")
        if (isFinishing || isDestroyed) return
        countDownTimerAutoStart?.cancel()
        StartupFlow.continueAfter(this, StartupFlow.Step.PERMISSIONS)
    }

    override fun onDestroy() {
        super.onDestroy()
        countDownTimerAutoStart?.cancel()
    }

    private fun requestDefaultSms() {
        if (isQPlus()) {
            val roleManager = getSystemService(RoleManager::class.java)
            if (roleManager.isRoleHeld(RoleManager.ROLE_SMS)) {
                checkAutoStartPermission()
            } else {
                startActivityForResult(
                    roleManager.createRequestRoleIntent(RoleManager.ROLE_SMS),
                    MAKE_DEFAULT_APP_REQUEST
                )
            }
        } else {
            if (Telephony.Sms.getDefaultSmsPackage(this) == packageName) {
                checkAutoStartPermission()
            } else {
                val intent = Intent(Telephony.Sms.Intents.ACTION_CHANGE_DEFAULT)
                intent.putExtra(
                    Telephony.Sms.Intents.EXTRA_PACKAGE_NAME,
                    packageName
                )
                startActivityForResult(intent, MAKE_DEFAULT_APP_REQUEST)
            }
        }
    }

    override fun onActivityResult(
        requestCode: Int,
        resultCode: Int,
        data: Intent?
    ) {
        super.onActivityResult(requestCode, resultCode, data)

        if (requestCode == MAKE_DEFAULT_APP_REQUEST) {
            refreshDefaultSmsState()
            if (resultCode == RESULT_OK) {
                checkAutoStartPermission()
            }
        }
    }
}
