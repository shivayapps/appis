package messages.text.sms.util


object AdsConfig {

    var ads_application_id= "ca-app-pub-6815839713838719~9735724445"
    var banner_compose= "ca-app-pub-6815839713838719/3655643660"
    var banner_home= "ca-app-pub-6815839713838719/8305335117"
    var banner_splash= "ca-app-pub-6815839713838719/3739318426"
    var banner_all= "ca-app-pub-6815839713838719/7890402142"
    var native_language= "ca-app-pub-6815839713838719/3136768910"
    var native_splash= "ca-app-pub-6815839713838719/2889356905"
    var native_all= "ca-app-pub-6815839713838719/5595411292"
    var open_resume= "ca-app-pub-6815839713838719/4557661791"
    var inter_back= "ca-app-pub-6815839713838719/4449850583"

//    var nativeAdsId: String="ca-app-pub-3940256099942544/2247696110"
//    var bannerAdsId: String="ca-app-pub-3940256099942544/9214589741"
//    var interstitialAdsId: String="ca-app-pub-3940256099942544/1033173712"
//    var appopenAdsId: String="ca-app-pub-3940256099942544/9257395921"
//    var rewardAdsId: String="ca-app-pub-3940256099942544/9257395921"
    var addButtonColor: String="#3478f6"

}