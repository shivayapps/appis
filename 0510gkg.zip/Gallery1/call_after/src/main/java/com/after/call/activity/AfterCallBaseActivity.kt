package com.after.call.activity

import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.FrameLayout
import androidx.activity.OnBackPressedCallback
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import com.after.call.R
import com.after.call.extensions.callerCadBaseConfig

open class AfterCallBaseActivity : AppCompatActivity() {

    private val predictiveBackCallback = object : OnBackPressedCallback(true) {
        override fun handleOnBackPressed() {
            onHandleBackPressed()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        onBackPressedDispatcher.addCallback(this, predictiveBackCallback)
    }

    protected open fun onHandleBackPressed() {
        finishBack()
    }

    protected fun finishBack() {
        predictiveBackCallback.isEnabled = false
        onBackPressedDispatcher.onBackPressed()
        if (!isFinishing && !isDestroyed) {
            predictiveBackCallback.isEnabled = true
        }
    }

    override fun onResume() {
        super.onResume()
        /* if (callerCadBaseConfig.callerCardDarkTheme) {
             AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES)
             WindowCompat.getInsetsController(window, window.decorView).apply {
                 isAppearanceLightStatusBars = false
             }
         } else {
             AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
             WindowCompat.getInsetsController(window, window.decorView).apply {
                 isAppearanceLightStatusBars = true
             }
         }*/

        setCustomStatusBar()
    }


    fun setCustomStatusBar() {
        if (baseContext.callerCadBaseConfig.callerCardDarkTheme) {
            val window = this.window
            window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS)
            window.statusBarColor = ContextCompat.getColor(this, R.color.after_call_card_bg_dark)
            window.navigationBarColor =
                ContextCompat.getColor(this, R.color.after_call_card_bg_dark)
            WindowCompat.getInsetsController(window, window.decorView).apply {
                isAppearanceLightStatusBars = false
                isAppearanceLightNavigationBars = false
            }
            paintSystemBarScrim(ContextCompat.getColor(this, R.color.after_call_card_bg_dark))
        } else {
            val window = this.window
            window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS)
            window.statusBarColor = ContextCompat.getColor(this, R.color.after_call_card_bg_light)
            window.navigationBarColor =
                ContextCompat.getColor(this, R.color.after_call_card_bg_light)
            WindowCompat.getInsetsController(window, window.decorView).apply {
                isAppearanceLightStatusBars = true
                isAppearanceLightNavigationBars = true
            }
            paintSystemBarScrim(ContextCompat.getColor(this, R.color.after_call_card_bg_light))
        }
    }

    private fun paintSystemBarScrim(color: Int) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.VANILLA_ICE_CREAM) return
        val parent = window.decorView as? ViewGroup ?: return
        val height = statusBarHeight()
        var scrim = parent.findViewWithTag<View>("after_call_status_bar")
        if (scrim == null) {
            scrim = View(this).apply { tag = "after_call_status_bar" }
            parent.addView(
                scrim,
                FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, height, Gravity.TOP)
            )
        } else {
            scrim.layoutParams.height = height
        }
        scrim.setBackgroundColor(color)
    }

    private fun statusBarHeight(): Int {
        val resourceId = resources.getIdentifier("status_bar_height", "dimen", "android")
        return if (resourceId > 0) resources.getDimensionPixelSize(resourceId) else 0
    }
}