package com.photogallery.uninstall

import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.util.Log
import android.view.View
import android.widget.Toast
import androidx.core.net.toUri
import androidx.fragment.app.FragmentActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.firebase.analytics.FirebaseAnalytics
import com.photogallery.R
import com.photogallery.SplashActivity
import com.photogallery.base.BaseActivity
import com.photogallery.databinding.ActivityUninstallReasonBinding

class UninstallSurveyActivity : BaseActivity() {

    companion object {
        private const val TAG = "UninstallSurveyActivity"

        fun start(activity: FragmentActivity) {
            activity.startActivity(Intent(activity, UninstallSurveyActivity::class.java))
        }
    }

    private val uninstallReasons = listOf(
        R.string.uninstall_reason_2,
        R.string.uninstall_reason_3,
        R.string.uninstall_reason_4,
        R.string.other
    )
    private val uninstallReasonsEn = listOf(
        "Too many ads",
        "I no longer need this app",
        "Too many notifications",
        "Others"
    )
    private val otherReasonIndex = uninstallReasons.lastIndex
    private var selectedReasonIndex = -1

    private lateinit var binding: ActivityUninstallReasonBinding
    private lateinit var adapter: IssueOptionAdapter
    private lateinit var firebaseAnalytics: FirebaseAnalytics

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityUninstallReasonBinding.inflate(layoutInflater)
        setContentView(binding.root)
        applySystemBarPadding(binding.root)
        firebaseAnalytics = FirebaseAnalytics.getInstance(this)
        initView()
        initListener()
    }

    private fun initView() {
        updateOkButtonState(false)

        adapter = IssueOptionAdapter(uninstallReasons, -1) { index ->
            selectedReasonIndex = index
            binding.etOtherReason.visibility =
                if (index == otherReasonIndex) View.VISIBLE else View.GONE
            updateOkButtonState(true)
        }

        binding.rcvData.layoutManager = LinearLayoutManager(this)
        binding.rcvData.adapter = adapter
    }

    private fun updateOkButtonState(enabled: Boolean) {
        binding.btnOk.isEnabled = enabled
        binding.btnOk.alpha = if (enabled) 1.0f else 0.5f
    }

    private fun initListener() {
        binding.btnOk.setOnClickListener {
            if (selectedReasonIndex < 0) {
                Toast.makeText(this, getString(R.string.select_reason_first), Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val reasonText = if (selectedReasonIndex == otherReasonIndex) {
                val input = binding.etOtherReason.text.toString().trim()
                if (input.length < 6) {
                    Toast.makeText(this, getString(R.string.feedback_warning), Toast.LENGTH_SHORT).show()
                    return@setOnClickListener
                }
                input
            } else {
                ""
            }

            firebaseAnalytics.logEvent("uninstall_reason_selected", Bundle().apply {
                putString("reason_text", reasonText)
                putString("reason_index", uninstallReasonsEn[selectedReasonIndex])
            })

            try {
                startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                    data = "package:${packageName}".toUri()
                })
            } catch (e: Exception) {
                Log.e(TAG, "Error opening app settings", e)
            }
            finish()
        }

        binding.btnCancel.setOnClickListener {
            firebaseAnalytics.logEvent("uninstall_survey_cancel", Bundle().apply {
                putString("button_action", "uninstall_survey_cancel")
                putString("screen", TAG)
            })
            val intent = Intent(this, SplashActivity::class.java)
            intent.putExtra("${packageName}.isFromUninstall", true)
            startActivity(intent)
            finish()
        }

        binding.ivBack.setOnClickListener {
            onHandleBackPressed()
        }
    }

    override fun onHandleBackPressed() {
        UninstallActivity.start(this)
        finish()
    }
}
