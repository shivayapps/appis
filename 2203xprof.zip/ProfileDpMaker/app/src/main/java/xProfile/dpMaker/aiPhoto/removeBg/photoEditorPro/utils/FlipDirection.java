package xProfile.dpMaker.aiPhoto.removeBg.photoEditorPro.utils;

public enum FlipDirection {
    VERTICAL,
    HORIZONTAL
}
