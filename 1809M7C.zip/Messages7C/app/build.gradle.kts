plugins {
    alias(libs.plugins.android.application)
    id("realm-android")   // must come before Kotlin plugins
    alias(libs.plugins.kotlin.android)
    alias(libs.plugins.ksp)
    id("kotlin-kapt")
    alias(libs.plugins.google.services)
    id("com.google.firebase.crashlytics")
}

android {
    namespace = "messages.text.sms"
    compileSdk {
        version = release(36)
    }

    defaultConfig {
        applicationId = "com.messages.sms.textmessagingapp"
        minSdk = 26
        targetSdk = 36

        versionCode = 1
        versionName = "1.0.0"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
        buildConfigField("String", "API_URL", "\"https://7seasol-application.s3.amazonaws.com/admin_prod/pbz-zrffntrf-fzf-grkgzrffntvatncc.json\"")
    }

    extensions.getByType(BasePluginExtension::class.java)
        .archivesName
        .set("Messages-v${defaultConfig.versionName}")

    buildFeatures {
        buildConfig = true
        viewBinding = true
    }

    buildTypes {

        debug {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
            signingConfig = signingConfigs.getByName("debug")
        }
        release {
            isMinifyEnabled = true
            isShrinkResources = true
//            proguardFiles(getDefaultProguardFile("proguard-android.txt"), "proguard-rules.pro")
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
            signingConfig = signingConfigs.getByName("debug")
        }
    }

    dependenciesInfo {
        // Disables dependency metadata when building APKs and AABs.
        includeInApk = false
        includeInBundle = false
    }

    lint {
        abortOnError = false
    }

//    flavorDimensions += "default"
//    productFlavors {
//        create("TestAd") {
//            isDefault = true
//            resValue("string", "ads_application_id", "ca-app-pub-3940256099942544~3347511713")
//            resValue("string", "ads_open", "ca-app-pub-3940256099942544/9257395921")
//            resValue("string", "ads_inter", "ca-app-pub-3940256099942544/1033173712")
//            resValue("string", "ads_reward", "ca-app-pub-3940256099942544/5224354917")
//            resValue("string", "ads_banner", "ca-app-pub-3940256099942544/9214589741")
//            resValue("string", "ads_native", "ca-app-pub-3940256099942544/2247696110")
//        }
//        create("LiveAd") {
//            resValue("string", "ads_application_id", "ca-app-pub-3940256099942544~3347511713")
//            resValue("string", "ads_open", "ca-app-pub-3940256099942544/9257395921")
//            resValue("string", "ads_inter", "ca-app-pub-3940256099942544/1033173712")
//            resValue("string", "ads_reward", "ca-app-pub-3940256099942544/5224354917")
//            resValue("string", "ads_banner", "ca-app-pub-3940256099942544/9214589741")
//            resValue("string", "ads_native", "ca-app-pub-3940256099942544/2247696110")
//        }
//    }
}

dependencies {

    implementation(libs.androidx.activity.ktx)
// -------------------- Lifecycle --------------------
    implementation(libs.lifecycle.viewmodel.ktx)
    implementation(libs.lifecycle.runtime.ktx)
    implementation(libs.lifecycle.livedata.ktx)
    implementation(libs.lifecycle.common.java8)

// -------------------- AndroidX --------------------
    implementation(libs.androidx.ktx)
    implementation(libs.androidx.appcompat)
    implementation(libs.androidx.constraintlayout)
    implementation(libs.androidx.documentfile)
    implementation(libs.androidx.exifinterface)
    implementation(libs.androidx.emoji2.bundled)
    implementation(libs.androidx.viewpager2)
    implementation(libs.androidx.browser)

// -------------------- Material --------------------
    implementation(libs.material)
    implementation("com.intuit.sdp:sdp-android:1.1.1")

// -------------------- WorkManager --------------------
    implementation(libs.androidx.work.runtime.ktx)
    implementation(libs.androidx.work.rxjava2)

// -------------------- Conductor --------------------
    implementation(libs.conductor)
    implementation(libs.conductor.archlifecycle)

// -------------------- Glide --------------------
    implementation(libs.glide)
    kapt(libs.glide.compiler)

// -------------------- Media3 --------------------
    implementation(libs.media3.common)
    implementation(libs.media3.exoplayer)
    implementation(libs.media3.ui)

// -------------------- RxBinding --------------------
    implementation(libs.rxbinding.kotlin)
    implementation(libs.rxbinding.support.v4.kotlin)

// -------------------- AutoDispose --------------------
    implementation(libs.autodispose)
    implementation(libs.autodispose.android)
    implementation(libs.autodispose.lifecycle)
    implementation(libs.autodispose.android.archcomponents)
    implementation(libs.autodispose.android.archcomponents.test)

// -------------------- Dagger --------------------
    implementation(libs.dagger)
    implementation(libs.dagger.android.support)
    kapt(libs.dagger.compiler)
    kapt(libs.dagger.android.processor)

    implementation(libs.javax.annotation.api)

// -------------------- Realm --------------------
    implementation(libs.realm.android.library)
    implementation(libs.realm.android.adapters)
    kapt(libs.realm.annotations.processor)

// -------------------- RxJava --------------------
    implementation(libs.rxjava)
    implementation(libs.rxandroid)
    implementation(libs.rxkotlin)
    implementation(libs.rxdogtag)
    implementation(libs.rxdogtag.autodispose)

// -------------------- Moshi --------------------
    implementation(libs.moshi)
    implementation(libs.moshi.kotlin)
    kapt(libs.moshi.kotlin.codegen)

// -------------------- Coroutines --------------------
    implementation(libs.kotlinx.coroutines.core)
    implementation(libs.kotlinx.coroutines.android)
    implementation(libs.kotlinx.coroutines.rx2)
    implementation(libs.kotlinx.coroutines.reactive)

// -------------------- Media / Utils --------------------
    implementation(libs.photoview)
    implementation(libs.flexbox)
    implementation(libs.shortcutbadger)
    implementation(libs.okhttp3.okhttp)
    implementation(libs.libphonenumber.android)
    implementation(libs.rx.preferences)

// -------------------- Kotlin --------------------
    implementation(libs.kotlin.stdlib)

// -------------------- ez-vcard --------------------
    implementation("com.googlecode.ez-vcard:ez-vcard:0.10.4") {
        exclude(group = "org.jsoup", module = "jsoup")
        exclude(group = "org.freemarker", module = "freemarker")
        exclude(group = "com.fasterxml.jackson.core", module = "jackson-core")
    }

    implementation("com.airbnb.android:lottie:4.1.0")
    implementation("com.karumi:dexter:6.2.3")
    implementation("com.google.android.gms:play-services-location:21.0.1")
    implementation("com.google.android.play:review-ktx:2.0.2")
    implementation("com.google.android.play:app-update:2.1.0")
    implementation("androidx.multidex:multidex:2.0.1")
    implementation("com.google.android.gms:play-services-ads:25.4.0")
    implementation("com.google.ads.mediation:facebook:6.21.0.3")
//    implementation("com.google.ads.mediation:applovin:13.6.3.0")
//    implementation("com.google.ads.mediation:pangle:8.1.0.4.0")
    implementation("com.facebook.shimmer:shimmer:0.5.0")

    implementation("androidx.lifecycle:lifecycle-extensions:2.2.0")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.6.1")
    annotationProcessor("androidx.lifecycle:lifecycle-compiler:2.6.1")

    implementation("com.android.volley:volley:1.2.1")
    implementation("com.google.code.gson:gson:2.14.0")
    implementation("se.warting.datepicker:singledateandtimepicker:2.2.10")

    implementation(platform(libs.firebase.bom))
    implementation(libs.firebase.inappmessaging.display)
    implementation(libs.firebase.analytics)
    implementation(libs.firebase.messaging)
    implementation(libs.firebase.config)
    implementation(libs.firebase.crashlytics)
//    implementation("com.google.firebase:firebase-crashlytics-ktx")
//    implementation("com.google.firebase:firebase-perf-ktx")

// -------------------- Local Modules --------------------
    implementation(project(":smsmms"))
//    implementation(project(":call_after"))

// -------------------- Unit Tests --------------------
//    testImplementation(libs.junit)
//    testImplementation(libs.mockito.core)
//    testImplementation(libs.mockito.kotlin)
//    testImplementation(libs.robolectric)
//    testImplementation(libs.truth)
//    testImplementation(libs.androidx.runner)
//    testImplementation(libs.androidx.test.core)

// -------------------- Instrumentation Tests --------------------
//    androidTestImplementation(libs.espresso.core)
//    androidTestImplementation(libs.mockito.android)
//    androidTestImplementation(libs.truth)
//    androidTestImplementation(libs.androidx.test.core)
//    androidTestImplementation(libs.androidx.test.core.ktx)
//    androidTestImplementation(libs.androidx.runner)
//    androidTestImplementation(libs.androidx.test.ext.junit)
}
