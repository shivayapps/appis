
package messages.text.sms.migration

import android.content.Context
import messages.text.sms.feature.blocking.SmsBlockingClient
import messages.text.sms.extensions.versionCode
import messages.text.sms.repository.ConversationRepository
import messages.text.sms.util.Preferences
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.runBlocking
import javax.inject.Inject

class MyMigration @Inject constructor(
    private val context: Context,
    private val conversationRepo: ConversationRepository,
    private val prefs: Preferences,
    private val smsBlockingClient: SmsBlockingClient
) {

    fun performMigration() = runBlocking(Dispatchers.IO) {
        val oldVersion = prefs.version.get()
//        if (oldVersion < 2199) {
//            upgradeTo370()
//        }
        prefs.version.set(context.versionCode)
    }

}
