package messages.text.sms.adhelper

object AdUtil {

    var isAppForeground = false
    var isAnyAdShowing = false
    var isSystemDialogOpen = false
    var isInterstitialAdShow = false
}