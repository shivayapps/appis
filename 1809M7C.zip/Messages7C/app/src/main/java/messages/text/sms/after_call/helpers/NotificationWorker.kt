package messages.text.sms.after_call.helpers

import android.annotation.SuppressLint
import android.content.Context
import android.os.Build
import android.provider.MediaStore
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters

import java.io.File


class NotificationWorker(
    context: Context,
    params: WorkerParameters
) : CoroutineWorker(context, params) {

    override suspend fun doWork(): Result {
        val message = inputData.getString("message").orEmpty()

        val ctx = applicationContext

        Notifier.show(ctx, "Reminder", message)

        return Result.success()
    }
}
