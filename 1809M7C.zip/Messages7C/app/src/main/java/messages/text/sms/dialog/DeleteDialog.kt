package messages.text.sms.dialog

import android.app.Activity
import android.content.Context
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.view.Gravity
import android.view.Window
import android.view.WindowManager
import androidx.appcompat.app.AlertDialog
import messages.text.sms.R
import messages.text.sms.repository.ConversationRepository
import messages.text.sms.util.Preferences
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.MainScope
import messages.text.sms.databinding.DialogDeleteBinding
import messages.text.sms.interactor.DeleteConversations
import javax.inject.Inject

class DeleteDialog @Inject constructor(
    private val context: Context,
    private val conversationRepo: ConversationRepository,
    private val prefs: Preferences,
    private val deleteConversations: DeleteConversations,
) {

    fun show(activity: Activity, conversationIds: List<Long>) = GlobalScope.launch {

        showDialog(activity, conversationIds)
    }

    private suspend fun showDialog(
        activity: Activity,
        conversationIds: List<Long>,
    ) = withContext(MainScope().coroutineContext) {

        // Otherwise, show a dialog asking the user if they want to be directed to the external
        // blocking manager
        val binding = DialogDeleteBinding.inflate(activity.layoutInflater)
//
//        val message = context.resources?.getQuantityString(R.plurals.dialog_delete_message, 1)
        val message = context.resources.getQuantityString(
            R.plurals.dialog_delete_message,
            conversationIds.size,
            conversationIds.size
        )
//        binding.tvTitle.setText(
//            if (archive) {
//                R.string.dialog_delete_title
//            } else {
//                R.string.unarchive_title
//            }
//        )
        binding.tvMessage.setText(message)
//            if (archive) {
//                R.string.archive_subtitle
//            } else {
//                R.string.unarchive_subtitle
//            }
//        )

        val dialog = AlertDialog.Builder(activity)
            .setView(binding.root)
            .setCancelable(true)
            .create()

        binding.btnPositive.setOnClickListener {
            deleteConversations.execute(conversationIds)
            dialog.dismiss()
        }

        binding.ivClose.setOnClickListener {
            dialog.dismiss()
        }
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.window?.apply {
            setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            setGravity(Gravity.CENTER)
            setDimAmount(0.8f)
            attributes?.windowAnimations = android.R.style.Animation_Dialog
            setLayout(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.WRAP_CONTENT
            )
        }
        dialog.show()

    }


}
