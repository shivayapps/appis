
package messages.text.sms.feature.quick_reply

import androidx.lifecycle.ViewModel
import dagger.Module
import dagger.Provides
import dagger.multibindings.IntoMap
import messages.text.sms.injection.ViewModelKey
import javax.inject.Named

@Module
class MyReplyActivityModule {

    @Provides
    @Named("threadId")
    fun provideThreadId(activity: QuickReplyActivity): Long =
        activity.intent.extras?.getLong("threadId") ?: 0L

    @Provides
    @IntoMap
    @ViewModelKey(QuickReplyViewModel::class)
    fun provideMessagesReplyViewModel(viewModel: QuickReplyViewModel): ViewModel = viewModel

}