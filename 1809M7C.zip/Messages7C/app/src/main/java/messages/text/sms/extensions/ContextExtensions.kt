package messages.text.sms.extensions

import android.Manifest
import android.app.job.JobScheduler
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Point
import android.net.ConnectivityManager
import android.net.Uri
import android.os.Build
import android.util.TypedValue
import android.view.WindowManager
import android.widget.Toast
import androidx.annotation.StringRes
import androidx.browser.customtabs.CustomTabColorSchemeParams
import androidx.browser.customtabs.CustomTabsIntent
import androidx.core.content.ContextCompat
import androidx.core.content.getSystemService
import messages.text.sms.R
import messages.text.sms.adhelper.AdUtil
import messages.text.sms.util.BaseConfig
import messages.text.sms.util.PERMISSION_READ_STORAGE
import messages.text.sms.util.PERMISSION_WRITE_STORAGE
import messages.text.sms.util.PERMISSION_CAMERA
import messages.text.sms.util.PERMISSION_RECORD_AUDIO
import messages.text.sms.util.PERMISSION_READ_CONTACTS
import messages.text.sms.util.PERMISSION_WRITE_CONTACTS
import messages.text.sms.util.PERMISSION_READ_CALENDAR
import messages.text.sms.util.PERMISSION_WRITE_CALENDAR
import messages.text.sms.util.PERMISSION_CALL_PHONE
import messages.text.sms.util.PERMISSION_READ_CALL_LOG
import messages.text.sms.util.PERMISSION_WRITE_CALL_LOG
import messages.text.sms.util.PERMISSION_GET_ACCOUNTS
import messages.text.sms.util.PERMISSION_READ_SMS
import messages.text.sms.util.PERMISSION_SEND_SMS
import messages.text.sms.util.PERMISSION_READ_PHONE_STATE
import messages.text.sms.util.PERMISSION_MEDIA_LOCATION
import messages.text.sms.util.PERMISSION_POST_NOTIFICATIONS
import messages.text.sms.util.PERMISSION_READ_MEDIA_IMAGES
import messages.text.sms.util.PERMISSION_READ_MEDIA_VIDEO
import messages.text.sms.util.PERMISSION_READ_MEDIA_AUDIO
import messages.text.sms.util.PERMISSION_ACCESS_COARSE_LOCATION
import messages.text.sms.util.PERMISSION_ACCESS_FINE_LOCATION
import messages.text.sms.util.PERMISSION_READ_MEDIA_VISUAL_USER_SELECTED
import messages.text.sms.util.PERMISSION_READ_SYNC_SETTINGS

import messages.text.sms.util.PREFS_KEY
import messages.text.sms.util.tryOrNull
import java.net.HttpURLConnection
import java.net.URL


val Context.navigationBarHeight: Int get() = newNavigationBarHeight
val Context.newNavigationBarHeight: Int
    get() {
        var navigationBarHeight = 0
        val resourceId = resources.getIdentifier("navigation_bar_height", "dimen", "android")
        if (resourceId > 0) {
            navigationBarHeight = resources.getDimensionPixelSize(resourceId)
        }
        return navigationBarHeight
    }

val Context.windowManager: WindowManager get() = getSystemService(Context.WINDOW_SERVICE) as WindowManager

val Context.usableScreenSize: Point
    get() {
        val size = Point()
        windowManager.defaultDisplay.getSize(size)
        return size
    }

val Context.realScreenSize: Point
    get() {
        val size = Point()
        windowManager.defaultDisplay.getRealSize(size)
        return size
    }

fun Context.isOnline(): Boolean {
    val connectivityManager =
        getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
    val activeNetworkInfo = connectivityManager.activeNetworkInfo
    return activeNetworkInfo != null && activeNetworkInfo.isConnected
}

fun Context.isInternetWorking(): Boolean {
    return try {
        val url = URL("https://www.google.com")
        val connection = url.openConnection() as HttpURLConnection
        connection.connectTimeout = 3000
        connection.connect()
        connection.responseCode == 200
    } catch (e: Exception) {
        false
    }
}

fun Context.getSharedPrefs() = getSharedPreferences(PREFS_KEY, Context.MODE_PRIVATE)
val Context.baseConfig: BaseConfig get() = BaseConfig.newInstance(this)
fun Context.isFirstTimeAppOpen(): Boolean {
    return this.baseConfig.splashCounter <= 1
}

fun Context.getColorCompat(colorRes: Int): Int {
    //return black as a default color, in case an invalid color ID was passed in
    return tryOrNull { ContextCompat.getColor(this, colorRes) } ?: Color.BLACK
}

fun Context.getColorStateListCompat(colorStateListRes: Int): ColorStateList {
    //return black as a default color, in case an invalid color ID was passed in
    return tryOrNull { ContextCompat.getColorStateList(this, colorStateListRes) }
        ?: ColorStateList.valueOf(Color.BLACK)
}

/**
 * Tries to resolve a resource id from the current theme, based on the [attributeId]
 */
fun Context.resolveThemeAttribute(attributeId: Int, default: Int = 0): Int {
    val outValue = TypedValue()
    val wasResolved = theme.resolveAttribute(attributeId, outValue, true)

    return if (wasResolved) outValue.resourceId else default
}

fun Context.resolveThemeBoolean(attributeId: Int, default: Boolean = false): Boolean {
    val outValue = TypedValue()
    val wasResolved = theme.resolveAttribute(attributeId, outValue, true)

    return if (wasResolved) outValue.data != 0 else default
}

fun Context.resolveThemeColor(attributeId: Int, default: Int = 0): Int {
    val outValue = TypedValue()
    val wasResolved = theme.resolveAttribute(attributeId, outValue, true)

    return if (wasResolved) getColorCompat(outValue.resourceId) else default
}

fun Context.resolveThemeColorStateList(attributeId: Int, default: Int = 0): ColorStateList {
    val outValue = TypedValue()
    val wasResolved = theme.resolveAttribute(attributeId, outValue, true)


    return getColorStateListCompat(if (wasResolved) outValue.resourceId else default)
}

fun Context.makeToast(@StringRes res: Int, duration: Int = Toast.LENGTH_SHORT) {
    Toast.makeText(this, res, duration).show()
}

fun Context.makeToast(text: String, duration: Int = Toast.LENGTH_SHORT) {
    Toast.makeText(this, text, duration).show()
}

fun Context.isInstalled(packageName: String): Boolean {
    return tryOrNull(false) { packageManager.getApplicationInfo(packageName, 0).enabled } ?: false
}

val Context.versionCode: Int
    get() {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            packageManager.getPackageInfo(
                packageName,
                PackageManager.PackageInfoFlags.of(0)
            ).longVersionCode.toInt()
        } else {
            packageManager.getPackageInfo(packageName, 0).versionCode
        }
    }
val Context.jobScheduler: JobScheduler
    get() = getSystemService()!!


fun Context.hasPermission(permId: Int) = ContextCompat.checkSelfPermission(
    this,
    getPermissionString(permId)
) == PackageManager.PERMISSION_GRANTED

fun Context.hasAllPermissions(permIds: Collection<Int>) = permIds.all(this::hasPermission)

fun Context.getPermissionString(id: Int) = when (id) {
    PERMISSION_READ_STORAGE -> Manifest.permission.READ_EXTERNAL_STORAGE
    PERMISSION_WRITE_STORAGE -> Manifest.permission.WRITE_EXTERNAL_STORAGE
    PERMISSION_CAMERA -> Manifest.permission.CAMERA
    PERMISSION_RECORD_AUDIO -> Manifest.permission.RECORD_AUDIO
    PERMISSION_READ_CONTACTS -> Manifest.permission.READ_CONTACTS
    PERMISSION_WRITE_CONTACTS -> Manifest.permission.WRITE_CONTACTS
    PERMISSION_READ_CALENDAR -> Manifest.permission.READ_CALENDAR
    PERMISSION_WRITE_CALENDAR -> Manifest.permission.WRITE_CALENDAR
    PERMISSION_CALL_PHONE -> Manifest.permission.CALL_PHONE
    PERMISSION_READ_CALL_LOG -> Manifest.permission.READ_CALL_LOG
    PERMISSION_WRITE_CALL_LOG -> Manifest.permission.WRITE_CALL_LOG
    PERMISSION_GET_ACCOUNTS -> Manifest.permission.GET_ACCOUNTS
    PERMISSION_READ_SMS -> Manifest.permission.READ_SMS
    PERMISSION_SEND_SMS -> Manifest.permission.SEND_SMS
    PERMISSION_READ_PHONE_STATE -> Manifest.permission.READ_PHONE_STATE
    PERMISSION_MEDIA_LOCATION -> if (isQPlus()) Manifest.permission.ACCESS_MEDIA_LOCATION else ""
    PERMISSION_POST_NOTIFICATIONS -> Manifest.permission.POST_NOTIFICATIONS
    PERMISSION_READ_MEDIA_IMAGES -> Manifest.permission.READ_MEDIA_IMAGES
    PERMISSION_READ_MEDIA_VIDEO -> Manifest.permission.READ_MEDIA_VIDEO
    PERMISSION_READ_MEDIA_AUDIO -> Manifest.permission.READ_MEDIA_AUDIO
    PERMISSION_ACCESS_COARSE_LOCATION -> Manifest.permission.ACCESS_COARSE_LOCATION
    PERMISSION_ACCESS_FINE_LOCATION -> Manifest.permission.ACCESS_FINE_LOCATION
    PERMISSION_READ_MEDIA_VISUAL_USER_SELECTED -> Manifest.permission.READ_MEDIA_VISUAL_USER_SELECTED
    PERMISSION_READ_SYNC_SETTINGS -> Manifest.permission.READ_SYNC_SETTINGS
    else -> ""
}

fun Context.launchUrl(url: String) {
    val builder = CustomTabsIntent.Builder()
    val params = CustomTabColorSchemeParams.Builder()
    params.setToolbarColor(
        ContextCompat.getColor(
            this,
            R.color.app_bg
        )
    )
    builder.setDefaultColorSchemeParams(params.build())
    builder.setShowTitle(true)
    builder.setShareState(CustomTabsIntent.SHARE_STATE_ON)
    builder.setInstantAppsEnabled(true)
    val customBuilder = builder.build()

    if (isPackageInstalled("com.android.chrome")) {
        customBuilder.intent.setPackage("com.android.chrome")
        customBuilder.launchUrl(this, Uri.parse(url))
    } else {
        AdUtil.isSystemDialogOpen = true
        val i = Intent(Intent.ACTION_VIEW)
        i.data = Uri.parse(url)
        startActivity(i)
    }
}

fun Context.isPackageInstalled(packageName: String?): Boolean {
    val packageManager = packageManager
    val intent = packageManager.getLaunchIntentForPackage(packageName!!) ?: return false
    val list = packageManager.queryIntentActivities(intent, PackageManager.MATCH_DEFAULT_ONLY)
    return !list.isEmpty()
}