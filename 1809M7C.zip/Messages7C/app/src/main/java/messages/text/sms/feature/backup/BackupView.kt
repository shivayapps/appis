
package messages.text.sms.feature.backup

import android.net.Uri
import io.reactivex.Observable
import messages.text.sms.common.base.MyViewContract

interface BackupView : MyViewContract<BackupState> {
    fun setBackupLocationClicks(): Observable<*>
    fun restoreClicks(): Observable<*>

    fun backupClicks(): Observable<*>

    fun locationRationaleConfirmClicks(): Observable<*>
    fun locationRationaleCancelClicks(): Observable<*>

    fun selectedBackupErrorClicks(): Observable<*>

    fun confirmRestoreBackupConfirmClicks(): Observable<*>
    fun confirmRestoreBackupCancelClicks(): Observable<*>

    fun stopRestoreClicks(): Observable<*>
    fun stopRestoreConfirmed(): Observable<*>
    fun stopRestoreCancel(): Observable<*>

    fun documentTreeSelected(): Observable<Uri>
    fun documentSelected(): Observable<Uri>

    fun selectFolder(initialUri: Uri)
    fun selectFile(initialUri: Uri)
}
