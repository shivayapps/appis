
package messages.text.sms.manager

import androidx.core.content.pm.ShortcutInfoCompat

interface ShortcutManager {

    fun updateBadge()

    fun updateShortcuts()

    fun getShortcut(threadId: Long): ShortcutInfoCompat?

    fun reportShortcutUsed(threadId: Long)

}