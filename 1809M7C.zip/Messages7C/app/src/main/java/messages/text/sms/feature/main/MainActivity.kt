package messages.text.sms.feature.main

import android.Manifest
import android.animation.ObjectAnimator
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.util.Log
import android.view.View
import androidx.activity.OnBackPressedCallback
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.view.isVisible
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.ItemTouchHelper
import androidx.recyclerview.widget.RecyclerView
import com.android.volley.Request
import com.android.volley.RequestQueue
import com.android.volley.toolbox.StringRequest
import com.android.volley.toolbox.Volley
import com.google.android.material.snackbar.Snackbar
import com.google.android.play.core.install.model.InstallStatus
import com.google.gson.Gson
import com.jakewharton.rxbinding2.view.clicks
import com.messenger.sms.text.inapp_helper.AppUpdateInstallerListener
import com.messenger.sms.text.inapp_helper.AppUpdateInstallerManager
import messages.text.sms.updatehelper.InAppUpdateInstallerManager
import com.uber.autodispose.android.lifecycle.scope
import com.uber.autodispose.autoDispose
import dagger.android.AndroidInjection
import io.reactivex.Observable
import io.reactivex.disposables.CompositeDisposable
import io.reactivex.subjects.PublishSubject
import io.reactivex.subjects.Subject
import messages.text.sms.R
import messages.text.sms.adhelper.BannerAdHelper
import messages.text.sms.common.ApiData
import messages.text.sms.dialog.DeleteDialog
import messages.text.sms.common.Navigator
import messages.text.sms.common.PopupWindowHelper
import messages.text.sms.common.base.MainBaseThemedActivity
import messages.text.sms.extensions.autoScrollToStart
import messages.text.sms.extensions.baseConfig
import messages.text.sms.extensions.beGone
import messages.text.sms.extensions.beVisibleIf
import messages.text.sms.extensions.dismissKeyboard
import messages.text.sms.extensions.scrapViews
import messages.text.sms.extensions.setVisible
import messages.text.sms.common.widget.TextInputDialog
import messages.text.sms.databinding.MainActivityBinding
import messages.text.sms.databinding.MainPermissionHintBinding
import messages.text.sms.databinding.MainSyncingBinding
import messages.text.sms.databinding.MenuHomeBinding
import messages.text.sms.feature.blocking.BlockingDialog
import messages.text.sms.feature.conversations.ConversationItemTouchCallback
import messages.text.sms.feature.conversations.ConversationsAdapter
import messages.text.sms.repository.SyncRepository
import messages.text.sms.util.Constants
import javax.inject.Inject

class MainActivity : MainBaseThemedActivity<MainActivityBinding>(MainActivityBinding::inflate),
    MainView {

    @Inject
    lateinit var blockingDialog: BlockingDialog

    @Inject
    lateinit var deleteDialog: DeleteDialog

    @Inject
    lateinit var disposables: CompositeDisposable

    @Inject
    lateinit var navigator: Navigator

    @Inject
    lateinit var conversationsAdapter: ConversationsAdapter

    @Inject
    lateinit var drawerBadgesExperiment: DrawerBadgesExperiment

    @Inject
    lateinit var searchAdapter: SearchAdapter

    @Inject
    lateinit var itemTouchCallback: ConversationItemTouchCallback

    @Inject
    lateinit var viewModelFactory: ViewModelProvider.Factory

    override val onNewIntentIntent: Subject<Intent> = PublishSubject.create()
    override val activityResumedIntent: Subject<Boolean> = PublishSubject.create()

    //    override val queryChangedIntent by lazy { binding.toolbarSearch.textChanges() }
    override val composeIntent by lazy { binding.compose.clicks() }
    override val filterSelectedIntent by lazy {
        Observable.merge(
            binding.filterAll.clicks().map { MessageCategory.ALL },
            binding.filterUnread.clicks().map { MessageCategory.UNREAD },
//            binding.filterArchived.clicks().map { MessageCategory.ARCHIVED }
        )
    }

    override val homeIntent: Subject<Unit> = PublishSubject.create()

    private val menuClickSubject: Subject<NavItem> = PublishSubject.create()
    override val navigationIntent: Observable<NavItem> by lazy {
        Observable.merge(listOf(menuClickSubject))
    }

    override val optionsItemIntent: Subject<Int> = PublishSubject.create()

    //    override val plusBannerIntent by lazy { plusBanner.clicks() }
//    override val dismissRatingIntent by lazy { binding.messagesText.clicks() }
//    override val rateIntent by lazy { binding.messagesText.clicks() }
    override val conversationsSelectedIntent by lazy { conversationsAdapter.selectionChanges }
    override val confirmDeleteIntent: Subject<List<Long>> = PublishSubject.create()
    override val renameConversationIntent: Subject<String> = PublishSubject.create()
    override val swipeConversationIntent by lazy { itemTouchCallback.swipes }
    override val undoArchiveIntent: Subject<Unit> = PublishSubject.create()
    override val snackbarButtonIntent: Subject<Unit> = PublishSubject.create()
    private val viewModel by lazy {
        ViewModelProvider(this, viewModelFactory)[MainViewModel::class.java]
    }

    private val itemTouchHelper by lazy { ItemTouchHelper(itemTouchCallback) }
    private lateinit var snackbarBinding: MainPermissionHintBinding
    private lateinit var syncingBinding: MainSyncingBinding
    private lateinit var menuBinding: MenuHomeBinding
    private lateinit var popupWindow: PopupWindowHelper

    private var hasSelection = false

    override fun onCreate(savedInstanceState: Bundle?) {
        AndroidInjection.inject(this)
        super.onCreate(savedInstanceState)
        viewModel.bindView(this)
        onNewIntentIntent.onNext(intent)

        snackbarBinding = MainPermissionHintBinding.bind(binding.snackbar.inflate()).also {
            it.snackbarButton.clicks()
                .autoDispose(scope(Lifecycle.Event.ON_DESTROY))
                .subscribe(snackbarButtonIntent)
        }

        syncingBinding = MainSyncingBinding.bind(binding.syncing.inflate())
//            .also {
//                it.syncingProgress.progressTintList =
//                    ColorStateList.valueOf(theme.blockingFirst().theme)
//                it.syncingProgress.indeterminateTintList =
//                    ColorStateList.valueOf(theme.blockingFirst().theme)
//            }

        binding.ivClose.setOnClickListener {
            clearSelection()
        }

        binding.btnChangeDefaultSms.setOnClickListener {
            requestDefaultSms()
        }

        menuBinding = MenuHomeBinding.inflate(layoutInflater)
        popupWindow = PopupWindowHelper(menuBinding.root)

        menuBinding.selectAll.setOnClickListener {
            optionsItemIntent.onNext(menuBinding.selectAll.id).let { true }; popupWindow.dismiss()
        }
        menuBinding.unarchive.setOnClickListener {
            optionsItemIntent.onNext(menuBinding.unarchive.id).let { true }; popupWindow.dismiss()
        }
        menuBinding.add.setOnClickListener {
            optionsItemIntent.onNext(menuBinding.add.id).let { true }; popupWindow.dismiss()
        }
        menuBinding.read.setOnClickListener {
            optionsItemIntent.onNext(menuBinding.read.id).let { true }; popupWindow.dismiss()
        }
        menuBinding.unread.setOnClickListener {
            optionsItemIntent.onNext(menuBinding.unread.id).let { true }; popupWindow.dismiss()
        }
        menuBinding.lock.setOnClickListener {
            optionsItemIntent.onNext(menuBinding.lock.id).let { true }; popupWindow.dismiss()
        }

        menuBinding.block.setOnClickListener {
            optionsItemIntent.onNext(menuBinding.block.id).let { true }; popupWindow.dismiss()
        }
        menuBinding.rename.setOnClickListener {
            optionsItemIntent.onNext(menuBinding.rename.id).let { true }; popupWindow.dismiss()
        }

        menuBinding.schedule.setOnClickListener { menuClickSubject.onNext(NavItem.SCHEDULED); popupWindow.dismiss() }
        menuBinding.blocking.setOnClickListener { menuClickSubject.onNext(NavItem.BLOCKING); popupWindow.dismiss() }
        menuBinding.privateChat.setOnClickListener { menuClickSubject.onNext(NavItem.PRIVATE); popupWindow.dismiss() }
        menuBinding.setting.setOnClickListener { menuClickSubject.onNext(NavItem.SETTINGS); popupWindow.dismiss() }

//        binding.clearSearch.clicks()
//            .autoDispose(scope())
//            .subscribe { clearSearch() }
//
//        binding.toolbarSearch.textChanges()
//            .autoDispose(scope())
//            .subscribe { text ->
//                binding.clearSearch.isVisible = text.isNotEmpty()
//            }

//        toggle.syncState()
        title = ""
//        binding.toolbar.setNavigationOnClickListener {
//            dismissKeyboard()
//            homeIntent.onNext(Unit)
//        }

        binding.menuIcon.clicks()
            .autoDispose(scope())
            .subscribe {
                showDrawerMenu(binding.menuIcon)
            }

        binding.searchIcon.clicks()
            .autoDispose(scope())
            .subscribe {
                openSearch()
            }

        itemTouchCallback.adapter = conversationsAdapter
        conversationsAdapter.autoScrollToStart(binding.recyclerView)
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (!menuClickSubject.hasObservers()) {
                    isEnabled = false
                    onBackPressedDispatcher.onBackPressed()
                    isEnabled = true
                } else {
                    menuClickSubject.onNext(NavItem.BACK)
//                    finish()
                }
            }
        })
        binding.recyclerView.addOnScrollListener(object : RecyclerView.OnScrollListener() {
            override fun onScrolled(recyclerView: RecyclerView, dx: Int, dy: Int) {
                super.onScrolled(recyclerView, dx, dy)

//                if (dy > 0 && binding.cVTopBar2.translationY == 0f) {
//                    // Hide
//                    val translationY = -binding.cVTopBar2.height.toFloat() - 8f * resources.displayMetrics.density
//                    binding.cVTopBar2.animate().translationY(translationY).setDuration(200).start()
//                    binding.menuIcon.animate().translationY(translationY).setDuration(200).start()
//                    binding.filterGroup.animate().translationY(translationY).setDuration(200).start()
//                    binding.recyclerView.animate().translationY(translationY).setDuration(200).start()
//                } else if (dy < 0 && binding.cVTopBar2.translationY != 0f) {
//                    // Show
//                    binding.cVTopBar2.animate().translationY(0f).setDuration(200).start()
//                    binding.menuIcon.animate().translationY(0f).setDuration(200).start()
//                    binding.filterGroup.animate().translationY(0f).setDuration(200).start()
//                    binding.recyclerView.animate().translationY(0f).setDuration(200).start()
//                }
            }
        })

        // Don't allow clicks to pass through the drawer layout
//        binding.drawer.root.clicks().autoDispose(scope()).subscribe()

        // Set the theme color tint to the recyclerView, progressbar, and FAB
//        theme
//            .autoDispose(scope())
//            .subscribe { theme ->
//                //                (binding.syncing as? ViewStub)?.findViewById<ProgressBar>(R.id.syncingProgress)
////                    ?.let {
////                        it.progressTintList = ColorStateList.valueOf(theme.theme)
////                        it.indeterminateTintList = ColorStateList.valueOf(theme.theme)
////                    }
////                binding.drawer.plusIcon.setTint(theme.theme)
////                binding.drawer.rateIcon.setTint(theme.theme)
//
////                val primaryTextColor = resolveThemeColor(android.R.attr.textColorPrimary)
////                val secondaryTextColor = resolveThemeColor(android.R.attr.textColorSecondary)
////                binding.searchIcon.setTint(primaryTextColor)
//////                binding.clearSearch.setTint(primaryTextColor)
//////                binding.toolbarSearch.setTextColor(primaryTextColor)
//////                binding.toolbarSearch.setHintTextColor(secondaryTextColor)
////
////                binding.messagesText.setTextColor(primaryTextColor)
////                binding.menuIcon.setTint(primaryTextColor)
////
////                binding.compose.setTint(primaryTextColor)
//            }

        checkInAppUpdate()
        callAPI()
        loadAds()
    }

    fun loadAds() {
        BannerAdHelper.showBanner(
            this,
            binding.adsView,
            baseConfig.bannerAdsId,
            { isLoaded, message ->

            })
    }

    private fun callAPI() {
        Log.e("ApiCall", "callAPI")
        val requestQueue: RequestQueue = Volley.newRequestQueue(this)
        val request = StringRequest(
            Request.Method.GET,
            Constants.BASE_URL,
            { apiResponse: String ->
//                val typeToken = object : TypeToken<ApiData>() {}
//                val gson = Gson()
                try {
//                    val apiData: ApiData = gson.fromJson(apiResponse, typeToken.type)
                    val apiData = Gson().fromJson(apiResponse, ApiData::class.java)
                    baseConfig.bannerAdsId = apiData.bannerId
                    baseConfig.nativeAdsId = apiData.nativeId
                    baseConfig.interstitialAdsId = apiData.interstialId
                    baseConfig.appopenAdsId = apiData.appopenId
                    baseConfig.rewardAdsId = apiData.rewardId
                    baseConfig.addButtonColor = apiData.addButtonColor

                    Log.e("ApiCall", "ApiData:$apiData")
                } catch (e: Exception) {
                    Log.e("ApiCall", "ErrorApiException:$e")
                }
            }, { error ->
                Log.e("ApiCall", "ErrorApiCalling:$error")
            }
        )
        requestQueue.add(request)
    }

    private fun checkInAppUpdate() {
        try {
            appUpdateInstallerManager.addAppUpdateListener(appUpdateInstallerListener)
            appUpdateInstallerManager.startCheckUpdate()
        } catch (e: Exception) {
            Log.e("UpdateListener", "checkAppUpdate.Exception:$e")
        }
    }

    private val appUpdateInstallerManager: AppUpdateInstallerManager by lazy {
        InAppUpdateInstallerManager(this)
    }

    private val appUpdateInstallerListener by lazy {
        object : AppUpdateInstallerListener() {
            override fun onDownloadedButNotInstalled() {
                Log.e("UpdateListener", "onDownloadedButNotInstalled")
                popupSnackBarForCompleteUpdate()
            }

            override fun onFailure(e: Exception) {
                Log.e("UpdateListener", "onFailure:$e")
            }

            override fun onNotUpdate() {
                Log.e("UpdateListener", "onNotUpdate")
            }

            override fun onCancelled() {
                Log.e("UpdateListener", "onCancelled")
            }

            override fun onStatus(@InstallStatus status: Int) {
                Log.e("UpdateListener", "onStatus:$status")
            }
        }
    }

    private fun popupSnackBarForCompleteUpdate() {
        val snackBar = Snackbar.make(
            findViewById(android.R.id.content),
            "An update has just been downloaded.",
            Snackbar.LENGTH_INDEFINITE
        )
        snackBar.setAction("RESTART") { appUpdateInstallerManager.completeUpdate() }
        snackBar.setActionTextColor(ContextCompat.getColor(this, android.R.color.holo_red_dark))
        snackBar.show()
    }

    override fun onNewIntent(intent: Intent) =
        intent.let {
            super.onNewIntent(intent)
            it.run(onNewIntentIntent::onNext)
        } ?: Unit

    override fun render(state: MainState) {
        if (state.hasError) {
            finish()
            return
        }

        if (!state.defaultSms) {
            binding.notDefaultSmsView.setVisible(true)
            binding.recyclerView.setVisible(false)
            binding.empty.setVisible(false)
//            binding.searchPill.setVisible(false)
            binding.compose.setVisible(false)
            binding.filterGroup.setVisible(false)
            return
        } else {
            binding.notDefaultSmsView.setVisible(false)
        }

        val addContact = when (state.page) {
            is Inbox -> state.page.addContact
            is Archived -> state.page.addContact
            else -> false
        }

        val markPinned = when (state.page) {
            is Inbox -> state.page.markPinned
            is Archived -> state.page.markPinned
            else -> true
        }

        val markRead = when (state.page) {
            is Inbox -> state.page.markRead
            is Archived -> state.page.markRead
            else -> true
        }

        val selectedConversations = when (state.page) {
            is Inbox -> state.page.selected
            is Archived -> state.page.selected
            else -> 0
        }

        if (selectedConversations == conversationsAdapter.itemCount) {
            menuBinding.selectAll.title = getString(R.string.main_menu_remove_selection)
        } else {
            menuBinding.selectAll.title = getString(R.string.main_menu_select_all)
        }

        hasSelection = selectedConversations > 0
//        binding.toolbar.setVisible(hasSelection)
        binding.groupToolbarSelection.setVisible(hasSelection)
        binding.groupToolbarHeader.setVisible(!hasSelection)
        binding.compose.setVisible(!hasSelection)

//        binding.menuIcon.setVisible(!hasSelection)

//        binding.toolbarSearch.setVisible(
//            (state.page is Inbox && state.page.selected == 0) ||
//                    (state.page is Archived && state.page.selected == 0) ||
//                    state.page is Searching
//        )
//        binding.toolbarTitle.setVisible(true)
        binding.filterGroup.setVisible(state.page is Inbox || state.page is Archived)
//        binding.menuIcon.beVisible()

        menuBinding.selectionMenuView.beVisibleIf(hasSelection)
        menuBinding.menuView.beVisibleIf(!hasSelection)

        binding.pin.beVisibleIf(markPinned && selectedConversations != 0)
        binding.unpin.beVisibleIf(!markPinned && selectedConversations != 0)
        binding.delete.beVisibleIf(selectedConversations != 0)
        binding.archive.beVisibleIf(state.page is Inbox && selectedConversations != 0)

        menuBinding.selectAll.beVisibleIf((conversationsAdapter.itemCount > 1) && selectedConversations != 0)
        menuBinding.unarchive.beVisibleIf(state.page is Archived && selectedConversations != 0)
        menuBinding.add.beVisibleIf(addContact && selectedConversations != 0)
        menuBinding.read.beVisibleIf((markRead && selectedConversations != 0) || selectedConversations > 1)
        menuBinding.unread.beVisibleIf((!markRead && selectedConversations != 0) || selectedConversations > 1)
        menuBinding.lock.beVisibleIf(selectedConversations != 0)
        menuBinding.unlock.beGone()
        menuBinding.block.beVisibleIf(selectedConversations != 0)
        menuBinding.rename.beVisibleIf(selectedConversations == 1)

        binding.pin.setOnClickListener { optionsItemIntent.onNext(binding.pin.id).let { true } }
        binding.unpin.setOnClickListener { optionsItemIntent.onNext(binding.unpin.id).let { true } }
        binding.delete.setOnClickListener {
            optionsItemIntent.onNext(binding.delete.id).let { true }
        }
        binding.archive.setOnClickListener {
            optionsItemIntent.onNext(binding.archive.id).let { true }
        }

//        binding.toolbar.menu.apply {
////            findItem(R.id.archive)?.isVisible = state.page is Inbox && selectedConversations != 0
////            findItem(R.id.delete)?.isVisible = selectedConversations != 0
////            findItem(R.id.pin)?.isVisible = markPinned && selectedConversations != 0
////            findItem(R.id.unpin)?.isVisible = !markPinned && selectedConversations != 0
//            findItem(R.id.select_all)?.isVisible = (conversationsAdapter.itemCount > 1) && selectedConversations != 0
//            findItem(R.id.unarchive)?.isVisible = state.page is Archived && selectedConversations != 0
//            findItem(R.id.add)?.isVisible = addContact && selectedConversations != 0
//            findItem(R.id.read)?.isVisible = (markRead && selectedConversations != 0) || selectedConversations > 1
//            findItem(R.id.unread)?.isVisible = (!markRead && selectedConversations != 0) || selectedConversations > 1
//            findItem(R.id.lock)?.isVisible = selectedConversations != 0
//            findItem(R.id.block)?.isVisible = selectedConversations != 0
//            findItem(R.id.rename)?.isVisible = selectedConversations == 1
//        }
//        listOf(binding.drawer.plusBadge1, binding.drawer.plusBadge2).forEach { badge ->
//            badge.isVisible = drawerBadgesExperiment.variant && !state.upgraded
//        }
//        plus.isVisible = state.upgraded
//        binding.drawer.plusBanner.isVisible = !state.upgraded
//        binding.drawer.rateLayout.setVisible(state.showRating)

        binding.compose.setVisible(state.page is Inbox || state.page is Archived)
        conversationsAdapter.emptyView = binding.empty.takeIf {
            state.page is Inbox || state.page is Archived
        }
        searchAdapter.emptyView = binding.empty.takeIf { state.page is Searching }

        when (state.page) {
            is Inbox -> {
                Log.e("PageState", "Inbox")
                showBackButton(state.page.selected > 0)
                binding.toolbarTitle.text = when {
                    state.page.selected > 0 -> getString(
                        R.string.main_title_selected,
                        state.page.selected
                    )

                    else -> getString(R.string.app_name)
                }
                if (binding.recyclerView.adapter !== conversationsAdapter)
                    binding.recyclerView.adapter = conversationsAdapter
                conversationsAdapter.updateData(state.page.data)
                if (state.page.selected > 0) {
                    itemTouchHelper.attachToRecyclerView(null)
                    binding.filterAll.setToggleEnabled(false)
                    binding.filterUnread.setToggleEnabled(false)
                } else {
                    itemTouchHelper.attachToRecyclerView(binding.recyclerView)
                    binding.filterAll.setToggleEnabled(true)
                    binding.filterUnread.setToggleEnabled(true)
                }
                binding.emptyText.setText(R.string.inbox_empty_text)
            }

            is Searching -> {
                Log.e("PageState", "Searching")
                showBackButton(true)
                binding.toolbarTitle.text = getString(R.string.title_conversations)
                if (binding.recyclerView.adapter !== searchAdapter) binding.recyclerView.adapter =
                    searchAdapter
                searchAdapter.data = state.page.data ?: listOf()
                itemTouchHelper.attachToRecyclerView(null)
                binding.emptyText.setText(R.string.inbox_search_empty_text)
            }

            is Archived -> {
                Log.e("PageState", "Archived")
                showBackButton(state.page.selected > 0)
                binding.toolbarTitle.text = when {
                    state.page.selected > 0 -> getString(
                        R.string.main_title_selected,
                        state.page.selected
                    )

                    else -> getString(R.string.title_archived)
                }
                if (binding.recyclerView.adapter !== conversationsAdapter)
                    binding.recyclerView.adapter = conversationsAdapter
                conversationsAdapter.updateData(state.page.data)
                itemTouchHelper.attachToRecyclerView(null)
                binding.emptyText.setText(R.string.archived_empty_text)
            }

            else -> {
                binding.toolbarTitle.text = getString(R.string.app_name)
            }
        }

        binding.filterAll.setChecked(state.activeChip == MessageCategory.ALL)
        binding.filterUnread.setChecked(state.activeChip == MessageCategory.UNREAD)
//        binding.filterArchived.isChecked = state.activeChip == MessageCategory.ARCHIVED

//        binding.drawer.inbox.isActivated = state.page is Inbox
//        binding.drawer.archived.isActivated = state.page is Archived

//        if (binding.drawerLayout.isDrawerOpen(GravityCompat.START) && !state.drawerOpen)
//            binding.drawerLayout.closeDrawer(GravityCompat.START)
//        else if (!binding.drawerLayout.isDrawerVisible(GravityCompat.START) && state.drawerOpen)
//            binding.drawerLayout.openDrawer(GravityCompat.START)

        when (state.syncing) {
            is SyncRepository.SyncProgress.Idle -> {
                binding.syncing.isVisible = false
                binding.snackbar.isVisible = (!state.defaultSms ||
                        !state.smsPermission ||
                        !state.contactPermission ||
                        !state.notificationPermission)
            }

            is SyncRepository.SyncProgress.Running -> {
                binding.syncing.isVisible = true
                syncingBinding.syncingProgress.let { progress ->
                    progress.max = state.syncing.max
                    ObjectAnimator.ofInt(
                        progress,
                        "progress",
                        progress.progress,
                        state.syncing.progress
                    ).start()
                    progress.isIndeterminate = state.syncing.indeterminate
                }
                binding.snackbar.isVisible = false
            }
        }

        when {
            !state.defaultSms -> {
                snackbarBinding.snackbarTitle.setText(R.string.main_default_sms_title)
                snackbarBinding.snackbarMessage.setText(R.string.main_default_sms_message)
                snackbarBinding.snackbarButton.setText(R.string.main_default_sms_change)
            }

            !state.smsPermission -> {
                snackbarBinding.snackbarTitle.setText(R.string.main_permission_required)
                snackbarBinding.snackbarMessage.setText(R.string.main_permission_sms)
                snackbarBinding.snackbarButton.setText(R.string.main_permission_allow)
            }

            !state.contactPermission -> {
                snackbarBinding.snackbarTitle.setText(R.string.main_permission_required)
                snackbarBinding.snackbarMessage.setText(R.string.main_permission_contacts)
                snackbarBinding.snackbarButton.setText(R.string.main_permission_allow)
            }

            !state.notificationPermission -> {
                snackbarBinding.snackbarTitle.setText(R.string.main_permission_required)
                snackbarBinding.snackbarMessage.setText(R.string.main_permission_notifications)
                snackbarBinding.snackbarButton.setText(R.string.main_permission_allow)
            }
        }
    }

    override fun onResume() =
        super.onResume().also { activityResumedIntent.onNext(true) }

    override fun onPause() =
        super.onPause().also { activityResumedIntent.onNext(false) }

    override fun onDestroy() =
        super.onDestroy().also { disposables.dispose() }

    override fun showBackButton(show: Boolean) {
        if (show) binding.ivClose.visibility = View.VISIBLE
        else binding.ivClose.visibility = View.GONE
    }
//    =toggle.let {
//            it.onDrawerSlide(binding.drawer.root, if (show) 1f else 0f)
//            it.drawerArrowDrawable.color = when (show) {
//                true -> resolveThemeColor(android.R.attr.textColorSecondary)
//                false -> resolveThemeColor(android.R.attr.textColorPrimary)
//            }
//        }

    override fun requestDefaultSms() =
        navigator.showDefaultSmsDialog(this)

    override fun restartActivity() {
        finish()
        startActivity(intent)
    }

    override fun requestPermissions() {
        val permissions = mutableListOf(
            Manifest.permission.READ_SMS,
            Manifest.permission.SEND_SMS,
            Manifest.permission.READ_CONTACTS
        )

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU)
            permissions += Manifest.permission.POST_NOTIFICATIONS

        ActivityCompat.requestPermissions(this, permissions.toTypedArray(), 0)
    }

    override fun clearSearch() {
        dismissKeyboard()
//        binding.toolbarSearch.text = null
//        binding.clearSearch.isVisible = false
    }

    override fun clearSelection() = conversationsAdapter.clearSelection()

    override fun toggleSelectAll() = conversationsAdapter.toggleSelectAll()

    override fun themeChanged() = binding.recyclerView.scrapViews()

    override fun showBlockingDialog(conversations: List<Long>, block: Boolean) {
        blockingDialog.show(this, conversations, block)
    }

    override fun showDeleteDialog(conversations: List<Long>) {
        deleteDialog.show(this, conversations)
    }

    override fun showRenameDialog(conversationName: String) {
        TextInputDialog(this)
            .setText(conversationName)
            .show(
                this,
                getString(R.string.info_name),
                renameConversationIntent::onNext
            )
    }


    override fun showArchivedSnackbar(countConversationsArchived: Int, isArchiving: Boolean) =
        Snackbar.make(
            binding.mainView,
            if (isArchiving) {
                resources.getQuantityString(
                    R.plurals.toast_archived,
                    countConversationsArchived,
                    countConversationsArchived
                )
            } else {
                resources.getQuantityString(
                    R.plurals.toast_unarchived,
                    countConversationsArchived,
                    countConversationsArchived
                )
            },
            if (countConversationsArchived < 10) Snackbar.LENGTH_LONG
            else Snackbar.LENGTH_INDEFINITE
        ).let {
            it.setAction(R.string.button_undo) { undoArchiveIntent.onNext(Unit) }
            it.setActionTextColor(colors.theme().theme)
            it.show()
        }

//    override fun onCreateOptionsMenu(menu: Menu?) =
//        menu?.let {
//            menuInflater.inflate(R.menu.main, it)
//            super.onCreateOptionsMenu(it)
//        } ?: false
//
//    override fun onOptionsItemSelected(item: MenuItem) =
//        optionsItemIntent.onNext(item.itemId).let { true }

//    override fun onBackPressed() = menuClickSubject.onNext(NavItem.BACK)

    override fun drawerToggled(opened: Boolean) {
        if (opened) {
            dismissKeyboard()
//            if (!binding.drawer.inbox.isInTouchMode)
//                binding.drawer.inbox.requestFocus()
        }
        //else
//            binding.toolbarSearch.requestFocus()
    }

    private fun openSearch() {
        val intent = Intent(this, SearchActivity::class.java)
        startActivity(intent)
    }

    private fun showDrawerMenu(anchorView: View) {
        popupWindow.showFromTopRight(anchorView)

    }
}
