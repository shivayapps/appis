package messages.text.sms.util

import messages.text.sms.BuildConfig

object Constants {
    const val SAVED_MESSAGE_TEXT_FILE_PREFIX = FileNamingConfig.SAVED_MESSAGE_TEXT_PREFIX
    const val BASE_URL = BuildConfig.API_URL
}