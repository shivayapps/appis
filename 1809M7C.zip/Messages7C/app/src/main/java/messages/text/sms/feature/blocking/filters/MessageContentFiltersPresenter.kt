
package messages.text.sms.feature.blocking.filters

import com.uber.autodispose.android.lifecycle.scope
import com.uber.autodispose.autoDispose
import io.reactivex.schedulers.Schedulers
import messages.text.sms.common.base.MyPresenter
import messages.text.sms.repository.MessageContentFilterRepository
import javax.inject.Inject

class MessageContentFiltersPresenter @Inject constructor(
    private val filterRepo: MessageContentFilterRepository,
) : MyPresenter<MessageContentFiltersView, MessageContentFiltersState>(
    MessageContentFiltersState(filters = filterRepo.getMessageContentFilters())
) {

    override fun bindIntents(view: MessageContentFiltersView) {
        super.bindIntents(view)

        view.removeFilter()
            .observeOn(Schedulers.io())
            .doOnNext(filterRepo::removeFilter)
            .subscribeOn(Schedulers.io())
            .autoDispose(view.scope())
            .subscribe()

        view.addFilter()
            .autoDispose(view.scope())
            .subscribe { view.showAddDialog() }

        view.saveFilter()
            .observeOn(Schedulers.io())
            .subscribeOn(Schedulers.io())
            .autoDispose(view.scope())
            .subscribe { filterData -> filterRepo.createFilter(filterData) }
    }

}
