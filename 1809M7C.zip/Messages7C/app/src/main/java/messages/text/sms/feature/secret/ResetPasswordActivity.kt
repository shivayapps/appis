package messages.text.sms.feature.secret

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.speech.RecognizerIntent
import android.util.Log
import android.view.View
import android.widget.ImageView
import android.widget.TextView
import androidx.activity.addCallback
import androidx.activity.result.contract.ActivityResultContracts
import dagger.android.AndroidInjection
import messages.text.sms.R
import messages.text.sms.common.base.MainBaseThemedActivity
import messages.text.sms.extensions.baseConfig
import messages.text.sms.extensions.makeToast
import messages.text.sms.common.widget.MessageEditText
import messages.text.sms.databinding.PasswordActivityBinding

class ResetPasswordActivity :
    MainBaseThemedActivity<PasswordActivityBinding>(PasswordActivityBinding::inflate) {
    private var firstTimePasswordSet = true
    private var password = ""
    private var mTempPassword = ""
    private lateinit var dots: List<ImageView>

    override fun onCreate(savedInstanceState: Bundle?) {
        AndroidInjection.inject(this)
        super.onCreate(savedInstanceState)

        onBackPressedDispatcher.addCallback(this) {
            isEnabled = false
            onBackPressedDispatcher.onBackPressed()
        }

        initPinLock()
        setNumberButtonListeners()
    }

    private fun initPinLock() {

        firstTimePasswordSet = true
        binding.tvPasswordHint.text = getString(R.string.create_your_pin)
        binding.btnForget.visibility = View.INVISIBLE

        dots = listOf(
            binding.dot1,
            binding.dot2,
            binding.dot3,
            binding.dot4
        )
    }

    private fun setNumberButtonListeners() {
        val buttons = listOf<TextView>(
            binding.btn1,
            binding.btn2,
            binding.btn3,
            binding.btn4,
            binding.btn5,
            binding.btn6,
            binding.btn7,
            binding.btn8,
            binding.btn9,
            binding.btn0
        )

        buttons.forEach { button ->
            button.setOnClickListener {
                if (password.length < 4) {
                    password += (button.text as String)
                    updateDots()
                }
                if (password.length == 4) {
                    // Handle 4-digit password entered
                    handlePasswordEntered()
                }
            }
        }
        binding.btnBackspace.setOnClickListener {
            if (password.isNotEmpty()) {
                password = password.dropLast(1)
                updateDots()
            }
        }
    }

    private fun updateDots() {
        for (i in 0 until 4) {
            if (i < password.length) {
                dots[i].setImageResource(R.drawable.ic_dot_filled)
            } else {
                dots[i].setImageResource(R.drawable.ic_dot_empty)
            }
        }
    }

    private fun handlePasswordEntered() {
//        if (firstTimePasswordSet) {
        if (mTempPassword.isNotEmpty()) {
            if (mTempPassword == password) {
                baseConfig.privatePin = password
                firstTimePasswordSet = false
                binding.tvPasswordHint.text = getString(R.string.enter_your_pin)
                password = ""
                updateDots()

                // Set Security Question Here
//                    setSecurityQuestion()
                authenticationSuccess()
            } else {
                binding.tvPasswordHint.text = getString(R.string.pin_does_not_match_try_again)
                password = ""
                mTempPassword = ""
                updateDots()
            }
        } else {
            if (password.length == 4) {
                binding.tvPasswordHint.text = getString(R.string.confirm_your_pin)
                mTempPassword = password
                password = ""
                updateDots()
            }
        }
//        } else {
//            if (password == baseConfig.privatePin) {
//                authenticationSuccess()
//            } else {
//                binding.tvPasswordHint.text = getString(R.string.incorrect_pin_try_again)
//                password = ""
//                updateDots()
//            }
//        }
    }

//    private val securityQuestionsLauncher =
//        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
//            if (result.resultCode != RESULT_OK) {
//                makeToast("Please set your PIN and select a security question to continue.")
//                baseConfig.privatePin = ""
//                finish()
//            } else {
//                authenticationSuccess()
//            }
//        }

    fun setSecurityQuestion() {
//        finish()
//        val intent = Intent(this, SecurityQuestionsActivity::class.java)
//        securityQuestionsLauncher.launch(intent)
////        startActivity(intent)
    }

    fun authenticationSuccess() {
        val intent = Intent(this, PrivateConversationsActivity::class.java)
        startActivity(intent)
        finish()
    }

}