package messages.text.sms.feature.blocking.filters

import android.app.Activity
import android.content.Context
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.LayoutInflater
import android.view.Window
import android.view.WindowManager
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.core.widget.doOnTextChanged
import com.jakewharton.rxbinding2.view.clicks
import com.uber.autodispose.android.lifecycle.scope
import com.uber.autodispose.autoDispose
import io.reactivex.Observable
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.MainScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import messages.text.sms.R
import messages.text.sms.common.base.MainBaseThemedActivity
import messages.text.sms.common.widget.PreferenceView
import messages.text.sms.databinding.MessageContentFiltersAddDialogBinding
import messages.text.sms.extensions.dismissKeyboard
import messages.text.sms.extensions.showKeyboard
import messages.text.sms.interactor.DeleteConversations
import messages.text.sms.repository.ConversationRepository
import messages.text.sms.util.Preferences
import javax.inject.Inject


class MessageContentFiltersAddDialog @Inject constructor(
    private val context: Context
) {

    private lateinit var binding: MessageContentFiltersAddDialogBinding
    private lateinit var dialog: AlertDialog
    private var isRegexChecked = false

    fun show(
        activity: Activity,
        listener: (String, Boolean, Boolean, Boolean) -> Unit
    ) {
        showDialog(activity,  listener)
    }

    var msg = ""
    private fun showDialog(
        activity: Activity,
        listener: (String, Boolean, Boolean, Boolean) -> Unit
    ) {
        binding = MessageContentFiltersAddDialogBinding.inflate(
            LayoutInflater.from(context)
        )

        dialog = AlertDialog.Builder(activity)
            .setView(binding.root)
            .setCancelable(true)
            .create()

        activity.dismissKeyboard()
        Handler(Looper.myLooper()!!).postDelayed({
            binding.input.requestFocus()
            binding.input.showKeyboard()
            binding.input.setText("")
        }, 500)

        binding.input.doOnTextChanged { text, start, before, count ->
            msg = text.toString().trim()
            if (msg.isEmpty()) {
                binding.btnPositive.alpha = 0.5f
//                binding.btnNegative.alpha = 0.5f
            } else {
                binding.btnPositive.alpha = 1.0f
//                binding.btnNegative.alpha = 1.0f
            }
        }

        setupPreferenceListeners()
        binding.btnPositive.setOnClickListener {
            if (msg.isNotEmpty()) {
                val inputText = binding.input.text.toString().trim()

                if (inputText.isEmpty()) {
                    return@setOnClickListener
                }

                val caseSensitive =
                    binding.caseSensitivity.checkbox?.isChecked == true && !isRegexChecked
                val regexChecked = isRegexChecked
                val contactChecked = binding.contacts.checkbox?.isChecked == true

                listener(
                    inputText,
                    caseSensitive,
                    regexChecked,
                    contactChecked
                )
                dialog.dismiss()
            } else {
                Toast.makeText(activity, "Please enter number", Toast.LENGTH_SHORT).show()
            }

        }
        binding.btnNegative.setOnClickListener {
            dialog.dismiss()
        }
        setupDialogWindow()

        dialog.show()
    }

    private fun setupPreferenceListeners() {
        // Set up click listeners for all preference views
        for (i in 0 until binding.addDialog.childCount) {
            val view = binding.addDialog.getChildAt(i)
            if (view is PreferenceView) {
                view.setOnClickListener {
                    view.checkbox?.let { checkbox ->
                        checkbox.isChecked = !checkbox.isChecked
                    }
                    updateCaseSensitivityState()
                }
            }
        }

        // Listen for regex checkbox changes
        binding.regexp.checkbox?.setOnCheckedChangeListener { _, isChecked ->
            isRegexChecked = isChecked
            updateCaseSensitivityState()
        }
    }

    private fun updateCaseSensitivityState() {
        binding.caseSensitivity.isEnabled = !isRegexChecked
        if (isRegexChecked) {
            binding.caseSensitivity.checkbox?.isChecked = false
        }
    }

    private fun setupDialogWindow() {
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.window?.apply {
            setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            setGravity(Gravity.CENTER)
            setDimAmount(0.8f)
            attributes?.windowAnimations = android.R.style.Animation_Dialog
            setLayout(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.WRAP_CONTENT
            )
        }
    }
}