package messages.text.sms.feature.blocking

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.CompoundButton
import android.widget.LinearLayout
import com.bluelinelabs.conductor.RouterTransaction
import com.jakewharton.rxbinding2.view.clicks
import messages.text.sms.R
import messages.text.sms.common.MyChangeHandler
import messages.text.sms.common.base.MyController
import messages.text.sms.common.util.Colors
import messages.text.sms.extensions.animateLayoutChanges
import messages.text.sms.extensions.isVisible
import messages.text.sms.extensions.setVisible
import messages.text.sms.common.widget.PreferenceView
import messages.text.sms.databinding.BlockingControllerBinding
import messages.text.sms.feature.blocking.filters.MessageContentFiltersController
import messages.text.sms.feature.blocking.messages.BlockedMessagesController
import messages.text.sms.feature.blocking.numbers.BlockedNumbersController
import messages.text.sms.injection.appComponent
import javax.inject.Inject

class BlockingController :
    MyController<BlockingControllerBinding, BlockingView, BlockingState, BlockingPresenter>(),
    BlockingView {

    override fun inflateBinding(
        inflater: LayoutInflater,
        container: ViewGroup
    ): BlockingControllerBinding =
        BlockingControllerBinding.inflate(inflater, container, false)

    //    override val blockingManagerIntent get() = binding.blockingManager.clicks()
    override val blockedNumbersIntent get() = binding.blockedNumbers.clicks()
    override val messageContentFiltersIntent get() = binding.messageContentFilters.clicks()
    override val blockedMessagesIntent get() = binding.blockedMessages.clicks()
    override val dropClickedIntent get() = binding.drop.clicks()

    @Inject
    lateinit var colors: Colors
    @Inject
    override lateinit var presenter: BlockingPresenter

    init {
        appComponent.inject(this)
        retainViewMode = RetainViewMode.RETAIN_DETACH
    }

    override fun onViewCreated() {
        super.onViewCreated()
        binding.parent.postDelayed({ binding.parent.animateLayoutChanges = true }, 100)
    }

    override fun onAttach(view: View) {
        super.onAttach(view)
        presenter.bindIntents(this)
        setTitle(R.string.blocking_title)
//        showBackButton(true)
    }

    override fun render(state: BlockingState) {
        binding.drop.checkbox.isChecked = state.dropEnabled
        binding.blockedMessages.isEnabled = !state.dropEnabled
        binding.blockedMessages.alpha = if (!state.dropEnabled) 1.0f else 0.6f
//        binding.blockedMessages.setVisible(!state.dropEnabled)
    }

    override fun openBlockedNumbers() {
        router.pushController(
            RouterTransaction.with(BlockedNumbersController())
                .pushChangeHandler(MyChangeHandler())
                .popChangeHandler(MyChangeHandler())
        )
    }

    override fun openMessageContentFilters() {
        router.pushController(
            RouterTransaction.with(MessageContentFiltersController())
                .pushChangeHandler(MyChangeHandler())
                .popChangeHandler(MyChangeHandler())
        )
    }

    override fun openBlockedMessages() {
        router.pushController(
            RouterTransaction.with(BlockedMessagesController())
                .pushChangeHandler(MyChangeHandler())
                .popChangeHandler(MyChangeHandler())
        )
    }
}
