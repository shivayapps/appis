package messages.text.sms.common

import android.content.res.Resources
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.util.Log
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.PopupWindow
import messages.text.sms.R

class PopupWindowHelper(private val popupView: View) {
    private var mPopupWindow: PopupWindow? = null

    fun showAsDropDown(anchor: View?, xoff: Int, yoff: Int) {
        initPopupWindow(TYPE_MATCH_PARENT)
        mPopupWindow!!.showAsDropDown(anchor, xoff, yoff)
    }

    fun showAtLocation(parent: View?, gravity: Int, x: Int, y: Int) {
        initPopupWindow(TYPE_WRAP_CONTENT)
        mPopupWindow!!.showAtLocation(parent, gravity, x, y)
    }

//    fun dismiss() {
//        if (mPopupWindow!!.isShowing) {
//            mPopupWindow!!.dismiss()
//        }
//    }

    fun dismiss() { mPopupWindow?.takeIf { it.isShowing }?.dismiss() }

    @JvmOverloads
    fun showAsPopUp(anchor: View, xoff: Int = 0, yoff: Int = 0) {
        initPopupWindow(TYPE_MATCH_PARENT)
        mPopupWindow!!.animationStyle = R.style.AnimationUpPopup
        popupView.measure(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        val height = popupView.measuredHeight
        val location = IntArray(2)
        anchor.getLocationInWindow(location)
        mPopupWindow!!.showAtLocation(
            anchor,
            Gravity.TOP,
            location[0] + xoff,
            location[1] - height + yoff
        )
    }

    fun showFromBottom(anchor: View?) {
        initPopupWindow(TYPE_MATCH_PARENT)
        mPopupWindow!!.animationStyle = R.style.AnimationFromBottom
        mPopupWindow!!.showAtLocation(anchor, Gravity.START or Gravity.BOTTOM, 0, 0)
    }

    fun showFromTopLeft(anchor: View?) {
        initPopupWindow(TYPE_WRAP_CONTENT)
        mPopupWindow!!.animationStyle = R.style.AnimationFromTop
        mPopupWindow!!.showAtLocation(anchor, Gravity.START or Gravity.TOP, 0, this.statusBarHeight)
    }

    fun showFromTopRight(anchor: View) {
        initPopupWindow(TYPE_WRAP_CONTENT)
        mPopupWindow!!.animationStyle = R.style.AnimationFromTopRight

        // Measure popup
        popupView.measure(
            View.MeasureSpec.UNSPECIFIED,
            View.MeasureSpec.UNSPECIFIED
        )

        val popupWidth = popupView.measuredWidth

        val location = IntArray(2)
        anchor.getLocationOnScreen(location)

        val x = location[0] + anchor.width - popupWidth
        val y = location[1] + anchor.height

        mPopupWindow!!.showAtLocation(anchor, Gravity.START or Gravity.TOP, x, y)
    }

//    fun showFromTopRight(anchor: View?) {
//        initPopupWindow(TYPE_WRAP_CONTENT)
//        mPopupWindow!!.animationStyle = R.style.AnimationFromTopRight
//        mPopupWindow!!.showAtLocation(anchor, Gravity.END or Gravity.TOP, 0, this.statusBarHeight)
//    }

    /**
     * touch outside dismiss the popupwindow, default is ture
     * @param isCancelable
     */
    fun setCancelable(isCancelable: Boolean) {
        if (isCancelable) {
            mPopupWindow!!.isOutsideTouchable = true
            mPopupWindow!!.isFocusable = true
        } else {
            mPopupWindow!!.isOutsideTouchable = false
            mPopupWindow!!.isFocusable = false
        }
    }

    private fun initPopupWindow(type: Int) {
        if (mPopupWindow != null) return

        mPopupWindow =
            if (type == TYPE_WRAP_CONTENT) {
                PopupWindow(
                    popupView,
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                    true
                )
            } else {
                PopupWindow(
                    popupView,
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                    true
                )
            }

        mPopupWindow?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        mPopupWindow?.isOutsideTouchable = true
    }

    private val statusBarHeight: Int
        get() = Math.round(
            25 * Resources.getSystem().getDisplayMetrics().density
        )

    companion object {
        private const val TYPE_WRAP_CONTENT = 0
        private const val TYPE_MATCH_PARENT = 1
    }
}

