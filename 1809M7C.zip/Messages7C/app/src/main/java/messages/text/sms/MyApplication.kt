package messages.text.sms

import android.app.Activity
import android.content.Intent
import android.content.IntentFilter
import android.content.res.Resources
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.telephony.TelephonyManager
import android.util.Log
import androidx.emoji2.bundled.BundledEmojiCompatConfig
import androidx.emoji2.text.EmojiCompat
import androidx.work.Configuration
import androidx.work.WorkManager
import androidx.work.WorkerFactory
import com.uber.rxdogtag.RxDogTag
import com.uber.rxdogtag.autodispose.AutoDisposeConfigurer
import dagger.android.AndroidInjector
import dagger.android.DispatchingAndroidInjector
import dagger.android.HasAndroidInjector
import io.realm.Realm
import io.realm.RealmConfiguration
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import messages.text.sms.adhelper.AdUtil
import messages.text.sms.adhelper.AppOpenApplication
import messages.text.sms.adhelper.OpenAdHelper
import messages.text.sms.adhelper.OpenAdHelper.showOpenAd
import messages.text.sms.after_call.activity.AfterCallHomeActivity
import messages.text.sms.after_call.helpers.AfterCallReceiver
import messages.text.sms.extensions.baseConfig
import messages.text.sms.feature.startup.OverlayPermissionActivity
import messages.text.sms.feature.startup.PermissionActivity
import messages.text.sms.feature.startup.SplashActivity
import messages.text.sms.injection.AppComponentManager
import messages.text.sms.injection.appComponent
import messages.text.sms.interactor.SpeakThreads
import messages.text.sms.manager.ReferralManager
import messages.text.sms.manager.SpeakManager
import messages.text.sms.migration.MyMigration
import messages.text.sms.migration.MyRealmMigration
import messages.text.sms.util.NightModeManager
import messages.text.sms.worker.HousekeepingWorker
import java.util.Locale
import javax.inject.Inject

class MyApplication : HasAndroidInjector, AppOpenApplication(),
    AppOpenApplication.AppLifecycleListener {

    /**
     * Inject these so that they are forced to initialize
     */
    @Suppress("unused")
    @Inject
    lateinit var myMigration: MyMigration

    @Inject
    lateinit var dispatchingAndroidInjector: DispatchingAndroidInjector<Any>

    @Inject
    lateinit var nightModeManager: NightModeManager

    @Inject
    lateinit var realmMigration: MyRealmMigration

    @Inject
    lateinit var referralManager: ReferralManager

    @Inject
    lateinit var workerFactory: WorkerFactory

    companion object {
        //        var messageApplicationContext: Context? = null
//        var mEnterScreen = false
//        var mOpenOverlayScreen = false
        var dataLoading: Boolean? = false
    }

    override fun onCreate() {
        super.onCreate()
        //registerActivityLifecycle()

        // set application context for SpeakManager
        SpeakManager.setContext(this)

        // set translated "no messages" string for speakThreads interactor
        SpeakThreads.setNoMessagesString(getString(R.string.speak_no_messages))

        AppComponentManager.init(this)
        appComponent.inject(this)

        Realm.init(this)
        Realm.setDefaultConfiguration(
            RealmConfiguration.Builder()
                .compactOnLaunch()
                .migration(realmMigration)
                .schemaVersion(MyRealmMigration.SchemaVersion)
                .build()
        )

        myMigration.performMigration()

        GlobalScope.launch(Dispatchers.IO) {
            referralManager.trackReferrer()
        }

        nightModeManager.updateCurrentTheme()

        // configure emoji compatibility with bundled package
        // (bundled library works with no play-services/gsm os versions)
        EmojiCompat.init(
            BundledEmojiCompatConfig(this)
                .registerInitCallback(object : EmojiCompat.InitCallback() {
                    override fun onInitialized() {
                        super.onInitialized()
                        Log.d("Timber", "bundled emojicompat initialized")
                    }

                    override fun onFailed(throwable: Throwable?) {
                        super.onFailed(throwable)
                        Log.d("Timber", "bundled emojicompat initialization failed")
                    }
                })
        )

        // rxdogtag provides 'look-back' for exceptions in rxjava2 'chains'
        RxDogTag.builder()
            .configureWith(AutoDisposeConfigurer::configure)
            .install()

        // init work manager with custom factory supporting dagger/injection capability
        WorkManager.initialize(
            this,
            Configuration.Builder().setWorkerFactory(workerFactory).build()
        )

        // register, or re-register, housekeeping work manager
        HousekeepingWorker.register(applicationContext)


        val defaultLanguage = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            getValidLanguageCode(Resources.getSystem().configuration.locale.language)
        } else {
            getValidLanguageCode(Locale.getDefault().language)
        }
        Log.e(
            "LanguageSetup",
            "defaultLanguage.001:${Resources.getSystem().configuration.locale.language}"
        )
        Log.e("LanguageSetup", "defaultLanguage.002:${Locale.getDefault().language}")
        Log.e("LanguageSetup", "defaultLanguage.003:$defaultLanguage")
        baseConfig.systemLocalLanguage = defaultLanguage

        setupAfterCall()

        setAppLifecycleListener(this)
    }

    public fun setupAfterCall() {
        val screenUnlockReceiver = AfterCallReceiver()
        val filter = IntentFilter()

        filter.addAction(Intent.ACTION_BOOT_COMPLETED)
        filter.addAction(Intent.ACTION_MY_PACKAGE_REPLACED)
        filter.addAction(Intent.ACTION_POWER_CONNECTED)
        filter.addAction(Intent.ACTION_SCREEN_OFF)
        filter.addAction(Intent.ACTION_SCREEN_ON)
        filter.addAction(Intent.ACTION_POWER_DISCONNECTED)
        filter.addAction(TelephonyManager.ACTION_PHONE_STATE_CHANGED)
        applicationContext.registerReceiver(screenUnlockReceiver, filter)
        //AfterCallGlobal.initializeAfterCall(this)
    }

    fun getValidLanguageCode(defaultLanguage: String): String {
        Log.i("MainApp", "defaultLanguage:$defaultLanguage")
        if (listOf(
                "en",
                "hi",
                "es",
                "de",
                "fr",
                "zh",
                "tr",
                "pt",
                "ar"
            ).contains(defaultLanguage)
        ) {
            return defaultLanguage
        }
        return "en"
    }

//    private fun registerActivityLifecycle() {
//        registerActivityLifecycleCallbacks(object : ActivityLifecycleCallbacks {
//            override fun onActivityCreated(
//                activity: Activity,
//                savedInstanceState: Bundle?
//            ) {
//                activity.applyEdgeToEdgeInsets()
//            }
//
//            override fun onActivityStarted(activity: Activity) {}
//            override fun onActivityResumed(activity: Activity) {}
//            override fun onActivityPaused(activity: Activity) {}
//            override fun onActivityStopped(activity: Activity) {}
//            override fun onActivitySaveInstanceState(activity: Activity, outState: Bundle) {}
//            override fun onActivityDestroyed(activity: Activity) {}
//        })
//    }

    override fun androidInjector(): AndroidInjector<Any> {
        return dispatchingAndroidInjector
    }

    override fun onResumeApp(fCurrentActivity: Activity): Boolean {
        if (fCurrentActivity is com.karumi.dexter.DexterActivity) {
            return false
        } else if (fCurrentActivity is SplashActivity) {
            return false
        } else if (fCurrentActivity is AfterCallHomeActivity) {
            return false
        } else if (fCurrentActivity is PermissionActivity) {
            return false
        } else if (fCurrentActivity is OverlayPermissionActivity) {
            return false
        } else if (AdUtil.isSystemDialogOpen) {
            Handler(Looper.getMainLooper()).postDelayed({
                AdUtil.isSystemDialogOpen = false
            }, 1000)
            return false
        }
        return true
    }

    override fun onAppOpenCreatedEvent(fCurrentActivity: Activity) {
        if (onResumeApp(fCurrentActivity))
            if (!fCurrentActivity.isDestroyed && !fCurrentActivity.isFinishing) {
                if (OpenAdHelper.isAdAvailable()) {
                    fCurrentActivity.showOpenAd { success ->
                        //finish()
                    }
                }
            }
    }
}