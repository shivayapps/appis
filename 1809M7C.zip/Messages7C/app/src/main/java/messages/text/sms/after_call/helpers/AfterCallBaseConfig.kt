package messages.text.sms.after_call.helpers

import android.content.Context
import androidx.annotation.Keep
import androidx.core.content.edit

@Keep
open class AfterCallBaseConfig(val context: Context) {
    protected val prefs = context.getSharedPrefs()

    companion object {
        fun newInstance(context: Context) = AfterCallBaseConfig(context)
    }
    var afterCallEnable: Boolean
        get() = prefs.getBoolean("CALLER_CAD_ENABLE", true)
        set(value) = prefs.edit { putBoolean("CALLER_CAD_ENABLE", value) }
    var isShowCallInfo: Boolean
        get() = prefs.getBoolean("isShowCallInfo", true)
        set(value) = prefs.edit { putBoolean("isShowCallInfo", value) }

}


