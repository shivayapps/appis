package messages.text.sms.feature.startup

import android.Manifest
import android.app.role.RoleManager
import android.content.ComponentName
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.CountDownTimer
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.provider.Telephony
import android.text.SpannableString
import android.text.Spanned
import android.text.TextPaint
import android.text.method.LinkMovementMethod
import android.text.style.ClickableSpan
import android.text.style.ForegroundColorSpan
import android.util.Log
import android.view.View
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.karumi.dexter.Dexter
import com.karumi.dexter.MultiplePermissionsReport
import com.karumi.dexter.PermissionToken
import com.karumi.dexter.listener.PermissionRequest
import com.karumi.dexter.listener.multi.MultiplePermissionsListener
import dagger.android.AndroidInjection
import kotlinx.coroutines.launch
import messages.text.sms.BuildConfig
import messages.text.sms.R
import messages.text.sms.adhelper.BannerAdHelper
import messages.text.sms.extensions.MiuiHelperUtils
import messages.text.sms.common.base.MainBaseThemedActivity
import messages.text.sms.extensions.baseConfig
import messages.text.sms.extensions.getPermissionString
import messages.text.sms.extensions.hasPermission
import messages.text.sms.extensions.isQPlus
import messages.text.sms.extensions.launchUrl
import messages.text.sms.databinding.ActivityPermissionBinding
import messages.text.sms.dialog.MessageDialog
import messages.text.sms.extensions.hasAllPermissions
import messages.text.sms.feature.localization.LocalizationActivity
import messages.text.sms.feature.main.MainActivity
import messages.text.sms.util.PERMISSION_POST_NOTIFICATIONS
import messages.text.sms.util.PERMISSION_READ_PHONE_STATE
import java.util.Locale


class PermissionActivity :
    MainBaseThemedActivity<ActivityPermissionBinding>(ActivityPermissionBinding::inflate) {

    private val MAKE_DEFAULT_APP_REQUEST = 1001
    private val GENERIC_PERM_HANDLER = 1002
    private var isAutoStartGranted = false

    //    private var permissionCallback: ((Boolean) -> Unit)? = null
    private var isReturningFromAutoStart = false

    val TAG = "PermissionActivity"

    override fun onCreate(savedInstanceState: Bundle?) {
        AndroidInjection.inject(this)
        super.onCreate(savedInstanceState)
        setContentView(binding.root)

        checkPermissions()
        binding.btnNext.setOnClickListener {
            askPermissions()
        }
        binding.cardPhonePermission.setOnClickListener {
            askPermissions()
        }
        binding.cardNotificationPermission.setOnClickListener {
            askNotificationPermission()
        }
        loadAds()
        setupPrivacyPolicy()
    }

    override fun onResume() {
        super.onResume()
        if (isReturningFromAutoStart) {
            isReturningFromAutoStart = false
            checkAutoStartAfterReturn()
        }
    }

    fun loadAds() {
        BannerAdHelper.showBanner(
            this,
            binding.adsView,
            baseConfig.bannerAdsId,
            { isLoaded, message ->

            })
    }

    private fun setupPrivacyPolicy() {
        val text = "By allowing, you agree to our Privacy Policy."
        val clickableText = "Privacy Policy"
        val spannable = SpannableString(text)
        val start = text.indexOf(clickableText)
        val end = start + clickableText.length
        spannable.setSpan(
            ForegroundColorSpan(ContextCompat.getColor(this, R.color.md_theme_primary)),
            start,
            end,
            Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
        )
        spannable.setSpan(object : ClickableSpan() {
            override fun onClick(widget: View) {
                launchUrl(getString(R.string.privacy_policy_url))
            }

            override fun updateDrawState(ds: TextPaint) {
                super.updateDrawState(ds)
                ds.color = ContextCompat.getColor(this@PermissionActivity, R.color.md_theme_primary)
                ds.isUnderlineText = false
            }
        }, start, end, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        binding.tvPolicy.text = spannable
        binding.tvPolicy.movementMethod = LinkMovementMethod.getInstance()
        binding.tvPolicy.highlightColor = Color.TRANSPARENT
    }


    private fun askPermissions() {
        val list: ArrayList<String> = ArrayList()
        list.add(Manifest.permission.READ_PHONE_STATE)
        list.add(Manifest.permission.POST_NOTIFICATIONS)
        requestPermission(list)

//        handlePermission(PERMISSION_READ_PHONE_STATE) { callGranted ->
//            if (callGranted) {
//                binding.ivCheckPhone.setImageResource(R.drawable.ic_radio_button_checked)
//            }
//            handlePermission(PERMISSION_POST_NOTIFICATIONS) { notificationsGranted ->
//                if (notificationsGranted) {
//                    binding.ivCheckNotification.setImageResource(R.drawable.ic_radio_button_checked)
//                }
//                requestDefaultSms()
//            }
//        }
    }

    private fun askNotificationPermission() {
        val list: ArrayList<String> = ArrayList()
        list.add(Manifest.permission.POST_NOTIFICATIONS)
        list.add(Manifest.permission.READ_PHONE_STATE)
        requestPermission(list)

//        handlePermission(PERMISSION_POST_NOTIFICATIONS) { notificationsGranted ->
//            if (notificationsGranted) {
//                binding.ivCheckNotification.setImageResource(R.drawable.ic_radio_button_checked)
//            }
//            handlePermission(PERMISSION_READ_PHONE_STATE) { callGranted ->
//                if (callGranted) {
//                    binding.ivCheckPhone.setImageResource(R.drawable.ic_radio_button_checked)
//                }
//                requestDefaultSms()
//            }
//        }
    }

    private fun requestPermission(list: ArrayList<String>) {

        Dexter.withContext(this@PermissionActivity)
            .withPermissions(
                list
            )
            .withListener(object : MultiplePermissionsListener {
                override fun onPermissionsChecked(report: MultiplePermissionsReport?) {
                    Log.e(TAG, "onPermissionsChecked")
                    report?.let {
                        if (report.areAllPermissionsGranted()) {
                            requestDefaultSms()
                        } else if (report.isAnyPermissionPermanentlyDenied) {
                            checkPermissions()
                            MessageDialog()
                                .show(
                                    this@PermissionActivity,
                                    getString(R.string.permission_needed),
                                    getString(R.string.permission_msg),
                                    getString(R.string.button_ok),
                                    positiveActionCallback = {
                                        val intent =
                                            Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
                                        val uri = Uri.fromParts("package", packageName, null)
                                        intent.data = uri
                                        permissionLauncher.launch(intent)
                                    },
                                    negativeActionCallback = {},
                                    dismissActionCallback = {}
                                )

                        } else {
                            checkPermissions()
                        }
                    }
                }

                override fun onPermissionRationaleShouldBeShown(
                    permissions: MutableList<PermissionRequest>?,
                    token: PermissionToken?,
                ) {
                    Log.e(TAG, "onPermissionRationaleShouldBeShown")
                    token?.continuePermissionRequest()
                }
            }).check()

    }

    var permissionLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { _ ->
            checkPermissions()
            if (hasAllPermissions(
                    listOf(
                        PERMISSION_READ_PHONE_STATE,
                        PERMISSION_POST_NOTIFICATIONS
                    )
                )
            ) {
                requestDefaultSms()
            }
        }

    private fun checkPermissions() {
        if (hasPermission(PERMISSION_READ_PHONE_STATE)) {
            binding.ivCheckPhone.setImageResource(R.drawable.ic_radio_button_checked)
        }
        if (hasPermission(PERMISSION_POST_NOTIFICATIONS)) {
            binding.ivCheckNotification.setImageResource(R.drawable.ic_radio_button_checked)
        }
    }

    private fun checkAutoStartPermission() {
        Log.e(TAG, "checkAutoStartPermission >>")
        isAutoStartGranted = MiuiHelperUtils.isAutoStartEnabled(this)
        if (isAutoStartGranted) {
            moveNext()
        } else {
            openAutoStartSettings()
        }
    }


    var countDownTimerAutoStart: CountDownTimer? = null
    private fun openAutoStartSettings() {
        Log.e(TAG, "openAutoStartSettings >>")
        val intentAutoStart = openAutoStartIntent()
        if (intentAutoStart != null) {
            startActivity(intentAutoStart)
            isReturningFromAutoStart = true
            Handler(Looper.myLooper()!!).postDelayed({
                startActivity(Intent(this, PermissionHintActivity::class.java))
            }, 500)
        } else {
            MiuiHelperUtils.openBgStartSettings(this)
            isReturningFromAutoStart = true
            Handler(Looper.myLooper()!!).postDelayed({
                startActivity(Intent(this, PermissionHintActivity::class.java))
            }, 500)
        }
        countDownTimerAutoStart?.cancel()
        countDownTimerAutoStart = object : CountDownTimer(1000000L, 500) {
            override fun onTick(l: Long) {
                isAutoStartGranted = MiuiHelperUtils.isAutoStartEnabled(this@PermissionActivity)
                Log.e(TAG, "countDownTimerAutoStart.isAutoStartGranted:$isAutoStartGranted")
                if (isAutoStartGranted) {
                    //intentAutoStart.finish()
                    countDownTimerAutoStart?.cancel()
                    Log.e(TAG, "countDownTimerAutoStart.moveNext")
                    moveNext()

                }
            }

            override fun onFinish() {}
        }
        countDownTimerAutoStart!!.start()
    }

    fun openAutoStartIntent(): Intent? {
        Log.e("MiuiHelper", "openAutoStartSettings")
        val autoStartIntent = Intent().apply {
            component = ComponentName(
                "com.miui.securitycenter",
                "com.miui.permcenter.autostart.AutoStartManagementActivity"
            )
            putExtra("package", BuildConfig.APPLICATION_ID)
            putExtra("package_name", BuildConfig.APPLICATION_ID)
            putExtra("extra_pkgname", BuildConfig.APPLICATION_ID)
//            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            addFlags(Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS)
        }

        try {
            return autoStartIntent
        } catch (e: Exception) {
            Log.e("MiuiHelper", "openAutoStartSettings.Exception:$e")
            // Try alternative activity
            return null
        }
    }

    private fun checkAutoStartAfterReturn() {
        // Simply check if permission is granted now
        isAutoStartGranted = MiuiHelperUtils.isAutoStartEnabled(this)
        if (isAutoStartGranted) {
            moveNext()
        }

    }

    private fun openOverlayScreen() {
        Log.e(TAG, "openOverlayScreen >>")
        Handler(Looper.myLooper()!!).postDelayed({
            try {
                val overlayIntent = Intent(this, OverlayPermissionActivity::class.java)
                overlayIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                overlayIntent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP)
                overlayIntent.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP)
                overlayIntent.addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT)
                overlayIntent.addFlags(Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
                Log.e(TAG, "startActivity overlayIntent")
                startActivity(overlayIntent)
            } catch (e: Exception) {
                Log.e(TAG, "Error bringing app to front: $e")
            }
            finish()
        }, 500)

    }

    private fun moveNext() {
        Log.e(TAG, "moveNext >>")
        if (isFinishing || isDestroyed) return
        if (Settings.canDrawOverlays(this)) {
            val locale = Locale.getDefault().language
            if (locale != "en"
                || !baseConfig.clickLangDone
            ) {
                startActivity(
                    Intent(this, LocalizationActivity::class.java)
                        .putExtra("from_splash", true)
                )
            } else {
                startActivity(Intent(this, MainActivity::class.java))
            }
            finish()

        } else {
            openOverlayScreen()
        }


    }

    private fun requestDefaultSms() {
        if (isQPlus()) {
            val roleManager = getSystemService(RoleManager::class.java)
            if (roleManager.isRoleHeld(RoleManager.ROLE_SMS)) {
                checkAutoStartPermission()
            } else {
                startActivityForResult(
                    roleManager.createRequestRoleIntent(RoleManager.ROLE_SMS),
                    MAKE_DEFAULT_APP_REQUEST
                )
            }
        } else {
            if (Telephony.Sms.getDefaultSmsPackage(this) == packageName) {
                checkAutoStartPermission()
            } else {
                val intent = Intent(Telephony.Sms.Intents.ACTION_CHANGE_DEFAULT)
                intent.putExtra(
                    Telephony.Sms.Intents.EXTRA_PACKAGE_NAME,
                    packageName
                )
                startActivityForResult(intent, MAKE_DEFAULT_APP_REQUEST)
            }
        }
    }

    override fun onActivityResult(
        requestCode: Int,
        resultCode: Int,
        data: Intent?
    ) {
        super.onActivityResult(requestCode, resultCode, data)

        if (requestCode == MAKE_DEFAULT_APP_REQUEST) {
            if (resultCode == RESULT_OK) {
                checkAutoStartPermission()
            }
        }
    }

//    fun handlePermission(
//        permissionId: Int,
//        callback: (Boolean) -> Unit
//    ) {
//        permissionCallback = callback
//        if (hasPermission(permissionId)) {
//            callback(true)
//        } else {
//            ActivityCompat.requestPermissions(
//                this,
//                arrayOf(getPermissionString(permissionId)),
//                GENERIC_PERM_HANDLER
//            )
//        }
//    }

//    override fun onRequestPermissionsResult(
//        requestCode: Int,
//        permissions: Array<out String>,
//        grantResults: IntArray
//    ) {
//        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
//        if (requestCode == GENERIC_PERM_HANDLER) {
//            val granted = grantResults.isNotEmpty() &&
//                    grantResults[0] == PackageManager.PERMISSION_GRANTED
//            permissionCallback?.invoke(granted)
//        }
//    }
}
