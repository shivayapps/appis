package messages.text.sms.feature.conversationinfo

import messages.text.sms.model.Recipient
import io.realm.RealmList
data class ConversationInfoSettings(
    val name: String,
    val title: String,
    val recipients: RealmList<Recipient>,
    val archived: Boolean,
    val blocked: Boolean
)