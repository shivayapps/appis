
package messages.text.sms.interactor

import messages.text.sms.repository.ConversationRepository
import messages.text.sms.repository.MessageRepository
import messages.text.sms.util.Preferences
import io.reactivex.Flowable
import android.util.Log
import javax.inject.Inject

class DeleteOldMessages @Inject constructor(
    private val conversationRepo: ConversationRepository,
    private val messageRepo: MessageRepository,
    private val prefs: Preferences
) : Interactor<Unit>() {

    override fun buildObservable(params: Unit): Flowable<*> = Flowable.fromCallable {
        val maxAge = prefs.autoDelete.get().takeIf { it > 0 } ?: return@fromCallable
        val counts = messageRepo.getOldMessageCounts(maxAge)
        val threadIds = counts.keys.toLongArray()

        Log.d("Timber","Deleting ${counts.values.sum()} old messages from ${threadIds.size} conversations")
        messageRepo.deleteOldMessages(maxAge)
        conversationRepo.updateConversations(*threadIds)
    }

}
