package messages.text.sms.adhelper

import android.app.Activity
import android.app.Application
import android.os.Bundle
import android.util.Log
import messages.text.sms.after_call.activity.AfterCallHomeActivity
import messages.text.sms.util.AppUtil.applyEdgeToEdgeInsets
import messages.text.sms.util.AppUtil.applyEdgeToEdgeLimited

class OpenAdManager(
    private val myApplication: AppOpenApplication
) : Application.ActivityLifecycleCallbacks {

    var mCurrentActivity: Activity? = null

    init {
        myApplication.registerActivityLifecycleCallbacks(this)
    }

    override fun onActivityResumed(activity: Activity) {
        mCurrentActivity = activity
    }

    override fun onActivityDestroyed(activity: Activity) {

    }

    override fun onActivityStopped(activity: Activity) {
    }

    override fun onActivityStarted(activity: Activity) {

    }

    override fun onActivityCreated(activity: Activity, savedInstanceState: Bundle?) {
        Log.e("ActivityCreated","activity:${activity.localClassName}")
        if(activity is com.google.android.gms.ads.AdActivity){

        } else if(activity is AfterCallHomeActivity){
            activity.applyEdgeToEdgeLimited()
        } else {
            activity.applyEdgeToEdgeInsets()
        }

    }

    override fun onActivityPaused(activity: Activity) {

    }

    override fun onActivitySaveInstanceState(activity: Activity, outState: Bundle) {}

//    fun showOpenAd() {
//        myApplication.mAppLifecycleListener?.onAppOpenCreatedEvent(mCurrentActivity!!)
//    }
}