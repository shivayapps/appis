
package messages.text.sms.feature.scheduled

import android.content.Context
import android.net.Uri
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import messages.text.sms.R
import messages.text.sms.common.base.MyAdapter
import messages.text.sms.common.base.MyBindingViewHolder
import messages.text.sms.extensions.getName
import messages.text.sms.extensions.LoadBestIconIntoImageView
import messages.text.sms.extensions.loadBestIconIntoImageView
import messages.text.sms.databinding.ScheduledMessageImageListItemBinding
import javax.inject.Inject


class ScheduledMessageAttachmentAdapter @Inject constructor(
    private val context: Context
) : MyAdapter<Uri, MyBindingViewHolder<ScheduledMessageImageListItemBinding>>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyBindingViewHolder<ScheduledMessageImageListItemBinding> =
        MyBindingViewHolder(
            ScheduledMessageImageListItemBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        )

    override fun onBindViewHolder(holder: MyBindingViewHolder<ScheduledMessageImageListItemBinding>, position: Int) {
        val uri = getItem(position)

        // set best image and text to use for icon
        when (getItem(position).loadBestIconIntoImageView(context, holder.binding.thumbnail)) {
            LoadBestIconIntoImageView.Missing -> {
                holder.binding.fileName.text = context.getString(R.string.attachment_missing)
                holder.binding.fileName.visibility = View.VISIBLE
            }
            LoadBestIconIntoImageView.ActivityIcon,
            LoadBestIconIntoImageView.DefaultAudioIcon,
            LoadBestIconIntoImageView.GenericIcon -> {
                // generic style icon used, also show name
                holder.binding.fileName.text = uri.getName(context)
                holder.binding.fileName.visibility = View.VISIBLE
            }
            else -> holder.binding.fileName.visibility = View.GONE
        }
    }
}
