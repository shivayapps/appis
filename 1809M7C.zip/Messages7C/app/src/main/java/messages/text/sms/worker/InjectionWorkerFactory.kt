package messages.text.sms.worker

import android.content.Context
import androidx.work.ListenableWorker
import androidx.work.Worker
import androidx.work.WorkerFactory
import androidx.work.WorkerParameters
import messages.text.sms.interactor.ReceiveSms
import messages.text.sms.repository.ScheduledMessageRepository
import javax.inject.Inject

class InjectionWorkerFactory @Inject constructor(
    private val receiveSms: ReceiveSms,
    private val scheduledMessageRepository: ScheduledMessageRepository
)
: WorkerFactory() {
    override fun createWorker(
        appContext: Context,
        workerClassName: String,
        workerParameters: WorkerParameters
    ): ListenableWorker? {
        val instance = Class
            .forName(workerClassName)
            .asSubclass(Worker::class.java)
            .getDeclaredConstructor(Context::class.java, WorkerParameters::class.java)
            .newInstance(appContext, workerParameters)

        when (instance) {
            is HousekeepingWorker -> {
                instance.scheduledMessageRepository = scheduledMessageRepository
            }
            is ReceiveSmsWorker -> {
                instance.receiveSms = receiveSms
            }
        }

        return instance
    }
}