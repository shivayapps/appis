package messages.text.sms.extensions

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.WindowInsetsController
import android.view.inputmethod.InputMethodManager
import androidx.core.view.isGone
import androidx.viewbinding.ViewBinding

inline fun <T : ViewBinding> Activity.viewBinding(crossinline bindingInflater: (LayoutInflater) -> T) =
    lazy(LazyThreadSafetyMode.NONE) {
        bindingInflater.invoke(layoutInflater)
    }
fun Activity.dismissKeyboard() {
    window.currentFocus?.let { focus ->
        val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        imm.hideSoftInputFromWindow(focus.windowToken, 0)
        focus.clearFocus()
    }
}
inline fun <reified T : Any> Context.launchActivity(
    options: Bundle? = null, noinline init: Intent.() -> Unit = {}
) {

    val intent = newIntent<T>(this)
    intent.init()
    startActivity(intent, options)
}
inline fun <reified T : Any> newIntent(context: Context): Intent = Intent(context, T::class.java)


fun Activity.setStatusBarFontColor(isBlack: Boolean) {
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
        // Android 11+ (API 30+)
        val controller = window.insetsController ?: return
        if (isBlack) {
            controller.setSystemBarsAppearance(
                WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS,
                WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS
            )
        } else {
            controller.setSystemBarsAppearance(
                0,
                WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS
            )
        }
    } else {
        // Android 6–10
        val decor = window.decorView
        decor.systemUiVisibility = if (isBlack) {
            decor.systemUiVisibility or View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
        } else {
            decor.systemUiVisibility and View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR.inv()
        }
    }
}


fun Activity.updateStatusBarColor(statusBarColor: Int) {
    window.statusBarColor = statusBarColor
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.VANILLA_ICE_CREAM) {
        val parent = window.decorView as ViewGroup
        var fakeStatusBarView = parent.findViewWithTag<View>("status_bar")
        if (fakeStatusBarView != null) {
            if (fakeStatusBarView.isGone) {
                fakeStatusBarView.visibility = View.VISIBLE
            }
            fakeStatusBarView.setBackgroundColor(statusBarColor)
        } else {
            fakeStatusBarView = createStatusBarView(window.context, statusBarColor, getStatusBarHeight())
            parent.addView(fakeStatusBarView)
        }
    }
}
private fun createStatusBarView(context: Context, statusBarColor: Int, height: Int): View {
    val statusBarView = View(context)
    statusBarView.layoutParams = ViewGroup.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT, height
    )
    statusBarView.setBackgroundColor(statusBarColor)
    statusBarView.tag = "status_bar"
    return statusBarView
}
fun Activity.getStatusBarHeight(): Int {
    val resourceId: Int = resources.getIdentifier("status_bar_height", "dimen", "android")
    return resources.getDimensionPixelSize(resourceId)
}