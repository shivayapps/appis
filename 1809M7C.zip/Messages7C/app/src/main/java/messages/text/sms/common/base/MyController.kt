package messages.text.sms.common.base

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.annotation.LayoutRes
import androidx.annotation.StringRes
import androidx.appcompat.app.AppCompatActivity
import androidx.viewbinding.ViewBinding
import com.bluelinelabs.conductor.archlifecycle.LifecycleController
import messages.text.sms.R

abstract class MyController<VB : ViewBinding, ViewContract : MyViewContract<State>, State: Any, Presenter : MyPresenter<ViewContract, State>> :
    LifecycleController() {

    abstract var presenter: Presenter

    private val appCompatActivity: AppCompatActivity?
        get() = activity as? AppCompatActivity

    protected val themedActivity: MainBaseThemedActivity<*>?
        get() = activity as? MainBaseThemedActivity<*>

    private var _binding: VB? = null
    protected val binding: VB
        get() = requireNotNull(_binding)

    protected abstract fun inflateBinding(inflater: LayoutInflater, container: ViewGroup): VB

    protected var containerView: View? = null

//    @LayoutRes
//    var layoutRes: Int = 0

//    override fun onCreateView(
//        inflater: LayoutInflater,
//        container: ViewGroup,
//        savedViewState: Bundle?
//    ): View {
//        return inflater.inflate(layoutRes, container, false).also {
//            containerView = it
//            onViewCreated()
//        }
//    }
    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup, savedViewState: Bundle?): View {
        val vb = inflateBinding(inflater, container)
        _binding = vb
        return vb.root.also { onViewCreated() }
    }

    open fun onViewCreated() {
    }

    fun setTitle(@StringRes titleId: Int) {
        setTitle(activity?.getString(titleId))
    }

    fun setTitle(title: CharSequence?) {
        activity?.title = title
        view?.findViewById<TextView>(R.id.toolbarTitle)?.text = title
    }

    override fun onDestroyView(view: View) {
        super.onDestroyView(view)
        _binding = null
    }

    override fun onDestroy() {
        super.onDestroy()
        presenter.onCleared()
    }

}

//abstract class MyController<
//        ViewContract : MyViewContract<State>,
//        State : Any,
//        Presenter : MyPresenter<ViewContract, State>> :
//    LifecycleController() {
//
//    abstract var presenter: Presenter
//
//    private val appCompatActivity: AppCompatActivity?
//        get() = activity as? AppCompatActivity
//
//    protected val themedActivity: MainBaseThemedActivity<*>?
//        get() = activity as? MainBaseThemedActivity<*>
//
//    protected var containerView: View? = null
//
//    @LayoutRes
//    var layoutRes: Int = 0
//
//    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup, savedViewState: Bundle?): View {
//        return inflater.inflate(layoutRes, container, false).also {
//            containerView = it
//            onViewCreated()
//        }
//    }
//
//    open fun onViewCreated() {
//    }
//
//    fun setTitle(@StringRes titleId: Int) {
//        setTitle(activity?.getString(titleId))
//    }
//
//    fun setTitle(title: CharSequence?) {
//        activity?.title = title
//        containerView?.findViewById<android.widget.TextView>(R.id.toolbarTitle)?.text = title
//    }
//
//    fun showBackButton(show: Boolean) {
//        appCompatActivity?.supportActionBar?.setDisplayHomeAsUpEnabled(show)
//    }
//
//    override fun onDestroyView(view: View) {
//        containerView = null
//    }
//
//    override fun onDestroy() {
//        super.onDestroy()
//        presenter.onCleared()
//    }
//}
