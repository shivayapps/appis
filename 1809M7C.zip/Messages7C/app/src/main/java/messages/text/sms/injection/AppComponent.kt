
package messages.text.sms.injection

import dagger.Component
import dagger.android.support.AndroidSupportInjectionModule
import messages.text.sms.MyApplication
import messages.text.sms.dialog.OptionDialog
import messages.text.sms.dialog.ThemeControlDialog
import messages.text.sms.common.util.MyChooserTargetService
import messages.text.sms.common.widget.AvatarView
import messages.text.sms.common.widget.PagerTitleView
import messages.text.sms.common.widget.PreferenceView
import messages.text.sms.common.widget.MessageEditText
import messages.text.sms.common.widget.MySwitch
import messages.text.sms.common.widget.MessagesTextView
import messages.text.sms.common.widget.RadioPreferenceView
import messages.text.sms.feature.backup.BackupController
import messages.text.sms.feature.blocking.BlockingController
import messages.text.sms.feature.blocking.filters.MessageContentFiltersController
import messages.text.sms.feature.blocking.messages.BlockedMessagesController
import messages.text.sms.feature.blocking.numbers.BlockedNumbersController
import messages.text.sms.feature.compose.editing.DetailedChipView
import messages.text.sms.feature.conversationinfo.injection.ConversationInfoComponent
import messages.text.sms.feature.settings.SettingsController
import messages.text.sms.feature.settings.SettingsOtherController
import messages.text.sms.feature.settings.swipe.SwipeActionsController
import messages.text.sms.feature.widget.WidgetAdapter
import messages.text.sms.injection.android.ActivityBuilderModule
import messages.text.sms.injection.android.BroadcastReceiverBuilderModule
import messages.text.sms.injection.android.ServiceBuilderModule
import javax.inject.Singleton

@Singleton
@Component(modules = [
    AndroidSupportInjectionModule::class,
    AppModule::class,
    ActivityBuilderModule::class,
    BroadcastReceiverBuilderModule::class,
    ServiceBuilderModule::class])
interface AppComponent {

    fun conversationInfoBuilder(): ConversationInfoComponent.Builder

    fun inject(application: MyApplication)

//    fun inject(controller: AboutController)
    fun inject(controller: BackupController)
    fun inject(controller: BlockedMessagesController)
    fun inject(controller: BlockedNumbersController)
    fun inject(controller: MessageContentFiltersController)
    fun inject(controller: BlockingController)
    fun inject(controller: SettingsController)
    fun inject(controller: SettingsOtherController)
    fun inject(controller: SwipeActionsController)

    fun inject(dialog: OptionDialog)
    fun inject(dialog: ThemeControlDialog)

    fun inject(service: WidgetAdapter)

    /**
     * This can't use AndroidInjection, or else it will crash on pre-marshmallow devices
     */
    fun inject(service: MyChooserTargetService)

    fun inject(view: AvatarView)
    fun inject(view: DetailedChipView)
    fun inject(view: PagerTitleView)
    fun inject(view: PreferenceView)
    fun inject(view: RadioPreferenceView)
    fun inject(view: MessageEditText)
    fun inject(view: MySwitch)
    fun inject(view: MessagesTextView)

}
