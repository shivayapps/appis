
package messages.text.sms.feature.backup

import messages.text.sms.repository.BackupRepository

data class BackupState(
    val backupProgress: BackupRepository.Progress = BackupRepository.Progress.Idle(),
    val restoreProgress: BackupRepository.Progress = BackupRepository.Progress.Idle(),

    val showLocationRationale: Boolean = false,
    val showSelectedBackupError: Boolean = false,
    val selectedBackupDetails: String? = null,
    val showStopRestoreDialog: Boolean = false,

//    val upgraded: Boolean = true
)
