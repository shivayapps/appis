
package messages.text.sms.feature.blocking

data class BlockingState(
    val dropEnabled: Boolean = false
)
