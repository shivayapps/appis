package messages.text.sms.common.base

import androidx.lifecycle.LifecycleOwner

interface MainBaseMsgView<in State> : LifecycleOwner {

    fun render(state: State)

}