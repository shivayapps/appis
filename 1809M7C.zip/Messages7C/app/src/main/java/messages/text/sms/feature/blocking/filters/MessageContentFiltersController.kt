package messages.text.sms.feature.blocking.filters

import android.view.LayoutInflater
import android.view.View
import androidx.appcompat.app.AlertDialog
import com.jakewharton.rxbinding2.view.clicks
import com.uber.autodispose.android.lifecycle.scope
import com.uber.autodispose.autoDispose
import io.reactivex.Observable
import io.reactivex.subjects.PublishSubject
import io.reactivex.subjects.Subject
import messages.text.sms.R
import messages.text.sms.common.base.MyController
import messages.text.sms.extensions.setBackgroundTint
import messages.text.sms.extensions.setTint
import messages.text.sms.common.util.Colors
import messages.text.sms.common.widget.PreferenceView
import messages.text.sms.databinding.MessageContentFiltersAddDialogBinding
import messages.text.sms.databinding.MessageContentFiltersControllerBinding
import messages.text.sms.injection.appComponent
import messages.text.sms.model.MessageContentFilterData
import javax.inject.Inject


class MessageContentFiltersController :
    MyController<MessageContentFiltersControllerBinding, MessageContentFiltersView, MessageContentFiltersState,
            MessageContentFiltersPresenter>(), MessageContentFiltersView {

    @Inject
    override lateinit var presenter: MessageContentFiltersPresenter
    @Inject
    lateinit var colors: Colors

    private val adapter = MessageContentFiltersAdapter()
    private val saveFilterSubject: Subject<MessageContentFilterData> = PublishSubject.create()

    init {
        appComponent.inject(this)
        retainViewMode = RetainViewMode.RETAIN_DETACH
    }

    override fun inflateBinding(
        inflater: android.view.LayoutInflater,
        container: android.view.ViewGroup
    ): MessageContentFiltersControllerBinding =
        MessageContentFiltersControllerBinding.inflate(inflater, container, false)

    override fun onAttach(view: View) {
        super.onAttach(view)
        presenter.bindIntents(this)
        setTitle(R.string.message_content_filters_title)
//        showBackButton(true)
    }

    override fun onViewCreated() {
        super.onViewCreated()
//        binding.add.setBackgroundTint(colors.theme().theme)
//        binding.add.setTint(colors.theme().textPrimary)
        adapter.emptyView = binding.empty
        binding.filters.adapter = adapter
    }

    override fun render(state: MessageContentFiltersState) {
        adapter.updateData(state.filters)
    }

    override fun removeFilter(): Observable<Long> = adapter.removeMessageContentFilter
    override fun addFilter(): Observable<*> = binding.add.clicks()
    override fun saveFilter(): Observable<MessageContentFilterData> = saveFilterSubject

    override fun showAddDialog() {
        MessageContentFiltersAddDialog(activity!!)
            .show(
                activity!!,
                {text,isCaseSensitive,isRegexChecked,isContactChecked->
                    saveFilterSubject.onNext(
                        MessageContentFilterData(
                            text,
                            isCaseSensitive,
                            isRegexChecked,
                            isContactChecked
                        )
                    )
                }
            )
//        val layout = MessageContentFiltersAddDialogBinding.inflate(LayoutInflater.from(activity))
//        (0 until layout.addDialog.childCount)
//            .map { index -> layout.addDialog.getChildAt(index) }
//            .mapNotNull { view -> view as? PreferenceView }
//            .map { preference -> preference.clicks().map { preference } }
//            .let { Observable.merge(it) }
//            .autoDispose(scope())
//            .subscribe { pref ->
//                pref.checkbox?.let { it.isChecked = !it.isChecked }
//                val regexChecked = layout.regexp.checkbox?.isChecked ?: false
//                layout.caseSensitivity.isEnabled = !regexChecked
//            }
//        val dialog = AlertDialog.Builder(activity!!)
//            .setView(layout.root)
//            .setPositiveButton(R.string.message_content_filters_dialog_create) { _, _ ->
//                var text = layout.input.text.toString();
//                if (!text.isBlank()) {
//                    val regexChecked = layout.regexp.checkbox?.isChecked ?: false
//                    if (!regexChecked) text = text.trim()
//                    saveFilterSubject.onNext(
//                        MessageContentFilterData(
//                            text,
//                            (layout.caseSensitivity.checkbox?.isChecked == true) && !regexChecked,
//                            regexChecked,
//                            layout.contacts.checkbox?.isChecked == true
//                        )
//                    )
//                }
//            }
//            .setNegativeButton(R.string.button_cancel) { _, _ -> }
//        dialog.show()

    }

}

