package messages.text.sms.dialog

import android.app.Activity
import android.app.Dialog
import android.content.Context
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.view.Gravity
import android.view.Window
import android.view.WindowManager
import androidx.annotation.StringRes
import androidx.recyclerview.widget.LinearLayoutManager
import messages.text.sms.common.MenuItemAdapter
import messages.text.sms.databinding.OptionDialogBinding
import messages.text.sms.injection.appComponent
import java.util.Locale
import javax.inject.Inject


class OptionDialog @Inject constructor(private val context: Context, val adapter: MenuItemAdapter) {

    var title: String? = null

    init {
        appComponent.inject(this)
    }


    private lateinit var dialog: Dialog
    private lateinit var binding: OptionDialogBinding

    var tempSelectedItem: Int? = 0

    fun show(activity: Activity, @StringRes titleText: Int) {
        dialog = Dialog(activity)
        updateLocale(activity)

        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.window?.apply {
            setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            setGravity(Gravity.CENTER)
            setDimAmount(0.8f)
            attributes?.windowAnimations = android.R.style.Animation_Dialog
            setLayout(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.WRAP_CONTENT
            )
        }

        binding = OptionDialogBinding.inflate(activity.layoutInflater)
        dialog.setContentView(binding.root)

        dialog.window?.setLayout(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.WRAP_CONTENT
        )

        binding.titleText.text = context.getString(titleText)
        binding.recyclerView.layoutManager = LinearLayoutManager(context)
        binding.recyclerView.adapter = adapter
//        val clicks = adapter.menuItemClicks
//            .subscribe { dialog.dismiss() }

        initView()

        val clicks = adapter.tempMenuItemClicks
            .subscribe { item ->
                tempSelectedItem = item
            }

        binding.btnPositive.setOnClickListener {
            tempSelectedItem?.let {
                adapter.menuItemClicks.onNext(it) // Emit after confirmation
                dialog.dismiss()
            }
        }
        binding.ivClose.setOnClickListener {
            clicks.dispose()
            dialog.dismiss()
        }
        dialog.setOnDismissListener {
            clicks.dispose()
        }
        dialog.show()
    }

    private fun updateLocale(context: Context) {
        val locale = Locale.getDefault()
        val config = Configuration(context.resources.configuration)
        config.setLocale(locale)
        context.resources.updateConfiguration(config, context.resources.displayMetrics)

        // Also update the activity's resources
        if (context is Activity) {
            context.resources.updateConfiguration(config, context.resources.displayMetrics)
        }
    }

    private fun initView() {

    }

    fun setTitle(@StringRes title: Int) {
//        this.title = context.getString(title)
    }

}