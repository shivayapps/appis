
package messages.text.sms.feature.compose

import android.net.Uri
import android.view.MenuItem
import android.view.View
import androidx.core.view.inputmethod.InputContentInfoCompat
import messages.text.sms.common.MyMediaPlayer
import io.reactivex.Observable
import io.reactivex.subjects.Subject
import messages.text.sms.common.base.MainBaseMsgView
import messages.text.sms.common.widget.MicInputCloudView
import messages.text.sms.model.Attachment
import messages.text.sms.model.Recipient

interface ComposeView : MainBaseMsgView<ComposeState> {

    companion object {
        const val TakePhotoRequestCode = 1
        const val AttachContactRequestCode = 3
        const val AttachAFileRequestCode = 4

        const val CameraDestinationKey = "camera_destination"
    }

    val activityVisibleIntent: Observable<Boolean>
    val chipsSelectedIntent: Subject<HashMap<String, String?>>
    val chipDeletedIntent: Subject<Recipient>
    val menuReadyIntent: Observable<Unit>
    val viewExactAlarmsSettingsIntent: Observable<Unit>
    val optionsItemIntent: Observable<Int>
    val contextItemIntent: Observable<MenuItem>
    val sendAsGroupIntent: Observable<*>
    val messagePartClickIntent: Subject<Long>
    val messagePartContextMenuRegistrar: Subject<View>
    val messagesSelectedIntent: Observable<List<Long>>
    val cancelSendingIntent: Subject<Long>
    val sendNowIntent: Subject<Long>
    val resendIntent: Subject<Long>
    val attachmentDeletedIntent: Subject<Attachment>
    val textChangedIntent: Observable<CharSequence>
    val attachIntent: Observable<Unit>
    val cameraIntent: Observable<*>
    val locationIntent: Observable<*>
    val attachAnyFileIntent: Observable<*>
//    val attachImageFileIntent: Observable<*>
    val scheduleIntent: Observable<*>
    val scheduleAction: Observable<*>
    val attachContactIntent: Observable<*>
    val attachAnyFileSelectedIntent: Observable<Uri>
    val contactSelectedIntent: Observable<Uri>
    val inputContentIntent: Observable<InputContentInfoCompat>
    val scheduleSelectedIntent: Observable<Long>
    val scheduleCancelIntent: Observable<*>
    val changeSimIntent: Observable<*>
    val sendIntent: Observable<Unit>
    val backPressedIntent: Observable<Unit>
    val confirmDeleteIntent: Observable<List<Long>>
    val clearCurrentMessageIntent: Subject<Boolean>
    val messageLinkAskIntent: Observable<Uri>
    val shadeIntent: Observable<Unit>
    val recordAudioStartStopRecording: Subject<Boolean>
    val recordAnAudioMessage: Observable<Unit>
    val recordAudioAbort: Observable<Unit>
    val recordAudioAttach: Observable<Unit>
    val recordAudioPlayerPlayPause: Observable<MyMediaPlayer.PlayingState>
    val recordAudioPlayerConfigUI: Subject<MyMediaPlayer.PlayingState>
    val recordAudioPlayerVisible: Subject<Boolean>
    val recordAudioMsgRecordVisible: Subject<Boolean>
    val recordAudioRecord: Subject<MicInputCloudView.ViewState>
    val recordAudioChronometer: Subject<Boolean>

    fun clearSelection()
    fun toggleSelectAll()
    fun expandMessages(messageIds: List<Long>, expand: Boolean)
    fun showDetails(details: String)
    fun showMessageLinkAskDialog(uri: Uri)
    fun requestDefaultSms()
    fun requestStoragePermission()
    fun requestRecordAudioPermission()
    fun requestSmsPermission()
    fun showAlarmPermission()
    fun showContacts(sharing: Boolean, chips: List<Recipient>)
    fun themeChanged()
    fun showKeyboard()
    fun requestCamera()
    fun requestLocationString()
    fun requestGallery(mimeType: String)
    fun requestDatePicker()
    fun requestContact()
    fun setDraft(draft: String)
    fun scrollToMessage(id: Long)
//    fun showsmsPlusSnackbar(@StringRes message: Int)
    fun showDeleteDialog(messages: List<Long>)
    fun showClearCurrentMessageDialog()
    fun focusMessage()
}
