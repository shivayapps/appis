package messages.text.sms.feature.main

import android.os.Handler
import android.os.Looper
import android.util.Log
import androidx.recyclerview.widget.ItemTouchHelper
import com.uber.autodispose.android.lifecycle.scope
import com.uber.autodispose.autoDispose
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.rxkotlin.plusAssign
import io.reactivex.schedulers.Schedulers
import io.realm.Realm
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import messages.text.sms.R
import messages.text.sms.common.Navigator
import messages.text.sms.common.base.MessagesViewModel
import messages.text.sms.extensions.mapNotNull
import messages.text.sms.feature.main.ConversationFilterType.ALL
import messages.text.sms.feature.main.ConversationFilterType.UNREAD
import messages.text.sms.interactor.DeleteConversations
import messages.text.sms.interactor.MarkAllSeen
import messages.text.sms.interactor.MarkArchived
import messages.text.sms.interactor.MarkPinned
import messages.text.sms.interactor.MarkPrivate
import messages.text.sms.interactor.MarkPrivateRemove
import messages.text.sms.interactor.MarkRead
import messages.text.sms.interactor.MarkUnarchived
import messages.text.sms.interactor.MarkUnpinned
import messages.text.sms.interactor.MarkUnread
import messages.text.sms.interactor.SpeakThreads
import messages.text.sms.interactor.SyncContacts
import messages.text.sms.interactor.SyncMessages
import messages.text.sms.interactor.MigratePreferences
import messages.text.sms.interactor.SyncMessagesTemp
import messages.text.sms.listener.ContactAddedListener
import messages.text.sms.manager.PermissionManager
import messages.text.sms.manager.RatingManager
import messages.text.sms.model.EmojiSyncNeeded
import messages.text.sms.model.SyncLog
import messages.text.sms.repository.ConversationRepository
import messages.text.sms.repository.EmojiReactionRepository
import messages.text.sms.repository.MessageRepository
import messages.text.sms.repository.SyncRepository
import messages.text.sms.util.Preferences
import java.util.concurrent.TimeUnit
import javax.inject.Inject

class MainViewModel @Inject constructor(
    contactAddedListener: ContactAddedListener,
    markAllSeen: MarkAllSeen,
    migratePreferences: MigratePreferences,
    syncRepository: SyncRepository,
    private val conversationRepo: ConversationRepository,
    private val messageRepo: MessageRepository,
    private val deleteConversations: DeleteConversations,
    private val markArchived: MarkArchived,
    private val markPinned: MarkPinned,
    private val markRead: MarkRead,
    private val markUnarchived: MarkUnarchived,
    private val markPrivate: MarkPrivate,
    private val markPrivateRemove: MarkPrivateRemove,
    private val markUnpinned: MarkUnpinned,
    private val markUnread: MarkUnread,
    private val speakThreads: SpeakThreads,
    private val navigator: Navigator,
    private val permissionManager: PermissionManager,
    private val prefs: Preferences,
    private val ratingManager: RatingManager,
    private val reactions: EmojiReactionRepository,
    private val syncContacts: SyncContacts,
    private val syncMessagesTemp: SyncMessagesTemp,
    private val syncMessages: SyncMessages
) : MessagesViewModel<MainView, MainState>(
    MainState(
        page = Inbox(
            data = conversationRepo.getConversations(
                prefs.unreadAtTop.get(),
                onlyUnread = false
            )
        ),
        currentFilter = ALL,
        activeChip = MessageCategory.ALL
    )
) {
    private var lastArchivedThreadIds = listOf<Long>(0)
    private fun inboxData(filter: ConversationFilterType) =
        conversationRepo.getConversations(
            prefs.unreadAtTop.get(),
            onlyUnread = filter == UNREAD
        )

    private fun archivedData(filter: ConversationFilterType) =
        conversationRepo.getConversations(
            prefs.unreadAtTop.get(),
            archived = true,
            onlyUnread = filter == UNREAD
        )

    init {
        disposables += deleteConversations
        disposables += markAllSeen
        disposables += markArchived
        disposables += markUnarchived
        disposables += markPrivate
        disposables += migratePreferences
        disposables += syncContacts
        disposables += syncMessages

        // Show the syncing UI
        disposables += syncRepository.syncProgress
            .sample(16, TimeUnit.MILLISECONDS)
            .distinctUntilChanged()
            .subscribe { syncing -> newState { copy(syncing = syncing) } }

        // Show the rating UI
        disposables += ratingManager.shouldShowRating
            .subscribe { show -> newState { copy(showRating = show) } }


        // Migrate the preferences from 2.7.3
        migratePreferences.execute(Unit)


        // If we have all permissions and we've never run a sync, run a sync. This will be the case
        // when upgrading from 2.7.3, or if the app's data was cleared
        refreshMessages()
//        val lastSync = Realm.getDefaultInstance()
//            .use { realm -> realm.where(SyncLog::class.java)?.max("date") ?: 0 }
//        if (lastSync == 0 && permissionManager.isDefaultSms() && permissionManager.hasReadSms() && permissionManager.hasContacts()) {
//            syncMessages.execute(Unit)
//        }

        // This is only used when we update to a version that newly supports emoji reactions
        Realm.getDefaultInstance().executeTransactionAsync { realm ->
            val emojiSyncNeeded = realm.where(EmojiSyncNeeded::class.java).findFirst()
            if (emojiSyncNeeded != null) {
                reactions.deleteAndReparseAllEmojiReactions(realm)
                emojiSyncNeeded.deleteFromRealm()
            }
        }

        // Sync contacts when we detect a change
        if (permissionManager.hasContacts()) {
            disposables += contactAddedListener.listen()
                .debounce(1, TimeUnit.SECONDS)
                .subscribeOn(Schedulers.io())
                .subscribe { syncContacts.execute(Unit) }
        }

        ratingManager.addSession()
        markAllSeen.execute(Unit)
    }


    fun refreshMessages() {

        val lastSync = Realm.getDefaultInstance()
            .use { realm -> realm.where(SyncLog::class.java)?.max("date") ?: 0 }
        if (lastSync == 0 && (permissionManager.isDefaultSms() || permissionManager.hasReadSms()) && permissionManager.hasContacts()) {

            CoroutineScope(Dispatchers.IO).launch {
                Log.d("CoroutineCoroutine", "Starting syncMessagesTemp")
                syncMessagesTemp.execute(Unit)
                Log.d("CoroutineCoroutine", "Completed syncMessagesTemp")

                withContext(Dispatchers.Main) {
                    Log.d("CoroutineCoroutine", "Starting syncMessages")
                    syncMessages.execute(Unit)
                    Log.d("CoroutineCoroutine", "Completed syncMessages")
                }
            }

        }

    }

    override fun bindView(view: MainView) {
        super.bindView(view)

        when {
            !permissionManager.isDefaultSms() -> view.requestDefaultSms()
            !permissionManager.hasReadSms() || !permissionManager.hasContacts() -> view.requestPermissions()
        }


        // when unreadAtTop preference changes, reload the model view data to refresh view
        prefs.unreadAtTop.asObservable()
            .skip(1)
            .debounce(400, TimeUnit.MILLISECONDS)
            .observeOn(AndroidSchedulers.mainThread())
            .withLatestFrom(state) { _, state ->
                if (state.page is Inbox)
                    newState {
                        copy(page = Inbox(data = inboxData(currentFilter)))
                    }
                else if (state.page is Archived)
                    newState {
                        copy(page = Archived(data = archivedData(currentFilter)))
                    }
            }
            .autoDispose(view.scope())
            .subscribe()

        view.activityResumedIntent
            .filter { resumed -> resumed }
            .observeOn(Schedulers.io())
            .map { permissionManager.isDefaultSms() }
            .distinctUntilChanged()
            .skip(1) // Skip initial state
            .filter { it } // Only when becoming default (true)
            .observeOn(AndroidSchedulers.mainThread())
            .subscribe { view.restartActivity() }

        // Update state on every resume
        view.activityResumedIntent
            .filter { resumed -> resumed }
            .observeOn(Schedulers.io())
            .map { permissionManager.isDefaultSms() }
            .observeOn(AndroidSchedulers.mainThread())
            .subscribe { defaultSms -> newState { copy(defaultSms = defaultSms) } }

        // If the SMS Permission state changes, reflect it in the State
        view.activityResumedIntent
            .filter { resumed -> resumed }
            .observeOn(Schedulers.io())
            .map { permissionManager.hasReadSms() }
            .distinctUntilChanged()
            .doOnNext { smsPermission -> newState { copy(smsPermission = smsPermission) } }
            .autoDispose(view.scope())
            .subscribe()

        // If the Contacts Permission state changes, reflect it in the State
        view.activityResumedIntent
            .filter { resumed -> resumed }
            .observeOn(Schedulers.io())
            .map { permissionManager.hasContacts() }
            .distinctUntilChanged()
            .doOnNext { contactPermission -> newState { copy(contactPermission = contactPermission) } }
            .autoDispose(view.scope())
            .subscribe()

        // If the Notifications Permission state changes, reflect it in the State
        view.activityResumedIntent
            .filter { resumed -> resumed }
            .observeOn(Schedulers.io())
            .map { permissionManager.hasNotifications() }
            .distinctUntilChanged()
            .doOnNext { notificationPermission -> newState { copy(notificationPermission = notificationPermission) } }
            .autoDispose(view.scope())
            .subscribe()

        // If we go from not having all SMS permissions to having them, sync messages
        view.activityResumedIntent
            .filter { resumed -> resumed }
            .observeOn(Schedulers.io())
            .map { permissionManager.isDefaultSms() && permissionManager.hasReadSms() && permissionManager.hasContacts() }
            .distinctUntilChanged()
            .skip(1)
            .filter { hasAllPermissions -> hasAllPermissions }
            .autoDispose(view.scope())
            .subscribe { syncMessages.execute(Unit) }

        // Launch screen from intent
        view.onNewIntentIntent
            .autoDispose(view.scope())
            .subscribe { intent ->
                when (intent.getStringExtra("screen")) {
                    "compose" -> navigator.showConversation(intent.getLongExtra("threadId", 0))
                    "blocking" -> navigator.showBlockedConversations()
                }
            }



        view.filterSelectedIntent
            .distinctUntilChanged()
            .autoDispose(view.scope())
            .subscribe { chip ->
                when (chip) {
                    MessageCategory.ALL -> newState {
                        copy(
                            activeChip = chip,
                            currentFilter = ALL,
                            page = Inbox(data = inboxData(ALL))
                        )
                    }

                    MessageCategory.UNREAD -> newState {
                        copy(
                            activeChip = chip,
                            currentFilter = UNREAD,
                            page = Inbox(data = inboxData(UNREAD))
                        )
                    }

//                    MessageCategory.ARCHIVED -> newState {
//                        copy(
//                            activeChip = chip,
//                            currentFilter = ALL,
//                            page = Archived(data = archivedData(ALL))
//                        )
//                    }
                }
            }

        view.activityResumedIntent
            .filter { resumed -> !resumed }
            .switchMap {
                // Take until the activity is resumed
                prefs.keyChanges
                    .filter { key -> key.contains("theme") }
                    .map { true }
                    .doOnNext { view.themeChanged() }
                    .takeUntil(view.activityResumedIntent.filter { resumed -> resumed })
            }
            .autoDispose(view.scope())
            .subscribe()

        view.composeIntent
            .autoDispose(view.scope())
            .subscribe { navigator.showCompose() }

        view.homeIntent
            .withLatestFrom(state) { _, state ->
                when {
                    state.page is Searching -> view.clearSearch()
                    state.page is Inbox && state.page.selected > 0 -> view.clearSelection()
                    state.page is Archived && state.page.selected > 0 -> view.clearSelection()

                    else -> newState { copy(drawerOpen = true) }
                }
            }
            .autoDispose(view.scope())
            .subscribe()

//        view.drawerToggledIntent
//            .doOnNext {
//                newState { copy(drawerOpen = it) }
//                view.drawerToggled(it)
//            }
//            .autoDispose(view.scope())
//            .subscribe { open -> newState { copy(drawerOpen = open) } }

        view.navigationIntent
            .withLatestFrom(state) { drawerItem, state ->
                newState { copy(drawerOpen = false) }
                when (drawerItem) {
                    NavItem.BACK -> when {
                        state.drawerOpen -> Unit
                        state.page is Searching -> view.clearSearch()
                        state.page is Inbox && state.page.selected > 0 -> view.clearSelection()
                        state.page is Archived && state.page.selected > 0 -> view.clearSelection()
                        state.page !is Inbox -> {
                            newState {
                                copy(
                                    page = Inbox(data = inboxData(currentFilter)),
                                    activeChip = if (currentFilter == UNREAD) MessageCategory.UNREAD else MessageCategory.ALL
                                )
                            }
                        }

                        else -> newState { copy(hasError = true) }
                    }

                    NavItem.BACKUP -> navigator.showBackup()
                    NavItem.SCHEDULED -> navigator.showScheduled(null)
                    NavItem.BLOCKING -> navigator.showBlockedConversations()
                    NavItem.SETTINGS -> navigator.showSettings()
                    NavItem.PRIVATE -> navigator.showPassword()
                    NavItem.ARCHIVED -> navigator.showArchivedConversations()
//                        NavItem.PLUS -> navigator.showSmsPlusActivity("main_menu")
//                        NavItem.HELP -> navigator.showSupport()
//                    NavItem.INVITE -> navigator.showInvite()
                    else -> Unit
                }
                drawerItem
            }
            .distinctUntilChanged()
            .doOnNext { drawerItem ->
                when (drawerItem) {
                    NavItem.INBOX -> newState {
                        copy(
                            page = Inbox(data = inboxData(currentFilter)),
                            activeChip = if (currentFilter == UNREAD) MessageCategory.UNREAD else MessageCategory.ALL
                        )
                    }

//                    NavItem.ARCHIVED -> newState {
//                        copy(
//                            page = Archived(data = archivedData(ALL)),
//                            currentFilter = ALL,
//                            activeChip = MessageCategory.ARCHIVED
//                        )
//                    }

                    else -> Unit
                }
            }
            .autoDispose(view.scope())
            .subscribe()

        view.optionsItemIntent
            .filter { itemId -> itemId == R.id.select_all }
            .autoDispose(view.scope())
            .subscribe { view.toggleSelectAll() }

        view.optionsItemIntent
            .filter { itemId -> itemId == R.id.archive }
            .withLatestFrom(view.conversationsSelectedIntent) { _, conversations ->
                markArchived.execute(conversations)
                lastArchivedThreadIds = conversations.toList()
                view.showArchivedSnackbar(lastArchivedThreadIds.count(), true)
                view.clearSelection()
            }
            .autoDispose(view.scope())
            .subscribe()

        view.optionsItemIntent
            .filter { itemId -> itemId == R.id.unarchive }
            .withLatestFrom(view.conversationsSelectedIntent) { _, conversations ->
                markUnarchived.execute(conversations.toList())
                view.showArchivedSnackbar(conversations.count(), false)
                view.clearSelection()
            }
            .autoDispose(view.scope())
            .subscribe()

        view.optionsItemIntent.filter { itemId -> itemId == R.id.lock }
            .filter {
                permissionManager.isDefaultSms().also {
                    if (!it) view.requestDefaultSms()
                }
            }
            .withLatestFrom(view.conversationsSelectedIntent) { _, conversations ->
                markPrivate.execute(conversations)
                view.clearSelection()
            }.autoDispose(view.scope()).subscribe()

        view.optionsItemIntent.filter { itemId -> itemId == R.id.unlock }
            .filter {
                permissionManager.isDefaultSms().also {
                    if (!it) view.requestDefaultSms()
                }
            }
            .withLatestFrom(view.conversationsSelectedIntent) { _, conversations ->
                markPrivateRemove.execute(conversations)
                view.clearSelection()
            }.autoDispose(view.scope()).subscribe()

        view.optionsItemIntent.filter { itemId -> itemId == R.id.unlock }
            .filter {
                permissionManager.isDefaultSms().also {
                    if (!it) view.requestDefaultSms()
                }
            }
            .withLatestFrom(view.conversationsSelectedIntent) { _, conversations ->
                markPrivate.execute(conversations)
                view.clearSelection()
            }.autoDispose(view.scope()).subscribe()

        view.optionsItemIntent
            .filter { itemId -> itemId == R.id.delete }
            .filter { permissionManager.isDefaultSms().also { if (!it) view.requestDefaultSms() } }
            .withLatestFrom(view.conversationsSelectedIntent) { _, conversations ->
                view.showDeleteDialog(conversations)
            }
            .autoDispose(view.scope())
            .subscribe()

//        view.optionsItemIntent
//            .filter { it == R.id.add }
//            .doOnNext { Log.d("ADD", "Add clicked") }
//            .withLatestFrom(view.conversationsSelectedIntent) { _, conversations ->
//                Log.d("ADD", "Selected: ${conversations.size}")
//                conversations
//            }
//            .doOnNext { view.clearSelection() }
//            .filter {
//                Log.d("ADD", "After filter: ${it.size}")
//                it.size == 1
//            }
//            .map { it.first() }
//            .doOnNext {
//                Log.d("ADD", "Conversation id = $it")
//            }
//            .mapNotNull(conversationRepo::getConversation)
//            .doOnNext {
//                Log.d("ADD", "Conversation = $it")
//            }
//            .subscribe()
        view.optionsItemIntent
            .filter { itemId -> itemId == R.id.add }
            .withLatestFrom(view.conversationsSelectedIntent) { _, conversations -> conversations }
            .filter { conversations -> conversations.size == 1 }
            .map { conversations -> conversations.first() }
            .mapNotNull(conversationRepo::getConversation)
            .map { conversation -> conversation.recipients }
            .mapNotNull { recipients -> recipients[0]?.address?.takeIf { recipients.size == 1 } }
            .doOnNext(navigator::addContact)
            .doOnNext { view.clearSelection() }
            .autoDispose(view.scope())
            .subscribe()

        view.optionsItemIntent
            .filter { itemId -> itemId == R.id.pin }
            .withLatestFrom(view.conversationsSelectedIntent) { _, conversations ->
                markPinned.execute(conversations.toList())
                view.clearSelection()
            }
            .autoDispose(view.scope())
            .subscribe()

        view.optionsItemIntent
            .filter { itemId -> itemId == R.id.unpin }
            .withLatestFrom(view.conversationsSelectedIntent) { _, conversations ->
                markUnpinned.execute(conversations.toList())
                view.clearSelection()
            }
            .autoDispose(view.scope())
            .subscribe()

        view.optionsItemIntent
            .filter { itemId -> itemId == R.id.read }
            .filter { permissionManager.isDefaultSms().also { if (!it) view.requestDefaultSms() } }
            .withLatestFrom(view.conversationsSelectedIntent) { _, conversations ->
                markRead.execute(conversations.toList())
                view.clearSelection()
            }
            .autoDispose(view.scope())
            .subscribe()

        view.optionsItemIntent
            .filter { itemId -> itemId == R.id.unread }
            .filter { permissionManager.isDefaultSms().also { if (!it) view.requestDefaultSms() } }
            .withLatestFrom(view.conversationsSelectedIntent) { _, conversations ->
                markUnread.execute(conversations.toList())
                view.clearSelection()
            }
            .autoDispose(view.scope())
            .subscribe()

        view.optionsItemIntent
            .filter { itemId -> itemId == R.id.block }
            .withLatestFrom(view.conversationsSelectedIntent) { _, conversations ->
                view.showBlockingDialog(conversations.toList(), true)
                view.clearSelection()
            }
            .autoDispose(view.scope())
            .subscribe()

        view.optionsItemIntent
            .filter { itemId -> itemId == R.id.rename }
            .withLatestFrom(view.conversationsSelectedIntent) { _, conversationIds -> conversationIds.first() }
            .mapNotNull { conversationId -> conversationRepo.getConversation(conversationId) }
            .autoDispose(view.scope())
            .subscribe { conversation -> view.showRenameDialog(conversation.name) }

//        view.plusBannerIntent
//                .autoDisposable(view.scope())
//                .subscribe {
//                    newState { copy(drawerOpen = false) }
//                    navigator.showSmsPlusActivity("main_banner")
//                }
//
//        view.rateIntent
//            .autoDispose(view.scope())
//            .subscribe {
//                navigator.showRating()
//                ratingManager.rate()
//            }
//
//        view.dismissRatingIntent
//            .autoDispose(view.scope())
//            .subscribe { ratingManager.dismiss() }

        view.conversationsSelectedIntent
            .withLatestFrom(state) { selection, state ->
                val conversations = selection.mapNotNull(conversationRepo::getConversation)
                val add = conversations.firstOrNull()
                    ?.takeIf { conversations.size == 1 }
                    ?.takeIf { conversation -> conversation.recipients.size == 1 }
                    ?.recipients?.first()
                    ?.takeIf { recipient -> recipient.contact == null } != null
                val pin = conversations.sumBy { if (it.pinned) -1 else 1 } >= 0
                val read = when (conversations.size) {
                    0 -> false
                    1 -> conversations[0].unread
                    else -> true
                }
                val selected = selection.size

                Log.d("MainViewModel","selected:$selected")
                when (state.page) {
                    is Inbox -> {
                        Log.d("MainViewModel","state.page Inbox")
                        val page = state.page.copy(
                            addContact = add,
                            markPinned = pin,
                            markRead = read,
                            selected = selected
                        )
                        newState { copy(page = page) }
                    }

                    is Archived -> {
                        Log.d("MainViewModel","state.page Archived")
                        val page = state.page.copy(
                            addContact = add,
                            markPinned = pin,
                            markRead = read,
                            selected = selected
                        )
                        newState { copy(page = page) }
                    }

                    is Searching -> {
                        Log.d("MainViewModel","state.page Searching")
                    } // Ignore
                    else -> {
                        Log.d("MainViewModel","state.page Other")
                    }
                }
            }
            .autoDispose(view.scope())
            .subscribe()

        // Delete the conversation
        view.confirmDeleteIntent
            .autoDispose(view.scope())
            .subscribe { conversations ->
                deleteConversations.execute(conversations.toList())
                view.clearSelection()
            }

        view.renameConversationIntent
            .withLatestFrom(view.conversationsSelectedIntent) { newConversationName, selectedConversationIds ->
                Pair(newConversationName, selectedConversationIds.first())
            }
            .doOnNext { view.clearSelection() }
            .map { newNameAndConversationId ->
                conversationRepo.setConversationName(
                    newNameAndConversationId.second,
                    newNameAndConversationId.first
                )
                    .subscribeOn(Schedulers.io())
                    .observeOn(AndroidSchedulers.mainThread())
            }
            .flatMapCompletable { it }
            .autoDispose(view.scope())
            .subscribe()

        view.swipeConversationIntent
            .autoDispose(view.scope())
            .subscribe { (threadId, direction) ->
                val action =
                    if (direction == ItemTouchHelper.RIGHT) prefs.swipeRight.get()
                    else prefs.swipeLeft.get()
                when (action) {
                    Preferences.SWIPE_ACTION_ARCHIVE ->
                        markArchived.execute(listOf(threadId)) {
                            lastArchivedThreadIds = listOf(threadId)
                            view.showArchivedSnackbar(1, true)
                        }

                    Preferences.SWIPE_ACTION_DELETE ->
                        view.showDeleteDialog(listOf(threadId))

                    Preferences.SWIPE_ACTION_BLOCK ->
                        view.showBlockingDialog(listOf(threadId), true)

                    Preferences.SWIPE_ACTION_CALL -> {
                        (
                                messageRepo.getMessagesSync(threadId).lastOrNull { !it.isMe() }
                                    ?.address // most recent non-me msg address
                                    ?: conversationRepo.getConversation(threadId)
                                        ?.recipients?.firstOrNull()?.address  // first recipient in convo
                                )?.let(navigator::makePhoneCall)
                    }

//                    Preferences.SWIPE_ACTION_READ -> markRead.execute(listOf(threadId))
//                    Preferences.SWIPE_ACTION_UNREAD -> {
//                        markUnread.execute(listOf(threadId))
//                    }
                    Preferences.SWIPE_ACTION_TOGGLE_READ -> {
                        val isCurrentlyRead =
                            checkIfRead(threadId) // Implement this function to check if the conversation is read
                        if (isCurrentlyRead) {
                            markUnread.execute(listOf(threadId)) {
                                Handler(Looper.myLooper()!!).postDelayed({
                                    newState { copy(drawerOpen = false) }
                                }, 100)
                            }
                        } else {
                            markRead.execute(listOf(threadId)) {
                                Handler(Looper.myLooper()!!).postDelayed({
                                    newState { copy(drawerOpen = false) }
                                }, 100)
                            }
                        }
                    }

                    Preferences.SWIPE_ACTION_SPEAK -> speakThreads.execute(listOf(threadId))
                }
            }

        view.undoArchiveIntent
            .autoDispose(view.scope())
            .subscribe {
                markUnarchived.execute(lastArchivedThreadIds.toList())
                lastArchivedThreadIds = listOf()
            }

        view.snackbarButtonIntent
            .withLatestFrom(state) { _, state ->
                when {
                    !state.defaultSms -> view.requestDefaultSms()
                    !state.smsPermission -> view.requestPermissions()
                    !state.contactPermission -> view.requestPermissions()
                    !state.notificationPermission -> {
                        if (prefs.hasAskedForNotificationPermission.get()) {
                            navigator.showPermissions()
                        } else {
                            prefs.hasAskedForNotificationPermission.set(true)
                            view.requestPermissions()
                        }
                    }
                }
            }
            .autoDispose(view.scope())
            .subscribe()
    }

    fun checkIfRead(threadId: Long): Boolean {
        // Implement this method to check if the conversation with threadId is currently read or unread
        return !(conversationRepo.getConversation(threadId)?.unread ?: false)
    }

}
