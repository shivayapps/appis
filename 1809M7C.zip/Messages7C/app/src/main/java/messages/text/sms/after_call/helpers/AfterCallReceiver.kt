package messages.text.sms.after_call.helpers

import android.app.KeyguardManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.provider.Settings
import android.telephony.TelephonyManager
import messages.text.sms.after_call.activity.AfterCallHomeActivity
import java.util.Calendar
import java.util.Date

open class AfterCallReceiver : BroadcastReceiver() {
    private lateinit var mContext: Context

    override fun onReceive(context: Context, intent: Intent) {
        if (!context.afterCallBaseConfig.afterCallEnable) return

        intent.extras?.let { extras ->
            val stateStr = extras.getString(TelephonyManager.EXTRA_STATE)
            val number = extras.getString(TelephonyManager.EXTRA_INCOMING_NUMBER)

            val state = when (stateStr) {
                TelephonyManager.EXTRA_STATE_IDLE -> TelephonyManager.CALL_STATE_IDLE
                TelephonyManager.EXTRA_STATE_OFFHOOK -> TelephonyManager.CALL_STATE_OFFHOOK
                TelephonyManager.EXTRA_STATE_RINGING -> TelephonyManager.CALL_STATE_RINGING
                else -> return
            }

            onCallStateChanged(context, state, number)
        }
    }


    private fun onCallStateChanged(context: Context?, state: Int, number: String?) {
        if (lastState == state) return
        val currentTime = Date()
        when (state) {
            TelephonyManager.CALL_STATE_RINGING -> {
                isIncoming = true
                callStartTimeDate = currentTime
                AfterCallOverlay.afterCallCallNumber = number
                onIncomingCallReceived(context, number)
            }

            TelephonyManager.CALL_STATE_OFFHOOK -> handleOffHookState(context, currentTime, number)
            TelephonyManager.CALL_STATE_IDLE -> handleCallEnded(context, currentTime)
        }
        lastState = state
    }

    private fun handleOffHookState(context: Context?, currentTime: Date, number: String?) {
        if (lastState != TelephonyManager.CALL_STATE_RINGING) {
            isIncoming = false
            if (!isOutgoingCallPickedUp) {
                callStartTimeDate = currentTime
                isOutgoingCallPickedUp = true
            }
            AfterCallOverlay.afterCallCallNumber = number
            onOutgoingCallStarted(context, AfterCallOverlay.afterCallCallNumber)
        } else {
            isIncoming = true
            callStartTimeDate = currentTime
            onIncomingCallAnswered(context, AfterCallOverlay.afterCallCallNumber)
        }
    }

    private fun handleCallEnded(context: Context?, currentTime: Date) {
        when (lastState) {
            TelephonyManager.CALL_STATE_RINGING -> {
                val ringingDuration =
                    currentTime.time - (callStartTimeDate?.time ?: currentTime.time)
                onMissedCall(
                    context,
                    callStartTimeDate?.time!!, AfterCallOverlay.afterCallCallNumber, ringingDuration
                )
            }

            TelephonyManager.CALL_STATE_OFFHOOK -> {
                val talkDuration = currentTime.time - (callStartTimeDate?.time ?: currentTime.time)
                if (isIncoming) {
                    onIncomingCallEnded(
                        context,
                        callStartTimeDate?.time!!,
                        AfterCallOverlay.afterCallCallNumber,
                        talkDuration
                    )
                } else {
                    onOutgoingCallEnded(
                        context,
                        callStartTimeDate?.time!!,
                        AfterCallOverlay.afterCallCallNumber,
                        talkDuration
                    )
                }
            }
        }
        isOutgoingCallPickedUp = false
    }

    private fun handleCallIdleState(context: Context) {
        if (AfterCallOverlay.isWindowShowing) {
            AfterCallOverlay.stopCounter()
            removeOverlayViewIfVisible(context)
        }
//        if (context.afterCallBaseConfig.switchUnknownCallerSaved) {
        val keyguardManager =
            context.getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager
        if (keyguardManager.isKeyguardLocked) {
            AfterCallNotification.startIntentNoti(context)
        } else {
            startAfterCallActivity(context)
        }
//        }
    }

    private fun handleCallRingingState(context: Context, number: String?) {
//        if (!isWindowShowing && checkOverlayPermission(context) && context.afterCallBaseConfig.switchUnknownCallerSaved) {
        if (!AfterCallOverlay.isWindowShowing && checkOverlayPermission(context)) {
            AfterCallOverlay.displayWindowView(context)
        }
    }

    private fun handleCallOffHookState(context: Context, number: String?) {
        if (!AfterCallOverlay.isWindowShowing && checkOverlayPermission(context)) {
            AfterCallOverlay.displayWindowView(context)
            AfterCallOverlay.isWindowShowing = true
        }
    }

    private fun removeOverlayViewIfVisible(context: Context) {
        if (AfterCallOverlay.isWindowShowing && Settings.canDrawOverlays(context)) {
            AfterCallOverlay.windowManager?.removeViewImmediate(AfterCallOverlay.binding!!.root)
            AfterCallOverlay.isWindowShowing = false
        }
    }

    private fun checkOverlayPermission(context: Context): Boolean =
        Settings.canDrawOverlays(context)

    private fun startAfterCallActivity(context: Context) {
        if (!AfterCallUtils.openAfterCall) {
            AfterCallUtils.openAfterCall = true
            val intent = Intent(context, AfterCallHomeActivity::class.java).apply {
                flags =
                    Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TASK
                putExtra("fromwhere", "ser")
            }
            context.startActivity(intent)
        }
    }

    private fun formatTalkDuration(durationMs: Long): String {
        val totalSeconds = durationMs / 1000
        val hours = totalSeconds / 3600
        val minutes = (totalSeconds / 60) % 60
        val seconds = totalSeconds % 60

        return if (totalSeconds < 60) {
            "$totalSeconds second${if (totalSeconds > 1) "s" else ""}"
        } else {
            String.format("%02d:%02d:%02d", hours, minutes, seconds)
        }
    }

    private fun getCurrentTime(time: Long): String {
        val calendar = Calendar.getInstance()
        calendar.timeInMillis = time
        val hours = calendar.get(Calendar.HOUR_OF_DAY)
        val minutes = calendar.get(Calendar.MINUTE)
        val seconds = calendar.get(Calendar.SECOND)

        return String.format("%02d:%02d:%02d", hours, minutes, seconds)
    }

    companion object {
        private const val TAG = "AfterCallPhoneCallReceiver"
        private var lastState = TelephonyManager.CALL_STATE_IDLE
        private var callStartTimeDate: Date? = null
        private var isIncoming = false
        private var isOutgoingCallPickedUp = false
    }

    fun onIncomingCallReceived(ctx: Context?, number: String?) {
        mContext = ctx ?: return
        AfterCallOverlay.afterCallCallNumber = number.orEmpty()

        if (mContext.afterCallBaseConfig.afterCallEnable && mContext.afterCallBaseConfig.isShowCallInfo) {
            handleCallRingingState(mContext, number)
        }
    }

    fun onIncomingCallAnswered(ctx: Context?, number: String?) {
        mContext = ctx ?: return
        AfterCallOverlay.afterCallCallNumber = number.orEmpty()

        if (mContext.afterCallBaseConfig.afterCallEnable && mContext.afterCallBaseConfig.isShowCallInfo) {
            handleCallOffHookState(mContext, number)
        }

        removeOverlayViewIfVisible(ctx)
    }

    fun onIncomingCallEnded(
        ctx: Context?,
        callStartTimeDate: Long,
        number: String?,
        talkDuration: Long
    ) {
        mContext = ctx ?: return
        AfterCallOverlay.afterCallCallNumber = number.orEmpty()
        AfterCallOverlay.afterCallCallType = "Incoming call"
        AfterCallOverlay.callType = "Incoming call"

        if (talkDuration > 0) {
            AfterCallOverlay.callStatus = "Incoming call"
            AfterCallOverlay.cadformattedTime = formatTalkDuration(talkDuration)
        } else {
            AfterCallOverlay.callStatus = "Incoming call"
            AfterCallOverlay.cadformattedTime = ""
        }
        AfterCallOverlay.callTime = getCurrentTime(callStartTimeDate)

        if (mContext.afterCallBaseConfig.afterCallEnable) {
            handleCallIdleState(mContext)
        }
    }

    fun onOutgoingCallStarted(ctx: Context?, number: String?) {
        mContext = ctx ?: return
        AfterCallOverlay.afterCallCallNumber = number.orEmpty()

        if (mContext.afterCallBaseConfig.afterCallEnable && mContext.afterCallBaseConfig.isShowCallInfo) {
            handleCallOffHookState(mContext, number)
        }
    }

    fun onOutgoingCallEnded(
        ctx: Context?,
        callStartTimeDate: Long, number: String?, talkDuration: Long
    ) {
        mContext = ctx ?: return
        AfterCallOverlay.afterCallCallNumber = number.orEmpty()
        AfterCallOverlay.afterCallCallType = "Outgoing call"
        AfterCallOverlay.callType = "Outgoing call"

        if (talkDuration > 0) {
            AfterCallOverlay.callStatus = "Outgoing call : "
            AfterCallOverlay.cadformattedTime = formatTalkDuration(talkDuration)
        } else {
            AfterCallOverlay.callStatus = "No Answer"
            AfterCallOverlay.cadformattedTime = ""
        }
        AfterCallOverlay.callTime = getCurrentTime(callStartTimeDate)

        if (mContext.afterCallBaseConfig.afterCallEnable) {
            handleCallIdleState(mContext)
        }
    }

    fun onMissedCall(
        ctx: Context?,
        callStartTimeDate: Long, number: String?, ringingDuration: Long
    ) {
        mContext = ctx ?: return
        AfterCallOverlay.afterCallCallNumber = number.orEmpty()
        AfterCallOverlay.callType = "Missed call"
        AfterCallOverlay.afterCallCallType = "Missed call"

        if (ringingDuration > 0) {
            AfterCallOverlay.callStatus = "Missed call : "
            AfterCallOverlay.cadformattedTime = formatTalkDuration(ringingDuration)
        } else {
            AfterCallOverlay.callStatus = "Missed call : "
            AfterCallOverlay.cadformattedTime = ""
        }
        AfterCallOverlay.callTime = getCurrentTime(callStartTimeDate)

        if (mContext.afterCallBaseConfig.afterCallEnable) {
            handleCallIdleState(mContext)
        }
    }
}