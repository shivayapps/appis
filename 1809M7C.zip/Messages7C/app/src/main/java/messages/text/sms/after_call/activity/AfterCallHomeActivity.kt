package messages.text.sms.after_call.activity

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.PorterDuff
import android.graphics.drawable.Drawable
import android.net.Uri
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.ImageView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.content.res.AppCompatResources
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.updatePadding
import androidx.core.widget.doOnTextChanged
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.viewpager.widget.ViewPager
import com.bumptech.glide.Glide
import com.google.android.gms.ads.AdSize
import com.google.common.reflect.TypeToken
import com.google.gson.Gson
import dagger.android.AndroidInjection
import io.realm.Realm
import io.realm.Sort
import messages.text.sms.after_call.helpers.AfterCallUtils

import messages.text.sms.after_call.helpers.createBitmapFromText
import messages.text.sms.after_call.helpers.getUserPhotoByPhoneNumber
import messages.text.sms.after_call.helpers.AfterCallOverlay
import messages.text.sms.after_call.helpers.AfterCallOverlay.afterCallCallNumber
import messages.text.sms.after_call.helpers.AfterCallOverlay.afterCallCallType
import messages.text.sms.after_call.helpers.AfterCallOverlay.hasContactPermission
import messages.text.sms.after_call.helpers.AfterCallOverlay.retrieveNameFromDevice

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import messages.text.sms.R
import messages.text.sms.adhelper.BannerAdHelper
import messages.text.sms.after_call.adapter.AfterCallConversationAdapter
import messages.text.sms.after_call.adapter.AfterCallMessageAdapter
import messages.text.sms.after_call.helpers.Notifier
import messages.text.sms.after_call.helpers.Reminder
import messages.text.sms.after_call.adapter.ReminderAdapter
import messages.text.sms.common.CommonPagerAdapter
import messages.text.sms.common.Navigator
import messages.text.sms.common.base.MainBaseThemedActivity
import messages.text.sms.extensions.baseConfig
import messages.text.sms.extensions.beGone
import messages.text.sms.extensions.beVisible
import messages.text.sms.databinding.ActivityAfterCallBinding
import messages.text.sms.feature.main.MainActivity
import messages.text.sms.model.Conversation
import java.io.File
import java.util.Date
import javax.inject.Inject

class AfterCallHomeActivity : MainBaseThemedActivity<ActivityAfterCallBinding>
    (ActivityAfterCallBinding::inflate) {
    lateinit var conversationsAdapter: AfterCallConversationAdapter
    private lateinit var quickReplyAdapter: AfterCallMessageAdapter
    private lateinit var reminderAdapter: ReminderAdapter
    private val notes = mutableListOf<String>()
    private val reminders = mutableListOf<Reminder>()
    private lateinit var notesFile: File

    @Inject
    lateinit var navigator: Navigator

    companion object {
        var isActivityOpen: Boolean = false
        private var instance: AfterCallHomeActivity? = null
        fun finishActivity() {
            instance?.finishAffinity()
        }
    }

    private var savedName: String? = ""
    private var serviceBind = false

    override fun onCreate(savedInstanceState: Bundle?) {
        AndroidInjection.inject(this)
        super.onCreate(savedInstanceState)
        setContentView(binding.root)
        isActivityOpen = true

        instance = this

//        val path = baseConfig.afterCallQuickNotes
//        Log.e("TextQuickReply", "loadNotes.path:$path")
//        notesFile = if (path.isNotEmpty()) {
//            File(path)
//        } else {
//            File(filesDir, "quick_reply_notes.txt").also {
//                baseConfig.afterCallQuickNotes = it.absolutePath
//            }
//        }

        setupPager()

        loadNotes()
        loadDataTab1()
        loadDataTab2()
        loadDataTab3()
        loadDataTab4()

        setUpToolbar()
        setupListeners()

        ViewCompat.setOnApplyWindowInsetsListener(binding.root) { v, windowInsets ->
//            val bars = windowInsets.getInsets(WindowInsetsCompat.Type.ime())
//            Log.e("AfterCallHome", "bars.top:${bars.top}")
//            Log.e("AfterCallHome", "bars.bottom:${bars.bottom}")
//            Log.e("AfterCallHome", "bars.left:${bars.left}")
//            Log.e("AfterCallHome", "bars.right:${bars.right}")
            val imeVisible = windowInsets.isVisible(WindowInsetsCompat.Type.ime())
            if (imeVisible) onKeyboardOpen()
            else onKeyboardClose()
            windowInsets
        }

        try {
            val notificationManager = NotificationManagerCompat.from(this)
            notificationManager.cancel(298)
        } catch (_: Exception) {
        }

        loadAds()
    }

    fun loadAds() {
        BannerAdHelper.showBanner(
            this,
            binding.adsView,
            baseConfig.bannerAdsId,
            { isLoaded, message ->

            }, AdSize.MEDIUM_RECTANGLE
        )
    }

    private fun loadNotes() {
        Log.e("AfterCallHome", "loadNotes")
        val path = baseConfig.afterCallQuickNotes
        notesFile = if (path.isNotEmpty()) {
            File(path)
        } else {
            File(filesDir, "after_call_reply.txt").also {
                baseConfig.afterCallQuickNotes = it.absolutePath
            }
        }

        notes.clear()

        if (!notesFile.exists() || notesFile.length() == 0L) {
            notes.addAll(
                listOf(
                    "Sorry, I can’t talk right now",
                    "Can I call you later?",
                    "I’m on my way",
                    "Please Call me back"
                )
            )
            saveNotes() // Persist defaults only once
        } else {
            notes.addAll(notesFile.readLines())
            Log.e("AfterCallHome", "loadNotes.notes:${notes.size}")
        }
    }

    private fun loadDataTab1() {
        //homeTab
        binding.homeTab.newMessage.setOnClickListener {
//            val contentIntent = Intent(this@AfterCallHomeActivity, MainActivity::class.java)
//            startActivity(contentIntent)
            navigator.showCompose()
            finishActivity()
        }
        binding.homeTab.scheduleMessage.setOnClickListener {
            navigator.showCompose(mode = "scheduling")
            finishActivity()
//            val contentIntent = Intent(this@AfterCallHomeActivity, MainActivity::class.java)
//            startActivity(contentIntent)

        }
        binding.homeTab.allMessage.setOnClickListener {
            val contentIntent = Intent(this@AfterCallHomeActivity, MainActivity::class.java)
            startActivity(contentIntent)
            finishActivity()
        }
    }

    private fun loadDataTab2() {
        //messageTab
        quickReplyAdapter =
            AfterCallMessageAdapter(this@AfterCallHomeActivity, notes, onClick = { pos ->

            }, onSend = { pos ->
                sendSms(afterCallCallNumber, notes[pos])
                finishActivity()
            }, onSave = { pos, text ->
                notes.add(text)
                quickReplyAdapter.notifyItemInserted(pos)
                saveNotes()
            })
        binding.messageTab.recyclerView.apply {
            layoutManager = LinearLayoutManager(this@AfterCallHomeActivity)
            adapter = quickReplyAdapter
        }
    }


    lateinit var reminderColorsList: List<ImageView>
    private fun loadDataTab3() {
        // Load reminders from SharedPreferences

        var selectedColor: String = "#E45D49" // Default color

        // Color list
        val colorList = listOf(
            "#E45D49",
            "#95CE1F",
            "#FEC107",
            "#FD9637",
            "#4BB7C4",
            "#3DA1FF",
            "#B956E5"
        )

        // Color ImageViews
        reminderColorsList = listOf(
            binding.reminderTab.ivColor1,
            binding.reminderTab.ivColor2,
            binding.reminderTab.ivColor3,
            binding.reminderTab.ivColor4,
            binding.reminderTab.ivColor5,
            binding.reminderTab.ivColor6,
            binding.reminderTab.ivColor7,
        )

        // Set colors to ImageViews and implement click listeners
        reminderColorsList.forEachIndexed { index, imageView ->
            // Set the color
            try {
                val colorInt = Color.parseColor(colorList[index])
                imageView.setColorFilter(colorInt, PorterDuff.Mode.SRC_IN)
            } catch (e: IllegalArgumentException) {
                // Handle invalid color
            }

            // Set click listener
            imageView.setOnClickListener {
                // Clear previous selection
                reminderColorsList.forEach {
                    it.background = null
                }

                // Set selected color
                selectedColor = colorList[index]

                // Apply border background to selected
                imageView.background = ContextCompat.getDrawable(
                    this@AfterCallHomeActivity,
                    R.drawable.bg_border_round
                )
            }
        }

        // Set default selection (first color)
        reminderColorsList.firstOrNull()?.let {
            it.background = ContextCompat.getDrawable(
                this@AfterCallHomeActivity,
                R.drawable.bg_border_round
            )
        }

        reminders.clear()
        reminders.addAll(loadRemindersFromPrefs())
        updateEmptyReminderViewVisibility()
        //reminderTab
        reminderAdapter = ReminderAdapter(
            this@AfterCallHomeActivity,
            reminders,
            onDelete = { pos ->
                if (pos in reminders.indices) {
                    reminders.removeAt(pos)
                    reminderAdapter.notifyItemRemoved(pos)
                    reminderAdapter.notifyItemRangeChanged(pos, reminders.size)
                    saveRemindersToPrefs(reminders)
                    updateEmptyReminderViewVisibility()
                }
            }
        )

        binding.reminderTab.recyclerView.apply {
            layoutManager = LinearLayoutManager(this@AfterCallHomeActivity)
            adapter = reminderAdapter // Fixed: was using quickReplyAdapter
        }

        var selectedDate: Date = Date()

        binding.reminderTab.add.setOnClickListener {
            binding.reminderTab.clEditView.beVisible()
            binding.reminderTab.clDataView.beGone()
            binding.reminderTab.add.beGone()
            binding.reminderTab.editTextMessage.setText("") // Clear previous input
        }

        binding.reminderTab.btnNegative.setOnClickListener {
            binding.reminderTab.clEditView.beGone()
            binding.reminderTab.clDataView.beVisible()
            binding.reminderTab.add.beVisible()
        }
        binding.reminderTab.editTextMessage.doOnTextChanged { text, start, before, count ->
            val msg = text.toString().trim()
            if (msg.isEmpty()) {
                binding.reminderTab.btnPositive.alpha = 0.5f
//                binding.btnNegative.alpha = 0.5f
            } else {
                binding.reminderTab.btnPositive.alpha = 1.0f
//                binding.btnNegative.alpha = 1.0f
            }
        }

        binding.reminderTab.btnPositive.setOnClickListener {
            val message = binding.reminderTab.editTextMessage.text.toString().trim()
            if (message.isNotEmpty()) {
                // Create reminder with selected color
                val reminder = Reminder(
                    message = message,
                    date = selectedDate.time, // Store as timestamp
                    color = selectedColor,
                    id = System.currentTimeMillis()
                )

                // Add to list
                reminders.add(reminder)
                reminderAdapter.notifyItemInserted(reminders.size - 1)
                reminderAdapter.notifyItemRangeChanged(0, reminders.size)

                // Save to SharedPreferences
                saveRemindersToPrefs(reminders)

                // Schedule notification
                Notifier.scheduleWorker(
                    context = this@AfterCallHomeActivity,
                    message = message,
                    date = selectedDate
                )

                // Hide edit view
                binding.reminderTab.clEditView.beGone()
                binding.reminderTab.clDataView.beVisible()
                binding.reminderTab.add.beVisible()
                updateEmptyReminderViewVisibility()

                // Show success message
                Toast.makeText(this, "Reminder added successfully", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "Please enter a message", Toast.LENGTH_SHORT).show()
            }
        }

        binding.reminderTab.dateAndTimePicker.addOnDateChangedListener { dateStr, date ->
            selectedDate = date
        }
    }

    private fun updateEmptyReminderViewVisibility() {
        if (reminders.isNotEmpty()) { // Size 1 if you have an edit view as last item
            binding.reminderTab.recyclerView.beVisible()
            binding.reminderTab.emptyView.beGone()
        } else {
            binding.reminderTab.recyclerView.beGone()
            binding.reminderTab.emptyView.beVisible()
        }
    }

    // Save reminders to SharedPreferences
    private fun saveRemindersToPrefs(reminders: List<Reminder>) {
        val prefs = getSharedPreferences("reminder_prefs", MODE_PRIVATE)
        val editor = prefs.edit()

        // Convert reminders to JSON
        val gson = Gson()
        val json = gson.toJson(reminders)
        editor.putString("reminders_list", json)
        editor.apply()
    }

    // Load reminders from SharedPreferences
    private fun loadRemindersFromPrefs(): MutableList<Reminder> {
        val prefs = getSharedPreferences("reminder_prefs", MODE_PRIVATE)
        val json = prefs.getString("reminders_list", null)

        return if (json != null) {
            val gson = Gson()
            val type = object : TypeToken<MutableList<Reminder>>() {}.type
            gson.fromJson(json, type) ?: mutableListOf()
        } else {
            mutableListOf()
        }
    }

    fun onKeyboardOpen() {
        Log.e("AfterCallHome", "onKeyboardOpen")
        binding.adsView.beGone()
    }

    fun onKeyboardClose() {
        Log.e("AfterCallHome", "onKeyboardClose")
        binding.adsView.beVisible()
    }


    private fun loadDataTab4() {
        //moreTab
        binding.moreTab.newMessage.setOnClickListener {
//            sendSms(afterCallCallNumber, "")
            navigator.showCompose()
        }
        binding.moreTab.sendMail.setOnClickListener {
            try {
                val intent = Intent(Intent.ACTION_SENDTO).apply {
                    data = Uri.parse("mailto:")
                }
                startActivity(intent)
            } catch (e: Exception) {
                e.printStackTrace()
                Toast.makeText(
                    this@AfterCallHomeActivity,
                    "Unable to open the create contact screen.",
                    Toast.LENGTH_SHORT
                ).show()
            }
        }

        binding.moreTab.calendar.setOnClickListener {
            startActivity(
                Intent(Intent.ACTION_MAIN).apply {
                    addCategory(Intent.CATEGORY_APP_CALENDAR)
                }
            )
        }

        binding.moreTab.web.setOnClickListener {
            startActivity(
                Intent(
                    Intent.ACTION_VIEW,
                    Uri.parse("https://www.example.com")
                )
            )
        }

    }

    private fun saveNotes() {

        notesFile.parentFile?.mkdirs()
        notesFile.printWriter().use { writer ->
            notes.forEach(writer::println)
        }
    }

    override fun onStart() {
        super.onStart()
    }

    override fun onStop() {
        super.onStop()
    }

//    override fun onBackPressed() {
//        super.onBackPressed()
//        finishAffinity()
//    }


    override fun onDestroy() {
        super.onDestroy()
        isActivityOpen = false
        instance = null
        AfterCallUtils.openAfterCall = false
        savedName = ""
        afterCallCallNumber = ""
    }

    private fun setupPager() {
        val commonPagerAdapter = CommonPagerAdapter()
        commonPagerAdapter.insertViewId(R.id.homeTab)
        commonPagerAdapter.insertViewId(R.id.messageTab)
        commonPagerAdapter.insertViewId(R.id.reminderTab)
        commonPagerAdapter.insertViewId(R.id.moreTab)
        binding.viewPager.offscreenPageLimit = 4
        binding.viewPager.adapter = commonPagerAdapter

        updateTabSelection(0)

        // Button click listeners
        binding.homeButton.setOnClickListener {
            binding.viewPager.currentItem = 0
        }
        binding.messageButton.setOnClickListener {
            binding.viewPager.currentItem = 1
        }
        binding.reminderButton.setOnClickListener {
            binding.viewPager.currentItem = 2
        }
        binding.moreButton.setOnClickListener {
            binding.viewPager.currentItem = 3
        }

        binding.viewPager.addOnPageChangeListener(object : ViewPager.OnPageChangeListener {
            override fun onPageScrolled(
                position: Int,
                positionOffset: Float,
                positionOffsetPixels: Int,
            ) {
            }

            override fun onPageSelected(position: Int) {
                updateTabSelection(position)
            }

            override fun onPageScrollStateChanged(state: Int) {
            }
        })
    }

    private fun updateTabSelection(position: Int) {
        // Hide all selected indicators
        binding.homeSelected.beGone()
        binding.messageSelected.beGone()
        binding.reminderSelected.beGone()
        binding.moreSelected.beGone()

        // Show selected indicator based on position
        when (position) {
            0 -> {
                binding.homeSelected.beVisible()
                // Optional: Update button colors
                updateButtonColors(0)
            }

            1 -> {
                binding.messageSelected.beVisible()
                updateButtonColors(1)
            }

            2 -> {
                binding.reminderSelected.beVisible()
                updateButtonColors(2)
            }

            3 -> {
                binding.moreSelected.beVisible()
                updateButtonColors(3)
            }
        }
    }

    private fun updateButtonColors(selectedPosition: Int) {

    }

//    private fun setupPager() {
//        val conversations = getConversationsSnapshot(prefs.unreadAtTop.get())
//        conversationsAdapter =
//            AfterCallConversationAdapter(this@AfterCallHomeActivity, conversations, { threadId ->
//                val contentIntent = Intent(this@AfterCallHomeActivity, ComposeActivity::class.java)
//                contentIntent.putExtra("threadId", threadId)
//                startActivity(contentIntent)
//            })
//        binding.recyclerView.apply {
//            adapter = conversationsAdapter
//        }
//    }

    fun getConversationsSnapshot(unreadAtTop: Boolean): List<Conversation> {
        val sortOrder: MutableList<String> = arrayListOf("pinned", "draft", "lastMessage.date")
        val sortDirections: MutableList<Sort> =
            arrayListOf(Sort.DESCENDING, Sort.DESCENDING, Sort.DESCENDING)

        if (unreadAtTop) {
            sortOrder.add(0, "lastMessage.read")
            sortDirections.add(0, Sort.ASCENDING)
        }

        return Realm.getDefaultInstance().use { realm ->
            realm.refresh()
            realm.where(Conversation::class.java)
                .notEqualTo("id", 0L)
                .equalTo("archived", false)
                .equalTo("blocked", false)
                .equalTo("isPrivate", false)
                .isNotEmpty("recipients")
                .beginGroup()
                .isNotNull("lastMessage")
                .or()
                .isNotEmpty("draft")
                .endGroup()
                .sort(sortOrder.toTypedArray(), sortDirections.toTypedArray())
                .findAll()
                .let(realm::copyFromRealm)
        }
    }

    private fun setupListeners() {
        binding.icClose.setOnClickListener {
            finish()
        }
//        binding.ivBack.setOnClickListener { onBackPressedDispatcher.onBackPressed() }
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                isEnabled = false
//                onBackPressedDispatcher.onBackPressed()
                finishAffinity()
            }
        })

        binding.icAppIcon.setOnClickListener {
            startLauncherScreenFromAfterCall()
        }

//        binding.contactButton.setOnClickListener {
//            if (afterCallCallNumber?.isNotEmpty() == true || !afterCallCallNumber.equals(
//                    resources.getString(
//                        R.string.after_call_private_number
//                    )
//                )
//            ) {
//                try {
//                    val intent = Intent(Intent.ACTION_DIAL)
//                    intent.setData(Uri.parse("tel:$afterCallCallNumber"))
//                    startActivity(intent)
//                } catch (_: Exception) {
//                }
//            } else {
//                try {
//                    val intent = Intent(Intent.ACTION_DIAL)
//                    intent.setData(Uri.parse("tel:"))
//                    startActivity(intent)
//                } catch (_: Exception) {
//                }
//            }
//            finish()
//        }
//        binding.mailButton.setOnClickListener {
//            val context = binding.mailButton?.context
//            if (context != null) {
//
//                try {
//                    val intent = Intent(Intent.ACTION_SENDTO).apply {
//                        data = Uri.parse("mailto:")
//                    }
//                    startActivity(intent)
//                } catch (e: Exception) {
//                    e.printStackTrace()
//                    Toast.makeText(
//                        context,
//                        "Unable to open the create contact screen.",
//                        Toast.LENGTH_SHORT
//                    ).show()
//                }
////                    }
//            }
//        }
//        binding.newMessageButton.setOnClickListener {
//            sendSms(afterCallCallNumber, "")
//        }

//        try {
//            if (AfterCallUtils.getLogoFromPackageManager(this@AfterCallHomeActivity) == null) {
//                binding?.icAppIcon?.visibility = View.GONE
//            } else {
//                binding?.icAppIcon?.setImageDrawable(
//                    AfterCallUtils.getLogoFromPackageManager(
//                        this@AfterCallHomeActivity
//                    )
//                )
//                binding?.icAppIcon?.visibility = View.VISIBLE
//            }
//
//        } catch (e: Exception) {
//            binding?.icAppIcon?.visibility = View.GONE
//        }
    }

    fun sendSms(afterCallCallNumber: String?, selectedItem: String) {
        var formattedCallNumber = afterCallCallNumber

        // Check if the call number is empty or equals a specific string and reset if true
        if (formattedCallNumber?.isEmpty() == true || formattedCallNumber == resources.getString(R.string.after_call_private_number)) {
            formattedCallNumber = ""
        }

        try {
            val intent = Intent(Intent.ACTION_SENDTO).apply {
                data = Uri.parse("smsto:$formattedCallNumber")
                putExtra("sms_body", selectedItem)
            }
            // Start the activity and finish the current one
            startActivity(intent)
            finish()
        } catch (e: Exception) {
            // Handle the error if the messaging app cannot be opened
            Toast.makeText(
                this@AfterCallHomeActivity,
                "Unable to open messaging app",
                Toast.LENGTH_SHORT
            ).show()
        }
    }


    private fun startLauncherScreenFromAfterCall() {
        try {
            val pm = packageManager
            val intent = pm.getLaunchIntentForPackage(application.packageName)
            intent?.flags = Intent.FLAG_ACTIVITY_CLEAR_TOP
            intent?.flags = Intent.FLAG_ACTIVITY_CLEAR_TASK
            intent?.flags = Intent.FLAG_ACTIVITY_NEW_TASK
            startActivity(intent)
            finish()
        } catch (e: Exception) {
            Log.e("Exception", "" + e.message)
        }
    }

    private fun expandMainViews() {
        binding.callerInfoDataMain.visibility = View.VISIBLE
    }


    private fun setUpToolbar() {
        if (afterCallCallNumber?.isNotEmpty() == true) {
            lifecycleScope.launch(Dispatchers.IO) {
                savedName = retrieveNameFromDevice(this@AfterCallHomeActivity, afterCallCallNumber)

                withContext(Dispatchers.Main) {
                    binding.mTVHeader.text = savedName ?: afterCallCallNumber
                }
            }
        } else {
            binding.mTVHeader.text = resources.getString(R.string.after_call_private_number)
        }

        try {
            binding.tvCallTime.text = AfterCallOverlay.callTime
        } catch (_: Exception) {
        }
        try {
            binding.tvCallStatus.text = AfterCallOverlay.callStatus
        } catch (_: Exception) {
        }
        try {
            binding.tvDuration.text = AfterCallOverlay.cadformattedTime
        } catch (_: Exception) {
        }


//        when (afterCallCallType.lowercase()) {
//            "outgoing call" -> {
//                binding.icCallIcon.setImageResource(R.drawable.ic_outgoing_call)
//            }
//
//            "incoming call" -> {
//                binding.icCallIcon.setImageResource(R.drawable.ic_incoming_call)
//
//            }
//
//            "missed call" -> {
//                binding.icCallIcon.setImageResource(R.drawable.ic_missed_call)
//
//            }
//        }

        if (hasContactPermission(this)) {
            lifecycleScope.launch(Dispatchers.IO) {
                val mUserImageBitmap =
                    getUserPhotoByPhoneNumber(afterCallCallNumber, this@AfterCallHomeActivity)

                withContext(Dispatchers.Main) {
                    if (mUserImageBitmap != null) {
                        Glide.with(this@AfterCallHomeActivity).load(mUserImageBitmap)
                            .placeholder(R.drawable.ic_after_call_user_new)
                            .error(R.drawable.ic_after_call_user_new)
                            .into(binding.mIVUser)
                    } else {
                        if (!savedName.isNullOrEmpty()) {
                            val firstChar = savedName!!.first().toString()
                            val bitmap = createBitmapFromText(firstChar)
                            binding.mIVUser.setImageBitmap(bitmap)
                        } else {
                            binding.mIVUser.setImageDrawable(
                                AppCompatResources.getDrawable(
                                    this@AfterCallHomeActivity, R.drawable.ic_after_call_user_new
                                )
                            )
                        }
                    }
                }
            }
        } else {
            binding.mIVUser.setImageDrawable(
                AppCompatResources.getDrawable(
                    this, R.drawable.ic_after_call_user_new
                )
            )
        }
    }

    override fun onResume() {
        super.onResume()
    }

    fun getDefaultAppIcon(context: Context): Drawable? {
        return try {
            val packageManager = context.packageManager
            // Get application info for the provided package name
            val applicationInfo = packageManager.getApplicationInfo(context.packageName, 0)
            // Get the default app icon
            packageManager.getApplicationIcon(applicationInfo)
        } catch (e: PackageManager.NameNotFoundException) {
            e.printStackTrace()
            null // Return null if the package is not found
        }
    }

    fun getAppName(context: Context): String {
        return try {
            val packageManager = context.packageManager
            val applicationInfo = context.applicationInfo
            packageManager.getApplicationLabel(applicationInfo).toString()
        } catch (e: Exception) {
            e.printStackTrace()
            "Unknown App Name" // Fallback in case of an error
        }
    }

}