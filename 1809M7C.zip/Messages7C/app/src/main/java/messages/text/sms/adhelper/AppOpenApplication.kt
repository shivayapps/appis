package messages.text.sms.adhelper


import android.app.Activity
import android.app.ActivityManager
import android.content.Context
import android.os.Build
import android.os.Process
import android.os.SystemClock
import android.util.Log
import android.webkit.WebView
import androidx.annotation.Keep
import androidx.lifecycle.DefaultLifecycleObserver
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.ProcessLifecycleOwner
import androidx.multidex.MultiDex
import androidx.multidex.MultiDexApplication
import com.google.android.gms.ads.AdActivity
import com.google.android.gms.ads.MobileAds
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Keep
open class AppOpenApplication : MultiDexApplication(), DefaultLifecycleObserver {

    companion object {
    }

    private val TAG: String = "ADCONFIG_Application"

    // variable to track pause event time
    private var isPause: Boolean = false
    private var mLastPauseTime: Long = 0
    private val mMinPauseDuration = 100

    private var mOpenAdManager: OpenAdManager? = null

//    private val mTestDeviceIds: ArrayList<String> = ArrayList()

    @Keep
    interface AppLifecycleListener {
        fun onResumeApp(fCurrentActivity: Activity): Boolean
        fun onAppOpenCreatedEvent(fCurrentActivity: Activity)
    }

    var mAppLifecycleListener: AppLifecycleListener? = null

    override fun attachBaseContext(base: Context?) {
        super.attachBaseContext(base)
        MultiDex.install(this)
    }

    override fun onCreate() {
        super<MultiDexApplication>.onCreate()
        ProcessLifecycleOwner.get().lifecycle.addObserver(this)

        mOpenAdManager = OpenAdManager(this@AppOpenApplication)

    }

    fun setAppLifecycleListener(fAppLifecycleListener: AppLifecycleListener) {
        this.mAppLifecycleListener = fAppLifecycleListener
    }

    fun initMobileAds() {
        setMobileAds()
    }


    private fun setMobileAds() {
        CoroutineScope(Dispatchers.IO).launch {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                val processName = getProcessName(applicationContext)
                if (processName != null && packageName != processName) {
                    try {
                        WebView.setDataDirectorySuffix(processName)
                    } catch (e: Exception) {
                        Log.i(TAG, "WebView Exception:$e")
                    }
                    MobileAds.initialize(applicationContext) {
                        Log.d("MobileAds", "onInitializationComplete.1")
                    }
                } else {
                    MobileAds.initialize(applicationContext) {
                        Log.d("MobileAds", "onInitializationComplete.2")
                    }
                }
            } else {
                MobileAds.initialize(applicationContext) {
                    Log.d("MobileAds", "onInitializationComplete.3")
                }
            }
        }
    }

    private fun getProcessName(context: Context?): String? {
        if (context == null) return null

        val manager = context.getSystemService(ACTIVITY_SERVICE) as? ActivityManager
        val runningProcesses = manager?.runningAppProcesses ?: return ""

        for (processInfo in runningProcesses) {
            if (processInfo.pid == Process.myPid()) {
                return processInfo.processName
            }
        }
        return ""
    }

    //<editor-fold desc="For Application Lifecycle">
    override fun onPause(owner: LifecycleOwner) {
        super.onPause(owner)
        Log.i(TAG, "onPause: ")
        mLastPauseTime = SystemClock.elapsedRealtime()
        isPause = true

    }

    override fun onStart(owner: LifecycleOwner) {
        super.onStart(owner)
        Log.i(TAG, "onStart: onAppForegrounded: ")
        AdUtil.isAppForeground = true
        if (AdUtil.isAppForeground && !OpenAdHelper.isAdAvailable()) {
            mOpenAdManager?.let {
                it.mCurrentActivity?.let { act ->
                    mAppLifecycleListener?.let { lListener ->
//                        Handler(Looper.getMainLooper()).postDelayed({
                        if (!act.isDestroyed && !act.isFinishing) {
                            if (lListener.onResumeApp(act)) {
                                Log.i("loadAd", "loadAd.002  1-  ${AdUtil.isSystemDialogOpen}")
                                OpenAdHelper.loadOpenAd(act)
                            }
                        }
//                        }, 500)
                    }
                }
            }
        }

    }

    override fun onStop(owner: LifecycleOwner) {
        super.onStop(owner)
        Log.i(TAG, "onStop: onAppBackgrounded: ")

        if (SystemClock.elapsedRealtime() - mLastPauseTime < mMinPauseDuration) {
            Log.i(TAG, "onStop: Reset Pause Flag")
            if (isPause) {
                isPause = false
            }
        }
        if (AdUtil.isAppForeground && !OpenAdHelper.isAdAvailable()) {
            mOpenAdManager?.let {
                it.mCurrentActivity?.let { act ->
                    mAppLifecycleListener?.let { lListener ->
                        if (!act.isDestroyed && !act.isFinishing) {
                            if (lListener.onResumeApp(act)) {
                                Log.i("loadAd", "loadAd.001")
                                OpenAdHelper.checkAndLoadAppOpen(act)
                            }
                        }
                    }
                }
            }
        }
        AdUtil.isAppForeground = false
    }

    override fun onResume(owner: LifecycleOwner) {
        super.onResume(owner)
        Log.i(TAG, "onResume")
        mAppLifecycleListener?.let { lListener ->
            mOpenAdManager?.let { lOpenAdManager ->
                Log.i(TAG, "onResume, isAppForeground${AdUtil.isAppForeground},isPause-${isPause}")
//                if (isAppForeground && !isPause) {
                if (AdUtil.isAppForeground) {
                    lOpenAdManager.mCurrentActivity?.let { fCurrentActivity ->
                        if (fCurrentActivity !is AdActivity) {
                            Log.i("loadAd", "fCurrentActivity:${fCurrentActivity.localClassName}")
                            if (AdUtil.isAnyAdShowing) {
                                AdUtil.isAnyAdShowing = false
                            } else {
                                if (!AdUtil.isInterstitialAdShow) {
                                    if (lListener.onResumeApp(fCurrentActivity)) {
                                        Log.i(TAG, "onResume 007")
//                                        lOpenAdManager.showOpenAd()
                                        mAppLifecycleListener?.onAppOpenCreatedEvent(
                                            fCurrentActivity
                                        )
                                    }
                                }
                            }
                        }
                    }
                }

                if (isPause) {
                    isPause = false
                }
            }
        }
    }
}