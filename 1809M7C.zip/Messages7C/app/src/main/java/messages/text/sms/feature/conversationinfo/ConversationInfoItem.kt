package messages.text.sms.feature.conversationinfo

import messages.text.sms.model.MmsPart
import messages.text.sms.model.Recipient
import io.realm.RealmList


sealed class ConversationInfoItem {
    data class ConversationInfoRecipient(val value: Recipient) : ConversationInfoItem()
    data class ConversationInfoMedia(val value: MmsPart) : ConversationInfoItem()
}
//sealed class ConversationInfoItem {
//    data class ConversationInfoRecipient(val value: Recipient) : ConversationInfoItem()
//    data class ConversationInfoMedia(val value: MmsPart) : ConversationInfoItem()
//    data class ConversationInfoSettings(
//        val name: String,
//        val recipients: RealmList<Recipient>,
//        val archived: Boolean,
//        val blocked: Boolean
//    ) : ConversationInfoItem()
//}
