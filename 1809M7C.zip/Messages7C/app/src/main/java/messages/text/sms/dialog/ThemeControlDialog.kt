package messages.text.sms.dialog

import android.app.Activity
import android.app.Dialog
import android.content.Context
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.view.Gravity
import android.view.Window
import android.view.WindowManager
import io.reactivex.subjects.PublishSubject
import io.reactivex.subjects.Subject
import messages.text.sms.databinding.DialogCustomThemeBinding
import messages.text.sms.injection.appComponent
import javax.inject.Inject


class ThemeControlDialog @Inject constructor(private val context: Context) {

    init {
        appComponent.inject(this)
    }

    var selectedItem: Int? = 0
    var tempSelectedItem: Int? = 0
    val menuItemClicks: Subject<Int> = PublishSubject.create()

    private lateinit var dialog: Dialog
    private lateinit var binding: DialogCustomThemeBinding

    fun show(activity: Activity) {
        dialog = Dialog(activity)

        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.window?.apply {
            setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            setGravity(Gravity.CENTER)
            setDimAmount(0.8f)
            attributes?.windowAnimations = android.R.style.Animation_Dialog
            setLayout(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.WRAP_CONTENT
            )
        }

//        binding = DialogCustomThemeBinding.inflate( LayoutInflater.from(context))
        binding = DialogCustomThemeBinding.inflate(activity.layoutInflater)
        dialog.setContentView(binding.root)

        dialog.window?.setLayout(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.WRAP_CONTENT
        )

        initView()

        dialog.show()
    }

    fun dismiss() {
        if (::dialog.isInitialized && dialog.isShowing) {
            dialog.dismiss()
        }
    }

    private fun updateSelection(selected: Int) {
        tempSelectedItem = selected

        binding.system.checked = selected == 0
        binding.light.checked = selected == 1
        binding.dark.checked = selected == 2
    }

    private fun initView() {
        updateSelection(selectedItem ?: 0)

        binding.system.setOnClickListener {
            updateSelection(0)
        }

        binding.light.setOnClickListener {
            updateSelection(1)
        }

        binding.dark.setOnClickListener {
            updateSelection(2)
        }

        binding.btnPositive.setOnClickListener {
            selectedItem = tempSelectedItem
            menuItemClicks.onNext(tempSelectedItem ?: 0)
            dismiss()
        }
        binding.ivClose.setOnClickListener {
//            selectedItem = tempSelectedItem
//            menuItemClicks.onNext(tempSelectedItem ?: 0)
            dismiss()
        }
    }
}
