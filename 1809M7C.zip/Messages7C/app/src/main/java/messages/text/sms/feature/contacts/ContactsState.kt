
package messages.text.sms.feature.contacts

import messages.text.sms.feature.compose.editing.ComposeItem
import messages.text.sms.model.Contact

data class ContactsState(
    val query: String = "",
    val composeItems: List<ComposeItem> = ArrayList(),
    val selectedContact: Contact? = null // For phone number picker
)
