package messages.text.sms.feature.compose.editing

import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import messages.text.sms.R
import java.util.Collections

class QuickReplyAdapter(
    private val items: List<String>,
    val onDrag: (RecyclerView.ViewHolder) -> Unit,
    private val onDelete: (Int) -> Unit
) : RecyclerView.Adapter<QuickReplyAdapter.VH>() {
    class VH(view: View) : RecyclerView.ViewHolder(view) {
        val text: TextView = view.findViewById(R.id.title)
        val dragView: ImageView = view.findViewById(R.id.dragView)
        val delete: ImageView = view.findViewById(R.id.delete)
    }

    fun moveItem(from: Int, to: Int) {
        Collections.swap(items, from, to)
        notifyItemMoved(from, to)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
        VH(
            LayoutInflater.from(parent.context)
                .inflate(R.layout.list_item_text_drag, parent, false)
        )

    override fun onBindViewHolder(holder: VH, position: Int) {
        holder.text.text = items[position]
        holder.dragView.setOnTouchListener { _, event ->
            if (event.actionMasked == MotionEvent.ACTION_DOWN) {
                if (items.size > 1) onDrag.invoke(holder)
            }
            false
        }
        holder.delete.setOnClickListener {
            val pos = holder.bindingAdapterPosition
            if (pos != RecyclerView.NO_POSITION) {
                onDelete(pos)
            }
        }
    }

    override fun getItemCount() = items.size
}