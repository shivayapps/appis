
package messages.text.sms.feature.blocking.numbers

import messages.text.sms.common.base.MyViewContract
import io.reactivex.Observable

interface BlockedNumbersView : MyViewContract<BlockedNumbersState> {

    fun unblockAddress(): Observable<Long>
    fun addAddress(): Observable<*>
    fun saveAddress(): Observable<String>

    fun showAddDialog()

}
