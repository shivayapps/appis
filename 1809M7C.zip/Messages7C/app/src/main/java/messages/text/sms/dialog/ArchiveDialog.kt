package messages.text.sms.dialog

import android.app.Activity
import android.content.Context
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.view.Gravity
import android.view.Window
import android.view.WindowManager
import androidx.appcompat.app.AlertDialog
import messages.text.sms.R
import messages.text.sms.repository.ConversationRepository
import messages.text.sms.util.Preferences
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.MainScope
import messages.text.sms.databinding.DialogArchiveBinding
import messages.text.sms.interactor.MarkArchived
import messages.text.sms.interactor.MarkUnarchived
import javax.inject.Inject

// TODO: Once we have a custom dialog based on conductor, turn this into a controller
class ArchiveDialog @Inject constructor(
    private val context: Context,
    private val conversationRepo: ConversationRepository,
    private val prefs: Preferences,
    private val markArchived: MarkArchived,
    private val markUnarchived: MarkUnarchived,
) {

    fun show(activity: Activity, conversationIds: List<Long>, archive: Boolean) = GlobalScope.launch {
//        val addresses = conversationIds.toLongArray()
//            .let { conversationRepo.getConversations(*it) }
//            .flatMap { conversation -> conversation.recipients }
//            .map { it.address }
//            .distinct()
//        if (addresses.isEmpty()) {
//            return@launch
//        }

        showDialog(activity, conversationIds, archive)
    }
    private suspend fun showDialog(
        activity: Activity,
        conversationIds: List<Long>,
        archive: Boolean
    ) = withContext(MainScope().coroutineContext) {

        // Otherwise, show a dialog asking the user if they want to be directed to the external
        // blocking manager
        val binding = DialogArchiveBinding.inflate(activity.layoutInflater)

        if (archive) {
            binding.tvTitle.setText(R.string.archive_title)
            binding.btnPositive.setText(R.string.archive_title)
        } else {
            binding.tvTitle.setText(R.string.unarchive_title)
            binding.btnPositive.setText(R.string.unarchive_title)
        }

        binding.tvMessage.setText(
            if (archive) {
                R.string.archive_subtitle
            } else {
                R.string.unarchive_subtitle
            }
        )

        val dialog = AlertDialog.Builder(activity)
            .setView(binding.root)
            .setCancelable(true)
            .create()

        binding.btnPositive.setOnClickListener {
            if (archive) {
                markArchived.execute(conversationIds)
            } else {
                markUnarchived.execute(conversationIds)
            }
            dialog.dismiss()
        }

        binding.ivClose.setOnClickListener {
            dialog.dismiss()
        }
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.window?.apply {
            setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            setGravity(Gravity.CENTER)
            setDimAmount(0.8f)
            attributes?.windowAnimations = android.R.style.Animation_Dialog
            setLayout(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.WRAP_CONTENT
            )
        }
        dialog.show()

    }


}
