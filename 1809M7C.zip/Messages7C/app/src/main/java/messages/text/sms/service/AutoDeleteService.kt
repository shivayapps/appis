package messages.text.sms.service

import android.annotation.SuppressLint
import android.app.job.JobInfo
import android.app.job.JobParameters
import android.app.job.JobService
import android.content.ComponentName
import android.content.Context
import dagger.android.AndroidInjection
import messages.text.sms.extensions.jobScheduler
import messages.text.sms.interactor.DeleteOldMessages
import io.reactivex.disposables.CompositeDisposable
import io.reactivex.rxkotlin.plusAssign
import android.util.Log
import java.util.concurrent.TimeUnit
import javax.inject.Inject

class AutoDeleteService : JobService() {

    companion object {
        private const val JobId = 8120235

        @SuppressLint("MissingPermission") // Added in [presentation]'s AndroidManifest.xml
        fun scheduleJob(context: Context) {
            Log.d("Timber","Scheduling job")
            val serviceComponent = ComponentName(context, AutoDeleteService::class.java)
            val periodicJob = JobInfo.Builder(JobId, serviceComponent)
                    .setPeriodic(TimeUnit.DAYS.toMillis(1))
                    .setPersisted(true)
                    .build()

            context.jobScheduler.schedule(periodicJob)
        }

        fun cancelJob(context: Context) {
            Log.d("Timber","Canceling job")
            context.jobScheduler.cancel(JobId)
        }
    }

    @Inject lateinit var deleteOldMessages: DeleteOldMessages

    private val disposables = CompositeDisposable()

    override fun onStartJob(params: JobParameters?): Boolean {
        Log.d("Timber","onStartJob")
        AndroidInjection.inject(this)
        disposables += deleteOldMessages
        deleteOldMessages.execute(Unit) {
            jobFinished(params, false)
        }
        return true
    }

    override fun onStopJob(params: JobParameters?): Boolean {
        Log.d("Timber","onStopJob")
        disposables.dispose()
        return true
    }
}
