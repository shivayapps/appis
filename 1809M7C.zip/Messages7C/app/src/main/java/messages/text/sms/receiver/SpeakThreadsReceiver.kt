
package messages.text.sms.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import dagger.android.AndroidInjection
import messages.text.sms.interactor.SpeakThreads
import messages.text.sms.repository.ConversationRepository
import javax.inject.Inject

class SpeakThreadsReceiver : BroadcastReceiver() {

    @Inject lateinit var speakThread: SpeakThreads
    @Inject lateinit var conversationRepo: ConversationRepository


    override fun onReceive(context: Context, intent: Intent) {
        AndroidInjection.inject(this, context)

        val pendingResult = goAsync()
        val threadId = intent.getLongExtra("threadId", 0)

        val threads = when {
            (threadId == -1L) -> conversationRepo.getUnseenIds()
            (threadId == -2L) -> conversationRepo.getUnreadIds()
            else -> listOf(threadId)
        }

        speakThread.execute(threads) { pendingResult.finish() }
    }

}