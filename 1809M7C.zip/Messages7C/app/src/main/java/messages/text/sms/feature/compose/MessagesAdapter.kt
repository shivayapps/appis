package messages.text.sms.feature.compose

import android.animation.ObjectAnimator
import android.content.Context
import android.content.res.Configuration
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.text.Layout
import android.text.Spannable
import android.text.SpannableString
import android.text.SpannableStringBuilder
import android.text.method.LinkMovementMethod
import android.text.style.ClickableSpan
import android.text.style.StyleSpan
import android.text.style.URLSpan
import android.text.util.Linkify
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import androidx.core.net.toUri
import com.jakewharton.rxbinding2.view.clicks
import messages.text.sms.common.MyMediaPlayer
import io.reactivex.disposables.Disposable
import io.reactivex.subjects.PublishSubject
import io.reactivex.subjects.Subject
import io.realm.RealmResults
import messages.text.sms.R
import messages.text.sms.common.Navigator
import messages.text.sms.common.base.MyRealmAdapter
import messages.text.sms.common.base.MyViewHolder
import messages.text.sms.common.util.Colors
import messages.text.sms.common.util.DateFormatter
import messages.text.sms.common.util.TextViewStyler
import messages.text.sms.extensions.dpToPx
import messages.text.sms.extensions.setBackgroundTint
import messages.text.sms.extensions.setPadding
import messages.text.sms.extensions.setTint
import messages.text.sms.extensions.setVisible
import messages.text.sms.extensions.withAlpha
import messages.text.sms.compat.SubscriptionManagerCompat
import messages.text.sms.databinding.MessageListItemInBinding
import messages.text.sms.databinding.MessageListItemOutBinding
import messages.text.sms.extensions.beVisible
import messages.text.sms.extensions.beVisibleIf
import messages.text.sms.extensions.isSmil
import messages.text.sms.extensions.isText
import messages.text.sms.extensions.joinTo
import messages.text.sms.extensions.millisecondsToMinutes
import messages.text.sms.extensions.truncateWithEllipses
import messages.text.sms.feature.compose.BubbleUtils.canGroup
import messages.text.sms.feature.compose.BubbleUtils.getBubble
import messages.text.sms.feature.compose.part.PartsAdapter
import messages.text.sms.extensions.isEmojiOnly
import messages.text.sms.model.Conversation
import messages.text.sms.model.Message
import messages.text.sms.model.Recipient
import messages.text.sms.util.PhoneNumberUtils
import messages.text.sms.util.Preferences
import java.util.concurrent.TimeUnit
import javax.inject.Inject
import javax.inject.Provider

class MessagesAdapter @Inject constructor(
    subscriptionManager: SubscriptionManagerCompat,
    private val context: Context,
    private val colors: Colors,
    private val dateFormatter: DateFormatter,
    private val partsAdapterProvider: Provider<PartsAdapter>,
    private val phoneNumberUtils: PhoneNumberUtils,
    private val prefs: Preferences,
    private val textViewStyler: TextViewStyler,
    private val navigator: Navigator,
) : MyRealmAdapter<Message, MyViewHolder>() {

    // Helper interface to access common views from both binding types
    private interface MessageBinding {
        val timestamp: messages.text.sms.common.widget.MessagesTextView
        val sim: ImageView
        val ivCheck: ImageView
        val simIndex: messages.text.sms.common.widget.MessagesTextView
        val body: messages.text.sms.common.widget.TightTextView
        val parts: messages.text.sms.common.widget.MyContextMenuRecyclerViewLongMmsPart
        val status: messages.text.sms.common.widget.MessagesTextView
        val reactions: android.widget.LinearLayout
        val reactionText: android.widget.TextView
    }

    // Wrapper for MessageListItemInBinding
    private class InBindingWrapper(private val binding: MessageListItemInBinding) : MessageBinding {
        override val timestamp = binding.timestamp
        override val sim = binding.sim
        override val ivCheck = binding.ivCheck
        override val simIndex = binding.simIndex
        override val body = binding.body
        override val parts = binding.parts
        override val status = binding.status
        override val reactions = binding.reactions
        override val reactionText = binding.reactionText
        val avatar = binding.avatar
    }

    // Wrapper for MessageListItemOutBinding
    private class OutBindingWrapper(private val binding: MessageListItemOutBinding) :
        MessageBinding {
        override val timestamp = binding.timestamp
        override val sim = binding.sim
        override val ivCheck = binding.ivCheck
        override val simIndex = binding.simIndex
        override val body = binding.body
        override val parts = binding.parts
        override val status = binding.status
        override val reactions = binding.reactions
        override val reactionText = binding.reactionText
        val cancelFrame = binding.cancelFrame
        val cancel = binding.cancel
        val sendNowIcon = binding.sendNowIcon
        val resendIcon = binding.resendIcon
    }

    class AudioState(
        var partId: Long = -1,
        var state: MyMediaPlayer.PlayingState = MyMediaPlayer.PlayingState.Stopped,
        var seekBarUpdater: Disposable? = null,
        var viewHolder: MyViewHolder? = null
    )

    companion object {
        private const val VIEW_TYPE_MESSAGE_IN = 0
        private const val VIEW_TYPE_MESSAGE_OUT = 1

        private const val MAX_MESSAGE_DISPLAY_LENGTH = 5000
    }

    // click events passed back to compose view model
    val partClicks: Subject<Long> = PublishSubject.create()
    val messageLinkClicks: Subject<Uri> = PublishSubject.create()
    val cancelSendingClicks: Subject<Long> = PublishSubject.create()
    val sendNowClicks: Subject<Long> = PublishSubject.create()
    val resendClicks: Subject<Long> = PublishSubject.create()
    val partContextMenuRegistrar: Subject<View> = PublishSubject.create()

    var data: Pair<Conversation, RealmResults<Message>>? = null
        set(value) {
            if (field === value) return

            field = value
            contactCache.clear()

            updateData(value?.second)
        }

    /**
     * Safely return the conversation, if available
     */
    private val conversation: Conversation?
        get() = data?.first?.takeIf { it.isValid }

    private val contactCache = ContactCache()
    private val expanded = HashMap<Long, Boolean>()
    private val subs = subscriptionManager.activeSubscriptionInfoList

    var theme: Colors.Theme = colors.theme()

    private val audioState = AudioState()

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {
        // Use the parent's context to inflate the layout, otherwise link clicks will crash the app
        val inflater = LayoutInflater.from(parent.context)

        return if (viewType == VIEW_TYPE_MESSAGE_OUT) {
            val binding = MessageListItemOutBinding.inflate(inflater, parent, false)
            binding.cancelIcon.setTint(theme.theme)
            binding.cancel.setTint(theme.theme)
            binding.sendNowIcon.setTint(theme.theme)
            binding.resendIcon.setTint(theme.theme)
            binding.body.hyphenationFrequency = Layout.HYPHENATION_FREQUENCY_NONE

            // register recycler view with compose activity for context menus
            partContextMenuRegistrar.onNext(binding.parts)

            MyViewHolder(binding.root).apply {
                containerView.setOnClickListener {
                    getItem(adapterPosition)?.let {
                        val statusBinding = MessageListItemOutBinding.bind(containerView)
                        when (toggleSelection(it.id, false)) {
                            true -> containerView.isActivated = isSelected(it.id)
                            false -> {
                                expanded[it.id] = statusBinding.status.visibility != View.VISIBLE
                                notifyItemChanged(adapterPosition)
                            }
                        }
                    }
                }
                containerView.setOnLongClickListener {
                    getItem(adapterPosition)?.let {
                        toggleSelection(it.id)
                        containerView.isActivated = isSelected(it.id)
                    }
                    true
                }
            }
        } else {
            val binding = MessageListItemInBinding.inflate(inflater, parent, false)
            binding.body.hyphenationFrequency = Layout.HYPHENATION_FREQUENCY_NONE

            // register recycler view with compose activity for context menus
            partContextMenuRegistrar.onNext(binding.parts)

            MyViewHolder(binding.root).apply {
                containerView.setOnClickListener {
                    getItem(adapterPosition)?.let {
                        val statusBinding = MessageListItemInBinding.bind(containerView)
                        when (toggleSelection(it.id, false)) {
                            true -> containerView.isActivated = isSelected(it.id)
                            false -> {
                                expanded[it.id] = statusBinding.status.visibility != View.VISIBLE
                                notifyItemChanged(adapterPosition)
                            }
                        }
                    }
                }
                containerView.setOnLongClickListener {
                    getItem(adapterPosition)?.let {
                        toggleSelection(it.id)
                        containerView.isActivated = isSelected(it.id)
                    }
                    true
                }
            }
        }
    }

    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
        val message = getItem(position) ?: return
        val previous = if (position == 0) null else getItem(position - 1)
        val next = if (position == itemCount - 1) null else getItem(position + 1)

        val theme = when (message.isOutgoingMessage()) {
            true -> colors.theme()
            false -> colors.theme(contactCache[message.address])
        }

        // Create binding wrapper based on view type
        val binding: MessageBinding = if (message.isMe()) {
            val outBinding = MessageListItemOutBinding.bind(holder.containerView)
            val wrapper = OutBindingWrapper(outBinding)

            // Bind outgoing-specific views
            val isCancellable = message.isSending() && message.date > System.currentTimeMillis()
            wrapper.cancelFrame.visibility = if (isCancellable) View.VISIBLE else View.GONE
            wrapper.cancelFrame.clicks().subscribe { cancelSendingClicks.onNext(message.id) }
            wrapper.cancel.progress = 2

            if (isCancellable) {
                val delay = when (prefs.sendDelay.get()) {
                    Preferences.SEND_DELAY_SHORT -> 3000
                    Preferences.SEND_DELAY_MEDIUM -> 5000
                    Preferences.SEND_DELAY_LONG -> 10000
                    else -> 0
                }
                val progress =
                    (1 - (message.date - System.currentTimeMillis()) / delay.toFloat()) * 100

                ObjectAnimator.ofInt(wrapper.cancel, "progress", progress.toInt(), 100)
                    .setDuration(message.date - System.currentTimeMillis())
                    .start()
            }

            // bind the send now icon view
            if (message.isSending() && message.date > System.currentTimeMillis()) {
                wrapper.sendNowIcon.visibility = View.VISIBLE
                wrapper.sendNowIcon.clicks().subscribe { sendNowClicks.onNext(message.id) }
            } else {
                wrapper.sendNowIcon.visibility = View.GONE
            }

            // bind the resend icon view
            if (message.isFailedMessage()) {
                wrapper.resendIcon.visibility = View.VISIBLE
                wrapper.resendIcon.clicks().subscribe {
                    resendClicks.onNext(message.id)
                    wrapper.resendIcon.visibility = View.GONE
                }
            } else {
                wrapper.resendIcon.visibility = View.GONE
            }
            wrapper
        } else {
            val inBinding = MessageListItemInBinding.bind(holder.containerView)
            InBindingWrapper(inBinding)
        }

        // Update the selected state
        holder.containerView.isActivated = isSelected(message.id) || highlight == message.id

        if (isSelected(message.id)) {
            binding.ivCheck.visibility = View.VISIBLE
        } else {
            binding.ivCheck.visibility = View.GONE
        }

        val subject = message.getCleansedSubject()

        var isMsgTextTruncated = false

        // get message text to display, which may need to be truncated
        val displayText = subject.joinTo(message.getText(false), "\n").let {
            isMsgTextTruncated = (it.length > MAX_MESSAGE_DISPLAY_LENGTH)

            // make subject sub-string bold, if subject is not blank
            if (subject.isNotBlank())
                SpannableString(it.truncateWithEllipses(MAX_MESSAGE_DISPLAY_LENGTH)).apply {
                    setSpan(
                        StyleSpan(Typeface.BOLD),
                        0,
                        subject.length,
                        Spannable.SPAN_INCLUSIVE_EXCLUSIVE
                    )
                }
            else
                it.truncateWithEllipses(MAX_MESSAGE_DISPLAY_LENGTH)
        }

        // Bind the message status
        bindStatus(holder, binding, isMsgTextTruncated, message, next)

        // Bind the timestamp
        val subscription = subs.find { it.subscriptionId == message.subId }

        binding.timestamp.apply {
            text = dateFormatter.getMessageTimestamp(message.date)
            setVisible(
                ((message.date - (previous?.date ?: 0))
                    .millisecondsToMinutes() >= BubbleUtils.TIMESTAMP_THRESHOLD) ||
                        (message.subId != previous?.subId) &&
                        (subscription != null)
            )
        }

        binding.simIndex.text = subscription?.simSlotIndex?.plus(1)?.toString()

        ((message.subId != previous?.subId) && (subscription != null) && (subs.size > 1)).also {
            binding.sim.setVisible(it)
            binding.simIndex.setVisible(it)
        }

        // Bind the grouping
        holder.containerView.setPadding(
            bottom = if (canGroup(message, next)) 0 else 16.dpToPx(context)
        )

        val isDarkMode = (context.resources.configuration.uiMode and
                Configuration.UI_MODE_NIGHT_MASK) ==
                Configuration.UI_MODE_NIGHT_YES

        if (!message.isMe()) {
            (binding as InBindingWrapper).avatar.apply {
                val isGroupChat = (conversation?.recipients?.size ?: 0) > 1
                if (isGroupChat) {
                    setRecipient(contactCache[message.address])
                    setVisible(!canGroup(message, next), View.INVISIBLE)
                } else {
                    visibility = View.GONE
                }
            }

            val incomingBubbleColor = context.getColor(R.color.bubbleIncoming)

            val incomingTextColor = if (isDarkMode) {
                context.getColor(R.color.white)
            } else {
                context.getColor(R.color.black)
            }

            binding.body.apply {
                setTextColor(incomingTextColor)
                setBackgroundTint(incomingBubbleColor)
                highlightColor = incomingBubbleColor.withAlpha(0x5d)
//                highlightColor = context.getColor(R.color.md_theme_primary)
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    textSelectHandle?.setTint(incomingBubbleColor.withAlpha(0x7d))
                    textSelectHandleLeft?.setTint(incomingBubbleColor.withAlpha(0x7d))
                    textSelectHandleRight?.setTint(incomingBubbleColor.withAlpha(0x7d))
                }
            }
        } else {
            val outgoingBubbleColor = context.getColor(R.color.bubbleOutgoing)
            val outgoingTextColor = context.getColor(R.color.bubbleOutgoingText)

            binding.body.apply {
                setTextColor(outgoingTextColor)
                setBackgroundTint(outgoingBubbleColor)
                highlightColor = outgoingBubbleColor.withAlpha(0x5d)
//                highlightColor = context.getColor(R.color.md_theme_primary)
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    textSelectHandle?.setTint(outgoingBubbleColor.withAlpha(0xad))
                    textSelectHandleLeft?.setTint(outgoingBubbleColor.withAlpha(0xad))
                    textSelectHandleRight?.setTint(outgoingBubbleColor.withAlpha(0xad))
                }
            }
        }

        // Bind the body text
        val emojiOnly = displayText.isEmojiOnly()
        textViewStyler.setTextSize(
            binding.body,
            when (emojiOnly) {
                true -> TextViewStyler.SIZE_EMOJI
                false -> TextViewStyler.SIZE_PRIMARY
            }
        )

        val spanString = SpannableStringBuilder(displayText)

        when (prefs.messageLinkHandling.get()) {
            Preferences.MESSAGE_LINK_HANDLING_BLOCK -> binding.body.autoLinkMask = 0
            Preferences.MESSAGE_LINK_HANDLING_ASK -> {
                //  manually handle link clicks if user has set to ask before opening links
                binding.body.apply {
                    isClickable = false
                    linksClickable = false
                    movementMethod = LinkMovementMethod.getInstance()

                    Linkify.addLinks(spanString, autoLinkMask)
                }

                spanString.apply {
                    for (span in getSpans(0, length, URLSpan::class.java)) {
                        // set handler for when user touches a link into new span
                        setSpan(
                            object : ClickableSpan() {
                                override fun onClick(widget: View) {
                                    messageLinkClicks.onNext(span.url.toUri())
                                }
                            },
                            getSpanStart(span),
                            getSpanEnd(span),
                            getSpanFlags(span)
                        )

                        // remove original span
                        removeSpan(span)
                    }
                }
            }

            else -> binding.body.movementMethod = LinkMovementMethod.getInstance()
        }

        binding.body.apply {
            text = spanString
            setVisible(message.isSms() || spanString.isNotBlank())

            setBackgroundResource(
                getBubble(
                    emojiOnly = emojiOnly,
                    canGroupWithPrevious = canGroup(message, previous) ||
                            message.parts.any { !it.isSmil() && !it.isText() },
                    canGroupWithNext = canGroup(message, next),
                    isMe = message.isMe()
                )
            )
        }

        // Bind the parts
        binding.parts.adapter = partsAdapterProvider.get().apply {
            this.theme = theme
            setData(message, previous, next, holder, audioState)
            contextMenuValue = message.id
            clicks.subscribe(partClicks)    // part clicks gets passed back to compose view model
        }

        showEmojiReactions(binding, message)
    }

    private fun showEmojiReactions(binding: MessageBinding, message: Message) {
        val reactions = message.emojiReactions
        val hasReactions = reactions.isNotEmpty()

        if (hasReactions) {
            val reactionCounts = reactions.groupBy { it.emoji }
                .mapValues { it.value.size }
                .toList()
                .sortedByDescending { it.second } // Sort by count, most reactions first

            // For now, show just the first (most popular) reaction
            val topReaction = reactionCounts.first()
            val reactionText = if (topReaction.second == 1) {
                topReaction.first
            } else {
                // Use a non-breaking space to keep the emoji and count together
                "${topReaction.first}\u00A0${topReaction.second}"
            }

            binding.reactionText.text = reactionText
            binding.reactions.setVisible(true)
            makeRoomForEmojis(binding.reactions)
        } else {
            binding.reactions.setVisible(false)
        }
    }

    private fun makeRoomForEmojis(reactionsContainer: View) {
        val paddingBottom = context.resources.getDimensionPixelSize(R.dimen.padding_reactions)

        (reactionsContainer.parent?.parent as? ViewGroup)?.let { parent ->
            parent.setPadding(
                parent.paddingLeft,
                parent.paddingTop,
                parent.paddingRight,
                paddingBottom
            )
        }
    }

    private fun bindStatus(
        holder: MyViewHolder,
        binding: MessageBinding,
        bodyTextTruncated: Boolean,
        message: Message,
        next: Message?
    ) {
        binding.status.apply {
            text = when {
                message.isSending() -> context.getString(R.string.message_status_sending)
                message.isDelivered() -> context.getString(
                    R.string.message_status_delivered,
                    dateFormatter.getTimestamp(message.dateSent)
                )

                message.isFailedMessage() -> context.getString(R.string.message_status_failed)
                bodyTextTruncated -> context.getString(R.string.message_body_too_long_to_display)
                (!message.isMe() && (conversation?.recipients?.size ?: 0) > 1) ->
                    // incoming group message
                    "${contactCache[message.address]?.getDisplayName()} • ${
                        dateFormatter.getTimestamp(message.date)
                    }"

                else -> dateFormatter.getTimestamp(message.date)
            }

            val age = TimeUnit.MILLISECONDS.toMinutes(
                System.currentTimeMillis() - message.date
            )

            setVisible(
                when {
                    expanded[message.id] == true -> true
                    message.isSending() -> true
                    message.isFailedMessage() -> true
                    bodyTextTruncated -> true
                    expanded[message.id] == false -> false
                    ((conversation?.recipients?.size ?: 0) > 1) &&
                            !message.isMe() && next?.compareSender(message) != true -> true

                    (message.isDelivered() &&
                            (next?.isDelivered() != true) &&
                            (age <= BubbleUtils.TIMESTAMP_THRESHOLD)) -> true

                    else -> false
                }
            )
        }
    }

    override fun getItemId(position: Int): Long {
        return getItem(position)?.id ?: -1
    }

    override fun getItemViewType(position: Int): Int {
        val message = getItem(position) ?: return -1
        return when (message.isMe()) {
            true -> VIEW_TYPE_MESSAGE_OUT
            false -> VIEW_TYPE_MESSAGE_IN
        }
    }

    fun expandMessages(messageIds: List<Long>, expand: Boolean) {
        messageIds.forEach { expanded[it] = expand }
        notifyDataSetChanged()
    }

    /**
     * Cache the contacts in a map by the address, because the messages we're binding don't have
     * a reference to the contact.
     */
    private inner class ContactCache : HashMap<String, Recipient?>() {
        override fun get(key: String): Recipient? {
            if (super.get(key)?.isValid != true)
                set(
                    key,
                    conversation?.recipients?.firstOrNull {
                        phoneNumberUtils.compare(it.address, key)
                    }
                )

            return super.get(key)?.takeIf { it.isValid }
        }

    }
}
