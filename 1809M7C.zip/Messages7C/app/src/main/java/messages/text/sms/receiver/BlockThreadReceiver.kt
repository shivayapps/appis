
package messages.text.sms.receiver

import android.annotation.SuppressLint
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import messages.text.sms.interactor.MarkBlocked
import dagger.android.AndroidInjection
import messages.text.sms.feature.blocking.BlockingClient
import messages.text.sms.repository.ConversationRepository
import messages.text.sms.util.Preferences
import io.reactivex.schedulers.Schedulers
import android.util.Log
import javax.inject.Inject

class BlockThreadReceiver : BroadcastReceiver() {

    @Inject lateinit var blockingClient: BlockingClient
    @Inject lateinit var conversationRepo: ConversationRepository
    @Inject lateinit var markBlocked: MarkBlocked
    @Inject lateinit var prefs: Preferences

    @SuppressLint("CheckResult")
    override fun onReceive(context: Context, intent: Intent) {
        AndroidInjection.inject(this, context)

        val threadId = intent.getLongExtra("threadId", 0)

        blockingClient
            .block(
                conversationRepo.getConversation(threadId)
                    ?.recipients
                    ?.map { it.address }
                    ?: listOf()
            )
            .subscribeOn(Schedulers.io())
            .andThen(
                markBlocked.buildObservable(
                    MarkBlocked.Params(listOf(threadId), null)
                )
            )
            .subscribe(
                {
                    goAsync().finish()
                },
                { error ->
                    Log.d("Timber","BlockThreadReceiver:blocking failed")
                    goAsync().finish()
                }
            )
    }
}
