package messages.text.sms.feature.compose

import android.Manifest
import android.animation.LayoutTransition
import android.app.Activity
import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.content.ContentValues
import android.content.DialogInterface
import android.content.Intent
import android.content.res.ColorStateList
import android.location.Address
import android.location.Geocoder
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.provider.ContactsContract
import android.provider.MediaStore
import android.provider.Settings
import android.text.format.DateFormat
import android.util.Log
import android.view.ContextMenu
import android.view.MenuItem
import android.view.View
import android.widget.SeekBar
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.view.isVisible
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.flexbox.FlexboxLayoutManager
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationServices
import com.jakewharton.rxbinding2.view.clicks
import com.jakewharton.rxbinding2.widget.textChanges
import com.karumi.dexter.Dexter
import com.karumi.dexter.MultiplePermissionsReport
import com.karumi.dexter.PermissionToken
import com.karumi.dexter.listener.PermissionDeniedResponse
import com.karumi.dexter.listener.PermissionGrantedResponse
import com.karumi.dexter.listener.PermissionRequest
import com.karumi.dexter.listener.multi.MultiplePermissionsListener
import com.karumi.dexter.listener.single.BasePermissionListener
import com.karumi.dexter.listener.single.CompositePermissionListener
import com.karumi.dexter.listener.single.DialogOnDeniedPermissionListener
import com.karumi.dexter.listener.single.PermissionListener
import messages.text.sms.common.MyMediaPlayer
import com.uber.autodispose.ObservableSubscribeProxy
import com.uber.autodispose.android.lifecycle.scope
import com.uber.autodispose.autoDispose
import dagger.android.AndroidInjection
import io.reactivex.Observable
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.disposables.Disposable
import io.reactivex.schedulers.Schedulers
import io.reactivex.subjects.PublishSubject
import io.reactivex.subjects.Subject
import messages.text.sms.R
import messages.text.sms.adhelper.AdUtil
import messages.text.sms.adhelper.NativeAdHelper
import messages.text.sms.adhelper.NativeLayoutType
import messages.text.sms.dialog.DeleteMessageDialog
import messages.text.sms.common.Navigator
import messages.text.sms.dialog.MessageDialog
import messages.text.sms.common.PopupWindowHelper
import messages.text.sms.common.base.MainBaseThemedActivity
import messages.text.sms.common.util.DateFormatter
import messages.text.sms.extensions.autoScrollToStart
import messages.text.sms.extensions.baseConfig
import messages.text.sms.extensions.beGone
import messages.text.sms.extensions.beVisible
import messages.text.sms.extensions.beVisibleIf
import messages.text.sms.extensions.dpToPx
import messages.text.sms.extensions.hideKeyboard
import messages.text.sms.extensions.scrapViews
import messages.text.sms.extensions.setTint
import messages.text.sms.extensions.setVisible
import messages.text.sms.extensions.showKeyboard
import messages.text.sms.extensions.resolveThemeColor
import messages.text.sms.common.widget.MicInputCloudView
import messages.text.sms.databinding.ComposeActivityBinding
import messages.text.sms.extensions.mapNotNull
import messages.text.sms.databinding.MenuComposeBinding
import messages.text.sms.extensions.dismissKeyboard
import messages.text.sms.extensions.hasAllPermissions
import messages.text.sms.feature.compose.editing.ChipsAdapter
import messages.text.sms.feature.compose.editing.TextAdapter
import messages.text.sms.feature.contacts.ContactsActivity
import messages.text.sms.model.Attachment
import messages.text.sms.model.Recipient
import messages.text.sms.util.PERMISSION_POST_NOTIFICATIONS
import messages.text.sms.util.PERMISSION_READ_PHONE_STATE
import java.io.File
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.concurrent.TimeUnit
import javax.inject.Inject


class ComposeActivity :
    MainBaseThemedActivity<ComposeActivityBinding>(ComposeActivityBinding::inflate),
    ComposeView {

    @Inject
    lateinit var composeAttachmentAdapter: ComposeAttachmentAdapter

    @Inject
    lateinit var chipsAdapter: ChipsAdapter

    @Inject
    lateinit var dateFormatter: DateFormatter

    @Inject
    lateinit var messageAdapter: MessagesAdapter

    @Inject
    lateinit var navigator: Navigator

    @Inject
    lateinit var viewModelFactory: ViewModelProvider.Factory

    override val activityVisibleIntent: Subject<Boolean> = PublishSubject.create()
    override val chipsSelectedIntent: Subject<HashMap<String, String?>> = PublishSubject.create()
    override val chipDeletedIntent: Subject<Recipient> by lazy { chipsAdapter.chipDeleted }
    override val menuReadyIntent: Observable<Unit> = menu.map { Unit }
    override val optionsItemIntent: Subject<Int> = PublishSubject.create()
    override val contextItemIntent: Subject<MenuItem> = PublishSubject.create()
    override val scheduleAction: Subject<Boolean> = PublishSubject.create()
    override val sendAsGroupIntent by lazy { binding.sendAsGroupBackground.clicks() }
    override val messagePartClickIntent: Subject<Long> by lazy { messageAdapter.partClicks }
    override val messagePartContextMenuRegistrar: Subject<View> by lazy { messageAdapter.partContextMenuRegistrar }
    override val messagesSelectedIntent by lazy { messageAdapter.selectionChanges }
    override val cancelSendingIntent: Subject<Long> by lazy { messageAdapter.cancelSendingClicks }
    override val sendNowIntent: Subject<Long> by lazy { messageAdapter.sendNowClicks }
    override val resendIntent: Subject<Long> by lazy { messageAdapter.resendClicks }
    override val attachmentDeletedIntent: Subject<Attachment> by lazy { composeAttachmentAdapter.attachmentDeleted }
    override val textChangedIntent by lazy { binding.message.textChanges() }
    override val attachIntent by lazy {
        Observable.merge(
            binding.attach.clicks(),
            binding.shadeBackground.clicks()
        )
    }
    override val cameraIntent by lazy { binding.sendCamera.clicks() }
    override val locationIntent by lazy { binding.sendLocation.clicks() }

    //    override val attachImageFileIntent by lazy {
//        Observable.merge(
//            binding.gallery.clicks(),
//            binding.galleryLabel.clicks()
//        )
//    }
    override val attachAnyFileIntent by lazy { binding.sendMedia.clicks() }
    override val scheduleIntent by lazy { binding.sendSchedule.clicks() }
    override val attachContactIntent by lazy { binding.sendContact.clicks() }
    override val attachAnyFileSelectedIntent: Subject<Uri> = PublishSubject.create()
    override val contactSelectedIntent: Subject<Uri> = PublishSubject.create()
    override val inputContentIntent by lazy { binding.message.inputContentSelected }
    override val scheduleSelectedIntent: Subject<Long> = PublishSubject.create()
    override val changeSimIntent by lazy { binding.sim.clicks() }
    override val scheduleCancelIntent by lazy { binding.scheduledCancel.clicks() }

    private val sendSubject = PublishSubject.create<Unit>()
    override val sendIntent: Observable<Unit> = sendSubject
//    override val sendIntent by lazy { binding.send.clicks() }

    override val viewExactAlarmsSettingsIntent: Subject<Unit> = PublishSubject.create()
    override val backPressedIntent: Subject<Unit> = PublishSubject.create()
    override val confirmDeleteIntent: Subject<List<Long>> = PublishSubject.create()
    override val clearCurrentMessageIntent: Subject<Boolean> = PublishSubject.create()
    override val messageLinkAskIntent: Subject<Uri> by lazy { messageAdapter.messageLinkClicks }
    override val shadeIntent by lazy { binding.shadeBackground.clicks() }
    override val recordAudioStartStopRecording: Subject<Boolean> = PublishSubject.create()

    //    override val recordAnAudioMessage by lazy {
//        Observable.merge(
//            binding.recordAudioMsg.clicks(),
//            binding.attachAnAudioMessageIcon.clicks(),
//            binding.attachAnAudioMessageLabel.clicks()
//        )
//    }
    override val recordAnAudioMessage by lazy { binding.sendAudio.clicks() }
    override val recordAudioAbort by lazy { binding.audioMsgAbort.clicks() }
    override val recordAudioAttach by lazy { binding.audioMsgAttach.clicks() }
    override val recordAudioPlayerPlayPause: Subject<MyMediaPlayer.PlayingState> =
        PublishSubject.create()
    override val recordAudioPlayerConfigUI: Subject<MyMediaPlayer.PlayingState> =
        PublishSubject.create()
    override val recordAudioPlayerVisible: Subject<Boolean> = PublishSubject.create()
    override val recordAudioMsgRecordVisible: Subject<Boolean> = PublishSubject.create()
    override val recordAudioChronometer: Subject<Boolean> = PublishSubject.create()
    override val recordAudioRecord: Subject<MicInputCloudView.ViewState> = PublishSubject.create()

    private var seekBarUpdater: Disposable? = null

    private val viewModel by lazy {
        ViewModelProvider(this, viewModelFactory)[ComposeViewModel::class.java]
    }

    private var cameraDestination: Uri? = null
    private var isSelection = false


    private lateinit var menuBinding: MenuComposeBinding
    private lateinit var popupWindow: PopupWindowHelper

    private fun getSeekBarUpdater(): ObservableSubscribeProxy<Long> {
        return Observable.interval(500, TimeUnit.MILLISECONDS)
            .subscribeOn(Schedulers.single())
            .observeOn(AndroidSchedulers.mainThread())
            .autoDispose(scope())
    }

    private var hasSelection = false
    override fun onCreate(savedInstanceState: Bundle?) {
        AndroidInjection.inject(this)
        super.onCreate(savedInstanceState)
//        showBackButton(true)
        viewModel.bindView(this)

        binding.send.setOnClickListener {
            sendSubject.onNext(Unit)
        }
        binding.ivClose.setOnClickListener { onBackPressedDispatcher.onBackPressed() }
        binding.ivBack.setOnClickListener { onBackPressedDispatcher.onBackPressed() }
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (!backPressedIntent.hasObservers()) {
                    isEnabled = false
                    onBackPressedDispatcher.onBackPressed()
                    isEnabled = true
                } else {
//                    backPressedIntent.onNext(NavItem.BACK)
                    finish()
                }
            }
        })

        binding.contentView.layoutTransition = LayoutTransition().apply {
            disableTransitionType(LayoutTransition.CHANGING)
        }
        chipsAdapter.view = binding.chips

        binding.chips.itemAnimator = null
        binding.chips.layoutManager = FlexboxLayoutManager(this)

        messageAdapter.autoScrollToStart(binding.messageList)
        messageAdapter.emptyView = binding.messagesEmpty

        binding.messageList.setHasFixedSize(true)
        binding.messageList.adapter = messageAdapter

        binding.messageAttachments.adapter = composeAttachmentAdapter

        binding.message.supportsInputContent = true

        menuBinding = MenuComposeBinding.inflate(layoutInflater)
        popupWindow = PopupWindowHelper(menuBinding.root)

        menuBinding.viewScheduledMessages.setOnClickListener {
            optionsItemIntent.onNext(menuBinding.viewScheduledMessages.id)
                .let { true }; popupWindow.dismiss()
        }
        binding.selectAll.setOnClickListener {
            optionsItemIntent.onNext(binding.selectAll.id).let { true }; popupWindow.dismiss()
        }
        binding.add.setOnClickListener {
            optionsItemIntent.onNext(binding.add.id).let { true }; popupWindow.dismiss()
        }
        menuBinding.call.setOnClickListener {
            optionsItemIntent.onNext(menuBinding.call.id).let { true }; popupWindow.dismiss()
        }
        menuBinding.info.setOnClickListener {
            optionsItemIntent.onNext(menuBinding.info.id).let { true }; popupWindow.dismiss()
        }
        menuBinding.copy.setOnClickListener {
            optionsItemIntent.onNext(menuBinding.copy.id).let { true }; popupWindow.dismiss()
        }
        menuBinding.share.setOnClickListener {
            optionsItemIntent.onNext(menuBinding.share.id).let { true }; popupWindow.dismiss()
        }
        binding.details.setOnClickListener {
            optionsItemIntent.onNext(binding.details.id).let { true }; popupWindow.dismiss()
        }
        binding.delete.setOnClickListener {
            optionsItemIntent.onNext(binding.delete.id).let { true }; popupWindow.dismiss()
        }
        menuBinding.forward.setOnClickListener {
            optionsItemIntent.onNext(menuBinding.forward.id).let { true }; popupWindow.dismiss()
        }
        menuBinding.showStatus.setOnClickListener {
            optionsItemIntent.onNext(menuBinding.showStatus.id).let { true }; popupWindow.dismiss()
        }
        binding.previous.setOnClickListener {
            optionsItemIntent.onNext(binding.previous.id).let { true }; popupWindow.dismiss()
        }
        binding.next.setOnClickListener {
            optionsItemIntent.onNext(binding.next.id).let { true }; popupWindow.dismiss()
        }
        binding.clear.setOnClickListener {
            optionsItemIntent.onNext(binding.clear.id).let { true }; popupWindow.dismiss()
        }

        binding.menuIcon.clicks()
            .autoDispose(scope())
            .subscribe {
                showDrawerMenu(hasSelection, binding.menuIcon)
            }
        binding.addQuickReply.clicks()
            .autoDispose(scope())
            .subscribe {
                val intentQuickReply = Intent(this, QuickSuggestionActivity::class.java)
                //startActivity(intent)
                startQuickReplyResult.launch(intentQuickReply)
            }
        loadQuickReply()

        theme
            .doOnNext {
                binding.loading.setTint(it.theme)

                // entire attach menu
//                binding.attach.setBackgroundTint(it.theme); binding.attach.setTint(it.textPrimary)
//                binding.contact.setBackgroundTint(it.theme); binding.contact.setTint(it.textPrimary)
//                binding.contactLabel.setBackgroundTint(it.theme); binding.contactLabel.setTint(it.textPrimary)
//                binding.schedule.setBackgroundTint(it.theme); binding.schedule.setTint(it.textPrimary)
//                binding.scheduleLabel.setBackgroundTint(it.theme); binding.scheduleLabel.setTint(it.textPrimary)
//                binding.attachAFileIcon.setBackgroundTint(it.theme); binding.attachAFileIcon.setTint(it.textPrimary)
//                binding.attachAFileLabel.setBackgroundTint(it.theme); binding.attachAFileLabel.setTint(it.textPrimary)
//                binding.attachAnAudioMessageIcon.setBackgroundTint(it.theme); binding.attachAnAudioMessageIcon.setTint(it.textPrimary)
//                binding.attachAnAudioMessageLabel.setBackgroundTint(it.theme); binding.attachAnAudioMessageLabel.setTint(it.textPrimary)
//                binding.gallery.setBackgroundTint(it.theme); binding.gallery.setTint(it.textPrimary)
//                binding.galleryLabel.setBackgroundTint(it.theme); binding.galleryLabel.setTint(it.textPrimary)
//                binding.camera.setBackgroundTint(it.theme); binding.camera.setTint(it.textPrimary)
//                binding.cameraLabel.setBackgroundTint(it.theme); binding.cameraLabel.setTint(it.textPrimary)

                // audio message recording
                binding.audioMsgRecord.setColor(it.theme)
                binding.audioMsgPlayerPlayPause.setTint(it.theme)
                binding.audioMsgPlayerSeekBar.apply {
                    thumbTintList = ColorStateList.valueOf(it.theme)
                    progressBackgroundTintList = ColorStateList.valueOf(it.theme)
                    progressTintList = ColorStateList.valueOf(it.theme)
                }

                messageAdapter.theme = it
            }
            .autoDispose(scope())
            .subscribe()

        // context menu registration for message parts
        messagePartContextMenuRegistrar
            .mapNotNull { it }
            .autoDispose(scope())
            .subscribe { registerForContextMenu(it) }

        // start/stop audio message recording
        binding.audioMsgRecord.setOnClickListener {
            recordAudioRecord.onNext(binding.audioMsgRecord.getState())
        }

        recordAudioChronometer
            .subscribeOn(AndroidSchedulers.mainThread())
            .distinctUntilChanged()
            .autoDispose(scope())
            .subscribe {
                if (it) {
                    binding.audioMsgDuration.base = SystemClock.elapsedRealtime()
                    binding.audioMsgDuration.start()
                } else {
                    binding.audioMsgDuration.stop()
                }
            }

        // audio record playback play/pause button
        binding.audioMsgPlayerPlayPause.setOnClickListener {
            recordAudioPlayerPlayPause.onNext(
                binding.audioMsgPlayerPlayPause.tag as MyMediaPlayer.PlayingState
            )
        }

        recordAudioMsgRecordVisible
            .subscribeOn(AndroidSchedulers.mainThread())
            .distinctUntilChanged()
            .autoDispose(scope())
            .subscribe {
                binding.audioMsgRecord.isVisible = it
                binding.audioMsgDuration.isVisible =
                    it   // chronometer follows record button visibility
                binding.audioMsgBluetooth.isVisible = !it
            }

        recordAudioPlayerVisible
            .subscribeOn(AndroidSchedulers.mainThread())
            .distinctUntilChanged()
            .autoDispose(scope())
            .subscribe {
                binding.audioMsgPlayerBackground.isVisible = it
                recordAudioPlayerConfigUI.onNext(MyMediaPlayer.PlayingState.Stopped)
            }

        recordAudioPlayerConfigUI
            .subscribeOn(AndroidSchedulers.mainThread())
            .distinctUntilChanged()
            .autoDispose(scope())
            .subscribe {
                when (it) {
                    MyMediaPlayer.PlayingState.Playing -> {
                        binding.audioMsgPlayerPlayPause.tag = MyMediaPlayer.PlayingState.Playing
                        MyMediaPlayer.start()
                        binding.audioMsgPlayerPlayPause.setImageResource(R.drawable.exo_icon_pause)
                        seekBarUpdater = getSeekBarUpdater().subscribe {
                            binding.audioMsgPlayerSeekBar.progress = MyMediaPlayer.currentPosition
                            binding.audioMsgPlayerSeekBar.max = MyMediaPlayer.duration
                        }
                        binding.audioMsgPlayerSeekBar.isEnabled = true
                    }

                    MyMediaPlayer.PlayingState.Paused -> {
                        binding.audioMsgPlayerPlayPause.tag = MyMediaPlayer.PlayingState.Paused
                        MyMediaPlayer.pause()
                        binding.audioMsgPlayerPlayPause.setImageResource(R.drawable.exo_icon_play)
                        seekBarUpdater?.dispose()
                    }

                    else -> {
                        binding.audioMsgPlayerPlayPause.tag = MyMediaPlayer.PlayingState.Stopped
                        MyMediaPlayer.reset()
                        binding.audioMsgPlayerPlayPause.setImageResource(R.drawable.exo_icon_play)
                        seekBarUpdater?.dispose()
                        binding.audioMsgPlayerSeekBar.progress = 0
                        binding.audioMsgPlayerSeekBar.isEnabled = false
                    }
                }
            }
        // audio msg player seek bar handler
        binding.audioMsgPlayerSeekBar.setOnSeekBarChangeListener(
            object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(p0: SeekBar?, progress: Int, fromUser: Boolean) {
                    // if seek was initiated by the user and this part is currently playing
                    if (fromUser)
                        MyMediaPlayer.seekTo(progress)
                }

                override fun onStartTrackingTouch(p0: SeekBar?) {}
                override fun onStopTrackingTouch(p0: SeekBar?) {}
            }
        )

        window.callback = ComposeWindowCallback(window.callback, this)
    }

    var isAdLoaded = false
    var isAdLoading = false
    fun loadAds() {
        if (isAdLoaded || isAdLoading) return
        isAdLoading = true
        NativeAdHelper(
            this@ComposeActivity,
            binding.adsView,
            NativeLayoutType.NativeBanner,
            baseConfig.nativeAdsId,
            { isLoaded ->
                isAdLoading = false
                isAdLoaded = isLoaded
            }
        ).loadAd()
    }

    private val startQuickReplyResult = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        loadQuickReply()
    }

    fun loadQuickReply() {
        val notes = mutableListOf<String>()
        val path = baseConfig.quickNotes
        val notesFile = if (path.isNotEmpty()) {
            File(path)
        } else {
            File(filesDir, "quick_reply_notes.txt").also {
                baseConfig.quickNotes = it.absolutePath
            }
        }
        notes.clear()
        if (notesFile.exists()) {
            notes.addAll(notesFile.readLines())
        }
        binding.rvQuickReply.apply {
            layoutManager =
                LinearLayoutManager(this@ComposeActivity, RecyclerView.HORIZONTAL, false)
            adapter = TextAdapter(notes, { text ->
                var msg = binding.message.text.toString()
                msg += text

                binding.message.apply {
                    setText(msg)
                    setSelection(msg.length ?: 0)
                    requestFocus()
                }
            })
        }
    }

    override fun onStart() {
        super.onStart()
        activityVisibleIntent.onNext(true)
    }

    override fun onPause() {
        super.onPause()
        activityVisibleIntent.onNext(false)
    }

    override fun onDestroy() {
        super.onDestroy()

        // stop any playing audio
        MyMediaPlayer.reset()

        seekBarUpdater?.dispose()
    }


    override fun render(state: ComposeState) {
        if (state.hasError) {
            finish()
            return
        }

        threadId.onNext(state.threadId)

        title = when {
            state.selectedMessages > 0 -> getString(
                R.string.compose_title_selected,
                state.selectedMessages
            )

            state.query.isNotEmpty() -> state.query
            else -> state.conversationtitle
        }

        binding.toolbarSubtitle.setVisible(state.query.isNotEmpty())
        binding.toolbarSubtitle.text = getString(
            R.string.compose_subtitle_results, state.searchSelectionPosition,
            state.searchResults
        )

        binding.toolbarTitle.setVisible(!state.editingMode)
        binding.chips.setVisible(state.editingMode)
        binding.composeBar.setVisible(!state.loading)

        val selectedConversations = state.selectedMessages

        hasSelection = selectedConversations > 0

        binding.delete.setVisible(hasSelection)
        binding.ivClose.setVisible(hasSelection)
//        binding.menuIcon.setVisible(hasSelection)
        binding.menuIcon.setVisible(state.query.isEmpty())
        binding.ivBack.setVisible(!hasSelection)

        // Don't set the adapters unless needed
        if (state.editingMode && binding.chips.adapter == null) {
            binding.chips.adapter = chipsAdapter
        }

        if (state.editingMode) {
            binding.add.beVisible()
            binding.menuIcon.beGone()
        } else {
            binding.add.beGone()
            binding.menuIcon.setVisible(state.query.isEmpty())
        }
        menuBinding.viewScheduledMessages.beVisibleIf(!state.editingMode && state.selectedMessages == 0 && state.query.isEmpty() && state.hasScheduledMessages)
        binding.selectAll.beVisibleIf(!state.editingMode && (messageAdapter.itemCount > 1) && state.selectedMessages != 0)
//        binding.add.beVisibleIf(state.editingMode)
        menuBinding.call.beVisibleIf(!state.editingMode && state.selectedMessages == 0 && state.query.isEmpty())
        menuBinding.info.beVisibleIf(!state.editingMode && state.selectedMessages == 0 && state.query.isEmpty())
        menuBinding.copy.beVisibleIf(!state.editingMode && state.selectedMessages > 0 && state.selectedMessagesHaveText)
        menuBinding.share.beVisibleIf(!state.editingMode && state.selectedMessages > 0 && state.selectedMessagesHaveText)
        binding.details.beVisibleIf(!state.editingMode && state.selectedMessages == 1)
//        binding.delete.beVisibleIf(!state.editingMode && ((state.selectedMessages > 0) || state.canSend))
        binding.delete.beVisibleIf(!state.editingMode && state.selectedMessages > 0)
        menuBinding.forward.beVisibleIf(!state.editingMode && state.selectedMessages == 1)
        menuBinding.showStatus.beVisibleIf(!state.editingMode && state.selectedMessages > 0)
        binding.previous.beVisibleIf(state.selectedMessages == 0 && state.query.isNotEmpty())
        binding.next.beVisibleIf(state.selectedMessages == 0 && state.query.isNotEmpty())
        binding.clear.beVisibleIf(state.selectedMessages == 0 && state.query.isNotEmpty())

//        binding.toolbar.menu.findItem(R.id.viewScheduledMessages)?.isVisible = !state.editingMode && state.selectedMessages == 0 && state.query.isEmpty() && state.hasScheduledMessages
//        binding.toolbar.menu.findItem(R.id.select_all)?.isVisible = !state.editingMode && (messageAdapter.itemCount > 1) && state.selectedMessages != 0
//        binding.toolbar.menu.findItem(R.id.add)?.isVisible = state.editingMode
//        binding.toolbar.menu.findItem(R.id.call)?.isVisible = !state.editingMode && state.selectedMessages == 0 && state.query.isEmpty()
//        binding.toolbar.menu.findItem(R.id.info)?.isVisible = !state.editingMode && state.selectedMessages == 0 && state.query.isEmpty()
//        binding.toolbar.menu.findItem(R.id.copy)?.isVisible = !state.editingMode && state.selectedMessages > 0 && state.selectedMessagesHaveText
//        binding.toolbar.menu.findItem(R.id.share)?.isVisible = !state.editingMode && state.selectedMessages > 0 && state.selectedMessagesHaveText
//        binding.toolbar.menu.findItem(R.id.details)?.isVisible = !state.editingMode && state.selectedMessages == 1
//        binding.toolbar.menu.findItem(R.id.delete)?.isVisible = !state.editingMode && ((state.selectedMessages > 0) || state.canSend)
//        binding.toolbar.menu.findItem(R.id.forward)?.isVisible = !state.editingMode && state.selectedMessages == 1
//        binding.toolbar.menu.findItem(R.id.show_status)?.isVisible = !state.editingMode && state.selectedMessages > 0
//        binding.toolbar.menu.findItem(R.id.previous)?.isVisible = state.selectedMessages == 0 && state.query.isNotEmpty()
//        binding.toolbar.menu.findItem(R.id.next)?.isVisible = state.selectedMessages == 0 && state.query.isNotEmpty()
//        binding.toolbar.menu.findItem(R.id.clear)?.isVisible = state.selectedMessages == 0 && state.query.isNotEmpty()

        chipsAdapter.data = state.selectedChips

        binding.loading.setVisible(state.loading)

        binding.sendAsGroup.setVisible(state.editingMode && state.selectedChips.size >= 2)
        binding.sendAsGroupSwitch.isChecked = state.sendAsGroup

        binding.messageList.setVisible(!state.editingMode || state.sendAsGroup || state.selectedChips.size == 1)
        Log.e("ComposeModel", "state.messages:${state.messages!!.second.size}")
        messageAdapter.data = state.messages
        messageAdapter.highlight = state.searchSelectionId


        binding.scheduledGroup.isVisible = state.scheduled != 0L
        binding.scheduledTime.text = dateFormatter.getScheduledTimestamp(state.scheduled)

        binding.messageAttachments.setVisible(state.attachments.isNotEmpty())
        composeAttachmentAdapter.data = state.attachments

        binding.attach.animate().rotation(if (state.attaching) 135f else 0f).start()
//        binding.attaching.isVisible = state.attaching
        binding.frameAttaching.isVisible = state.attaching

        binding.shadeBackground.apply {
            when {
                state.attaching -> {
                    visibility = View.VISIBLE
                    elevation = 4.dpToPx(context).toFloat() // below attach menu
                }

                state.audioMsgRecording -> {
                    visibility = View.VISIBLE
                    elevation = 5.dpToPx(context).toFloat() // above attach menu
                }

                else -> visibility = View.GONE
            }
        }

        // show or hide audio message recording panel and shade background
        binding.audioMsgBackground.isVisible = state.audioMsgRecording

        binding.counter.text = state.remaining
        binding.counter.setVisible(binding.counter.text.isNotBlank())

        binding.sim.setVisible(state.subscription != null)
        binding.sim.contentDescription =
            getString(R.string.compose_sim_cd, state.subscription?.displayName)
        binding.simIndex.text = state.subscription?.simSlotIndex?.plus(1)?.toString()

        // show either send, audio msg record, or sendScheduled button
//        binding.send.visibility = if (state.canSend && !state.loading && state.scheduled == 0L) View.VISIBLE else View.INVISIBLE
//        binding.scheduledSend.visibility = if (state.canSend && (state.scheduled != 0L) && !state.loading) View.VISIBLE else View.INVISIBLE
//        binding.send.visibility = if (state.canSend && !state.loading && state.scheduled == 0L) View.VISIBLE else View.INVISIBLE
        binding.send.alpha =
            if (state.canSend && !state.loading && state.scheduled == 0L) 1.0f else 0.6f
        binding.clQuickReply.visibility =
            if (state.canSend && !state.loading && state.scheduled == 0L) View.GONE else View.VISIBLE

//        binding.scheduledSend.alpha = if (state.canSend && (state.scheduled != 0L) && !state.loading) 1.0f else 0.6f
//        binding.recordAudioMsg.visibility = if (state.canSend && !state.loading) View.INVISIBLE else View.VISIBLE

        // if not in editing mode, and there are no non-me participants that can be sent to,
        // hide controls that allow constructing a reply and inform user no valid recipients
        if (!state.editingMode && (state.validRecipientNumbers == 0)) {
            binding.composeBar.visibility = View.GONE
            binding.sim.visibility = View.GONE

            binding.noValidRecipients.visibility = View.VISIBLE
            binding.clQuickReply.visibility = View.GONE
            // change constraint of messageList to constrain bottom to top of noValidRecipients
//            ConstraintSet().apply {
//                clone(binding.contentView)
//                connect(
//                    R.id.llExtra,
//                    ConstraintSet.BOTTOM,
//                    R.id.noValidRecipients,
//                    ConstraintSet.TOP,
//                    0
//                )
//                applyTo(binding.contentView)
//            }

            loadAds()
        }

        // if scheduling mode is set, show schedule dialog
        if (state.scheduling)
            scheduleAction.onNext(true)

    }

    override fun clearSelection() = messageAdapter.clearSelection()

    override fun toggleSelectAll() {
        messageAdapter.toggleSelectAll()
    }

    override fun expandMessages(messageIds: List<Long>, expand: Boolean) {
        messageAdapter.expandMessages(messageIds, expand)
    }

    override fun showDetails(details: String) {
        MessageDialog()
            .show(
                this,
                getString(R.string.compose_details_title),
                details,
                getString(R.string.button_ok),
                positiveActionCallback = {},
                negativeActionCallback = {},
                dismissActionCallback = {}
            )

//        val dialog = AlertDialog.Builder(this, R.style.AppThemeDialog)
//            .setTitle(R.string.compose_details_title)
//            .setMessage(details)
//            .setCancelable(true)
//            .create()
//        dialog.show()
//
//        theme.take(1)
//            .autoDispose(scope())
//            .subscribe { theme ->
//                dialog.getButton(AlertDialog.BUTTON_POSITIVE)?.setTextColor(theme.theme)
//                dialog.getButton(AlertDialog.BUTTON_NEGATIVE)?.setTextColor(theme.theme)
//            }
    }

    override fun showMessageLinkAskDialog(uri: Uri) {
        MessageDialog()
            .show(
                this,
                getString(R.string.message_link_handling_dialog_title),
                getString(R.string.message_link_handling_dialog_body, uri.toString()),
                getString(R.string.message_link_handling_dialog_positive),
                positiveActionCallback = {
                    AdUtil.isSystemDialogOpen = true
                    ContextCompat.startActivity(
                        this,
                        Intent(Intent.ACTION_VIEW).setData(uri),
                        null
                    )
                },
                negativeActionCallback = {},
                dismissActionCallback = {}
            )

//        val dialog = AlertDialog.Builder(this, R.style.AppThemeDialog)
//            .setTitle(R.string.message_link_handling_dialog_title)
//            .setMessage(getString(R.string.message_link_handling_dialog_body, uri.toString()))
//            .setPositiveButton(
//                R.string.message_link_handling_dialog_positive
//            ) { _, _ ->
//                ContextCompat.startActivity(
//                    this,
//                    Intent(Intent.ACTION_VIEW).setData(uri),
//                    null
//                )
//            }
//            .setNegativeButton(R.string.message_link_handling_dialog_negative) { _, _ -> { } }
//            .create()

//        dialog.show()
//
//        theme.take(1)
//            .autoDispose(scope())
//            .subscribe { theme ->
//                dialog.getButton(AlertDialog.BUTTON_POSITIVE)?.setTextColor(theme.theme)
//                dialog.getButton(AlertDialog.BUTTON_NEGATIVE)?.setTextColor(theme.theme)
//            }
    }

    override fun requestDefaultSms() {
        navigator.showDefaultSmsDialog(this)
    }

    override fun requestStoragePermission() {
        ActivityCompat.requestPermissions(
            this,
            arrayOf(Manifest.permission.WRITE_EXTERNAL_STORAGE),
            0
        )
    }

    override fun requestRecordAudioPermission() {
        ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), 0)
    }

    override fun requestSmsPermission() {
        ActivityCompat.requestPermissions(
            this, arrayOf(
                Manifest.permission.READ_SMS,
                Manifest.permission.SEND_SMS
            ), 0
        )
    }

    override fun showAlarmPermission() {
        runOnUiThread {
            MessageDialog()
                .show(
                    this,
                    getString(R.string.permission_required),
                    getString(R.string.alarm_permission_description),
                    getString(R.string.grant_permission),
                    positiveActionCallback = {
                        viewExactAlarmsSettingsIntent.onNext(Unit)
//                    showExactAlarmsSettings()
                    },
                    negativeActionCallback = {

                    }
                )
        }
    }

    override fun requestDatePicker() {
        val calendar = Calendar.getInstance(Locale.getDefault())
        val datePicker = DatePickerDialog(
            this,
            DatePickerDialog.OnDateSetListener { _, year, month, day ->
                val timePicker = TimePickerDialog(
                    this,
                    TimePickerDialog.OnTimeSetListener { _, hour, minute ->
                        calendar.set(Calendar.YEAR, year)
                        calendar.set(Calendar.MONTH, month)
                        calendar.set(Calendar.DAY_OF_MONTH, day)
                        calendar.set(Calendar.HOUR_OF_DAY, hour)
                        calendar.set(Calendar.MINUTE, minute)
                        scheduleSelectedIntent.onNext(calendar.timeInMillis)
                    },
                    calendar.get(Calendar.HOUR_OF_DAY),
                    calendar.get(Calendar.MINUTE),
                    DateFormat.is24HourFormat(this)
                )
                tintDialogButtons(timePicker)
                timePicker.show()
            },
            calendar.get(Calendar.YEAR),
            calendar.get(Calendar.MONTH),
            calendar.get(Calendar.DAY_OF_MONTH)
        )
        tintDialogButtons(datePicker)
        datePicker.show()

        // On some devices, the keyboard can cover the date picker
        binding.message.hideKeyboard()
    }

    override fun requestContact() {
        AdUtil.isSystemDialogOpen = true

        val intent = Intent(Intent.ACTION_PICK)
            .setType(ContactsContract.Contacts.CONTENT_TYPE)
        startActivityForResult(
            Intent.createChooser(intent, null),
            ComposeView.AttachContactRequestCode
        )
    }

    override fun showContacts(sharing: Boolean, chips: List<Recipient>) {
        binding.message.hideKeyboard()
        // Track if this is the initial contact selection (no existing chips)
        isSelection = chips.isEmpty()
        val serialized =
            HashMap(chips.associate { chip -> chip.address to chip.contact?.lookupKey })
        val intent = Intent(this, ContactsActivity::class.java)
            .putExtra(ContactsActivity.SharingKey, sharing)
            .putExtra(ContactsActivity.ChipsKey, serialized)
//        startActivityForResult(intent, ComposeView.SelectContactRequestCode)
        contactLauncher.launch(intent)
    }

    var contactLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { intent ->
            val selectedContacts = intent.data?.getSerializableExtra(ContactsActivity.ChipsKey)
                ?.let { serializable -> serializable as? HashMap<String, String?> }
                ?: hashMapOf()

            // finish immediately to avoid showing empty compose screen
            if (isSelection && selectedContacts.isEmpty()) {
                //finish()
//                return
            } else {
                // Reset the flag after handling
                isSelection = false
                chipsSelectedIntent.onNext(selectedContacts)
            }
        }

    override fun themeChanged() {
        binding.messageList.scrapViews()
    }

    override fun showKeyboard() {
        dismissKeyboard()
        Handler(Looper.myLooper()!!).postDelayed({
            binding.message.requestFocus()
            binding.message.showKeyboard()
        }, 500)
    }


    override fun requestCamera() {
        AdUtil.isSystemDialogOpen = true
        cameraDestination = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())
            .let { timestamp ->
                ContentValues().apply {
                    put(
                        MediaStore.Images.Media.TITLE,
                        timestamp
                    )
                }
            }
            .let { cv -> contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cv) }

        val intent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
            .putExtra(MediaStore.EXTRA_OUTPUT, cameraDestination)
        startActivityForResult(Intent.createChooser(intent, null), ComposeView.TakePhotoRequestCode)
    }


    override fun requestGallery(mimeType: String) {
        AdUtil.isSystemDialogOpen = true
        val intent = Intent(Intent.ACTION_PICK)
            .putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
            .addFlags(Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
            .putExtra(Intent.EXTRA_LOCAL_ONLY, false)
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            .setType(mimeType)
        startActivityForResult(
            Intent.createChooser(intent, null),
            ComposeView.AttachAFileRequestCode
        )
    }

    private lateinit var fusedLocationClient: FusedLocationProviderClient
    override fun requestLocationString() {
        MessageDialog()
            .show(
                this@ComposeActivity,
                "Location Permission",
                "We only need your location to help you find relevant nearby places.",
                getString(R.string.button_ok),
                positiveActionCallback = {

                    Dexter.withContext(this@ComposeActivity)
                        .withPermission(
                            Manifest.permission.ACCESS_FINE_LOCATION
                        )
                        .withListener(object : PermissionListener {
                            override fun onPermissionGranted(p0: PermissionGrantedResponse?) {
                                initLocation()
                            }

                            override fun onPermissionDenied(p0: PermissionDeniedResponse?) {
                                initLocation()
                            }

                            override fun onPermissionRationaleShouldBeShown(
                                p0: PermissionRequest?,
                                token: PermissionToken?
                            ) {
                                token?.continuePermissionRequest()

                            }
                        }).check()
                },
                negativeActionCallback = {},
                dismissActionCallback = {}
            )


//        checkForLocationPermission(this, object : BasePermissionListener() {
//            override fun onPermissionDenied(response: PermissionDeniedResponse?) {
//                AdUtil.isSystemDialogOpen = false
////                isLocationPermissionGranted = false
//                initLocation()
//            }
//
//            override fun onPermissionGranted(response: PermissionGrantedResponse?) {
//                AdUtil.isSystemDialogOpen = false
////                isLocationPermissionGranted = true
//                initLocation()
//            }
//        })
    }

//    private fun checkForLocationPermission(activity: Activity, listener: BasePermissionListener?) {
//        val dialogPermissionListener = DialogOnDeniedPermissionListener.Builder
//            .withContext(activity)
//            .withTitle("Location Permission")
//            .withMessage("We only need your location to help you find relevant nearby places.")
//            .withButtonText(android.R.string.ok)
//            .build()
//        val compositeListener =
//            if (listener != null) {
//                CompositePermissionListener(dialogPermissionListener, listener)
//            } else {
//                CompositePermissionListener(dialogPermissionListener)
//            }
//        AdUtil.isSystemDialogOpen = true
//        Dexter.withContext(activity)
//            .withPermission(Manifest.permission.ACCESS_FINE_LOCATION)
//            .withListener(compositeListener)
//            .check()
//    }

    private fun initLocation() {
        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this@ComposeActivity)
        try {
            fusedLocationClient.lastLocation.addOnSuccessListener { location ->
                if (location != null) {
                    val latitude = location.latitude
                    val longitude = location.longitude
                    Log.w(
                        "msg",
                        "getLastKnownLocation: latitude: $latitude and longitude: $longitude"
                    )
                    // Do something with the latitude and longitude (e.g., show on map, send to server)
//                    val location = getLocationFromLatLng(LatLng(latitude, longitude))
                    val location = getLocationFromLatLng(latitude, longitude)
                    location?.let {
                        // Handle the location data here (e.g., display the address, place name, etc.)
                        val address = it.getAddressLine(0)
                        val city = it.locality
                        val country = it.countryName
                        Log.w(
                            "msg",
                            "getLastKnownLocation: address: $address and city: $city and country: $country"
                        )

                        var msg = binding.message.text.toString()
                        msg += address
                        msg += "\nhttps://maps.google.com/?q=$latitude,$longitude"

                        binding.message.apply {
                            setText(msg)
                            setSelection(msg.length ?: 0)
                            requestFocus()
                        }

                    }
                } else {
                    Toast.makeText(this@ComposeActivity, "error_location", Toast.LENGTH_SHORT)
                        .show()
                    // Location is null, handle accordingly (e.g., show an error message, request location updates)
                }
            }.addOnFailureListener { exception ->
                // Handle failure, such as if the location services are disabled or the device doesn't have the necessary features
                Log.w("msg", "getLastKnownLocation: exception" + exception.message)
            }
        } catch (e: SecurityException) {
            // Handle exception (e.g., show a message to the user that location access is not granted)
            e.printStackTrace()
        }
    }

    private fun getLocationFromLatLng(latitude: Double, longitude: Double): Address? {
        val geocoder = Geocoder(this, Locale.getDefault())
        val addresses: List<Address> = geocoder.getFromLocation(latitude, longitude, 1)!!
        return if (addresses.isNotEmpty()) addresses[0] else null
    }

    override fun setDraft(draft: String) {
        binding.message.setText(draft)
        binding.message.setSelection(draft.length)
    }

    override fun scrollToMessage(id: Long) {
        messageAdapter.data?.second
            ?.indexOfLast { message -> message.id == id }
            ?.takeIf { position -> position != -1 }
            ?.let(binding.messageList::scrollToPosition)
    }

//    override fun showSmsPlusSnackbar(message: Int) {
//        Snackbar.make(binding.contentView, message, Snackbar.LENGTH_LONG).run {
//            setAction(R.string.button_more) { viewSmsPlusIntent.onNext(Unit) }
//            setActionTextColor(colors.theme().theme)
//            show()
//        }
//    }

    override fun showDeleteDialog(messages: List<Long>) {
        val count = messages.size
        DeleteMessageDialog()
            .show(
                this,
                getString(R.string.dialog_delete_title),
                resources.getQuantityString(R.plurals.dialog_delete_chat, count, count),
                positiveActionCallback = {
                    confirmDeleteIntent.onNext(messages)
                },
                negativeActionCallback = {

                }
            )

//        val dialog = AlertDialog.Builder(this, R.style.AppThemeDialog)
//            .setTitle(R.string.dialog_delete_title)
//            .setMessage(resources.getQuantityString(R.plurals.dialog_delete_chat, count, count))
//            .setPositiveButton(R.string.button_delete) { _, _ -> confirmDeleteIntent.onNext(messages) }
//            .setNegativeButton(R.string.button_cancel, null)
//            .create()
//
//        dialog.show()
//
//        theme.take(1)
//            .autoDispose(scope())
//            .subscribe { theme ->
//                dialog.getButton(AlertDialog.BUTTON_POSITIVE)?.setTextColor(theme.theme)
//                dialog.getButton(AlertDialog.BUTTON_NEGATIVE)?.setTextColor(theme.theme)
//            }
    }

    override fun showClearCurrentMessageDialog() {
        MessageDialog()
            .show(
                this,
                getString(R.string.dialog_clear_compose_title),
                getString(R.string.dialog_clear_compose),
                getString(R.string.button_clear),
                positiveActionCallback = {
                    clearCurrentMessageIntent.onNext(false)
                },
                negativeActionCallback = {},
                dismissActionCallback = {}
            )

//        val dialog = AlertDialog.Builder(this, R.style.AppThemeDialog)
//            .setTitle(R.string.dialog_clear_compose_title)
//            .setMessage(R.string.dialog_clear_compose)
//            .setPositiveButton(R.string.button_clear) { _, _ ->
//                clearCurrentMessageIntent.onNext(false)
//            }
//            .setNegativeButton(R.string.button_cancel, null)
//            .create()
//        dialog.show()
//        theme.take(1)
//            .autoDispose(scope())
//            .subscribe { theme ->
//                dialog.getButton(AlertDialog.BUTTON_POSITIVE)?.setTextColor(theme.theme)
//                dialog.getButton(AlertDialog.BUTTON_NEGATIVE)?.setTextColor(theme.theme)
//            }
    }

//    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
//        menuInflater.inflate(R.menu.compose, menu)
//        return super.onCreateOptionsMenu(menu)
//    }
//
//    override fun onOptionsItemSelected(item: MenuItem): Boolean {
//        optionsItemIntent.onNext(item.itemId)
//        return true
//    }

    override fun getColoredMenuItems(): List<Int> {
        return super.getColoredMenuItems() + R.id.call
    }

    override fun onCreateContextMenu(
        menu: ContextMenu?,
        v: View?,
        menuInfo: ContextMenu.ContextMenuInfo?
    ) {
        super.onCreateContextMenu(menu, v, menuInfo)
        menuInflater.inflate(R.menu.mms_part_menu, menu)
    }

    override fun onContextItemSelected(item: MenuItem): Boolean {
        super.onContextItemSelected(item)
        contextItemIntent.onNext(item)
        return true
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        if (resultCode != RESULT_OK)
            return

        when (requestCode) {

            ComposeView.TakePhotoRequestCode -> {
                cameraDestination?.let(attachAnyFileSelectedIntent::onNext)
            }

            ComposeView.AttachAFileRequestCode -> {
                data?.clipData?.itemCount
                    ?.let { count -> 0 until count }
                    ?.mapNotNull { i -> data.clipData?.getItemAt(i)?.uri }
                    ?.forEach(attachAnyFileSelectedIntent::onNext)
                    ?: data?.data?.let(attachAnyFileSelectedIntent::onNext)
            }

            ComposeView.AttachContactRequestCode -> {
                data?.data?.let(contactSelectedIntent::onNext)
            }

            else -> super.onActivityResult(requestCode, resultCode, data)
        }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        outState.putParcelable(ComposeView.CameraDestinationKey, cameraDestination)
        super.onSaveInstanceState(outState)
    }

    override fun onRestoreInstanceState(savedInstanceState: Bundle) {
        cameraDestination = savedInstanceState.getParcelable(ComposeView.CameraDestinationKey)
        super.onRestoreInstanceState(savedInstanceState)
    }

//    override fun onBackPressed() = backPressedIntent.onNext(Unit)

    override fun focusMessage() {
        binding.message.requestFocus()
    }

    private fun tintDialogButtons(dialog: android.app.AlertDialog) {
        dialog.setOnShowListener {
            val color =
                resolveThemeColor(android.R.attr.textColorPrimary, colors.theme().textPrimary)
            listOf(
                DialogInterface.BUTTON_POSITIVE,
                DialogInterface.BUTTON_NEGATIVE,
                DialogInterface.BUTTON_NEUTRAL
            ).forEach { type ->
                dialog.getButton(type)?.setTextColor(color)
            }
        }
    }

    private fun showDrawerMenu(hasSelection: Boolean, anchorView: View) {
        if (hasSelection) {
            popupWindow.showFromTopRight(anchorView)
        } else {
            optionsItemIntent.onNext(menuBinding.info.id).let { true }; popupWindow.dismiss()
        }
    }

}
