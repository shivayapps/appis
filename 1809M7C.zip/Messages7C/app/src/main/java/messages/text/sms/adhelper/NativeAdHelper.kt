package messages.text.sms.adhelper

import android.annotation.SuppressLint
import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Color
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.RatingBar
import android.widget.TextView
import messages.text.sms.R
import androidx.constraintlayout.widget.ConstraintLayout

import com.facebook.shimmer.ShimmerFrameLayout
import com.google.android.gms.ads.nativead.MediaView
import com.google.android.gms.ads.*
import com.google.android.gms.ads.nativead.*
import messages.text.sms.extensions.baseConfig
import messages.text.sms.extensions.isOnline
import java.lang.Exception
import kotlin.contracts.ExperimentalContracts
import kotlin.contracts.contract

enum class NativeLayoutType {
    NativeBanner,
    NativeMedium,
    NativeBig,
}

class NativeAdHelper(
    private val mContext: Context,
    private val frameLayout: FrameLayout,
    private val mLayoutType: NativeLayoutType? = NativeLayoutType.NativeMedium,
    private val mAdId: String,
    private val isAdLoaded: (isLoaded: Boolean) -> Unit = {}
) {

    val TAG = "ADCONFIG_NativeAdHelper"

    private var mLayout: Int = R.layout.layout_google_native_ad_banner
    private var mShimmerLayout: Int = R.layout.layout_shimmer_google_native_ad_banner
    private var mShimmerView: ShimmerFrameLayout? = null

    private lateinit var adView: NativeAdView

    private var isDestroyed = false

    fun loadAd() {
        try {
            when (mLayoutType) {
                NativeLayoutType.NativeBanner -> {//banner
                    mLayout = R.layout.layout_google_native_ad_banner
                    mShimmerLayout = R.layout.layout_shimmer_google_native_ad_banner
                }

                NativeLayoutType.NativeMedium -> {//medium
                    mLayout = R.layout.layout_google_native_ad_medium
                    mShimmerLayout = R.layout.layout_shimmer_google_native_ad_medium
                }

                NativeLayoutType.NativeBig -> {//big
                    mLayout = R.layout.layout_google_native_ad_bigg
                    mShimmerLayout = R.layout.layout_shimmer_google_native_ad_big
                }

                else -> {
                    mLayout = R.layout.layout_google_native_ad_medium
                    mShimmerLayout = R.layout.layout_shimmer_google_native_ad_medium
                }
            }

        } finally {
//            frameLayout.recycle()
        }

        if (mContext.isOnline()) {

            adView = LayoutInflater.from(mContext).inflate(mLayout, null) as NativeAdView
            val mShimmerLayout =
                LayoutInflater.from(mContext).inflate(mShimmerLayout, null) as ConstraintLayout
            mShimmerView = mShimmerLayout.findViewById(R.id.shimmerView)

            frameLayout.visibility = View.VISIBLE
            frameLayout.removeAllViews()

            frameLayout.addView(mShimmerLayout)
            mShimmerView?.startShimmer()

            val adId = mAdId
            requireNotEmpty(adId) { "Ad Id cannot be empty" }

            loadAdmobNativeAd(adId)
        } else {
            frameLayout.visibility = View.GONE
            isAdLoaded.invoke(false)
        }
    }


    @OptIn(ExperimentalContracts::class)
    inline fun requireNotEmpty(value: String?, lazyMessage: () -> String): String {
        contract {
            returns() implies (value != null)
        }

        if (value == null) {
            val message = lazyMessage()
            throw IllegalArgumentException(message)
        } else {
            return value
        }
    }


    @SuppressLint("MissingPermission")
    private fun loadAdmobNativeAd(adId: String) {

        Log.i("ADCONFIG_NativeAdHelper", "loadAdmobNativeAd.adId:${adId}")
        val videoOptionBuilder = VideoOptions.Builder()
            .setClickToExpandRequested(true)
            .setStartMuted(true)

        val nativeAdOptionsBuilder = NativeAdOptions.Builder()
            .setReturnUrlsForImageAssets(false)
            .setRequestMultipleImages(false)
            .setAdChoicesPlacement(NativeAdOptions.ADCHOICES_TOP_RIGHT)
            .setVideoOptions(videoOptionBuilder.build())
//            .build()
//        val nativeAdOptionsBuilder = NativeAdOptions.Builder()
//            .setVideoOptions(videoOptionBuilder.build())

        val adLoader = AdLoader.Builder(mContext, adId)
            .forNativeAd { nativeAd: NativeAd ->

                if (isDestroyed) {
                    nativeAd.destroy()
                    return@forNativeAd
                }

                populateAdmobNativeAd(nativeAd)
                isAdLoaded.invoke(true)
            }
            .withAdListener(object : AdListener() {
                override fun onAdFailedToLoad(adError: LoadAdError) {
//                    adView.visibility = View.GONE
                    frameLayout.removeAllViews()
                    frameLayout.visibility = View.GONE
                    isAdLoaded.invoke(false)
                    Log.i(
                        TAG,
                        "onAdFailedToLoad: Ad failed to load -> \nresponseInfo::${adError.responseInfo}\nErrorCode::${adError.code}\nErrorMessage::${adError.message}"
                    )
                }
            })
            .withNativeAdOptions(nativeAdOptionsBuilder.build())
            .build()

        Log.d("LoadAd", "loadNativeAd:$adId")
        adLoader.loadAd(AdRequest.Builder().build())
    }

    private fun populateAdmobNativeAd(nativeAd: NativeAd) {
        frameLayout.removeAllViews()
        frameLayout.addView(adView)
        frameLayout.visibility = View.VISIBLE

        val headlineView = adView.findViewById<TextView>(R.id.ad_headline)
        if (headlineView != null) {
            headlineView.text = nativeAd.headline
            adView.headlineView = headlineView
        }

        val bodyView = adView.findViewById<TextView>(R.id.ad_body)
        if (bodyView != null) {
            bodyView.text = nativeAd.body
            adView.bodyView = bodyView
        }

//        val adChoiceView = adView.findViewById<AdChoicesView>(R.id.adChoiceView)
//        if (adChoiceView != null) {
//            adView.adChoicesView = adChoiceView
//        }
//
//        val adPrice = adView.findViewById<TextView>(R.id.ad_price)
//        if (adPrice != null) {
//            adPrice.text = nativeAd.price
//            adView.priceView = adPrice
//        }
//        val adStore = adView.findViewById<TextView>(R.id.ad_store)
//        if (adStore != null) {
//            adStore.text = nativeAd.store
//            adView.storeView = adStore
//        }

        val callToActionView = adView.findViewById<TextView>(R.id.ad_call_to_action)
        callToActionView.backgroundTintList =
            ColorStateList.valueOf(Color.parseColor(mContext.baseConfig.addButtonColor))
        if (callToActionView != null) {
            callToActionView.text = nativeAd.callToAction
            adView.callToActionView = callToActionView
        }

        val adAppIcon = adView.findViewById<ImageView>(R.id.ad_app_icon)
        if (adAppIcon != null && nativeAd.icon != null) {
            adAppIcon.setImageDrawable(nativeAd.icon!!.drawable)
            adView.iconView = adAppIcon
        }

        val adStars = adView.findViewById<RatingBar>(R.id.ad_stars)
        if (adStars != null && nativeAd.starRating != null) {
            adStars.rating = nativeAd.starRating!!.toFloat()
            adView.starRatingView = adStars
        }

        val advertiser = adView.findViewById<TextView>(R.id.ad_advertiser)
        if (advertiser != null) {
            advertiser.text = nativeAd.advertiser
            adView.advertiserView = advertiser
        }

        try {
            val mediaView = adView.findViewById<MediaView>(R.id.ad_media)
            if (mediaView != null) {
                mediaView.visibility = View.VISIBLE
                adView.mediaView = mediaView
                nativeAd.mediaContent?.let {
                    mediaView.mediaContent = it
                }
                mediaView.setImageScaleType(ImageView.ScaleType.FIT_CENTER)
            } else {
            }

        } catch (e: Exception) {
            e.printStackTrace()
        }


        adView.setNativeAd(nativeAd)
    }

}