package messages.text.sms.interactor

import android.annotation.SuppressLint
import android.content.Context
import messages.text.sms.repository.ScheduledMessageRepository
import io.reactivex.Flowable
import android.util.Log
import java.io.File
import javax.inject.Inject

class DeleteScheduledMessages @Inject constructor(
    private val scheduledMessageRepo: ScheduledMessageRepository,
    private val context: Context,
) : Interactor<List<Long>>() {

    @SuppressLint("Range")
    override fun buildObservable(scheduledMessageIds: List<Long>): Flowable<*> {
        return Flowable.just(scheduledMessageIds)
            .map {
                try {
                    // for each message id to delete
                    it.forEach {
                        // recursively delete scheduled message top level dir
                        val topDir = File(context.filesDir, "scheduled-${it}")
                        topDir.exists() && topDir.deleteRecursively()
                    }
                } catch (e: Exception) {
                    Log.d("Timber","Unable to delete scheduled messages.")
                }

                // delete the db entries
                scheduledMessageRepo.deleteScheduledMessages(it)
            }
    }
}
