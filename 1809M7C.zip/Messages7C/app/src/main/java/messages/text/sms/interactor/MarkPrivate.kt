package messages.text.sms.interactor

import io.reactivex.Flowable
import messages.text.sms.repository.ConversationRepository
import javax.inject.Inject

class MarkPrivate @Inject constructor(
    private val conversationRepo: ConversationRepository,
    private val markRead: MarkRead,
) : Interactor<List<Long>>() {

    override fun buildObservable(params: List<Long>): Flowable<*> {
        return Flowable.just(params.toLongArray())
            .doOnNext { threadIds -> conversationRepo.markPrivate(*threadIds) }
            .flatMap { markRead.buildObservable(params) }
    }

}