
package messages.text.sms.common.base

import android.view.View
import androidx.recyclerview.widget.RecyclerView
import androidx.viewbinding.ViewBinding

open class MyViewHolder(view: View) : RecyclerView.ViewHolder(view) {
    val containerView: View = view
}

open class MyBindingViewHolder<T : ViewBinding>(val binding: T) : MyViewHolder(binding.root)
