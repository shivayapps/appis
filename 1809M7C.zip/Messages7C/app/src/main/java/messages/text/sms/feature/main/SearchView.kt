package messages.text.sms.feature.main

import android.content.Intent
import io.reactivex.Observable
import messages.text.sms.common.base.MainBaseMsgView

interface SearchView : MainBaseMsgView<MainState> {

    val onNewIntentIntent: Observable<Intent>
    val onSearchIntent: Observable<String>
    val activityResumedIntent: Observable<Boolean>
    val queryClearedIntent: Observable<*>
    val homeIntent: Observable<*>
    val optionsItemIntent: Observable<Int>
    val confirmDeleteIntent: Observable<List<Long>>
    val undoArchiveIntent: Observable<Unit>
    val snackbarButtonIntent: Observable<Unit>

    fun requestDefaultSms()
    fun requestPermissions()
    fun clearSearch()
    fun clearSelection()
    fun themeChanged()
    fun showBlockingDialog(conversations: List<Long>, block: Boolean,isTrue:(Boolean)->Unit)
    fun showDeleteDialog(conversations: List<Long>)
    fun showArchivedSnackbar()
}

