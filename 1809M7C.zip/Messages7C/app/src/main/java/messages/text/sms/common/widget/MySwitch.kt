package messages.text.sms.common.widget

import android.content.Context
import android.content.res.ColorStateList
import android.util.AttributeSet
import androidx.appcompat.widget.SwitchCompat
import androidx.core.content.ContextCompat
import messages.text.sms.R
import messages.text.sms.common.util.Colors
import messages.text.sms.extensions.resolveThemeColor
import messages.text.sms.extensions.withAlpha
import messages.text.sms.injection.appComponent
import messages.text.sms.util.Preferences
import javax.inject.Inject

class MySwitch @JvmOverloads constructor(context: Context, attrs: AttributeSet? = null) :
    SwitchCompat(context, attrs) {

    @Inject
    lateinit var colors: Colors
    @Inject
    lateinit var prefs: Preferences

    init {
        if (!isInEditMode) {
            appComponent.inject(this)
        }
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()

        if (!isInEditMode) {
            val states = arrayOf(
                intArrayOf(-android.R.attr.state_enabled),
                intArrayOf(android.R.attr.state_checked),
                intArrayOf()
            )

            thumbTintList = ColorStateList(
                states,
                intArrayOf(
                    ContextCompat.getColor(context, R.color.switchThumbDisabled),
                    ContextCompat.getColor(context, R.color.switchThumbEnabled),
                    ContextCompat.getColor(context, R.color.switchThumbEnabled)
                )
            )

            trackTintList = ColorStateList(
                states,
                intArrayOf(
                    ContextCompat.getColor(context, R.color.switchTrackDisabled),
                    ContextCompat.getColor(context, R.color.switchTrackEnabled),
                    ContextCompat.getColor(context, R.color.switchTrackDisabled)
                )
            )

//            thumbTintList = ColorStateList(
//                states, intArrayOf(
//                    context.resolveThemeColor(R.attr.switchThumbDisabled),
//                    colors.theme().theme,
//                    context.resolveThemeColor(R.attr.switchThumbEnabled)
//                )
//            )
//
//            trackTintList = ColorStateList(
//                states, intArrayOf(
//                    context.resolveThemeColor(R.attr.switchTrackDisabled),
//                    colors.theme().theme,//.withAlpha(0x4D),
//                    context.resolveThemeColor(R.attr.switchTrackEnabled)
//                )
//            )
        }
    }
}