package messages.text.sms.after_call.adapter

import android.content.Context
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import messages.text.sms.R

import android.widget.EditText
import androidx.core.content.ContextCompat
import androidx.core.widget.doOnTextChanged
import messages.text.sms.extensions.beGone
import messages.text.sms.extensions.beVisible

class AfterCallMessageAdapter(
    private val mContext: Context,
    private val items: List<String>,
    private val onClick: (Int) -> Unit,
    private val onSend: (Int) -> Unit,
    private val onSave: (Int, String) -> Unit,
) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {
    var selectPos = 0

    companion object {
        private const val TYPE_MESSAGE = 0
        private const val TYPE_EDIT = 1
    }

    // Standard message item view holder
    class MessageVH(view: View) : RecyclerView.ViewHolder(view) {
        val text: TextView = view.findViewById(R.id.title)
        val radioView: ImageView = view.findViewById(R.id.radioView)
        val send: ImageView = view.findViewById(R.id.send)
    }

    // Last item view holder containing the EditText and Save button
    class EditVH(view: View) : RecyclerView.ViewHolder(view) {
        val editText: EditText =
            view.findViewById(R.id.edit_text_message) // Replace with your actual ID
        val saveButton: ImageView =
            view.findViewById(R.id.save)          // Replace with your actual ID
    }

    // Determine the view type based on position
    override fun getItemViewType(position: Int): Int {
        return if (position == items.size - 1) TYPE_EDIT else TYPE_MESSAGE
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        val inflater = LayoutInflater.from(parent.context)
        return if (viewType == TYPE_EDIT) {
            // Replace with your actual layout resource for the edit item
            val view = inflater.inflate(R.layout.list_item_quick_message_edit, parent, false)
            EditVH(view)
        } else {
            val view = inflater.inflate(R.layout.list_item_quick_message, parent, false)
            MessageVH(view)
        }
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        if (holder is MessageVH) {
            holder.text.text = items[position]

            if (selectPos == position) {
                holder.send.beVisible()
                holder.radioView.setImageDrawable(
                    ContextCompat.getDrawable(
                        mContext,
                        R.drawable.ic_radio_button_selected
                    )
                )
            } else {
                holder.send.beGone()
                holder.radioView.setImageDrawable(
                    ContextCompat.getDrawable(
                        mContext,
                        R.drawable.ic_radio_button_unchecked
                    )
                )
            }

            holder.itemView.setOnClickListener {
                val p = selectPos
                selectPos = position
                val pos = holder.bindingAdapterPosition
                if (pos != RecyclerView.NO_POSITION) onClick(pos)

                notifyItemChanged(selectPos)
                if (p != -1)
                    notifyItemChanged(p)
            }

            holder.send.setOnClickListener {
                val pos = holder.bindingAdapterPosition
                if (pos != RecyclerView.NO_POSITION) onSend(pos)
            }

        } else if (holder is EditVH) {
            //holder.editText.setText(items[position])
//            holder.editText.setOnFocusChangeListener { _, hasFocus ->
//                if (hasFocus) {
//                    // Keyboard is about to show
//                    Log.d("Keyboard", "Keyboard opened")
//                    //onKeyboardOpen()
//                    onKeyboard.invoke(true)
//                } else {
//                    // Keyboard is about to hide
//                    Log.d("Keyboard", "Keyboard closed")
//                    //onKeyboardClose()
//                    onKeyboard.invoke(false)
//                }
//            }

            holder.editText.doOnTextChanged { text, start, before, count ->
                if (text.toString().trim().isNotEmpty()) {
                    holder.saveButton.beVisible()
                } else {
                    holder.saveButton.beGone()
                }
            }
            holder.saveButton.setOnClickListener {
                val pos = holder.bindingAdapterPosition
                if (pos != RecyclerView.NO_POSITION) {
                    val typedText = holder.editText.text.toString()
                    onSave(pos, typedText)
                    holder.editText.setText("")
                }
            }
        }
    }

    override fun getItemCount() = items.size

}