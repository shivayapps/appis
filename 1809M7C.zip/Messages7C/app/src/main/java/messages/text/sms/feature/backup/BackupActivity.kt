
package messages.text.sms.feature.backup

import android.os.Bundle
import androidx.activity.addCallback
import com.bluelinelabs.conductor.Conductor
import com.bluelinelabs.conductor.Router
import com.bluelinelabs.conductor.RouterTransaction
import dagger.android.AndroidInjection
import messages.text.sms.common.base.MainBaseThemedActivity
import messages.text.sms.databinding.ContainerActivityBinding


class BackupActivity :
    MainBaseThemedActivity<ContainerActivityBinding>(ContainerActivityBinding::inflate) {

    private lateinit var router: Router

    override fun onCreate(savedInstanceState: Bundle?) {
        AndroidInjection.inject(this)
        super.onCreate(savedInstanceState)

        router = Conductor.attachRouter(this, binding.container, savedInstanceState)
        if (!router.hasRootController()) {
            router.setRoot(RouterTransaction.with(BackupController()))
        }
        binding.ivBack.setOnClickListener {
            onBackPressedDispatcher.onBackPressed()
        }
        onBackPressedDispatcher.addCallback(this) {
            if (!router.handleBack()) {
                isEnabled = false
                onBackPressedDispatcher.onBackPressed()
            }
        }
    }

//    override fun onBackPressed() {
//        if (!router.handleBack()) {
//            super.onBackPressed()
//        }
//    }

}
