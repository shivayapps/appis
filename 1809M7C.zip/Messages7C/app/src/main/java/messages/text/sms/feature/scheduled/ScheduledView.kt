
package messages.text.sms.feature.scheduled

import messages.text.sms.common.base.MainBaseMsgView
import io.reactivex.Observable

interface ScheduledView : MainBaseMsgView<ScheduledState> {

    val composeIntent: Observable<*>
//    val upgradeIntent: Observable<*>
    val messagesSelectedIntent: Observable<List<Long>>
    val optionsItemIntent: Observable<Int>
    val deleteScheduledMessages: Observable<List<Long>>
    val sendScheduledMessages: Observable<List<Long>>
    val editScheduledMessage: Observable<Long>
    val backPressedIntent: Observable<Unit>

    fun clearSelection()
    fun toggleSelectAll()
    fun showDeleteDialog(messages: List<Long>)
    fun showSendNowDialog(messages: List<Long>)
    fun showEditMessageDialog(message: Long)
    fun finishActivity()

}
