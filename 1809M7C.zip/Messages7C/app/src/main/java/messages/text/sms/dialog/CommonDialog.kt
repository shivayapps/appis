package messages.text.sms.dialog

import android.app.Activity
import android.app.AlertDialog
import android.app.Dialog
import android.content.Context
import android.util.TypedValue
import androidx.core.content.ContextCompat
import io.reactivex.subjects.PublishSubject
import io.reactivex.subjects.Subject
import messages.text.sms.R

class CommonDialog(val context: Context) {

    val moreClicks: Subject<Unit> = PublishSubject.create()

    fun show(
        activity: Activity,
        title: String,
        message: String,
        positive: String,
        negative: String,
        neutral: String,
        onPositive: () -> Unit = {},
        onNegative: () -> Unit = {},
        onNeutral: () -> Unit = {},
        onDialogClose: () -> Unit = {},
        cancelable: Boolean = true
    ) {
        val alertDialog = AlertDialog.Builder(activity, R.style.FontMyOptionDialogTheme)
        if (title.isNotEmpty()) {
            alertDialog.setTitle(title)
        }
        alertDialog.setMessage(message)
        if (positive.isNotEmpty()) {
            alertDialog.setPositiveButton(positive) { _, _ ->
                onPositive()
            }
        }
        if (negative.isNotEmpty()) {
            alertDialog.setNegativeButton(negative) { _, _ ->
                onNegative()
            }
        }
        if (neutral.isNotEmpty()) {
            alertDialog.setNeutralButton(neutral) { _, _ ->
                onNeutral()
            }
        }
        alertDialog.setOnCancelListener {
            onDialogClose()
        }
        alertDialog.setCancelable(cancelable)
        alertDialog.show().apply {
            if (neutral.isNotEmpty()) {
                getButton(Dialog.BUTTON_NEUTRAL)?.setTextColor(
                    ContextCompat.getColor(
                        activity, R.color.textPrimary
                    )
                )
                getButton(Dialog.BUTTON_NEUTRAL)?.setTextSize(TypedValue.COMPLEX_UNIT_SP, 18F)
            }
            if (negative.isNotEmpty()) {
                getButton(Dialog.BUTTON_NEGATIVE)?.setTextColor(
                    ContextCompat.getColor(
                        activity, R.color.textPrimary
                    )
                )
                getButton(Dialog.BUTTON_NEGATIVE)?.setTextSize(TypedValue.COMPLEX_UNIT_SP, 18F)
            }
            if (positive.isNotEmpty()) {
                getButton(Dialog.BUTTON_POSITIVE)?.setTextColor(
                    ContextCompat.getColor(
                        activity, R.color.textPrimary
                    )
                )
                getButton(Dialog.BUTTON_POSITIVE)?.setTextSize(TypedValue.COMPLEX_UNIT_SP, 18F)
            }
        }
    }


}