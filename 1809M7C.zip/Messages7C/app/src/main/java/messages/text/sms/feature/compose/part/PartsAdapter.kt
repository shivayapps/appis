
package messages.text.sms.feature.compose.part

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import io.reactivex.Observable
import messages.text.sms.R
import messages.text.sms.common.base.MyViewHolder
import messages.text.sms.common.util.Colors
import messages.text.sms.common.widget.MyContextMenuRecyclerView
import messages.text.sms.extensions.isSmil
import messages.text.sms.extensions.isText
import messages.text.sms.feature.compose.BubbleUtils.canGroup
import messages.text.sms.feature.compose.MessagesAdapter
import messages.text.sms.model.Message
import messages.text.sms.model.MmsPart
import javax.inject.Inject


class PartsAdapter @Inject constructor(
    colors: Colors,
    fileBinder: FileBinder,
    imageBinder: ImageBinder,
    audioBinder: AudioBinder,
    vCardBinder: VCardBinder,
) : MyContextMenuRecyclerView.Adapter<Long, MmsPart, MyContextMenuRecyclerView.ViewHolder<MmsPart>>() {

    private val partBinders = listOf(audioBinder, imageBinder, vCardBinder, fileBinder)

    var theme: Colors.Theme = colors.theme()
        set(value) {
            field = value
            partBinders.forEach { binder -> binder.theme = value }
        }

    val clicks: Observable<Long> = Observable.merge(partBinders.map { it.clicks })

    private lateinit var message: Message
    private var previous: Message? = null
    private var next: Message? = null
    private var bodyVisible: Boolean = true
    private var audioState: MessagesAdapter.AudioState? = null

    fun setData(
        message: Message,
        previous: Message?,
        next: Message?,
        holder: MyViewHolder,
        audioState: MessagesAdapter.AudioState?
    ) {
        this.message = message
        this.previous = previous
        this.next = next
        this.bodyVisible =
            holder.containerView.findViewById<View>(R.id.body)?.visibility == View.VISIBLE
        this.data = message.parts.filter { !it.isSmil() && !it.isText() }
        this.audioState = audioState
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int)
            : MyContextMenuRecyclerView.ViewHolder<MmsPart> {
        val layout = partBinders.getOrNull(viewType)?.partLayout ?: 0
        val view = LayoutInflater.from(parent.context).inflate(layout, parent, false)
        return MyContextMenuRecyclerView.ViewHolder(view)
    }

    override fun onBindViewHolder(
        holder: MyContextMenuRecyclerView.ViewHolder<MmsPart>,
        position: Int
    ) {
        val part = data[position]

        holder.contextMenuValue = part

        val canGroupWithPrevious = canGroup(message, previous) || position > 0
        val canGroupWithNext = canGroup(message, next) || position < itemCount - 1 || bodyVisible

        val binder = partBinders.firstOrNull { it.canBindPart(part) }
        if (binder == null)
            return

        // if audioState is set and binder is audio type, set it's audioState ref
        if ((audioState != null) && (binder is AudioBinder))
            binder.audioState = audioState!!

        binder.bindPart(holder, part, message, canGroupWithPrevious, canGroupWithNext)
    }

    override fun getItemViewType(position: Int): Int {
        return partBinders.indexOfFirst { it.canBindPart(data[position]) }
    }

}
