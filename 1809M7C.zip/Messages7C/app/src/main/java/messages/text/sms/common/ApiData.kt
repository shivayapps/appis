package messages.text.sms.common

import androidx.annotation.Keep

@Keep
data class ApiData(
    var bannerId: String = "",
    var nativeId: String = "",
    var interstialId: String = "",
    var appopenId: String = "",
    var rewardId: String = "",
    var addButtonColor: String = "#7462FF",
)