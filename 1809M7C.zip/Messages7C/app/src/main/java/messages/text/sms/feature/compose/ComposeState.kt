
package messages.text.sms.feature.compose

import io.realm.RealmResults
import messages.text.sms.compat.SubscriptionInfoCompat
import messages.text.sms.model.Attachment
import messages.text.sms.model.Conversation
import messages.text.sms.model.Message
import messages.text.sms.model.Recipient

data class ComposeState(
    val hasError: Boolean = false,
    val editingMode: Boolean = false,
    val threadId: Long = 0,
    val selectedChips: List<Recipient> = ArrayList(),
    val sendAsGroup: Boolean = true,
    val conversationtitle: String = "",
    val loading: Boolean = false,
    val query: String = "",
    val searchSelectionId: Long = -1,
    val searchSelectionPosition: Int = 0,
    val searchResults: Int = 0,
    val messages: Pair<Conversation, RealmResults<Message>>? = null,
    val selectedMessages: Int = 0,
    val selectedMessagesHaveText: Boolean = false,
    val scheduled: Long = 0,
    val attachments: List<Attachment> = listOf(),
    val attaching: Boolean = false,
    val scheduling: Boolean = false,
    val remaining: String = "",
    val subscription: SubscriptionInfoCompat? = null,
    val canSend: Boolean = false,
    val hasScheduledMessages: Boolean = false,
    val validRecipientNumbers: Int = 1,
    val audioMsgRecording: Boolean = false,
    val saveDraft: Boolean = true,
)