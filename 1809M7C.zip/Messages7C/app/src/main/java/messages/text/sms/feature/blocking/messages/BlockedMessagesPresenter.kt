
package messages.text.sms.feature.blocking.messages

import com.uber.autodispose.android.lifecycle.scope
import com.uber.autodispose.autoDispose
import messages.text.sms.R
import messages.text.sms.feature.blocking.BlockingClient
import messages.text.sms.common.Navigator
import messages.text.sms.common.base.MyPresenter
import messages.text.sms.interactor.DeleteConversations
import messages.text.sms.repository.ConversationRepository
import javax.inject.Inject

class BlockedMessagesPresenter @Inject constructor(
    conversationRepo: ConversationRepository,
    private val blockingClient: BlockingClient,
    private val deleteConversations: DeleteConversations,
    private val navigator: Navigator
) : MyPresenter<BlockedMessagesView, BlockedMessagesState>(BlockedMessagesState(
        data = conversationRepo.getBlockedConversationsAsync()
)) {

    override fun bindIntents(view: BlockedMessagesView) {
        super.bindIntents(view)

        view.menuReadyIntent
            .autoDispose(view.scope())
            .subscribe { newState { copy() } }

        view.optionsItemIntent
            .withLatestFrom(view.selectionChanges) { itemId, conversations ->
                when (itemId) {
                    R.id.block -> {
                        view.showBlockingDialog(conversations, false)
                        view.clearSelection()
                    }

                    R.id.delete -> {
                        view.showDeleteDialog(conversations)
                    }
                }

            }
            .autoDispose(view.scope())
            .subscribe()

        view.confirmDeleteIntent
            .autoDispose(view.scope())
            .subscribe { conversations ->
                deleteConversations.execute(conversations)
                view.clearSelection()
            }

        view.conversationClicks
            .autoDispose(view.scope())
            .subscribe { threadId -> navigator.showConversation(threadId) }

        view.selectionChanges
            .autoDispose(view.scope())
            .subscribe { selection -> newState { copy(selected = selection.size) } }

        view.backClicked
            .withLatestFrom(state) { _, state ->
                when (state.selected) {
                    0 -> view.goBack()
                    else -> view.clearSelection()
                }
            }
            .autoDispose(view.scope())
            .subscribe()
    }

}
