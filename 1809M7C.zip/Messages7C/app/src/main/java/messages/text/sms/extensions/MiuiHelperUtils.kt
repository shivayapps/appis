package messages.text.sms.extensions

import android.app.AppOpsManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Process
import android.provider.Settings
import android.util.Log
import messages.text.sms.BuildConfig


object MiuiHelperUtils {

    fun isMiui(): Boolean {
        val manufacturer = Build.MANUFACTURER.lowercase()
        return manufacturer.contains("xiaomi") ||
                manufacturer.contains("redmi") ||
                manufacturer.contains("poco")
    }

    /**
     * Check if AutoStart permission is enabled for the app
     */
    fun isAutoStartEnabled(context: Context): Boolean {
        Log.e("MiuiHelper", "isAutoStartEnabled")
        if (!isMiui()) return true

        return try {
            // Method 1: Check using AppOps for auto-start specific operation
            val appOps = context.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
            val opCode = 10008 // OP_AUTO_START for MIUI

            val method = AppOpsManager::class.java.getDeclaredMethod(
                "checkOpNoThrow",
                Int::class.javaPrimitiveType,
                Int::class.javaPrimitiveType,
                String::class.java
            )

            val result = method.invoke(
                appOps,
                opCode,
                Process.myUid(),
                BuildConfig.APPLICATION_ID
            ) as Int

            result == AppOpsManager.MODE_ALLOWED
        } catch (e: Exception) {
            // Method 2: Fallback - Check if app can receive boot completed
            checkAutoStartAlternative(context)
        }
    }

    private fun checkAutoStartAlternative(context: Context): Boolean {
        Log.e("MiuiHelper", "checkAutoStartAlternative")
        return try {
            val pm = context.packageManager
            val permission = "android.permission.RECEIVE_BOOT_COMPLETED"
            pm.checkPermission(
                permission,
                BuildConfig.APPLICATION_ID
            ) == PackageManager.PERMISSION_GRANTED
        } catch (e: Exception) {
            Log.e("MiuiHelper", "checkAutoStartAlternative.Exception:$e")
            // Method 3: Check if app is in auto-start list using content provider
            checkAutoStartViaProvider(context)
        }
    }

    private fun checkAutoStartViaProvider(context: Context): Boolean {
        Log.e("MiuiHelper", "checkAutoStartViaProvider")
        return try {
            val uri = Uri.parse("content://com.miui.securitycenter.provider/autostart")
            val cursor = context.contentResolver.query(
                uri,
                null,
                "package_name=?",
                arrayOf(BuildConfig.APPLICATION_ID),
                null
            )

            cursor?.use {
                if (it.moveToFirst()) {
                    val enabled = it.getInt(it.getColumnIndex("enabled"))
                    return enabled == 1
                }
            }
            false
        } catch (e: Exception) {
            Log.e("MiuiHelper", "checkAutoStartViaProvider.Exception:$e")
            // If all methods fail, assume not enabled
            false
        }
    }

    /**
     * Opens the DIRECT Auto-Start settings page for the app.
     */
    fun openAutoStartSettings(context: Context): Intent? {
        Log.e("MiuiHelper", "openAutoStartSettings")
        val autoStartIntent = Intent().apply {
            component = ComponentName(
                "com.miui.securitycenter",
                "com.miui.permcenter.autostart.AutoStartManagementActivity"
            )
            putExtra("package_name", BuildConfig.APPLICATION_ID)
            putExtra("extra_pkgname", BuildConfig.APPLICATION_ID)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }

        try {
            context.startActivity(autoStartIntent)
            return autoStartIntent
        } catch (e: Exception) {
            Log.e("MiuiHelper", "openAutoStartSettings.Exception:$e")
            // Try alternative activity
//            return tryAlternativeAutoStartActivity(context)
            return null
        }
    }

    private fun tryAlternativeAutoStartActivity(context: Context): Boolean {
        Log.e("MiuiHelper", "tryAlternativeAutoStartActivity")
        val alternativeIntents = listOf(
            // Alternative MIUI 12+ activity
            Intent().apply {
                component = ComponentName(
                    "com.miui.securitycenter",
                    "com.miui.permcenter.autostart.CustomAutoStartManagementActivity"
                )
                putExtra("extra_pkgname", BuildConfig.APPLICATION_ID)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            },
            // MIUI 13+ activity
            Intent().apply {
                component = ComponentName(
                    "com.miui.securitycenter",
                    "com.miui.appmanager.ApplicationsDetailsActivity"
                )
                putExtra("package_name", BuildConfig.APPLICATION_ID)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
        )

        for (intent in alternativeIntents) {
            try {
                context.startActivity(intent)
                return true
            } catch (e: Exception) {
                Log.e("MiuiHelper", "tryAlternativeAutoStartActivity.Exception:$e")
                continue
            }
        }

        return false
    }


    private const val OP_BACKGROUND_START_ACTIVITY = 10021


    fun isBgStartAllowed(context: Context): Boolean {
        Log.e("MiuiHelper", "isBgStartAllowed")
        if (!isMiui()) {
            return true
        }

        return try {
            val appOpsManager = context.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
            val method = appOpsManager.javaClass.getDeclaredMethod(
                "checkOpNoThrow",
                Int::class.javaPrimitiveType,
                Int::class.javaPrimitiveType,
                String::class.java
            )
            method.isAccessible = true

            val result = method.invoke(
                appOpsManager,
                OP_BACKGROUND_START_ACTIVITY,
                Process.myUid(),
                BuildConfig.APPLICATION_ID
            ) as Int

            result == AppOpsManager.MODE_ALLOWED
        } catch (e: Exception) {
            Log.e("MiuiHelper", "isBgStartAllowed.Exception:$e")
            true // Fail open
        }
    }

    /**
     * Opens the MIUI Permission Editor where Background Pop-up can be enabled.
     * There's no direct activity for Background Pop-up, so we use the permission editor.
     */
    fun openBgStartSettings(context: Context): Boolean {
        Log.e("MiuiHelper", "openBgStartSettings")
        val intents = listOf(
            // MIUI Permission Editor (shows all permissions including Background Pop-up)
            Intent("miui.intent.action.APP_PERM_EDITOR")
                .setClassName(
                    "com.miui.securitycenter",
                    "com.miui.permcenter.permissions.PermissionsEditorActivity"
                )
                .putExtra("extra_pkgname", BuildConfig.APPLICATION_ID),
            //.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)


            // Alternative MIUI permission screen
            Intent("miui.intent.action.APP_PERM_EDITOR")
                .setClassName(
                    "com.miui.securitycenter",
                    "com.miui.permcenter.permissions.AppPermissionsEditorActivity"
                )
                .putExtra("extra_pkgname", BuildConfig.APPLICATION_ID)
            //.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        )


        Log.e("MiuiHelper", "openBgStartSettings.intents:${intents.size}")
        for (intent in intents) {
            try {
                context.startActivity(intent)
                return true
            } catch (e: Exception) {
                Log.e("MiuiHelper", "openBgStartSettings.Exception.001:$e")
                // Try next intent
                return false
            }
        }

        // Fallback to App Settings
        try {
            val intent = Intent(
                Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                Uri.parse("package:" + BuildConfig.APPLICATION_ID)
            )
            intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
            context.startActivity(intent)
            return true
        } catch (e: Exception) {
            Log.e("MiuiHelper", "openBgStartSettings.Exception.002:$e")
            return false
        }
    }
}
