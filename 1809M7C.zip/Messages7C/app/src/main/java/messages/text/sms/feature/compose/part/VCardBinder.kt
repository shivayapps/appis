
package messages.text.sms.feature.compose.part

import android.content.Context
import androidx.core.view.isVisible
import ezvcard.Ezvcard
import io.reactivex.Observable
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.schedulers.Schedulers
import messages.text.sms.R
import messages.text.sms.common.base.MyViewHolder
import messages.text.sms.common.util.Colors
import messages.text.sms.extensions.getDisplayName
import messages.text.sms.extensions.resolveThemeColor
import messages.text.sms.extensions.setBackgroundTint
import messages.text.sms.extensions.setTint
import messages.text.sms.databinding.MmsVcardListItemBinding
import messages.text.sms.extensions.isVCard
import messages.text.sms.extensions.mapNotNull
import messages.text.sms.feature.compose.BubbleUtils
import messages.text.sms.model.Message
import messages.text.sms.model.MmsPart
import javax.inject.Inject

class VCardBinder @Inject constructor(colors: Colors, private val context: Context) : PartBinder() {

    override val partLayout = R.layout.mms_vcard_list_item
    override var theme = colors.theme()

    override fun canBindPart(part: MmsPart) = part.isVCard()

    override fun bindPart(
        holder: MyViewHolder,
        part: MmsPart,
        message: Message,
        canGroupWithPrevious: Boolean,
        canGroupWithNext: Boolean
    ) {
        val binding = MmsVcardListItemBinding.bind(holder.containerView)

        BubbleUtils.getBubble(false, canGroupWithPrevious, canGroupWithNext, message.isMe())
            .let(binding.vCardBackground::setBackgroundResource)

        holder.containerView.setOnClickListener { clicks.onNext(part.id) }

        Observable.just(part.getUri())
            .map(context.contentResolver::openInputStream)
            .mapNotNull { inputStream -> inputStream.use { Ezvcard.parse(it).first() } }
            .map { vcard -> vcard.getDisplayName() ?: "" }
            .subscribeOn(Schedulers.computation())
            .observeOn(AndroidSchedulers.mainThread())
            .subscribe { displayName ->
                binding.name?.text = displayName
                binding.name.isVisible = displayName.isNotEmpty()
            }

        if (!message.isMe()) {
            binding.vCardBackground.setBackgroundTint(theme.theme)
            binding.vCardAvatar.setTint(theme.textPrimary)
            binding.name.setTextColor(theme.textPrimary)
            binding.label.setTextColor(theme.textTertiary)
        } else {
            binding.vCardBackground.setBackgroundTint(
                holder.containerView.context.resolveThemeColor(
                    R.attr.bubbleColor
                )
            )
            binding.vCardAvatar.setTint(holder.containerView.context.resolveThemeColor(android.R.attr.textColorSecondary))
            binding.name.setTextColor(holder.containerView.context.resolveThemeColor(android.R.attr.textColorPrimary))
            binding.label.setTextColor(holder.containerView.context.resolveThemeColor(android.R.attr.textColorTertiary))
        }
    }

}
