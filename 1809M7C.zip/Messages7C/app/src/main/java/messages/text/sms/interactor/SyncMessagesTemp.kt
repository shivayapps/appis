package messages.text.sms.interactor

import io.reactivex.Flowable
import messages.text.sms.repository.SyncRepository
import android.util.Log
import java.util.concurrent.TimeUnit
import javax.inject.Inject

class SyncMessagesTemp @Inject constructor(
    private val syncManager: SyncRepository,
    private val updateBadge: UpdateBadge,
) : Interactor<Unit>() {

    override fun buildObservable(params: Unit): Flowable<*> {
        return Flowable.just(System.currentTimeMillis())
            .doOnNext { syncManager.syncMessagesTemp() }
            .map { startTime -> System.currentTimeMillis() - startTime }
            .map { elapsed -> TimeUnit.MILLISECONDS.toSeconds(elapsed) }
            .doOnNext { seconds -> Log.d("Timber","Completed sync in $seconds seconds") }
            .flatMap { updateBadge.buildObservable(Unit) } // Update the badge
    }

}