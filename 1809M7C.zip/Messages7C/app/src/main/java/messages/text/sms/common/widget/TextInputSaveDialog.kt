package messages.text.sms.common.widget

import android.app.Activity
import android.content.Context
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.LayoutInflater
import android.view.Window
import android.view.WindowManager
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.core.widget.doOnTextChanged
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.MainScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import messages.text.sms.R
import messages.text.sms.common.base.MainBaseThemedActivity
import messages.text.sms.databinding.TextInputSaveDialogBinding
import messages.text.sms.extensions.dismissKeyboard
import messages.text.sms.extensions.showKeyboard
import messages.text.sms.interactor.DeleteConversations
import messages.text.sms.repository.ConversationRepository
import messages.text.sms.util.Preferences
import javax.inject.Inject


class TextInputSaveDialog @Inject constructor(context: Activity) {

    fun show(
        activity: Activity,
        hint: String,
        listener: (String) -> Unit
    ) = GlobalScope.launch {
        showDialog(activity, hint, listener)
    }

    var msg = ""
    private val binding = TextInputSaveDialogBinding.inflate(LayoutInflater.from(context))
    private suspend fun showDialog(
        activity: Activity,
        hint: String,
        listener: (String) -> Unit
    ) = withContext(MainScope().coroutineContext) {
        binding.titleText.text = hint
        val dialog = AlertDialog.Builder(activity)
            .setView(binding.root)
            .setCancelable(true)
            .create()
        binding.btnPositive.setOnClickListener {
            if (msg.isNotEmpty()) {
                listener(binding.field.text.toString())
                dialog.dismiss()
            } else {
                Toast.makeText(activity, "Please enter text", Toast.LENGTH_SHORT).show()
            }
        }
        binding.ivClose.setOnClickListener {
            dialog.dismiss()
        }
        activity.dismissKeyboard()
        Handler(Looper.myLooper()!!).postDelayed({
            binding.field.requestFocus()
            binding.field.showKeyboard()
            binding.field.setText(msg)
        }, 500)

        binding.field.doOnTextChanged { text, start, before, count ->
            msg = text.toString().trim()
            if (msg.isEmpty()) {
                binding.btnPositive.alpha = 0.5f
            } else {
                binding.btnPositive.alpha = 1.0f
            }
        }

        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.window?.apply {
            setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            setGravity(Gravity.CENTER)
            setDimAmount(0.8f)
            attributes?.windowAnimations = android.R.style.Animation_Dialog
            setLayout(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.WRAP_CONTENT
            )
        }
        dialog.show()

    }

    fun setText(text: String): TextInputSaveDialog {
        binding.field.setText(text)
        msg = text

        return this
    }

}
