package messages.text.sms.feature.compose

import android.app.Activity
import android.os.Bundle
import android.util.Log
import androidx.activity.addCallback
import androidx.recyclerview.widget.ItemTouchHelper
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import dagger.android.AndroidInjection
import messages.text.sms.databinding.ActivityQuickSuggestionBinding
import messages.text.sms.R
import messages.text.sms.common.base.MainBaseThemedActivity
import messages.text.sms.extensions.baseConfig
import messages.text.sms.common.widget.TextInputSaveDialog
import messages.text.sms.extensions.beGone
import messages.text.sms.extensions.beVisible
import messages.text.sms.feature.compose.editing.QuickReplyAdapter
import java.io.File

class QuickSuggestionActivity :
    MainBaseThemedActivity<ActivityQuickSuggestionBinding>(ActivityQuickSuggestionBinding::inflate) {

    private val notes = mutableListOf<String>()
    private lateinit var quickReplyAdapter: QuickReplyAdapter
    private lateinit var notesFile: File
    lateinit var itemTouchHelper: ItemTouchHelper

    override fun onCreate(savedInstanceState: Bundle?) {
        AndroidInjection.inject(this)
        super.onCreate(savedInstanceState)

//        binding = ActivityQuickReplyBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val path = baseConfig.quickNotes
        Log.e("TextQuickReply", "loadNotes.path:$path")
        notesFile = if (path.isNotEmpty()) {
            File(path)
        } else {
            File(filesDir, "quick_reply_notes.txt").also {
                baseConfig.quickNotes = it.absolutePath
            }
        }
        loadNotes()

        quickReplyAdapter = QuickReplyAdapter(notes, onDrag = { vh ->
            itemTouchHelper.startDrag(vh)
        }, onDelete = { pos ->
            notes.removeAt(pos)
            quickReplyAdapter.notifyItemRemoved(pos)
            saveNotes()
            checkEmpty()
        })
        enableDragAndSort()

        binding.recyclerView.apply {
            layoutManager = LinearLayoutManager(this@QuickSuggestionActivity)
            adapter = quickReplyAdapter
        }

        binding.ivBack.setOnClickListener {
            onBackPressedDispatcher.onBackPressed()
        }
        onBackPressedDispatcher.addCallback(this) {
            setResult(Activity.RESULT_OK)
            finish()
        }
//        onBackPressedDispatcher.addCallback(this) {
//            isEnabled = false
//            onBackPressedDispatcher.onBackPressed()
//        }
        binding.compose.setOnClickListener {
            TextInputSaveDialog(this)
                .show(
                    this,
                    getString(R.string.add_quick_replies),
                    { text ->
                        if (text.isNotEmpty()) {
                            notes.add(text)
                            saveNotes()
                            Log.e("TextQuickReply", "notes.add:$text")
                            quickReplyAdapter.notifyItemInserted(notes.lastIndex)
                            checkEmpty()
                        }
                    })
        }
    }

    private fun checkEmpty() {
        if (notes.isEmpty()) {
            binding.empty.beVisible()
            binding.recyclerView.beGone()
        } else {
            binding.empty.beGone()
            binding.recyclerView.beVisible()
        }
    }

    private fun enableDragAndSort() {
        val callback = object : ItemTouchHelper.SimpleCallback(
            ItemTouchHelper.UP or ItemTouchHelper.DOWN,
            0
        ) {
            override fun isLongPressDragEnabled() = false

            override fun onMove(
                recyclerView: RecyclerView,
                viewHolder: RecyclerView.ViewHolder,
                target: RecyclerView.ViewHolder
            ): Boolean {
                quickReplyAdapter.moveItem(
                    viewHolder.bindingAdapterPosition,
                    target.bindingAdapterPosition
                )
                return true
            }

            override fun onSwiped(viewHolder: RecyclerView.ViewHolder, direction: Int) {}

            override fun clearView(
                recyclerView: RecyclerView,
                viewHolder: RecyclerView.ViewHolder
            ) {
                super.clearView(recyclerView, viewHolder)
                saveNotes() // saves the new order to the file
            }
        }

        itemTouchHelper = ItemTouchHelper(callback)
        itemTouchHelper.attachToRecyclerView(binding.recyclerView)
    }

    private fun loadNotes() {
        Log.e("TextQuickReply", "loadNotes")
        notes.clear()
        if (notesFile.exists()) {
            notes.addAll(notesFile.readLines())
        }
        Log.e("TextQuickReply", "notes.size:${notes.size}")
        checkEmpty()
    }

    private fun saveNotes() {
        Log.e("TextQuickReply", "saveNotes")
        notesFile.printWriter().use { writer ->
            notes.forEach(writer::println)
        }
    }

}