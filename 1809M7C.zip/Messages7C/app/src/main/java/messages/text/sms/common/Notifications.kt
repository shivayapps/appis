package messages.text.sms.common

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.Build
import androidx.work.Constraints
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import java.util.Calendar
import java.util.concurrent.TimeUnit

object NotificationChannels {
    const val ENGAGEMENT = "messages_engagement"
    const val DEFAULT_NOTIFICATION = "DEFAULT"

    fun create(context: Context) {

        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return

        val manager =
            context.getSystemService(NotificationManager::class.java)

        val channel = NotificationChannel(
            ENGAGEMENT,
            "Offers & Notification",
            NotificationManager.IMPORTANCE_HIGH
        ).apply {

            description = "Messages reminders"

            enableLights(true)
            enableVibration(true)

            lockscreenVisibility = Notification.VISIBILITY_PUBLIC
            setShowBadge(true)
        }

        manager.createNotificationChannel(channel)
    }
    fun createHomeNotificationChannel(context: Context) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return

        val manager =
            context.getSystemService(NotificationManager::class.java)

        val existing =
            manager.getNotificationChannel(
                DEFAULT_NOTIFICATION
            )

        if (existing != null) return

        val channel = NotificationChannel(
            DEFAULT_NOTIFICATION,
            "Default Shortcuts",
            NotificationManager.IMPORTANCE_DEFAULT
        ).apply {

            description = "Default messages shortcuts"

            setShowBadge(false)

            enableVibration(false)

            enableLights(false)

            lockscreenVisibility = Notification.VISIBILITY_PUBLIC
        }

        manager.createNotificationChannel(channel)
    }
}

