
package messages.text.sms.common

import android.app.Activity
import android.app.role.RoleManager
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.net.Uri
import android.os.Build
import android.provider.ContactsContract
import android.provider.Settings
import android.provider.Telephony
import android.util.Log
import android.view.Gravity
import android.view.Window
import android.view.WindowManager
import androidx.appcompat.app.AlertDialog
import messages.text.sms.BuildConfig
import messages.text.sms.R
import messages.text.sms.adhelper.AdUtil
import messages.text.sms.compat.TelephonyCompat
import messages.text.sms.extensions.resourceExists
import messages.text.sms.databinding.DialogCustomMessageBinding
import messages.text.sms.feature.backup.BackupActivity
import messages.text.sms.feature.blocking.BlockingActivity
import messages.text.sms.feature.compose.ComposeActivity
import messages.text.sms.feature.conversationinfo.ConversationInfoActivity
import messages.text.sms.feature.gallery.GalleryActivity
import messages.text.sms.feature.main.ArchivedActivity
import messages.text.sms.feature.main.MainActivity
import messages.text.sms.feature.secret.PrivateConversationsActivity
import messages.text.sms.feature.notificationprefs.NotificationPrefsActivity
import messages.text.sms.feature.scheduled.ScheduledActivity
import messages.text.sms.feature.secret.PasswordActivity
import messages.text.sms.feature.settings.SettingsActivity
import messages.text.sms.manager.NotificationManager
import messages.text.sms.manager.PermissionManager
import messages.text.sms.model.ScheduledMessage
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class Navigator @Inject constructor(
    private val context: Context,
    private val notificationManager: NotificationManager,
    private val permissions: PermissionManager
) {

    private fun startActivity(intent: Intent) {
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(intent)
    }

    private fun startActivityExternal(intent: Intent) {
        if (intent.resolveActivity(context.packageManager) != null) {
            startActivity(intent)
        } else {
            startActivity(Intent.createChooser(intent, null))
        }
    }

    /**
     * This won't work unless we use startActivityForResult
     */
    fun showDefaultSmsDialog(context: Activity) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val roleManager = context.getSystemService(RoleManager::class.java) as RoleManager
            val intent = roleManager.createRequestRoleIntent(RoleManager.ROLE_SMS)
            context.startActivityForResult(intent, 42389)
        } else {
            val intent = Intent(Telephony.Sms.Intents.ACTION_CHANGE_DEFAULT)
            intent.putExtra(Telephony.Sms.Intents.EXTRA_PACKAGE_NAME, context.packageName)
            context.startActivity(intent)
        }
    }

    fun showMainActivity() {
        val intent = Intent(context, MainActivity::class.java)
        startActivity(intent)
    }

    fun showCompose(body: String? = null, attachments: List<Uri>? = null, mode: String? = null) {
        val intent = Intent(context, ComposeActivity::class.java)
        intent.putExtra(Intent.EXTRA_TEXT, body)
        intent.putExtra("mode", mode)

        attachments
            ?.takeIf { it.isNotEmpty() }
            ?.mapNotNull {
                if (it.resourceExists(context)) it
                else null
            }
            ?.let { intent.putParcelableArrayListExtra(Intent.EXTRA_STREAM, ArrayList(it)) }

        startActivity(intent)
    }

    fun showCompose(scheduledMessage: ScheduledMessage) {
        val scheduledThreadId = TelephonyCompat.getOrCreateThreadId(
            context,
            scheduledMessage.recipients
        )

        val intent = Intent(context, ComposeActivity::class.java)
        intent.putExtra(Intent.EXTRA_TEXT, scheduledMessage.body)
        intent.putExtra("threadId", scheduledThreadId)
        intent.putExtra("subscriptionId", scheduledMessage.subId)
        intent.putExtra("sendAsGroup", scheduledMessage.sendAsGroup)
        intent.putExtra("scheduleDateTime", scheduledMessage.date)

        scheduledMessage.recipients
            .takeIf { it.isNotEmpty() }
            ?.let { intent.putStringArrayListExtra("addresses", ArrayList(it)) }

        scheduledMessage.attachments
            .takeIf { it.isNotEmpty() }
            ?.mapNotNull {
                val uri = Uri.parse(it)
                if (uri.resourceExists(context)) uri
                else null
            }
            ?.let { intent.putParcelableArrayListExtra(Intent.EXTRA_STREAM, ArrayList(it)) }

        startActivity(intent)
    }

    fun showConversation(threadId: Long, query: String? = null) {
        val intent = Intent(context, ComposeActivity::class.java)
            .putExtra("threadId", threadId)
            .putExtra("query", query)
        startActivity(intent)
    }

    fun showConversationInfo(threadId: Long) {
        val intent = Intent(context, ConversationInfoActivity::class.java)
        intent.putExtra("threadId", threadId)
        startActivity(intent)
    }

    fun showMedia(partId: Long) {
        val intent = Intent(context, GalleryActivity::class.java)
        intent.putExtra("partId", partId)
        startActivity(intent)
    }

    fun showBackup() {
        startActivity(Intent(context, BackupActivity::class.java))
    }

    fun showScheduled(conversationId: Long?) {
        val intent = Intent(context, ScheduledActivity::class.java)
        conversationId?.let { intent.putExtra("conversationId", it) }
        startActivity(intent)
    }

    fun showSettings() {
        val intent = Intent(context, SettingsActivity::class.java)
        startActivity(intent)
    }

//    fun showDeveloper() {
//        val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://github.com/danascape"))
//        startActivityExternal(intent)
//    }
//
//    fun showSourceCode() {
//        val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://github.com/PVOT-OSS/Messages"))
//        startActivityExternal(intent)
//    }
//    fun showLicense() {
//        val intent = Intent(
//            Intent.ACTION_VIEW,
//            Uri.parse("https://github.com/PVOT-OSS/Messages/blob/master/LICENSE")
//        )
//        startActivityExternal(intent)
//    }

    fun showBlockedConversations() {
        val intent = Intent(context, BlockingActivity::class.java)
        startActivity(intent)
    }


//    fun showDonation() {
//        val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://github.com/PVOT-OSS/Messages"))
//        startActivityExternal(intent)
//    }

    fun showRating() {
        val intent = Intent(
            Intent.ACTION_VIEW,
            Uri.parse("http://play.google.com/store/apps/details?id=${context?.packageName}")
        )
        startActivity(intent)
    }

    fun showSupport() {
        val intent = Intent(Intent.ACTION_SENDTO)
        intent.data = Uri.parse("mailto:")
        intent.putExtra(Intent.EXTRA_EMAIL, arrayOf("admin.7message@gmail.com"))
        intent.putExtra(Intent.EXTRA_SUBJECT, "Messages Support")
        intent.putExtra(
            Intent.EXTRA_TEXT, StringBuilder("\n\n")
            .append("\n\n--- Please write your message above this line ---\n\n")
            .append("Package: ${context.packageName}\n")
            .append("Version: ${BuildConfig.VERSION_NAME}\n")
            .append("Device: ${Build.BRAND} ${Build.MODEL}\n")
            .append("SDK: ${Build.VERSION.SDK_INT}\n")

            .toString())
        startActivityExternal(intent)
    }

    fun showPassword() {
        val intent = Intent(context, PasswordActivity::class.java)
        startActivity(intent)
    }
    fun showPrivateConversations() {
        val intent = Intent(context, PrivateConversationsActivity::class.java)
        startActivity(intent)
    }
    fun showArchivedConversations() {
        val intent = Intent(context, ArchivedActivity::class.java)
//        val intent = Intent(this, SearchActivity::class.java)
        startActivity(intent)
    }
//    fun showInvite() {
//        Intent(Intent.ACTION_SEND)
//            .setType("text/plain")
//            .putExtra(Intent.EXTRA_TEXT, "https://github.com/PVOT-OSS/Messages/releases/latest")
//            .let { Intent.createChooser(it, null) }
//            .let(::startActivityExternal)
//    }

    fun addContact(address: String) {
        AdUtil.isSystemDialogOpen = true
        Log.d("ADD","addContact:$address")
        val intent = Intent(Intent.ACTION_INSERT)
            .setType(ContactsContract.Contacts.CONTENT_TYPE)
            .putExtra(ContactsContract.Intents.Insert.PHONE, address)

        startActivityExternal(intent)
    }
    fun launchDialer(address: String) {
        Log.d("ADD", "phoneNo: $address")

        val intent = Intent(Intent.ACTION_DIAL).apply {
            data = Uri.parse("tel:${Uri.encode(address)}")
        }
        startActivity(intent)
    }

    fun makePhoneCall(address: String) {
        AdUtil.isSystemDialogOpen = true
        val action = if (permissions.hasCalling()) Intent.ACTION_CALL else Intent.ACTION_DIAL
        val intent = Intent(action, Uri.parse("tel:$address"))
        startActivityExternal(intent)
    }

    fun showContact(lookupKey: String) {
        AdUtil.isSystemDialogOpen = true
        val intent = Intent(Intent.ACTION_VIEW)
            .setData(Uri.withAppendedPath(ContactsContract.Contacts.CONTENT_LOOKUP_URI, lookupKey))

        startActivityExternal(intent)
    }

    fun viewFile(uri: Uri, mimeType: String) {
        AdUtil.isSystemDialogOpen = true
        val intent = Intent(Intent.ACTION_VIEW)
            .setDataAndType(uri, mimeType.lowercase())
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            .let { Intent.createChooser(it, null) }

        startActivityExternal(intent)
    }

    fun shareFile(uri: Uri, mimeType: String) {
        AdUtil.isSystemDialogOpen = true
        val intent = Intent(Intent.ACTION_SEND)
            .setType(mimeType.lowercase())
            .putExtra(Intent.EXTRA_STREAM, uri)
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            .let { Intent.createChooser(it, null) }

        startActivityExternal(intent)
    }

    fun showPermissions() {
        AdUtil.isSystemDialogOpen = true
        val intent = Intent()
        intent.action = Settings.ACTION_APPLICATION_DETAILS_SETTINGS
        intent.data = Uri.fromParts("package", context.packageName, null)

        startActivity(intent)
    }

    fun showNotificationSettings(threadId: Long = 0) {
        val intent = Intent(context, NotificationPrefsActivity::class.java)
        intent.putExtra("threadId", threadId)
        startActivity(intent)
    }

    fun showNotificationChannel(threadId: Long = 0) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            AdUtil.isSystemDialogOpen = true
            if (threadId != 0L) {
                notificationManager.createNotificationChannel(threadId)
            }
            val channelId = notificationManager.buildNotificationChannelId(threadId)
            val intent = Intent(Settings.ACTION_CHANNEL_NOTIFICATION_SETTINGS)
                .putExtra(Settings.EXTRA_CHANNEL_ID, channelId)
                .putExtra(Settings.EXTRA_APP_PACKAGE, context.packageName)
            startActivity(intent)
        }
    }

    fun showExactAlarmsSettings() {
        AdUtil.isSystemDialogOpen = true
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val intent = Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM)
                .setData(Uri.parse("package:${context.packageName}"))
            startActivity(intent)
        }
    }


}
