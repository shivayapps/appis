package messages.text.sms.feature.scheduled

import android.os.Bundle
import android.view.View
import androidx.activity.OnBackPressedCallback
import androidx.core.view.isVisible
import androidx.lifecycle.ViewModelProvider
import com.jakewharton.rxbinding2.view.clicks
import com.uber.autodispose.android.lifecycle.scope
import com.uber.autodispose.autoDispose
import dagger.android.AndroidInjection
import io.reactivex.subjects.PublishSubject
import io.reactivex.subjects.Subject
import messages.text.sms.R
import messages.text.sms.dialog.DeleteMessageDialog
import messages.text.sms.dialog.MessageDialog
import messages.text.sms.common.PopupWindowHelper
import messages.text.sms.common.base.MainBaseThemedActivity
import messages.text.sms.databinding.MenuScheduledBinding
import messages.text.sms.databinding.ScheduledActivityBinding
import javax.inject.Inject

class ScheduledActivity :
    MainBaseThemedActivity<ScheduledActivityBinding>(ScheduledActivityBinding::inflate),
    ScheduledView {

    @Inject
    lateinit var scheduledMessageAdapter: ScheduledMessageAdapter

    @Inject
    lateinit var viewModelFactory: ViewModelProvider.Factory

    override val composeIntent by lazy { binding.compose.clicks() }

    //    override val upgradeIntent by lazy { binding.upgrade.clicks() }
    override val messagesSelectedIntent by lazy { scheduledMessageAdapter.selectionChanges }
    override val optionsItemIntent: Subject<Int> = PublishSubject.create()
    override val deleteScheduledMessages: Subject<List<Long>> = PublishSubject.create()
    override val sendScheduledMessages: Subject<List<Long>> = PublishSubject.create()
    override val editScheduledMessage: Subject<Long> = PublishSubject.create()
    override val backPressedIntent: Subject<Unit> = PublishSubject.create()

    private val viewModel by lazy {
        ViewModelProvider(this, viewModelFactory)[ScheduledViewModel::class.java]
    }


    private lateinit var menuBinding: MenuScheduledBinding
    private lateinit var popupWindow: PopupWindowHelper

    override fun onCreate(savedInstanceState: Bundle?) {
        AndroidInjection.inject(this)
        super.onCreate(savedInstanceState)
        setTitle(R.string.scheduled_title)
        showBackButton(true)
        viewModel.bindView(this)

        scheduledMessageAdapter.emptyView = binding.empty
        binding.messages.adapter = scheduledMessageAdapter

        colors.theme().let { theme ->
//            binding.sampleMessage.setBackgroundTint(theme.theme)
//            binding.sampleMessage.setTextColor(theme.textPrimary)
//            binding.compose.setTint(theme.textPrimary)
//            binding.compose.setBackgroundTint(theme.theme)
//            binding.upgrade.setBackgroundTint(theme.theme)
//            binding.upgradeIcon.setTint(theme.textPrimary)
//            binding.upgradeLabel.setTextColor(theme.textPrimary)
        }

        binding.ivBack.setOnClickListener {
            onBackPressedDispatcher.onBackPressed()
        }
        binding.ivClose.setOnClickListener {
            clearSelection()
        }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (!backPressedIntent.hasObservers()) {
                    isEnabled = false
                    onBackPressedDispatcher.onBackPressed()
                    isEnabled = true
                } else {
                    backPressedIntent.onNext(Unit)
                    finish()
                }
            }
        })

        menuBinding = MenuScheduledBinding.inflate(layoutInflater)
        popupWindow = PopupWindowHelper(menuBinding.root)

        binding.delete.setOnClickListener {
            optionsItemIntent.onNext(binding.delete.id).let { true }; popupWindow.dismiss()
        }
        menuBinding.selectAll.setOnClickListener {
            optionsItemIntent.onNext(menuBinding.selectAll.id).let { true }; popupWindow.dismiss()
        }
        menuBinding.copy.setOnClickListener {
            optionsItemIntent.onNext(menuBinding.copy.id).let { true }; popupWindow.dismiss()
        }
        menuBinding.sendNow.setOnClickListener {
            optionsItemIntent.onNext(menuBinding.sendNow.id).let { true }; popupWindow.dismiss()
        }
//        menuBinding.editMessage.setOnClickListener { optionsItemIntent.onNext(menuBinding.editMessage.id).let { true }; popupWindow.dismiss() }
        binding.menuIcon.clicks()
            .autoDispose(scope())
            .subscribe {
                showMenu(binding.menuIcon)
            }

    }

    private fun showMenu(anchorView: View) {
        popupWindow.showFromTopRight(anchorView)
    }

    override fun render(state: ScheduledState) {
        scheduledMessageAdapter.updateData(state.scheduledMessages)

        setTitle(
            when {
                (state.selectedMessages > 0) ->
                    getString(R.string.compose_title_selected, state.selectedMessages)

                else -> getString(R.string.scheduled_title)
            }
        )

        // show/hide menu items
//        binding.toolbar.menu.findItem(R.id.select_all)?.isVisible = ((scheduledMessageAdapter.itemCount > 1) && (state.selectedMessages != 0))
//        binding.toolbar.menu.findItem(R.id.delete)?.isVisible = ((scheduledMessageAdapter.itemCount != 0) && (state.selectedMessages != 0))
//        binding.toolbar.menu.findItem(R.id.copy)?.isVisible = ((scheduledMessageAdapter.itemCount != 0) && (state.selectedMessages != 0))
//        binding.toolbar.menu.findItem(R.id.send_now)?.isVisible = ((scheduledMessageAdapter.itemCount != 0) && (state.selectedMessages != 0))
//        binding.toolbar.menu.findItem(R.id.edit_message)?.isVisible = ((scheduledMessageAdapter.itemCount != 0) && (state.selectedMessages == 1))

        binding.ivBack.isVisible = ((scheduledMessageAdapter.itemCount == 0) && (state.selectedMessages == 0))
        binding.menuIcon.isVisible = ((scheduledMessageAdapter.itemCount != 0) && (state.selectedMessages != 0))
        binding.delete.isVisible = ((scheduledMessageAdapter.itemCount != 0) && (state.selectedMessages != 0))
        menuBinding.selectAll.isVisible = ((scheduledMessageAdapter.itemCount > 1) && (state.selectedMessages != 0))
        menuBinding.copy.isVisible = ((scheduledMessageAdapter.itemCount != 0) && (state.selectedMessages != 0))
        menuBinding.sendNow.isVisible = ((scheduledMessageAdapter.itemCount != 0) && (state.selectedMessages != 0))

//        menuBinding.editMessage.isVisible = ((scheduledMessageAdapter.itemCount != 0) && (state.selectedMessages == 1))

        // show compose button
        binding.compose.isVisible = (state.conversationId == null)
    }

//    override fun onBackPressed() = backPressedIntent.onNext(Unit)

    override fun clearSelection() = scheduledMessageAdapter.clearSelection()

    override fun toggleSelectAll() = scheduledMessageAdapter.toggleSelectAll()

    override fun showDeleteDialog(messages: List<Long>) {
        val count = messages.size
        DeleteMessageDialog()
            .show(
                this,
                getString(R.string.dialog_delete_title),
                resources.getQuantityString(R.plurals.dialog_delete_chat, count, count),
                positiveActionCallback = {
                    deleteScheduledMessages.onNext(messages)
                },
                negativeActionCallback = {

                }
            )

//        val count = messages.size
//        val dialog = AlertDialog.Builder(this, R.style.AppThemeDialog)
//            .setTitle(R.string.dialog_delete_title)
//            .setMessage(resources.getQuantityString(R.plurals.dialog_delete_chat, count, count))
//            .setPositiveButton(R.string.button_delete) { _, _ ->
//                deleteScheduledMessages.onNext(
//                    messages
//                )
//            }
//            .setNegativeButton(R.string.button_cancel, null)
//            .create()
//
//        dialog.show()
//
//        theme.take(1)
//            .autoDispose(scope())
//            .subscribe { theme ->
//                dialog.getButton(AlertDialog.BUTTON_POSITIVE)?.setTextColor(theme.theme)
//                dialog.getButton(AlertDialog.BUTTON_NEGATIVE)?.setTextColor(theme.theme)
//            }
    }

    override fun showSendNowDialog(messages: List<Long>) {
        val count = messages.size
        MessageDialog()
            .show(
                this,
                getString(R.string.main_menu_send_now),
                resources.getQuantityString(R.plurals.dialog_send_now, count, count),
                getString(R.string.main_menu_send_now),
                positiveActionCallback = {
                    sendScheduledMessages.onNext(
                        messages
                    )
                },
                negativeActionCallback = {},
                dismissActionCallback = {}
            )

//        val dialog = AlertDialog.Builder(this, R.style.AppThemeDialog)
//            .setTitle(R.string.main_menu_send_now)
//            .setMessage(resources.getQuantityString(R.plurals.dialog_send_now, count, count))
//            .setPositiveButton(R.string.main_menu_send_now) { _, _ ->
//                sendScheduledMessages.onNext(
//                    messages
//                )
//            }
//            .setNegativeButton(R.string.button_cancel, null)
//            .create()
//
//        dialog.show()
//
//        theme.take(1)
//            .autoDispose(scope())
//            .subscribe { theme ->
//                dialog.getButton(AlertDialog.BUTTON_POSITIVE)?.setTextColor(theme.theme)
//                dialog.getButton(AlertDialog.BUTTON_NEGATIVE)?.setTextColor(theme.theme)
//            }
    }

    override fun showEditMessageDialog(message: Long) {
        MessageDialog()
            .show(
                this,
                getString(R.string.dialog_edit_scheduled_message_title),
                getString(R.string.dialog_edit_scheduled_message),
                getString(R.string.dialog_edit_scheduled_message_positive_button),
                positiveActionCallback = {
                    editScheduledMessage.onNext(message)
                },
                negativeActionCallback = {},
                dismissActionCallback = {}
            )

//        val dialog = AlertDialog.Builder(this, R.style.AppThemeDialog)
//            .setTitle(R.string.dialog_edit_scheduled_message_title)
//            .setMessage(R.string.dialog_edit_scheduled_message)
//            .setPositiveButton(R.string.dialog_edit_scheduled_message_positive_button) { _, _ ->
//                editScheduledMessage.onNext(message)
//            }
//            .setNegativeButton(R.string.button_cancel, null)
//            .create()
//
//        dialog.show()
//
//        theme.take(1)
//            .autoDispose(scope())
//            .subscribe { theme ->
//                dialog.getButton(AlertDialog.BUTTON_POSITIVE)?.setTextColor(theme.theme)
//                dialog.getButton(AlertDialog.BUTTON_NEGATIVE)?.setTextColor(theme.theme)
//            }
    }

//    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
//        menuInflater.inflate(R.menu.scheduled_messages, menu)
//        return super.onCreateOptionsMenu(menu)
//    }
//
//    override fun onOptionsItemSelected(item: MenuItem): Boolean {
//        optionsItemIntent.onNext(item.itemId)
//        return true
//    }

    override fun finishActivity() {
        finish()
    }
}
