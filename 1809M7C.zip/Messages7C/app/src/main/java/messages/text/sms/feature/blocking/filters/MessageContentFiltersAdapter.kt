
package messages.text.sms.feature.blocking.filters

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import io.reactivex.subjects.PublishSubject
import io.reactivex.subjects.Subject
import messages.text.sms.common.base.MyBindingViewHolder
import messages.text.sms.common.base.MyRealmAdapter
import messages.text.sms.databinding.MessageContentFilterListItemBinding
import messages.text.sms.model.MessageContentFilter

class MessageContentFiltersAdapter :
    MyRealmAdapter<MessageContentFilter, MyBindingViewHolder<MessageContentFilterListItemBinding>>() {

    val removeMessageContentFilter: Subject<Long> = PublishSubject.create()

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): MyBindingViewHolder<MessageContentFilterListItemBinding> {
        val binding = MessageContentFilterListItemBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false
        )
        return MyBindingViewHolder(binding).apply {
            binding.removeFilter.setOnClickListener {
                val filter = getItem(adapterPosition) ?: return@setOnClickListener
                removeMessageContentFilter.onNext(filter.id)
            }
        }
    }

    override fun onBindViewHolder(
        holder: MyBindingViewHolder<MessageContentFilterListItemBinding>,
        position: Int
    ) {
        val item = getItem(position)!!
        holder.binding.caseIcon.visibility = if (item.caseSensitive) View.VISIBLE else View.GONE
        holder.binding.regexIcon.visibility = if (item.isRegex) View.VISIBLE else View.GONE
        holder.binding.contactsIcon.visibility =
            if (item.includeContacts) View.VISIBLE else View.GONE
        holder.binding.filter.text = item.value
    }

}
