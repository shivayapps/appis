
package messages.text.sms.feature.compose.part

import android.annotation.SuppressLint
import android.content.Context
import io.reactivex.Observable
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.schedulers.Schedulers
import messages.text.sms.R
import messages.text.sms.common.Navigator
import messages.text.sms.common.base.MyViewHolder
import messages.text.sms.common.util.Colors
import messages.text.sms.extensions.resolveThemeColor
import messages.text.sms.extensions.setBackgroundTint
import messages.text.sms.extensions.setTint
import messages.text.sms.databinding.MmsFileListItemBinding
import messages.text.sms.feature.compose.BubbleUtils
import messages.text.sms.model.Message
import messages.text.sms.model.MmsPart
import javax.inject.Inject

class FileBinder @Inject constructor(colors: Colors, private val context: Context) : PartBinder() {

    @Inject
    lateinit var navigator: Navigator

    override val partLayout = R.layout.mms_file_list_item
    override var theme = colors.theme()

    // This is the last binder we check. If we're here, we can bind the part
    override fun canBindPart(part: MmsPart) = true

    @SuppressLint("CheckResult")
    override fun bindPart(
        holder: MyViewHolder,
        part: MmsPart,
        message: Message,
        canGroupWithPrevious: Boolean,
        canGroupWithNext: Boolean
    ) {
        val binding = MmsFileListItemBinding.bind(holder.containerView)

        BubbleUtils.getBubble(false, canGroupWithPrevious, canGroupWithNext, message.isMe())
            .let(binding.fileBackground::setBackgroundResource)

        Observable.just(part.getUri())
            .map(context.contentResolver::openInputStream)
            .map { inputStream -> inputStream.use { it.available() } }
            .map { bytes ->
                when (bytes) {
                    in 0..999 -> "$bytes B"
                    in 1000..999999 -> "${"%.1f".format(bytes / 1000f)} KB"
                    in 1000000..9999999 -> "${"%.1f".format(bytes / 1000000f)} MB"
                    else -> "${"%.1f".format(bytes / 1000000000f)} GB"
                }
            }
            .onErrorReturn { context.getString(R.string.compose_file_size_unavailable) }
            .subscribeOn(Schedulers.io())
            .observeOn(AndroidSchedulers.mainThread())
            .subscribe { size -> binding.size.text = size }

        binding.filename.text = part.name

        if (!message.isMe()) {
            binding.fileBackground.setBackgroundTint(theme.theme)
            binding.icon.setTint(theme.textPrimary)
            binding.filename.setTextColor(theme.textPrimary)
            binding.size.setTextColor(theme.textTertiary)
        } else {
            binding.fileBackground.setBackgroundTint(
                holder.containerView.context.resolveThemeColor(
                    R.attr.bubbleColor
                )
            )
//            binding.icon.setTint(holder.containerView.context.resolveThemeColor(android.R.attr.textColorSecondary))
//            binding.filename.setTextColor(holder.containerView.context.resolveThemeColor(android.R.attr.textColorPrimary))
//            binding.size.setTextColor(holder.containerView.context.resolveThemeColor(android.R.attr.textColorTertiary))
        }
    }

}