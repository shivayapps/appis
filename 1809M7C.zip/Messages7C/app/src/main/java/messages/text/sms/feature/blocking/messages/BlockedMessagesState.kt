
package messages.text.sms.feature.blocking.messages

import messages.text.sms.model.Conversation
import io.realm.RealmResults

data class BlockedMessagesState(
    val data: RealmResults<Conversation>? = null,
    val selected: Int = 0
)
