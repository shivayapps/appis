
package messages.text.sms.interactor

import messages.text.sms.repository.SyncRepository
import io.reactivex.Flowable
import android.util.Log
import javax.inject.Inject

class SyncContacts @Inject constructor(private val syncManager: SyncRepository) : Interactor<Unit>() {

    override fun buildObservable(params: Unit): Flowable<Long> {
        return Flowable.just(System.currentTimeMillis())
                .doOnNext { syncManager.syncContacts() }
                .map { startTime -> System.currentTimeMillis() - startTime }
                .doOnNext { duration -> Log.d("Timber","Completed sync in ${duration}ms") }
    }

}