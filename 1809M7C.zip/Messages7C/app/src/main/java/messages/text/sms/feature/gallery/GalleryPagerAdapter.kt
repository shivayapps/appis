
package messages.text.sms.feature.gallery

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import com.google.android.mms.ContentType
import io.reactivex.subjects.PublishSubject
import io.reactivex.subjects.Subject
import messages.text.sms.R
import messages.text.sms.common.base.MyRealmAdapter
import messages.text.sms.common.base.MyViewHolder
import messages.text.sms.databinding.GalleryImagePageBinding
import messages.text.sms.databinding.GalleryVideoPageBinding
import messages.text.sms.extensions.isImage
import messages.text.sms.extensions.isVideo
import messages.text.sms.model.MmsPart
import messages.text.sms.util.GlideApp
import java.util.Collections
import java.util.WeakHashMap
import javax.inject.Inject

class GalleryPagerAdapter @Inject constructor(private val context: Context) :
    MyRealmAdapter<MmsPart, MyViewHolder>() {

    companion object {
        private const val VIEW_TYPE_INVALID = 0
        private const val VIEW_TYPE_IMAGE = 1
        private const val VIEW_TYPE_VIDEO = 2
    }

    val clicks: Subject<View> = PublishSubject.create()

    private val contentResolver = context.contentResolver
    private val exoPlayers = Collections.newSetFromMap(WeakHashMap<ExoPlayer?, Boolean>())

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {
        val inflater = LayoutInflater.from(parent.context)
        return MyViewHolder(
            when (viewType) {
            VIEW_TYPE_IMAGE -> {
                val binding = GalleryImagePageBinding.inflate(inflater, parent, false)
                // When calling the public setter, it doesn't allow the midscale to be the same as the
                // maxscale or the minscale. We don't want 3 levels and we don't want to modify the library
                // so let's celebrate the invention of reflection!
                binding.image.attacher.run {
                    javaClass.getDeclaredField("mMinScale").run {
                        isAccessible = true
                        setFloat(binding.image.attacher, 1f)
                    }
                    javaClass.getDeclaredField("mMidScale").run {
                        isAccessible = true
                        setFloat(binding.image.attacher, 1f)
                    }
                    javaClass.getDeclaredField("mMaxScale").run {
                        isAccessible = true
                        setFloat(binding.image.attacher, 3f)
                    }
                }
                binding.root.apply { setOnClickListener(clicks::onNext) }
            }

            VIEW_TYPE_VIDEO -> {
                val binding = GalleryVideoPageBinding.inflate(inflater, parent, false)
                binding.root.apply { setOnClickListener(clicks::onNext) }
            }

            else -> inflater.inflate(R.layout.gallery_invalid_page, parent, false).apply {
                setOnClickListener(clicks::onNext)
            }
        })
    }

    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
        val part = getItem(position) ?: return
        when (getItemViewType(position)) {
            VIEW_TYPE_IMAGE -> {
                val binding = GalleryImagePageBinding.bind(holder.containerView)
                // We need to explicitly request a gif from glide for animations to work
                when (part.getUri().let(contentResolver::getType)) {
                    ContentType.IMAGE_GIF -> GlideApp.with(context)
                        .asGif()
                        .load(part.getUri())
                        .into(binding.image)

                    else -> GlideApp.with(context)
                        .asBitmap()
                        .load(part.getUri())
                        .into(binding.image)
                }
            }

            VIEW_TYPE_VIDEO -> {
                val binding = GalleryVideoPageBinding.bind(holder.containerView)
                val exoPlayer = ExoPlayer.Builder(context).build()
                binding.video.player = exoPlayer
                exoPlayers.add(exoPlayer)

                val mediaItem = MediaItem.fromUri(part.getUri())
                exoPlayer.setMediaItem(mediaItem)
                exoPlayer.prepare()
            }
        }
    }

    override fun getItemViewType(position: Int): Int {
        val part = getItem(position)
        return when {
            part?.isImage() == true -> VIEW_TYPE_IMAGE
            part?.isVideo() == true -> VIEW_TYPE_VIDEO
            else -> VIEW_TYPE_INVALID
        }
    }

    fun destroy() {
        exoPlayers.forEach { exoPlayer -> exoPlayer?.release() }
    }

}
