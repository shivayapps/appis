package messages.text.sms.repository

import android.content.ContentResolver
import android.content.ContentUris
import android.net.Uri
import android.provider.Telephony
import com.f2prateek.rx.preferences2.RxSharedPreferences
import messages.text.sms.extensions.insertOrUpdate
import messages.text.sms.extensions.map
import messages.text.sms.manager.KeyManager
import messages.text.sms.mapper.CursorToContact
import messages.text.sms.mapper.CursorToContactGroup
import messages.text.sms.mapper.CursorToContactGroupMember
import messages.text.sms.mapper.CursorToConversation
import messages.text.sms.mapper.CursorToMessage
import messages.text.sms.mapper.CursorToPart
import messages.text.sms.mapper.CursorToRecipient
import messages.text.sms.model.Contact
import messages.text.sms.model.ContactGroup
import messages.text.sms.model.Conversation
import messages.text.sms.model.Message
import messages.text.sms.model.MmsPart
import messages.text.sms.model.PhoneNumber
import messages.text.sms.model.Recipient
import messages.text.sms.model.SyncLog
import messages.text.sms.util.PhoneNumberUtils
import messages.text.sms.util.tryOrNull
import io.reactivex.subjects.BehaviorSubject
import io.reactivex.subjects.Subject
import io.realm.Realm
import io.realm.RealmList
import io.realm.Sort
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import messages.text.sms.MyApplication
import android.util.Log
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class SyncRepositoryImpl @Inject constructor(
    private val contentResolver: ContentResolver,
    private val conversationRepo: ConversationRepository,
    private val cursorToConversation: CursorToConversation,
    private val cursorToMessage: CursorToMessage,
    private val cursorToPart: CursorToPart,
    private val cursorToRecipient: CursorToRecipient,
    private val cursorToContact: CursorToContact,
    private val cursorToContactGroup: CursorToContactGroup,
    private val cursorToContactGroupMember: CursorToContactGroupMember,
    private val keys: KeyManager,
    private val phoneNumberUtils: PhoneNumberUtils,
    private val rxPrefs: RxSharedPreferences,
    private val reactions: EmojiReactionRepository,
) : SyncRepository {

    override val syncProgress: Subject<SyncRepository.SyncProgress> =
        BehaviorSubject.createDefault(SyncRepository.SyncProgress.Idle)

//    override fun syncMessages() {
//
//        val oldBlockedSenders = rxPrefs.getStringSet("pref_key_blocked_senders")
//
//        // If the sync is already running, don't try to do another one
//        if (syncProgress.blockingFirst() is SyncRepository.SyncProgress.Running) return
//        syncProgress.onNext(SyncRepository.SyncProgress.Running(0, 0, true))
//
//        val handlerThread = HandlerThread("RealmSyncThread")
//        handlerThread.start()
//        Handler(handlerThread.looper).post {
//            Realm.getDefaultInstance().executeTransactionAsync(
//                { realm ->
//                // Prepare existing conversation data
//                val persistedData = realm.copyFromRealm(
//                    realm.where(Conversation::class.java)
//                        .beginGroup()
//                        .equalTo("archived", true)
//                        .or()
//                        .equalTo("blocked", true)
//                        .or()
//                        .equalTo("pinned", true)
//                        .or()
//                        .isNotEmpty("name")
////                        .or()
////                        .isNotNull("blockingClient")
//                        .or()
//                        .isNotEmpty("blockReason")
//                        .endGroup()
//                        .findAll()
//                ).associateBy { conversation -> conversation.id }.toMutableMap()
//
//                removeOldMessages(realm)
//
//                keys.reset()
//
//                val partsCursor = cursorToPart.getPartsCursor()
//                val messageCursor = cursorToMessage.getMessagesCursor()
//                val conversationCursor = cursorToConversation.getConversationsCursor()
//                val recipientCursor = cursorToRecipient.getRecipientCursor()
//
//                val max = (partsCursor?.count ?: 0) +
//                        (messageCursor?.count ?: 0) +
//                        (conversationCursor?.count ?: 0) +
//                        (recipientCursor?.count ?: 0)
//
//                var progress = 0
//
//                // Sync message parts
//                partsCursor?.use {
//                    partsCursor.forEach { cursor ->
//                        tryOrNull {
//                            val part = cursorToPart.map(partsCursor)
//                            realm.insertOrUpdate(part)
//                            progress++
//                        }
//                    }
//                }
//
//                // Sync messages
//                messageCursor?.use {
//                    val messageColumns = CursorToMessage.MessageColumns(messageCursor)
//                    messageCursor.forEach { cursor ->
//                        tryOrNull {
//                            syncProgress.onNext(
//                                SyncRepository.SyncProgress.Running(
//                                    max,
//                                    ++progress,
//                                    false
//                                )
//                            )
//                            val message = cursorToMessage.map(Pair(cursor, messageColumns)).apply {
//                                if (isMms()) {
//                                    parts = RealmList<MmsPart>().apply {
//                                        addAll(
//                                            realm.where(MmsPart::class.java)
//                                                .equalTo("messageId", contentId)
//                                                .findAll()
//                                        )
//                                    }
//                                }
//                            }
//                            realm.insertOrUpdate(message)
//                        }
//                    }
//                }
//
//                // Migrate blocked conversations from 2.7.3
//                oldBlockedSenders.get()
//                    .map { threadIdString -> threadIdString.toLong() }
//                    .filter { threadId -> !persistedData.contains(threadId) }
//                    .forEach { threadId ->
//                        persistedData[threadId] = Conversation(id = threadId, blocked = true)
//                    }
//
//                // Sync conversations
//                conversationCursor?.use {
//                    conversationCursor.forEach { cursor ->
//                        tryOrNull {
//                            syncProgress.onNext(
//                                SyncRepository.SyncProgress.Running(
//                                    max,
//                                    ++progress,
//                                    false
//                                )
//                            )
//                            val conversation = cursorToConversation.map(cursor).apply {
//                                persistedData[id]?.let { persistedConversation ->
//                                    archived = persistedConversation.archived
//                                    blocked = persistedConversation.blocked
//                                    pinned = persistedConversation.pinned
//                                    isPrivate = persistedConversation.isPrivate
//                                    name = persistedConversation.name
//                                    blockReason = persistedConversation.blockReason
//                                }
//                                lastMessage = realm.where(Message::class.java)
//                                    .sort("date", Sort.DESCENDING)
//                                    .equalTo("threadId", id)
//                                    .findFirst()
//                            }
//                            realm.insertOrUpdate(conversation)
//                        }
//                    }
//                }
//
//                // Sync recipients
//                val contacts = realm.copyToRealmOrUpdate(getContacts())
//                recipientCursor?.use {
//                    recipientCursor.forEach { cursor ->
//                        tryOrNull {
//                            syncProgress.onNext(
//                                SyncRepository.SyncProgress.Running(
//                                    max,
//                                    ++progress,
//                                    false
//                                )
//                            )
//                            val rec = cursorToRecipient.map(cursor).apply {
//                                contact = contacts.firstOrNull { c ->
//                                    c.numbers.any { num ->
//                                        phoneNumberUtils.compare(
//                                            address,
//                                            num.address
//                                        )
//                                    }
//                                }
//                            }
//                            realm.insertOrUpdate(rec)
//                        }
//                    }
//                }
//
//                syncProgress.onNext(SyncRepository.SyncProgress.Running(0, 0, true))
//
//                // Now that we have all the messages, we can scan for emoji reactions
//                reactions.deleteAndReparseAllEmojiReactions(realm)
//
//                realm.insert(SyncLog())
//            }, {
//                handlerThread.quitSafely()
//                oldBlockedSenders.delete()
//                syncProgress.onNext(SyncRepository.SyncProgress.Idle)
//            },
//                { error ->
//                    handlerThread.quitSafely()
//                    Log.d("Timber",error, "syncMessages Failed")
//                    syncProgress.onNext(SyncRepository.SyncProgress.Idle)
//                })
//        }
//    }


    override fun syncMessagesTemp() {
        if (MyApplication.dataLoading == true) return
        Log.e("Message_Log", "getContacts: ")
        Log.e("Message_Log", "messages - messages - : Start")

        val contacts = getContacts()
        keys.reset()

        CoroutineScope(Dispatchers.IO).launch {
            val realmTemp = Realm.getDefaultInstance()
            try {
                realmTemp.beginTransaction()

                val messageCursorTemp = cursorToMessage.getMessagesCursor()
                val conversationCursorTemp = cursorToConversation.getConversationsCursor()
                val recipientCursorTemp = cursorToRecipient.getRecipientCursor()

                Log.e("Message_Log", "beginTransaction: ")

                val persistedDataTemp = realmTemp.copyFromRealm(
                    realmTemp.where(Conversation::class.java)
                        .beginGroup()
                        .equalTo("archived", true)
                        .or()
                        .equalTo("blocked", true)
                        .or()
                        .equalTo("pinned", true)
                        .or()
                        .isNotEmpty("name")
                        .or()
                        .isNotEmpty("blockReason")
                        .endGroup()
                        .findAll()
                ).associateBy { it.id }.toMutableMap()

                removeOldMessages(realmTemp)

                // Sync messages (limit to 200)
                messageCursorTemp?.use {
                    val messageColumns = CursorToMessage.MessageColumns(messageCursorTemp)
                    val messages = mutableListOf<Message>()

                    while (messageCursorTemp.moveToNext() && messages.size < 200) {
                        val message = cursorToMessage.map(Pair(messageCursorTemp, messageColumns))
                        messages.add(message)
                    }

                    Log.e("Message_Log", "messages - messages - : ${messages.size}")
                    realmTemp.insertOrUpdate(messages)
                }

                // Sync conversations
                conversationCursorTemp?.use {
                    val conversations = conversationCursorTemp.map { cursor ->
                        cursorToConversation.map(cursor).apply {
                            persistedDataTemp[id]?.let { persistedConversation ->
                                archived = persistedConversation.archived
                                blocked = persistedConversation.blocked
                                isPrivate = persistedConversation.isPrivate
                                pinned = persistedConversation.pinned
                                name = persistedConversation.name
                                blockReason = persistedConversation.blockReason
                            }
                        }
                    }

                    if (conversations.isNotEmpty()) {
                        realmTemp.where(Message::class.java)
                            .sort("date", Sort.DESCENDING)
                            .distinct("threadId")
                            .findAll()
                            .forEach { message ->
                                conversations.find { it.id == message.threadId }?.lastMessage =
                                    message
                            }

                        realmTemp.insertOrUpdate(conversations)
                    }

                    Log.e("Message_Log", "conversations - conversations - : ${conversations.size}")
                }

                // Sync recipients
                recipientCursorTemp?.use {
                    val recipients = recipientCursorTemp.map { cursor ->
                        cursorToRecipient.map(cursor).apply {
                            contact = contacts.firstOrNull { contact ->
                                contact.numbers.any {
                                    // Use exact match instead of compare
                                    address == it.address
                                }
                            }
                        }
                    }
                    realmTemp.insertOrUpdate(recipients)
                }
//                recipientCursorTemp?.use {
//                    val recipients = recipientCursorTemp.map { cursor ->
//                        cursorToRecipient.map(cursor).apply {
//                            contact = contacts.firstOrNull { contact ->
//                                contact.numbers.any {
//                                    phoneNumberUtils.compare(
//                                        address,
//                                        it.address
//                                    )
//                                }
//                            }
//                        }
//                    }
//                    realmTemp.insertOrUpdate(recipients)
//                }

                realmTemp.insert(SyncLog())
                realmTemp.commitTransaction()
            } catch (e: Exception) {
                realmTemp.cancelTransaction()
                e.printStackTrace()
            } finally {
                realmTemp.close()
//                EventBus.getDefault().post(MessageEvent(TEMP_REFRESH_MESSAGE))
            }
        }
    }

    override fun syncMessages() {
        if (MyApplication.dataLoading == true) return
        if (syncProgress.blockingFirst() is SyncRepository.SyncProgress.Running) return

        val contacts = getContacts()
        keys.reset()

        val messageCursor = cursorToMessage.getMessagesCursor()
        val conversationCursor = cursorToConversation.getConversationsCursor()
        val recipientCursor = cursorToRecipient.getRecipientCursor()

        val totalCount = (messageCursor?.count ?: 0) +
                (conversationCursor?.count ?: 0) +
                (recipientCursor?.count ?: 0)

        syncProgress.onNext(SyncRepository.SyncProgress.Running(0, 0, true))

        CoroutineScope(Dispatchers.IO).launch {
            var progress = 0
            val realm = Realm.getDefaultInstance()
            try {
                realm.beginTransaction()

                val persistedData = realm.copyFromRealm(
                    realm.where(Conversation::class.java)
                        .beginGroup()
                        .equalTo("archived", true)
                        .or()
                        .equalTo("blocked", true)
                        .or()
                        .equalTo("pinned", true)
                        .or()
                        .isNotEmpty("name")
                        .or()
                        .isNotEmpty("blockReason")
                        .endGroup()
                        .findAll()
                ).associateBy { it.id }.toMutableMap()

//                realm.delete(Conversation::class.java)
//                realm.delete(Message::class.java)
//                realm.delete(MmsPart::class.java)
//                realm.delete(Recipient::class.java)

                removeOldMessages(realm)
                realm.delete(Contact::class.java)
                realm.delete(ContactGroup::class.java)
                realm.delete(Conversation::class.java)
                realm.delete(Message::class.java)
                realm.delete(MmsPart::class.java)
                realm.delete(Recipient::class.java)

                messageCursor?.use {
                    val messageColumns = CursorToMessage.MessageColumns(messageCursor)
                    val messages = messageCursor.map { cursor ->
                        val message = cursorToMessage.map(Pair(cursor, messageColumns))
                        progress++
                        syncProgress.onNext(
                            SyncRepository.SyncProgress.Running(totalCount, progress, false)
                        )
                        message
                    }
                    realm.insertOrUpdate(messages)
                }

                // Legacy blocked senders
                val oldBlockedSenders = rxPrefs.getStringSet("pref_key_blocked_senders")
                oldBlockedSenders.get()
                    .mapNotNull { it.toLongOrNull() }
                    .filterNot { persistedData.containsKey(it) }
                    .forEach { threadId ->
                        persistedData[threadId] = Conversation(id = threadId, blocked = true)
                    }

                conversationCursor?.use {
                    val conversations = conversationCursor.map { cursor ->
                        cursorToConversation.map(cursor).apply {
                            persistedData[id]?.let {
                                archived = it.archived
                                blocked = it.blocked
                                isPrivate = it.isPrivate
                                pinned = it.pinned
                                name = it.name
                                blockReason = it.blockReason
                            }
                        }.also {
                            progress++
                            syncProgress.onNext(
                                SyncRepository.SyncProgress.Running(totalCount, progress, false)
                            )
                        }
                    }

                    if (conversations.isNotEmpty()) {
                        realm.where(Message::class.java)
                            .sort("date", Sort.DESCENDING)
                            .distinct("threadId")
                            .findAll()
                            .forEach { message ->
                                conversations.find { it.id == message.threadId }?.lastMessage =
                                    message
                            }

                        realm.insertOrUpdate(conversations)
                    }
                }


                recipientCursor?.use {
                    val recipients = recipientCursor.map { cursor ->
                        cursorToRecipient.map(cursor).apply {
                            val matchedContact = contacts.firstOrNull { contact ->
                                contact.numbers.any {
                                    val isMatch = address == it.address
                                    Log.d("SyncDebug", "Address: $address, Contact: ${contact.name}, Number: ${it.address}, Match: $isMatch")
                                    isMatch
                                }
                            }
                            contact = matchedContact
                            Log.d("SyncDebug", "Recipient: $address -> Contact: ${matchedContact?.name ?: "null"}")
                        }.also {
                            progress++
                            syncProgress.onNext(
                                SyncRepository.SyncProgress.Running(totalCount, progress, false)
                            )
                        }
                    }
                    realm.insertOrUpdate(recipients)
                }

//                recipientCursor?.use {
//                    val recipients = recipientCursor.map { cursor ->
//                        cursorToRecipient.map(cursor).apply {
//                            contact = contacts.firstOrNull { contact ->
//                                contact.numbers.any {
//                                    phoneNumberUtils.compare(address, it.address)
//                                }
//                            }
//                        }.also {
//                            progress++
//                            syncProgress.onNext(
//                                SyncRepository.SyncProgress.Running(totalCount, progress, false)
//                            )
//                        }
//                    }
//                    realm.insertOrUpdate(recipients)
//                }

                realm.insert(SyncLog())
                realm.commitTransaction()

                rxPrefs.getStringSet("pref_key_blocked_senders").delete()
            } catch (e: Exception) {
                realm.cancelTransaction()
                e.printStackTrace()
            } finally {
                realm.close()
                syncProgress.onNext(SyncRepository.SyncProgress.Idle)
//                EventBus.getDefault().post(MessageEvent(REFRESH_MESSAGE))
            }
        }
    }

    override fun syncMessage(uri: Uri): Message? {

        // If we don't have a valid type, return null
        val type = when {
            uri.toString().contains("mms") -> "mms"
            uri.toString().contains("sms") -> "sms"
            else -> return null
        }

        // If we don't have a valid id, return null
        val id = tryOrNull(false) { ContentUris.parseId(uri) } ?: return null

        // Check if the message already exists, so we can reuse the id
        val existingId = Realm.getDefaultInstance().use { realm ->
            realm.refresh()
            realm.where(Message::class.java)
                .equalTo("type", type)
                .equalTo("contentId", id)
                .findFirst()
                ?.id
        }

        // The uri might be something like content://mms/inbox/id
        // The box might change though, so we should just use the mms/id uri
        val stableUri = when (type) {
            "mms" -> ContentUris.withAppendedId(Telephony.Mms.CONTENT_URI, id)
            else -> ContentUris.withAppendedId(Telephony.Sms.CONTENT_URI, id)
        }

        return contentResolver.query(stableUri, null, null, null, null)?.use { cursor ->

            // If there are no rows, return null. Otherwise, we've moved to the first row
            if (!cursor.moveToFirst()) return null

            val columnsMap = CursorToMessage.MessageColumns(cursor)
            cursorToMessage.map(Pair(cursor, columnsMap)).apply {
                existingId?.let { this.id = it }

                if (isMms()) {
                    parts = RealmList<MmsPart>().apply {
                        addAll(cursorToPart.getPartsCursor(contentId)?.map { cursorToPart.map(it) }
                            .orEmpty())
                    }
                }

                conversationRepo.getOrCreateConversation(threadId)
                insertOrUpdate()

                val text = getText(false)
                val parsedReaction = reactions.parseEmojiReaction(text)
                if (parsedReaction != null) {
                    Realm.getDefaultInstance().use { realm ->
                        val targetMessage = reactions.findTargetMessage(
                            threadId,
                            parsedReaction.originalMessage,
                            realm
                        )
                        realm.executeTransaction {
                            reactions.saveEmojiReaction(
                                this,
                                parsedReaction,
                                targetMessage,
                                realm,
                            )
                        }
                    }
                }
            }
        }
    }

    override fun syncContacts() {
        // Load all the contacts
        var contacts = getContacts()

        Realm.getDefaultInstance()?.use { realm ->
            val recipients = realm.where(Recipient::class.java).findAll()

            realm.executeTransaction {
                realm.delete(Contact::class.java)
                realm.delete(ContactGroup::class.java)

                contacts = realm.copyToRealmOrUpdate(contacts)
                realm.insertOrUpdate(getContactGroups(contacts))

                // Update all the recipients with the new contacts
                recipients.forEach { recipient ->
                    recipient.contact = contacts.find { contact ->
                        contact.numbers.any {
                            phoneNumberUtils.compare(
                                recipient.address,
                                it.address
                            )
                        }
                    }
                }

                realm.insertOrUpdate(recipients)
            }

        }
    }

    private fun getContacts(): List<Contact> {
        val defaultNumberIds = Realm.getDefaultInstance().use { realm ->
            realm.where(PhoneNumber::class.java)
                .equalTo("isDefault", true)
                .findAll()
                .map { number -> number.id }
        }

        return cursorToContact.getContactsCursor()
            ?.map { cursor -> cursorToContact.map(cursor) }
            ?.groupBy { contact -> contact.lookupKey }
            ?.map { contacts ->
                // Sometimes, contacts providers on the phone will create duplicate phone number entries. This
                // commonly happens with Whatsapp. Let's try to detect these duplicate entries and filter them out
                val uniqueNumbers = mutableListOf<PhoneNumber>()
                contacts.value
                    .flatMap { it.numbers }
                    .forEach { number ->
                        number.isDefault = defaultNumberIds.any { id -> id == number.id }
                        val duplicate = uniqueNumbers.find { other ->
                            phoneNumberUtils.compare(number.address, other.address)
                        }

                        if (duplicate == null) {
                            uniqueNumbers += number
                        } else if (!duplicate.isDefault && number.isDefault) {
                            duplicate.isDefault = true
                        }
                    }

                contacts.value.first().apply {
                    numbers.clear()
                    numbers.addAll(uniqueNumbers)
                }
            } ?: listOf()
    }

    private fun getContactGroups(contacts: List<Contact>): List<ContactGroup> {
        val groupMembers = cursorToContactGroupMember.getGroupMembersCursor()
            ?.map(cursorToContactGroupMember::map)
            .orEmpty()

        val groups = cursorToContactGroup.getContactGroupsCursor()
            ?.map(cursorToContactGroup::map)
            .orEmpty()

        groups.forEach { group ->
            group.contacts.addAll(
                groupMembers
                .filter { member -> member.groupId == group.id }
                .mapNotNull { member -> contacts.find { contact -> contact.lookupKey == member.lookupKey } })
        }

        return groups
    }

    private fun removeOldMessages(realm: Realm) {
        realm.delete(Contact::class.java)
        realm.delete(ContactGroup::class.java)
        realm.delete(Conversation::class.java)
        realm.delete(Message::class.java)
        realm.delete(MmsPart::class.java)
        realm.delete(Recipient::class.java)
    }

}
