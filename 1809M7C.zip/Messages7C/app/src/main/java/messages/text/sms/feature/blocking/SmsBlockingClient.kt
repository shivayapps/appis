package messages.text.sms.feature.blocking

import io.reactivex.Completable
import io.reactivex.Single
import io.reactivex.schedulers.Schedulers
import messages.text.sms.repository.BlockingRepository
import javax.inject.Inject

class SmsBlockingClient @Inject constructor(
    private val blockingRepo: BlockingRepository
) : BlockingClient {

    override fun isAvailable(): Boolean = true

    override fun getClientCapability() = BlockingClient.Capability.BLOCK_WITH_PERMISSION

    override fun shouldBlock(address: String): Single<BlockingClient.Action> = isBlacklisted(address)

    override fun isBlacklisted(address: String): Single<BlockingClient.Action> =
        Single.fromCallable {
            when (blockingRepo.isBlocked(address)) {
                true -> BlockingClient.Action.Block()
                false -> BlockingClient.Action.DoNothing
            }
        }.subscribeOn(Schedulers.io())

    override fun block(addresses: List<String>): Completable =
        Completable.fromCallable {
            blockingRepo.blockNumber(*addresses.toTypedArray())
        }.subscribeOn(Schedulers.io())

    override fun unblock(addresses: List<String>): Completable =
        Completable.fromCallable {
            blockingRepo.unblockNumbers(*addresses.toTypedArray())
        }.subscribeOn(Schedulers.io())

    override fun openSettings() = Unit // TODO: Do this here once we implement AndroidX navigation

}