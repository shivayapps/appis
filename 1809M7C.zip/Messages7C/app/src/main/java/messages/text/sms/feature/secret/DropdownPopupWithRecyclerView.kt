package messages.text.sms.feature.secret

import android.content.Context
import android.graphics.Typeface
import android.util.Log
import android.view.Gravity
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.PopupWindow
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import messages.text.sms.databinding.PopupSpinnerDropdownBinding
import messages.text.sms.R


class DropdownPopupWithRecyclerView(
    private val context: Context,
    private val anchor: View
) {
    private var popupWindow: PopupWindow? = null
    private var binding: PopupSpinnerDropdownBinding? = null
    private var adapter: DropdownRecyclerAdapter? = null
    private var onItemSelectedListener: ((position: Int, item: String) -> Unit)? = null
    private var onDismissListener: (() -> Unit)? = null
    private var selectedPosition: Int = -1
    private var lastSelectedPosition: Int = -1
    private var items: Array<String> = emptyArray()
    private var maxVisibleItems: Int = 5
    private var itemHeightDp: Int = 56
    private var popupAnimation: Int = R.style.AnimationDropDownFromAnchor
    private var horizontalOffset: Int = 0
    private var verticalOffset: Int = 0
    private var isShowing: Boolean = false
    private var popupWidth: Int = ViewGroup.LayoutParams.MATCH_PARENT
    private var popupHeight: Int = ViewGroup.LayoutParams.WRAP_CONTENT
    private var enableCustomAnimation: Boolean = true
    private var animationDuration: Long = 200
    private var isBuilt: Boolean = false

    // Builder pattern methods
    fun setItems(items: Array<String>): DropdownPopupWithRecyclerView {
        this.items = items
        return this
    }

    fun setSelectedPosition(position: Int): DropdownPopupWithRecyclerView {
        this.selectedPosition = position
        this.lastSelectedPosition = position
        return this
    }

    fun setOnItemSelectedListener(listener: (position: Int, item: String) -> Unit): DropdownPopupWithRecyclerView {
        this.onItemSelectedListener = listener
        return this
    }

    fun setOnDismissListener(listener: () -> Unit): DropdownPopupWithRecyclerView {
        this.onDismissListener = listener
        return this
    }

    fun setMaxVisibleItems(max: Int): DropdownPopupWithRecyclerView {
        this.maxVisibleItems = max
        return this
    }

    fun setItemHeight(heightInDp: Int): DropdownPopupWithRecyclerView {
        this.itemHeightDp = heightInDp
        return this
    }

    fun setPopupAnimation(styleRes: Int): DropdownPopupWithRecyclerView {
        this.popupAnimation = styleRes
        return this
    }

    fun setOffset(xOffset: Int, yOffset: Int): DropdownPopupWithRecyclerView {
        this.horizontalOffset = xOffset
        this.verticalOffset = yOffset
        return this
    }

    fun setPopupWidth(width: Int): DropdownPopupWithRecyclerView {
        this.popupWidth = width
        return this
    }

    fun setPopupHeight(height: Int): DropdownPopupWithRecyclerView {
        this.popupHeight = height
        return this
    }

    fun setCustomAnimationEnabled(enabled: Boolean): DropdownPopupWithRecyclerView {
        this.enableCustomAnimation = enabled
        return this
    }

    fun setAnimationDuration(duration: Long): DropdownPopupWithRecyclerView {
        this.animationDuration = duration
        return this
    }

    fun build(): DropdownPopupWithRecyclerView {
        if (!isBuilt) {
            createPopup()
            isBuilt = true
        }
        return this
    }

    private fun createPopup() {
        binding = PopupSpinnerDropdownBinding.inflate(LayoutInflater.from(context))

        val recyclerView = binding?.recyclerViewPopup
        recyclerView?.apply {
            layoutManager = LinearLayoutManager(context)
            isNestedScrollingEnabled = false
            setHasFixedSize(true)

            addItemDecoration(object : RecyclerView.ItemDecoration() {
                override fun getItemOffsets(
                    outRect: android.graphics.Rect,
                    view: View,
                    parent: RecyclerView,
                    state: RecyclerView.State
                ) {
                    val position = parent.getChildAdapterPosition(view)
//                    if (position == 0) {
//                        outRect.top = 0
//                    } else {
                    outRect.top = 2.dpToPx()
//                    }
                }
            })

            // Create adapter and store it in the class variable
            adapter = DropdownRecyclerAdapter(context, items).apply {
                setOnItemClickListener { position, item ->
                    Log.d("Dropdown", "setOnItemClickListener:$position")
                    selectedPosition = position
                    lastSelectedPosition = position
                    onItemSelectedListener?.invoke(position, item)
                    dismissWithAnimation()
                }
                // Apply initial selection if set
                if (selectedPosition != -1) {
                    setSelectedPosition(selectedPosition)
                }
            }
            this.adapter = this@apply.adapter
        }

        // Calculate popup dimensions
        val width = if (popupWidth != ViewGroup.LayoutParams.WRAP_CONTENT) {
            popupWidth
        } else if (anchor.width > 0) {
            anchor.width
        } else {
            ViewGroup.LayoutParams.WRAP_CONTENT
        }

        val maxHeight = (context.resources.displayMetrics.heightPixels * 0.5).toInt()

        val visibleItems = items.filterIndexed { index, _ -> index != 0 }
        val visibleCount = minOf(visibleItems.size, maxVisibleItems)
        val itemHeightPx = itemHeightDp.dpToPx()
        val padding = 16.dpToPx()
        val height = if (popupHeight != ViewGroup.LayoutParams.WRAP_CONTENT) {
            popupHeight
        } else if (visibleCount > 0) {
            minOf(visibleCount * itemHeightPx + padding, maxHeight)
        } else {
            ViewGroup.LayoutParams.WRAP_CONTENT
        }

        popupWindow = PopupWindow(
            binding?.root,
            width,
            height,
            true
        ).apply {
            animationStyle = popupAnimation
            isOutsideTouchable = true
            elevation = 8f
            inputMethodMode = PopupWindow.INPUT_METHOD_NOT_NEEDED

            setTouchInterceptor { _, event ->
                if (event.action == MotionEvent.ACTION_OUTSIDE) {
                    dismissWithAnimation()
                    true
                } else {
                    false
                }
            }

            setOnDismissListener {
                this@DropdownPopupWithRecyclerView.isShowing = false
                onDismissListener?.invoke()
            }
        }

        Log.d("Dropdown", "createPopup: adapter created = ${adapter != null}")
    }

    fun show() {
        Log.d("Dropdown", "show.adapter:${adapter != null}")
        Log.d("Dropdown", "show.isBuilt:$isBuilt")

        if (!isShowing && items.isNotEmpty()) {
            // Ensure adapter is not null
            if (adapter == null) {
                Log.d("Dropdown", "show.adapter is NULL, recreating...")
                recreateAdapter()
            }

            // Apply the last selected position before showing
            val positionToShow =
                if (lastSelectedPosition != -1) lastSelectedPosition else selectedPosition
            Log.d("Dropdown", "show.positionToShow:$positionToShow")

            adapter?.let {
                if (positionToShow != -1) {
                    Log.d("Dropdown", "show.calling setSelectedPosition:$positionToShow")
                    it.setSelectedPosition(positionToShow)
                }
            }

            popupWindow?.showAsDropDown(anchor, horizontalOffset, verticalOffset)
            isShowing = true
            if (enableCustomAnimation) {
                animatePopupEnter()
            }
        }
    }

    private fun recreateAdapter() {
        binding?.recyclerViewPopup?.let { recyclerView ->
            adapter = DropdownRecyclerAdapter(context, items).apply {
                setOnItemClickListener { position, item ->
                    Log.d("Dropdown", "setOnItemClickListener:$position")
                    selectedPosition = position
                    lastSelectedPosition = position
                    onItemSelectedListener?.invoke(position, item)
                    dismissWithAnimation()
                }
                if (selectedPosition != -1) {
                    setSelectedPosition(selectedPosition)
                }
            }
            recyclerView.adapter = adapter
            Log.d("Dropdown", "recreateAdapter: adapter recreated = ${adapter != null}")
        }
    }

    fun showWithOffset(xOffset: Int, yOffset: Int) {
        if (!isShowing && items.isNotEmpty()) {
            if (adapter == null) {
                recreateAdapter()
            }

            val positionToShow =
                if (lastSelectedPosition != -1) lastSelectedPosition else selectedPosition
            adapter?.let {
                if (positionToShow != -1) {
                    it.setSelectedPosition(positionToShow)
                }
            }
            popupWindow?.showAsDropDown(anchor, xOffset, yOffset)
            isShowing = true
            if (enableCustomAnimation) {
                animatePopupEnter()
            }
        }
    }

    fun showAtLocation(x: Int, y: Int) {
        if (!isShowing && items.isNotEmpty()) {
            if (adapter == null) {
                recreateAdapter()
            }

            val positionToShow =
                if (lastSelectedPosition != -1) lastSelectedPosition else selectedPosition
            adapter?.let {
                if (positionToShow != -1) {
                    it.setSelectedPosition(positionToShow)
                }
            }
            popupWindow?.showAtLocation(anchor, Gravity.NO_GRAVITY, x, y)
            isShowing = true
            if (enableCustomAnimation) {
                animatePopupEnter()
            }
        }
    }

    fun showAsDropDown(xOffset: Int, yOffset: Int, gravity: Int) {
        if (!isShowing && items.isNotEmpty()) {
            if (adapter == null) {
                recreateAdapter()
            }

            val positionToShow =
                if (lastSelectedPosition != -1) lastSelectedPosition else selectedPosition
            adapter?.let {
                if (positionToShow != -1) {
                    it.setSelectedPosition(positionToShow)
                }
            }
            popupWindow?.showAsDropDown(anchor, xOffset, yOffset, gravity)
            isShowing = true
            if (enableCustomAnimation) {
                animatePopupEnter()
            }
        }
    }

    fun dismiss() {
        if (isShowing) {
            popupWindow?.dismiss()
            isShowing = false
        }
    }

    fun dismissWithAnimation() {
        if (isShowing) {
            animatePopupExit {
                popupWindow?.dismiss()
                isShowing = false
            }
        }
    }

    fun toggle() {
        Log.d("Dropdown", "toggle.selectedPosition:$selectedPosition")
        Log.d("Dropdown", "toggle.lastSelectedPosition:$lastSelectedPosition")
        Log.d("Dropdown", "toggle.adapter:${adapter != null}")

        if (isShowing) {
            dismissWithAnimation()
        } else {
            if (lastSelectedPosition != -1) {
                selectedPosition = lastSelectedPosition
            }
            show()
        }
    }

    private fun animatePopupEnter() {
        val root = binding?.root ?: return
        root.apply {
            alpha = 0f
            translationY = -20.dpToPx().toFloat()
            animate()
                .alpha(1f)
                .translationY(0f)
                .setDuration(animationDuration)
                .setInterpolator(android.view.animation.AccelerateDecelerateInterpolator())
                .start()
        }
    }

    private fun animatePopupExit(onComplete: () -> Unit) {
        val root = binding?.root ?: run { onComplete(); return }
        root.animate()
            .alpha(0f)
            .translationY(-20.dpToPx().toFloat())
            .setDuration(animationDuration / 2)
            .setInterpolator(android.view.animation.AccelerateInterpolator())
            .withEndAction {
                onComplete()
            }
            .start()
    }

    fun isShowing(): Boolean = isShowing

    fun updateSelectedPosition(position: Int) {
        Log.d("Dropdown", "updateSelectedPosition:$position")
        selectedPosition = position
        lastSelectedPosition = position
        if (adapter == null) {
            recreateAdapter()
        }
        adapter?.let {
            Log.d("Dropdown", "updateSelectedPosition.calling setSelectedPosition")
            it.setSelectedPosition(position)
            if (isShowing) {
                it.refreshSelected()
            }
        }
    }

    fun getSelectedPosition(): Int =
        if (lastSelectedPosition != -1) lastSelectedPosition else selectedPosition

    fun getLastSelectedPosition(): Int = lastSelectedPosition

    fun getSelectedItem(): String? {
        val pos = getSelectedPosition()
        return if (pos >= 0 && pos < items.size) items[pos] else null
    }

    fun getItems(): Array<String> = items

    private fun updatePopupHeight() {
        val visibleItems = items.filterIndexed { index, _ -> index != 0 }
        val visibleCount = minOf(visibleItems.size, maxVisibleItems)
        val itemHeightPx = itemHeightDp.dpToPx()
        val padding = 16.dpToPx()
        val maxHeight = (context.resources.displayMetrics.heightPixels * 0.5).toInt()
        val height = if (visibleCount > 0) {
            minOf(visibleCount * itemHeightPx + padding, maxHeight)
        } else {
            ViewGroup.LayoutParams.WRAP_CONTENT
        }
        popupWindow?.height = height
        popupWindow?.update()
    }

    fun updateWidth(width: Int) {
        popupWindow?.width = width
        popupWindow?.update()
    }

    fun setBackgroundDrawable(drawableRes: Int) {
        popupWindow?.setBackgroundDrawable(ContextCompat.getDrawable(context, drawableRes))
    }

    fun getRecyclerView(): RecyclerView? = binding?.recyclerViewPopup

    fun getBinding(): PopupSpinnerDropdownBinding? = binding

    private fun Int.dpToPx(): Int {
        return (this * context.resources.displayMetrics.density).toInt()
    }

    // Inner Adapter Class
    class DropdownRecyclerAdapter(
        private val context: Context,
        private val items: Array<String>
    ) : RecyclerView.Adapter<DropdownRecyclerAdapter.ViewHolder>() {

        private var selectedPosition: Int = -1
        private var onItemClickListener: ((position: Int, item: String) -> Unit)? = null
        private var onItemLongClickListener: ((position: Int, item: String) -> Unit)? = null

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
            val view = LayoutInflater.from(context)
                .inflate(R.layout.item_spinner_que, parent, false)
            return ViewHolder(view)
        }

        override fun onBindViewHolder(holder: ViewHolder, position: Int) {
            val item = items[position]
            holder.textView.text = item

//            if (position == 0) {
//                holder.textView.setTextColor(ContextCompat.getColor(context, R.color.textPrimary))
//                holder.textView.textSize = 18f
//                holder.textView.setTypeface(holder.textView.typeface, Typeface.BOLD)
//                holder.textView.setCompoundDrawablesRelativeWithIntrinsicBounds(0, 0, 0, 0)
//                holder.itemView.isEnabled = false
//                holder.textView.isEnabled = false
//                holder.itemView.setOnClickListener(null)
//            } else {
            holder.textView.setTextColor(ContextCompat.getColor(context, R.color.textPrimary))
            holder.textView.textSize = 16f
            holder.itemView.isEnabled = true
            holder.textView.isEnabled = true

            if (position == selectedPosition) {
                highlightSelected(holder.textView)
            } else {
                unHighlight(holder.textView)
            }

            holder.itemView.setOnClickListener {
                onItemClickListener?.invoke(position, item)
            }

            holder.itemView.setOnLongClickListener {
                onItemLongClickListener?.invoke(position, item)
                true
            }
//            }
        }

        override fun getItemCount(): Int = items.size

//        override fun getItemViewType(position: Int): Int {
//            return if (position == 0) 0 else 1
//        }

        fun setSelectedPosition(position: Int) {
            Log.d("Dropdown", "setSelectedPosition CALLED:$position")
            if (position != 0 && position < items.size) {
                val oldPosition = selectedPosition
                selectedPosition = position
                if (oldPosition != -1 && oldPosition < items.size) {
                    notifyItemChanged(oldPosition)
                }
                notifyItemChanged(position)
                Log.d("Dropdown", "setSelectedPosition COMPLETED:$position")
            } else {
                Log.d(
                    "Dropdown",
                    "setSelectedPosition SKIPPED: position=$position, items.size=${items.size}"
                )
            }
        }

        fun getSelectedPosition(): Int = selectedPosition

        fun refreshSelected() {
            Log.d("Dropdown", "refreshSelected:$selectedPosition")
            if (selectedPosition != -1 && selectedPosition < items.size) {
                notifyItemChanged(selectedPosition)
            }
        }

        fun setOnItemClickListener(listener: (position: Int, item: String) -> Unit) {
            onItemClickListener = listener
        }

        fun setOnItemLongClickListener(listener: (position: Int, item: String) -> Unit) {
            onItemLongClickListener = listener
        }

        private fun highlightSelected(view: TextView) {
            view.setTextColor(ContextCompat.getColor(context, R.color.md_theme_primary))
            view.setCompoundDrawablesRelativeWithIntrinsicBounds(
                0,
                0,
                R.drawable.ic_check_primary,
                0
            )
            view.compoundDrawablePadding = context.resources.getDimensionPixelSize(R.dimen._8sdp)
        }

        private fun unHighlight(view: TextView) {
            view.setTextColor(ContextCompat.getColor(context, R.color.textPrimary))
            view.setCompoundDrawablesRelativeWithIntrinsicBounds(0, 0, 0, 0)
            view.compoundDrawablePadding = 0
        }

        class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
            val textView: TextView = itemView.findViewById(R.id.textViewQue)
        }
    }
}