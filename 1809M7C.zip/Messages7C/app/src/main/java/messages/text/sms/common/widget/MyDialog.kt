package messages.text.sms.common.widget

import android.app.Activity
import android.app.Dialog
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.view.Gravity
import android.view.Window
import android.view.WindowManager
import messages.text.sms.common.base.MyAdapter
import messages.text.sms.extensions.beVisible
import messages.text.sms.databinding.QuickDialogBinding


class MyDialog {
    private lateinit var dialog: Dialog

    fun show(
        activity: Activity,
        titleText: String,
        subTitleText: String,
        adapter: MyAdapter<*, *>? = null,
        positiveText: String,
        negativeText: String,
        positiveActionCallback: () -> Unit,
        negativeActionCallback: () -> Unit,
        cancelListener: () -> Unit
    ) {

        dialog = Dialog(activity)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.window?.apply {
            setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            setGravity(Gravity.CENTER)
            setDimAmount(0.8f)
            attributes?.windowAnimations = android.R.style.Animation_Dialog
            setLayout(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.WRAP_CONTENT
            )
        }

        val binding = QuickDialogBinding.inflate(activity.layoutInflater)
        dialog.setContentView(binding.root)

        dialog.window?.setLayout(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.WRAP_CONTENT
        )

        binding.title.text = titleText
        binding.subtitle.text = subTitleText
        binding.positiveButton.text = positiveText
        binding.negativeButton.text = negativeText
        binding.list.beVisible()
        binding.list.adapter = adapter
        binding.positiveButton.setOnClickListener {
            positiveActionCallback()
            dialog.dismiss()
        }
        binding.negativeButton.setOnClickListener {
            negativeActionCallback()
            dialog.dismiss()
        }
        dialog.setOnDismissListener {
            cancelListener()
        }
        dialog.show()
    }

}


