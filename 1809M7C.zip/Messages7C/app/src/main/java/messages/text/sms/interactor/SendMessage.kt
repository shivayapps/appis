
package messages.text.sms.interactor

import android.content.Context
import android.util.Log
import messages.text.sms.manager.ShortcutManager
import messages.text.sms.model.Attachment
import messages.text.sms.repository.ConversationRepository
import messages.text.sms.repository.MessageRepository
import io.reactivex.Flowable
import javax.inject.Inject

class SendMessage @Inject constructor(
    private val context: Context,
    private val conversationRepo: ConversationRepository,
    private val messageRepo: MessageRepository,
    private val updateBadge: UpdateBadge,
    private val shortcutManager: ShortcutManager
) : Interactor<SendMessage.Params>() {

    data class Params(
        val subId: Int,
        val threadId: Long,
        val addresses: List<String>,
        val body: String,
        val attachments: List<Attachment> = listOf(),
        val delay: Int = 0
    )

    override fun buildObservable(params: Params): Flowable<*> = Flowable.just(Unit)
        .filter { params.addresses.isNotEmpty() }
        .doOnNext {
            Log.e("ComposeModel", "SendMessage buildObservable")
            Log.e("ComposeModel", "SendMessage addresses:${params.addresses}")
            Log.e("ComposeModel", "SendMessage threadId:${params.threadId}")
            // If a threadId isn't provided, try to obtain one
            val threadId = when (params.threadId) {
                0L -> conversationRepo.getOrCreateConversation(params.addresses)?.id ?: 0
                else -> params.threadId
            }

            // if unable to find or create a conversation (and/or underlying threadId), fail
            if (threadId == 0L)
                return@doOnNext

            params.apply {
                messageRepo.sendMessage(subId, threadId, addresses, body, attachments, delay)
            }

            conversationRepo.updateConversations(threadId)

            conversationRepo.markUnarchived(threadId)

            shortcutManager.reportShortcutUsed(threadId)

            // delete attachment local files, if any, because they're saved to mms db by now
            params.attachments.forEach { it.removeCacheFile() }
        }
        .flatMap { updateBadge.buildObservable(Unit) } // Update the widget

}