package messages.text.sms.feature.backup

import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.net.Uri
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.view.WindowManager
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.core.view.children
import androidx.core.view.isVisible
import com.jakewharton.rxbinding2.view.clicks
import io.reactivex.Observable
import io.reactivex.subjects.PublishSubject
import io.reactivex.subjects.Subject
import messages.text.sms.R
import messages.text.sms.adhelper.AdUtil
import messages.text.sms.common.base.MyController
import messages.text.sms.extensions.baseConfig
import messages.text.sms.extensions.beGone
import messages.text.sms.common.util.MyActivityResultContracts
import messages.text.sms.extensions.getLabel
import messages.text.sms.extensions.setBackgroundTint
import messages.text.sms.extensions.setNegativeButton
import messages.text.sms.extensions.setPositiveButton
import messages.text.sms.extensions.setShowing
import messages.text.sms.extensions.setTint
import messages.text.sms.common.util.DateFormatter
import messages.text.sms.common.widget.PreferenceView
import messages.text.sms.databinding.BackupControllerBinding
import messages.text.sms.databinding.DialogCustomMessageBinding
import messages.text.sms.databinding.DialogCustomThemeBinding
import messages.text.sms.injection.appComponent
import messages.text.sms.repository.BackupRepository
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale
import javax.inject.Inject

class BackupController :
    MyController<BackupControllerBinding, BackupView, BackupState, BackupPresenter>(), BackupView {

    @Inject
    override lateinit var presenter: BackupPresenter

    private val selectFolderCancelSubject: Subject<Unit> = PublishSubject.create()
    private val selectFolderConfirmSubject: Subject<Unit> = PublishSubject.create()

    private val restoreErrorConfirmSubject: Subject<Unit> = PublishSubject.create()

    private val confirmRestoreCancelSubject: Subject<Unit> = PublishSubject.create()
    private val confirmRestoreConfirmSubject: Subject<Unit> = PublishSubject.create()

    private val stopRestoreConfirmSubject: Subject<Unit> = PublishSubject.create()
    private val stopRestoreCancelSubject: Subject<Unit> = PublishSubject.create()

    private val documentTreeSelectedSubject: Subject<Uri> = PublishSubject.create()
    private val documentSelectedSubject: Subject<Uri> = PublishSubject.create()

    private fun createStopRestoreDialog(): AlertDialog {
        val binding = DialogCustomMessageBinding.inflate(activity!!.layoutInflater)

        binding.titleText.setText(R.string.backup_restore_stop_title)
        binding.messageText.setText(R.string.backup_restore_stop_message)
        binding.btnNegative.setText(R.string.button_cancel)
        binding.btnPositive.setText(R.string.button_stop)

        val dialog = AlertDialog.Builder(activity!!)
            .setView(binding.root)
            .setCancelable(false)
            .create()
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.window?.apply {
            setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            setGravity(Gravity.CENTER)
            setDimAmount(0.8f)
            attributes?.windowAnimations = android.R.style.Animation_Dialog
            setLayout(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.WRAP_CONTENT
            )
        }

        binding.btnNegative.setOnClickListener {
            stopRestoreCancelSubject.onNext(Unit)
            dialog.dismiss()
        }

        binding.btnPositive.setOnClickListener {
            stopRestoreConfirmSubject.onNext(Unit)
            dialog.dismiss()
        }

        return dialog

    }

    private val stopRestoreDialog by lazy {
        createStopRestoreDialog()
//        AlertDialog.Builder(activity!!)
//            .setTitle(R.string.backup_restore_stop_title)
//            .setMessage(R.string.backup_restore_stop_message)
//            .setPositiveButton(R.string.button_stop, stopRestoreConfirmSubject)
//            .setNegativeButton(R.string.button_cancel, stopRestoreCancelSubject)
//            .setCancelable(false)
//            .create()
    }

    private fun createSelectLocationRationaleDialog(): AlertDialog {
        val binding = DialogCustomMessageBinding.inflate(activity!!.layoutInflater)

        binding.titleText.setText(R.string.backup_select_location_rationale_title)
        binding.messageText.setText(R.string.backup_select_location_rationale_message)
        binding.btnNegative.setText(R.string.button_cancel)
        binding.btnPositive.setText(R.string.button_continue)

        val dialog = AlertDialog.Builder(activity!!)
            .setView(binding.root)
            .setCancelable(false)
            .create()
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.window?.apply {
            setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            setGravity(Gravity.CENTER)
            setDimAmount(0.8f)
            attributes?.windowAnimations = android.R.style.Animation_Dialog
            setLayout(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.WRAP_CONTENT
            )
        }

        binding.btnNegative.setOnClickListener {
            selectFolderCancelSubject.onNext(Unit)
            dialog.dismiss()
        }

        binding.btnPositive.setOnClickListener {
            selectFolderConfirmSubject.onNext(Unit)
            dialog.dismiss()
        }

        return dialog
    }

    private val selectLocationRationaleDialog by lazy {
        createSelectLocationRationaleDialog()
//        AlertDialog.Builder(activity!!)
//            .setTitle(R.string.backup_select_location_rationale_title)
//            .setMessage(R.string.backup_select_location_rationale_message)
//            .setPositiveButton(R.string.button_continue, selectFolderConfirmSubject)
//            .setNegativeButton(R.string.button_cancel, selectFolderCancelSubject)
//            .setCancelable(false)
//            .create()
    }

    private fun createSelectedBackupErrorDialog(): AlertDialog {
        val binding = DialogCustomMessageBinding.inflate(activity!!.layoutInflater)

        binding.titleText.setText(R.string.backup_selected_backup_error_title)
        binding.messageText.setText(R.string.backup_selected_backup_error_message)
        binding.btnNegative.setText(R.string.button_cancel)
        binding.btnPositive.setText(R.string.button_continue)

        val dialog = AlertDialog.Builder(activity!!)
            .setView(binding.root)
            .setCancelable(false)
            .create()
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.window?.apply {
            setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            setGravity(Gravity.CENTER)
            setDimAmount(0.8f)
            attributes?.windowAnimations = android.R.style.Animation_Dialog
            setLayout(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.WRAP_CONTENT
            )
        }

        binding.btnNegative.setOnClickListener {
            dialog.dismiss()
        }

        binding.btnPositive.setOnClickListener {
            restoreErrorConfirmSubject.onNext(Unit)
            dialog.dismiss()
        }

        return dialog

    }

    private val selectedBackupErrorDialog by lazy {
        createSelectedBackupErrorDialog()
//        AlertDialog.Builder(activity!!)
//            .setTitle(R.string.backup_selected_backup_error_title)
//            .setMessage(R.string.backup_selected_backup_error_message)
//            .setPositiveButton(R.string.button_continue, restoreErrorConfirmSubject)
//            .setCancelable(false)
//            .create()
    }

    private var selectedBackupDetailsDialog: AlertDialog? = null

    private fun showSelectedBackupDetailsDialog(message: String) {
        selectedBackupDetailsDialog?.dismiss()
        val binding = DialogCustomMessageBinding.inflate(activity!!.layoutInflater)
        binding.titleText.setText(R.string.backup_selected_backup_details_title)
        binding.messageText.text = message
        binding.btnNegative.setText(R.string.button_cancel)
        binding.btnPositive.setText(R.string.label_restore)
        val dialog = AlertDialog.Builder(activity!!)
            .setView(binding.root)
            .setCancelable(false)
            .create()
        binding.btnNegative.setOnClickListener {
            confirmRestoreCancelSubject.onNext(Unit)
            dialog.dismiss()
        }
        binding.btnPositive.setOnClickListener {
            confirmRestoreConfirmSubject.onNext(Unit)
            dialog.dismiss()
        }
        dialog.setOnDismissListener {
            if (selectedBackupDetailsDialog === dialog) {
                selectedBackupDetailsDialog = null
            }
        }
        dialog.show()
        dialog.window?.apply {
            setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            setLayout(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.WRAP_CONTENT
            )
        }
        selectedBackupDetailsDialog = dialog
    }

    private fun hideSelectedBackupDetailsDialog() {
        selectedBackupDetailsDialog?.dismiss()
    }

//    private fun createSelectedBackupDetailsDialog(): AlertDialog {
//        val binding = DialogCustomMessageBinding.inflate(activity!!.layoutInflater)
//        binding.titleText.setText(R.string.backup_selected_backup_details_title)
////        binding.messageText.setText(R.string.backup_selected_backup_error_message)
//        //binding.messageText.beGone()
//        binding.btnNegative.setText(R.string.button_cancel)
//        binding.btnPositive.setText(R.string.label_restore)
//
//        val dialog = AlertDialog.Builder(activity!!)
//            .setView(binding.root)
//            .setCancelable(false)
//            .create()
//        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
//        dialog.window?.apply {
//            setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
//            setGravity(Gravity.CENTER)
//            setDimAmount(0.8f)
//            attributes?.windowAnimations = android.R.style.Animation_Dialog
//            setLayout(
//                WindowManager.LayoutParams.MATCH_PARENT,
//                WindowManager.LayoutParams.WRAP_CONTENT
//            )
//        }
//
//        binding.btnNegative.setOnClickListener {
//            confirmRestoreCancelSubject.onNext(Unit)
//            dialog.dismiss()
//        }
//
//        binding.btnPositive.setOnClickListener {
//            confirmRestoreConfirmSubject.onNext(Unit)
//            dialog.dismiss()
//        }
////        fun setMessage(message: CharSequence) {
////            binding.messageText.text = message
////        }
//        return dialog
//
//    }
//    private val selectedBackupDetailsDialog by lazy {
//        createSelectedBackupDetailsDialog()
////        AlertDialog.Builder(activity!!)
////            .setTitle(R.string.backup_selected_backup_details_title)
////            .setPositiveButton(R.string.label_restore, confirmRestoreConfirmSubject)
////            .setNegativeButton(R.string.button_cancel, confirmRestoreCancelSubject)
////            .setCancelable(false)
////            .create()
//    }

    private lateinit var openDirectory: ActivityResultLauncher<Uri?>
    private lateinit var openDocument: ActivityResultLauncher<MyActivityResultContracts.OpenDocumentParams>

    init {
        appComponent.inject(this)
    }

    override fun inflateBinding(
        inflater: LayoutInflater,
        container: ViewGroup
    ): BackupControllerBinding =
        BackupControllerBinding.inflate(inflater, container, false)

    override fun onContextAvailable(context: Context) {
        // Init activity result contracts
        openDirectory = themedActivity!!
            .registerForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
                uri?.let(documentTreeSelectedSubject::onNext)
            }

        openDocument = themedActivity!!
            .registerForActivityResult(MyActivityResultContracts.OpenDocument()) { uri ->
                uri?.let(documentSelectedSubject::onNext)
            }
    }

    override fun onAttach(view: View) {
        super.onAttach(view)
        presenter.bindIntents(this)
        setTitle(R.string.backup_title)
//        showBackButton(true)
    }

    override fun onViewCreated() {
        super.onViewCreated()

        themedActivity?.colors?.theme()?.let { theme ->
//            binding.progressBar.indeterminateTintList = ColorStateList.valueOf(theme.theme)
//            binding.progressBar.progressTintList = ColorStateList.valueOf(theme.theme)
//            binding.fab.setBackgroundTint(theme.theme)
//            binding.fabIcon.setTint(theme.textPrimary)
//            binding.fabLabel.setTextColor(theme.textPrimary)
        }

//        binding.linearLayout.children
//            .mapNotNull { it as? PreferenceView }
//            .map { it.titleView }
//            .forEach { it.setTypeface(it.typeface, Typeface.BOLD) }
    }

    override fun render(state: BackupState) {
        when {
            state.backupProgress.running -> {
                binding.progressIcon.setImageResource(R.drawable.ic_file_upload_black_24dp)
                binding.progressTitle.setText(R.string.backup_backing_up)
                binding.progressSummary.text = state.backupProgress.getLabel(activity!!)
                binding.progressSummary.isVisible = binding.progressSummary.text.isNotEmpty()
                binding.progressCancel.isVisible = false
                val running = (state.backupProgress as? BackupRepository.Progress.Running)
                binding.progressBar.isVisible =
                    state.backupProgress.indeterminate || (running?.max ?: 0) > 0
                binding.progressBar.isIndeterminate = state.backupProgress.indeterminate
                binding.progressBar.max = running?.max ?: 0
                binding.progressBar.progress = running?.count ?: 0
                binding.progress.isVisible = true
                binding.btnBackUp.isVisible = false

                if (state.backupProgress is BackupRepository.Progress.Finished) {
                    val timestamp = SimpleDateFormat(
                        "MM/dd/yyyy HH:mm",
                        Locale.getDefault()
                    ).format(System.currentTimeMillis())
                    activity!!.baseConfig.lastBackup = timestamp
                }
            }

            state.restoreProgress.running -> {
                binding.progressIcon.setImageResource(R.drawable.ic_file_download_black_24dp)
                binding.progressTitle.setText(R.string.backup_restoring)
                binding.progressSummary.text = state.restoreProgress.getLabel(activity!!)
                binding.progressSummary.isVisible = binding.progressSummary.text.isNotEmpty()
                binding.progressCancel.isVisible = true
                val running = (state.restoreProgress as? BackupRepository.Progress.Running)
                binding.progressBar.isVisible =
                    state.restoreProgress.indeterminate || (running?.max ?: 0) > 0
                binding.progressBar.isIndeterminate = state.restoreProgress.indeterminate
                binding.progressBar.max = running?.max ?: 0
                binding.progressBar.progress = running?.count ?: 0
                binding.progress.isVisible = true
                binding.btnBackUp.isVisible = false
            }

            else -> {
                binding.progress.isVisible = false
                binding.btnBackUp.isVisible = true
                //BackupRepository.Progress.Finished

//                val currentTime=Calendar.getInstance().timeInMillis
                binding.lastBackupTime.text = activity!!.baseConfig.lastBackup
            }
        }

        selectLocationRationaleDialog.setShowing(state.showLocationRationale)

        selectedBackupErrorDialog.setShowing(state.showSelectedBackupError)

//        selectedBackupDetailsDialog.setMessage(state.selectedBackupDetails)
//        selectedBackupDetailsDialog.setShowing(state.selectedBackupDetails != null)
        state.selectedBackupDetails?.let(::showSelectedBackupDetailsDialog)
            ?: hideSelectedBackupDetailsDialog()

        stopRestoreDialog.setShowing(state.showStopRestoreDialog)

//        binding.fabIcon.setImageResource(R.drawable.ic_file_upload_black_24dp)
//        binding.fabLabel.setText(R.string.backup_now)
    }

    override fun setBackupLocationClicks(): Observable<*> = binding.location.clicks()

    override fun restoreClicks(): Observable<*> = binding.cardRestore.clicks()

    override fun locationRationaleConfirmClicks(): Observable<*> = selectFolderConfirmSubject

    override fun locationRationaleCancelClicks(): Observable<*> = selectFolderCancelSubject

    override fun selectedBackupErrorClicks(): Observable<*> = restoreErrorConfirmSubject

    override fun confirmRestoreBackupConfirmClicks(): Observable<*> = confirmRestoreConfirmSubject

    override fun confirmRestoreBackupCancelClicks(): Observable<*> = confirmRestoreCancelSubject

    override fun stopRestoreClicks(): Observable<*> = binding.progressCancel.clicks()

    override fun stopRestoreConfirmed(): Observable<*> = stopRestoreConfirmSubject

    override fun stopRestoreCancel(): Observable<*> = stopRestoreCancelSubject

    override fun backupClicks(): Observable<*> = binding.btnBackUp.clicks()

    override fun documentTreeSelected(): Observable<Uri> = documentTreeSelectedSubject

    override fun documentSelected(): Observable<Uri> = documentSelectedSubject

    override fun selectFolder(initialUri: Uri) {
        AdUtil.isSystemDialogOpen = true
        openDirectory.launch(initialUri)
    }

    override fun selectFile(initialUri: Uri) {
        AdUtil.isSystemDialogOpen = true
        openDocument.launch(
            MyActivityResultContracts.OpenDocumentParams(
                mimeTypes = listOf("application/json", "application/octet-stream"),
                initialUri = initialUri
            )
        )
    }

}
