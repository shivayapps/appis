package messages.text.sms.feature.notificationprefs

import android.app.Activity
import android.content.Intent
import android.media.RingtoneManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import androidx.activity.OnBackPressedCallback
import androidx.core.view.isVisible
import androidx.lifecycle.ViewModelProvider
import com.jakewharton.rxbinding2.view.clicks
import com.uber.autodispose.android.lifecycle.scope
import com.uber.autodispose.autoDispose
import dagger.android.AndroidInjection
import messages.text.sms.R
import messages.text.sms.dialog.OptionDialog
import messages.text.sms.common.base.MainBaseThemedActivity
import messages.text.sms.extensions.setVisible
import messages.text.sms.common.widget.PreferenceView
import messages.text.sms.databinding.NotificationPrefsActivityBinding
import io.reactivex.Observable
import io.reactivex.subjects.PublishSubject
import io.reactivex.subjects.Subject
import javax.inject.Inject

class NotificationPrefsActivity : MainBaseThemedActivity<NotificationPrefsActivityBinding>(
    NotificationPrefsActivityBinding::inflate
), NotificationPrefsView {

    @Inject
    lateinit var previewModeDialog: OptionDialog

    @Inject
    lateinit var actionsDialog: OptionDialog

    @Inject
    lateinit var viewModelFactory: ViewModelProvider.Factory

    override val preferenceClickIntent: Subject<PreferenceView> = PublishSubject.create()
    override val previewModeSelectedIntent by lazy { previewModeDialog.adapter.menuItemClicks }
    override val ringtoneSelectedIntent: Subject<String> = PublishSubject.create()
    override val actionsSelectedIntent by lazy { actionsDialog.adapter.menuItemClicks }

    private val viewModel by lazy {
        ViewModelProvider(this, viewModelFactory)[NotificationPrefsViewModel::class.java]
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        AndroidInjection.inject(this)
        super.onCreate(savedInstanceState)
        setTitle(R.string.title_notification_prefs)
//        showBackButton(true)
        viewModel.bindView(this)

//        binding.preferences.postDelayed({ binding.preferences?.animateLayoutChanges = true }, 100)

        val hasOreo = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O

        binding.ivBack.setOnClickListener { onBackPressedDispatcher.onBackPressed() }
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                isEnabled = false
                onBackPressedDispatcher.onBackPressed()
            }
        })
        binding.notificationsO.setVisible(hasOreo)
        binding.notifications.setVisible(!hasOreo)
        binding.vibration.setVisible(!hasOreo)
        binding.ringtone.setVisible(!hasOreo)

//        previewModeDialog.setTitle(R.string.settings_notification_previews_title)
        previewModeDialog.adapter.setData(R.array.notification_preview_options)
        actionsDialog.adapter.setData(R.array.notification_actions)

        // Listen to clicks for all of the preferences
        (0 until binding.preferences.childCount)
            .map { index -> binding.preferences.getChildAt(index) }
            .mapNotNull { view -> view as? PreferenceView }
            .map { preference -> preference.clicks().map { preference } }
            .let { Observable.merge(it) }
            .autoDispose(scope())
            .subscribe(preferenceClickIntent)
    }

    override fun render(state: NotificationPrefsState) {
        if (state.threadId != 0L) {
            title = state.conversationTitle
        }

        binding.notifications.findViewById<android.widget.CompoundButton>(R.id.checkbox)?.isChecked = state.notificationsEnabled
        binding.previews.summary = state.previewSummary
        previewModeDialog.adapter.selectedItem = state.previewId
        binding.wake.findViewById<android.widget.CompoundButton>(R.id.checkbox)?.isChecked = state.wakeEnabled
        binding.silentNotContact.findViewById<android.widget.CompoundButton>(R.id.checkbox)?.isChecked = state.silentNotContact
        binding.silentNotContact.isVisible = state.threadId == 0L
        binding.vibration.findViewById<android.widget.CompoundButton>(R.id.checkbox)?.isChecked = state.vibrationEnabled
        binding.ringtone.summary = state.ringtoneName

        binding.actionsDivider.isVisible = state.threadId == 0L
        binding.actionsTitle.isVisible = state.threadId == 0L
        binding.action1.isVisible = state.threadId == 0L
        binding.action1.summary = state.action1Summary
        binding.action2.isVisible = state.threadId == 0L
        binding.action2.summary = state.action2Summary
        binding.action3.isVisible = state.threadId == 0L
        binding.action3.summary = state.action3Summary

        binding.quickReplyDivider.isVisible = state.threadId == 0L
        binding.fastReplyTitle.isVisible = state.threadId == 0L
        binding.quickReply.findViewById<android.widget.CompoundButton>(R.id.checkbox)?.isChecked = state.quickReplyEnabled
        binding.quickReply.isVisible = state.threadId == 0L
        binding.quickReplyTapDismiss.isVisible = state.threadId == 0L
        binding.quickReplyTapDismiss.isEnabled = state.quickReplyEnabled
        binding.quickReplyTapDismiss.findViewById<android.widget.CompoundButton>(R.id.checkbox)?.isChecked = state.quickReplyTapDismiss
    }

    override fun showPreviewModeDialog() = previewModeDialog.show(this,R.string.settings_notification_previews_title)

    override fun showRingtonePicker(default: Uri?) {
        val intent = Intent(RingtoneManager.ACTION_RINGTONE_PICKER)
        intent.putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_SILENT, true)
        intent.putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_DEFAULT, true)
        intent.putExtra(RingtoneManager.EXTRA_RINGTONE_EXISTING_URI, default)
        intent.putExtra(RingtoneManager.EXTRA_RINGTONE_TYPE, RingtoneManager.TYPE_NOTIFICATION)
        startActivityForResult(intent, 123)
    }

    override fun showActionDialog(selected: Int) {
        actionsDialog.adapter.selectedItem = selected
        actionsDialog.show(this,R.string.settings_notification_actions_title)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 123 && resultCode == Activity.RESULT_OK) {
            val uri: Uri? = data?.getParcelableExtra(RingtoneManager.EXTRA_RINGTONE_PICKED_URI)
            ringtoneSelectedIntent.onNext(uri?.toString() ?: "")
        }
    }
}