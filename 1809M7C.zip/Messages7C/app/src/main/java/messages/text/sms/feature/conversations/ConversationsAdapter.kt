
package messages.text.sms.feature.conversations

import android.content.Context
import android.graphics.Typeface
import android.util.Log
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.core.text.buildSpannedString
import androidx.core.view.isVisible
import androidx.recyclerview.widget.RecyclerView
import messages.text.sms.R
import messages.text.sms.common.Navigator
import messages.text.sms.common.base.MyRealmAdapter
import messages.text.sms.common.base.MyViewHolder
import messages.text.sms.common.util.Colors
import messages.text.sms.common.util.DateFormatter
import messages.text.sms.extensions.resolveThemeColor
import messages.text.sms.databinding.ConversationListItemBinding
import messages.text.sms.model.Conversation
import messages.text.sms.repository.ScheduledMessageRepository
import messages.text.sms.util.PhoneNumberUtils
import io.reactivex.disposables.CompositeDisposable
import messages.text.sms.extensions.beGone
import messages.text.sms.extensions.beVisible
import messages.text.sms.extensions.beVisibleIf
import messages.text.sms.extensions.getColorCompat
import javax.inject.Inject

class ConversationsAdapter @Inject constructor(
    private val colors: Colors,
    private val context: Context,
    private val dateFormatter: DateFormatter,
    private val scheduledMessageRepo: ScheduledMessageRepository,
    private val navigator: Navigator,
    private val phoneNumberUtils: PhoneNumberUtils
) : MyRealmAdapter<Conversation, MyViewHolder>() {
    private val disposables = CompositeDisposable()

    init {
        // This is how we access the threadId for the swipe actions
        setHasStableIds(true)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {
        val layoutInflater = LayoutInflater.from(parent.context)
        val binding = ConversationListItemBinding.inflate(layoutInflater, parent, false)

        binding.title.setTypeface(binding.title.typeface, Typeface.BOLD)

        if (viewType == 1) {
//            val textColorPrimary = parent.context.resolveThemeColor(android.R.attr.textColorPrimary)
//            val textColorPrimary = context.getColorCompat(R.color.textPrimary)
            binding.snippet.setTypeface(binding.snippet.typeface, Typeface.BOLD)
//            binding.snippet.setTextColor(textColorPrimary)
            binding.snippet.maxLines = 3
            binding.unread.isVisible = true
            binding.date.setTypeface(binding.date.typeface, Typeface.BOLD)
//            binding.date.setTextColor(textColorPrimary)
        }

        return MyViewHolder(binding.root).apply {
            binding.root.setOnClickListener {
                val conversation = getItem(adapterPosition) ?: return@setOnClickListener
                when (toggleSelection(conversation.id, false)) {
                    true -> {
                        if(isSelected(conversation.id)){
                            binding.selectionView.beVisible()
                            binding.root.isActivated = true
                        }else{
                            binding.selectionView.beGone()
                            binding.root.isActivated = false
                        }
//                        binding.selectionView.beVisibleIf(isSelected(conversation.id))
//                        binding.root.isActivated = isSelected(conversation.id)
                    }
                    false -> navigator.showConversation(conversation.id)
                }
            }
            binding.root.setOnLongClickListener {
                val conversation = getItem(adapterPosition) ?: return@setOnLongClickListener true
                toggleSelection(conversation.id)
//                binding.root.isActivated = isSelected(conversation.id)
                if(isSelected(conversation.id)){
                    binding.selectionView.beVisible()
                    binding.root.isActivated = true
                }else{
                    binding.selectionView.beGone()
                    binding.root.isActivated = false
                }
                true
            }
        }
    }

    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
        val conversation = getItem(position) ?: return
        val binding = ConversationListItemBinding.bind(holder.containerView)

        // If the last message wasn't incoming, then the colour doesn't really matter anyway
        val lastMessage = conversation.lastMessage
        val recipient = when {
            conversation.recipients.size == 1 || lastMessage == null -> conversation.recipients.firstOrNull()
            else -> conversation.recipients.find { recipient ->
                phoneNumberUtils.compare(recipient.address, lastMessage.address)
            }
        }
//        val theme = colors.theme(recipient).theme

        holder.containerView.isActivated = isSelected(conversation.id)
        binding.selectionView.beVisibleIf(isSelected(conversation.id))

        binding.avatars.recipients = conversation.recipients
        binding.title.collapseEnabled = conversation.recipients.size > 1

//        Log.d("titleCheck","getTitle:${conversation.getTitle()}")
//        Log.d("titleCheck","getName:${conversation.name}")
//        Log.d("titleCheck","recipients.size:${conversation.recipients.size}")
//        Log.d("titleCheck","recipients.joinToString:${conversation.recipients.joinToString { recipient -> recipient.getDisplayName() }}")
//        conversation.recipients.forEach {
//            Log.d(
//                "titleCheck",
//                "recipientId=${it.id}, address=${it.address}, contact=${it.contact?.name}"
//            )
//        }

        binding.title.text = buildSpannedString {
            append(conversation.getTitle())
        }
        binding.date.text = conversation.date.takeIf { it > 0 }?.let(dateFormatter::getConversationTimestamp)
        binding.snippet.text = when {
            conversation.draft.isNotEmpty() -> context.getString(R.string.main_sender_draft, conversation.draft)
            conversation.me -> context.getString(R.string.main_sender_you, conversation.snippet)
            else -> conversation.snippet
        }

        // Make the preview in italics if draft
        if (conversation.draft.isNotEmpty()) binding.snippet.setTypeface(null, Typeface.ITALIC)

        // Get Scheduled Messages
        val disposable = scheduledMessageRepo
            .getScheduledMessagesForConversation(conversation.id)
            .asFlowable()
            .toObservable()
            .subscribe { messages ->
                binding.scheduled.isVisible = messages.isNotEmpty()
            }
        disposables.add(disposable)

        binding.pinned.isVisible = conversation.pinned
    }

    override fun getItemId(position: Int): Long {
        return getItem(position)?.id ?: -1
    }

    override fun getItemViewType(position: Int): Int {
        return if (getItem(position)?.unread == false) 0 else 1
    }

    override fun onDetachedFromRecyclerView(recyclerView: RecyclerView) {
        super.onDetachedFromRecyclerView(recyclerView)
        disposables.clear()
    }

    /**
     * Public method to start selection mode by selecting the first item
     */
    fun startSelectionMode() {
        if (itemCount > 0) {
            val firstId = getItemId(0)
            toggleSelection(firstId, force = true)
            notifyItemChanged(0)
        }
    }

}
