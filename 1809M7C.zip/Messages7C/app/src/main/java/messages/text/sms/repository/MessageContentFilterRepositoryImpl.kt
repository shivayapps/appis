
package messages.text.sms.repository

import android.util.Log
import messages.text.sms.model.MessageContentFilter
import messages.text.sms.model.MessageContentFilterData
import io.realm.Realm
import io.realm.RealmResults
import javax.inject.Inject

class MessageContentFilterRepositoryImpl @Inject constructor() : MessageContentFilterRepository {
    override fun createFilter(data: MessageContentFilterData) {
        Realm.getDefaultInstance().use { realm ->
            realm.refresh()
            val maxId = realm.where(MessageContentFilter::class.java)
                .max("id")?.toLong() ?: -1

            realm.executeTransaction {
                realm.insert(MessageContentFilter(maxId + 1, data.value, data.caseSensitive, data.isRegex, data.includeContacts))
            }
        }
    }

    override fun getMessageContentFilters(): RealmResults<MessageContentFilter> {
        return Realm.getDefaultInstance()
            .where(MessageContentFilter::class.java)
            .findAllAsync()
    }

    override fun getMessageContentFilter(id: Long): MessageContentFilter? {
        return Realm.getDefaultInstance()
            .where(MessageContentFilter::class.java)
            .equalTo("id", id)
            .findFirst()
    }

    override fun isBlocked(
        messageBody: String,
        address: String,
        contactsRepo: ContactRepository
    ): Boolean {

        val isContact = contactsRepo.isContact(address)

        Log.d("MessageFilter", "---------------------------")
        Log.d("MessageFilter", "Message : $messageBody")
        Log.d("MessageFilter", "Address : $address")
        Log.d("MessageFilter", "IsContact : $isContact")

        return Realm.getDefaultInstance().use { realm ->

            val filters = realm.where(MessageContentFilter::class.java).findAll()

            Log.d("MessageFilter", "Filter Count : ${filters.size}")

            filters.any { filter ->

                Log.d(
                    "MessageFilter",
                    "Filter -> value='${filter.value}', caseSensitive=${filter.caseSensitive}, isRegex=${filter.isRegex}, includeContacts=${filter.includeContacts}"
                )

                val result = if (isContact && !filter.includeContacts) {

                    Log.d("MessageFilter", "Skipped (contact not included)")
                    false

                } else if (filter.isRegex) {

                    val matched = Regex(filter.value).matches(messageBody)
                    Log.d("MessageFilter", "Regex Match : $matched")
                    matched

                } else if (filter.caseSensitive) {

                    val regexp = "[\\s\\S]*\\b${Regex.escape(filter.value)}\\b[\\s\\S]*"
                    val matched = Regex(regexp).matches(messageBody)

                    Log.d("MessageFilter", "Pattern : $regexp")
                    Log.d("MessageFilter", "Match : $matched")

                    matched

                } else {

                    val regexp =
                        "[\\s\\S]*\\b${Regex.escape(filter.value.lowercase())}\\b[\\s\\S]*"

                    val matched = Regex(regexp).matches(messageBody.lowercase())

                    Log.d("MessageFilter", "Pattern : $regexp")
                    Log.d("MessageFilter", "Message(lower) : ${messageBody.lowercase()}")
                    Log.d("MessageFilter", "Match : $matched")

                    matched
                }

                Log.d("MessageFilter", "Final Result : $result")
                result
            }.also {
                Log.d("MessageFilter", "isBlocked = $it")
            }
        }
    }

    override fun removeFilter(id: Long) {
        Realm.getDefaultInstance().use { realm ->
            realm.executeTransaction {
                realm.where(MessageContentFilter::class.java)
                    .equalTo("id", id)
                    .findAll()
                    .deleteAllFromRealm()
            }
        }
    }

}
