
package messages.text.sms.receiver

import com.android.mms.transaction.PushReceiver

class MmsReceiver : PushReceiver()