package messages.text.sms.common

import android.R
import android.content.Context
import android.content.res.ColorStateList
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.annotation.ArrayRes
import androidx.recyclerview.widget.RecyclerView
import io.reactivex.disposables.CompositeDisposable
import io.reactivex.subjects.PublishSubject
import io.reactivex.subjects.Subject
import messages.text.sms.common.base.MyAdapter
import messages.text.sms.common.base.MyBindingViewHolder
import messages.text.sms.common.util.Colors
import messages.text.sms.extensions.resolveThemeColor
import messages.text.sms.extensions.setVisible
import messages.text.sms.databinding.MenuListItemBinding
import javax.inject.Inject

data class MenuItem(val title: String, val actionId: Int)

class MenuItemAdapter @Inject constructor(
    private val context: Context,
) : MyAdapter<MenuItem, MyBindingViewHolder<MenuListItemBinding>>() {

    val menuItemClicks: Subject<Int> = PublishSubject.create()
    val tempMenuItemClicks: Subject<Int> = PublishSubject.create()

    private val disposables = CompositeDisposable()

    var selectedItem: Int? = null
        set(value) {
            val old = data.map { it.actionId }.indexOfFirst { it == field }
            val new = data.map { it.actionId }.indexOfFirst { it == value }

            field = value
            old.let { notifyItemChanged(it) }
            new.let { notifyItemChanged(it) }
        }

    fun setData(@ArrayRes titles: Int, @ArrayRes values: Int = -1) {
        val valueInts = if (values != -1) context.resources.getIntArray(values) else null

        data = context.resources.getStringArray(titles)
            .mapIndexed { index, title -> MenuItem(title, valueInts?.getOrNull(index) ?: index) }
    }

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): MyBindingViewHolder<MenuListItemBinding> {
        val binding =
            MenuListItemBinding.inflate(LayoutInflater.from(parent.context), parent, false)

        return MyBindingViewHolder(binding).apply {
            binding.root.setOnClickListener {
                val menuItem = getItem(adapterPosition)
                selectedItem = menuItem.actionId
                tempMenuItemClicks.onNext(menuItem.actionId)
//                menuItemClicks.onNext(menuItem.actionId)
            }
        }
    }

    override fun onBindViewHolder(holder: MyBindingViewHolder<MenuListItemBinding>, position: Int) {
        val menuItem = getItem(position)
        holder.binding.optionView.title = menuItem.title
        holder.binding.optionView.checked = (menuItem.actionId == selectedItem)
    }

    override fun onDetachedFromRecyclerView(recyclerView: RecyclerView) {
        super.onDetachedFromRecyclerView(recyclerView)
        disposables.clear()
    }

}