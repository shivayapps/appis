
package messages.text.sms.repository

import android.net.Uri
import androidx.documentfile.provider.DocumentFile
import messages.text.sms.model.BackupFile
import io.reactivex.Observable

interface BackupRepository {

    sealed class Progress(val running: Boolean = false, val indeterminate: Boolean = true) {
        class Idle : Progress()
        class Parsing : Progress(true)
        class Running(val max: Int, val count: Int) : Progress(true, false)
        class Saving : Progress(true)
        class Syncing : Progress(true)
        class Finished : Progress(true, false)
    }

    fun getDefaultBackupPath(): String

    fun getBackupDocumentTree(): DocumentFile?

    fun getBackupPathUriForPicker(): Uri

    fun persistBackupDirectory(directory: Uri)

    fun performBackup()

    fun getBackupProgress(): Observable<Progress>

    fun parseBackup(uri: Uri): BackupFile

    fun performRestore(uri: Uri)

    fun getRestoreProgress(): Observable<Progress>

    fun stopRestore()

}
