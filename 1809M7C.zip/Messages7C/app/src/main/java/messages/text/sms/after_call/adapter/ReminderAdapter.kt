package messages.text.sms.after_call.adapter

import android.content.Context
import android.graphics.Color
import android.graphics.PorterDuff
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import messages.text.sms.R

import androidx.core.content.ContextCompat
import messages.text.sms.after_call.helpers.Reminder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class ReminderAdapter(
    private val mContext: Context,
    private val items: List<Reminder>,
    private val onDelete: (Int) -> Unit,
) : RecyclerView.Adapter<ReminderAdapter.MessageVH>() {

    // Standard message item view holder
    class MessageVH(view: View) : RecyclerView.ViewHolder(view) {
        val title: TextView = view.findViewById(R.id.title)
        val time: TextView = view.findViewById(R.id.time)
        val ivCircle: ImageView = view.findViewById(R.id.ivCircle)
        val delete: ImageView = view.findViewById(R.id.delete)
    }


    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MessageVH {
        val inflater = LayoutInflater.from(parent.context)
        val view = inflater.inflate(R.layout.list_item_reminder, parent, false)
        return MessageVH(view)
    }

    override fun onBindViewHolder(holder: MessageVH, position: Int) {
        val item = items[position]

        // Set message text
        holder.title.text = item.message

        // Format and set date/time
        holder.time.text = formatDate(item.date)

        // Set circle color from string (hex color or color name)
        try {
            val colorInt = Color.parseColor(item.color)
            holder.ivCircle.setColorFilter(colorInt, PorterDuff.Mode.SRC_IN)
        } catch (e: IllegalArgumentException) {
            // If color string is invalid, use default color
            holder.ivCircle.setColorFilter(
                ContextCompat.getColor(mContext, R.color.md_theme_primary),
                PorterDuff.Mode.SRC_IN
            )
        }

        // Set delete button click listener
        holder.delete.setOnClickListener {
            onDelete(position)
        }

        holder.delete.visibility = View.VISIBLE
        holder.ivCircle.visibility = View.VISIBLE
        holder.title.setTextColor(ContextCompat.getColor(mContext, R.color.text_primary))
    }

    override fun getItemCount() = items.size

    // Helper function to format date
    private fun formatDate(date: Any?): String {
        return when (date) {
            is Date -> {
                SimpleDateFormat("MMM dd, yyyy • hh:mm a", Locale.getDefault())
                    .format(date)
            }
            is Long -> {
                SimpleDateFormat("MMM dd, yyyy • hh:mm a", Locale.getDefault())
                    .format(Date(date))
            }
            is String -> date
            else -> ""
        }
    }
}