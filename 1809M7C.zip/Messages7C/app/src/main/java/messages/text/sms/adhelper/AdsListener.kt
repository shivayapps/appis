package messages.text.sms.adhelper

import com.google.android.gms.ads.AdValue


data class AdsError(
    val code: Int,
    val error: String
)

interface AdsListener {
    fun onAdClicked()

    fun onAdDismissed()

    fun onAdLoaded(appOpenAd: Any)

    fun onAdLoaded()

    fun onAdFailedToLoad(adsError: AdsError)
    fun onAdFailedToShow(adsError: AdsError)

    fun onAdImpression()

    fun onAdShowed()

}