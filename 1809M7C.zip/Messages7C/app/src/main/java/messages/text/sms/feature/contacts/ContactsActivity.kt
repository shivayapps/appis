package messages.text.sms.feature.contacts

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.KeyEvent
import android.view.inputmethod.EditorInfo
import android.widget.TextView
import androidx.activity.OnBackPressedCallback
import androidx.core.view.isVisible
import androidx.lifecycle.ViewModelProvider
import com.jakewharton.rxbinding2.view.clicks
import com.jakewharton.rxbinding2.widget.editorActions
import com.jakewharton.rxbinding2.widget.textChanges
import dagger.android.AndroidInjection
import messages.text.sms.R
import messages.text.sms.common.ViewModelFactory
import messages.text.sms.common.base.MainBaseThemedActivity
import messages.text.sms.extensions.hideKeyboard
import messages.text.sms.extensions.showKeyboard
import messages.text.sms.common.widget.MyDialog
import messages.text.sms.databinding.ContactsActivityBinding
import messages.text.sms.extensions.Optional
import messages.text.sms.feature.compose.editing.ComposeItem
import messages.text.sms.feature.compose.editing.ComposeItemAdapter
import messages.text.sms.feature.compose.editing.PhoneNumberAction
import messages.text.sms.feature.compose.editing.PhoneNumberPickerAdapter
import io.reactivex.Observable
import io.reactivex.subjects.PublishSubject
import io.reactivex.subjects.Subject
import messages.text.sms.extensions.dismissKeyboard
import javax.inject.Inject

class ContactsActivity :
    MainBaseThemedActivity<ContactsActivityBinding>(ContactsActivityBinding::inflate),
    ContactsContract {

    companion object {
        const val SharingKey = "sharing"
        const val ChipsKey = "chips"
    }

    @Inject
    lateinit var contactsAdapter: ComposeItemAdapter

    @Inject
    lateinit var phoneNumberAdapter: PhoneNumberPickerAdapter

    @Inject
    lateinit var viewModelFactory: ViewModelFactory

    override val queryChangedIntent: Observable<CharSequence> by lazy { binding.search.textChanges() }
    override val queryClearedIntent: Observable<*> by lazy { binding.ivCancel.clicks() }

//    override val queryEditorActionIntent: Observable<Int> by lazy { binding.search.editorActions() }
    override val composeItemPressedIntent: Subject<ComposeItem> by lazy { contactsAdapter.clicks }
    override val composeItemLongPressedIntent: Subject<ComposeItem> by lazy { contactsAdapter.longClicks }
    override val phoneNumberSelectedIntent: Subject<Optional<Long>> by lazy { phoneNumberAdapter.selectedItemChanges }
    override val phoneNumberActionIntent: Subject<PhoneNumberAction> = PublishSubject.create()

    private val viewModel by lazy {
        ViewModelProvider(this, viewModelFactory)[ContactsViewModel::class.java]
    }

//    private val phoneNumberDialog by lazy {
////        MyDialog(this).apply {
////            titleRes = R.string.compose_number_picker_title
////            adapter = phoneNumberAdapter
////            positiveButton = R.string.compose_number_picker_always
////            positiveButtonListener = { phoneNumberActionIntent.onNext(PhoneNumberAction.ALWAYS) }
////            negativeButton = R.string.compose_number_picker_once
////            negativeButtonListener = { phoneNumberActionIntent.onNext(PhoneNumberAction.JUST_ONCE) }
////            cancelListener = { phoneNumberActionIntent.onNext(PhoneNumberAction.CANCEL) }
////        }
//    }

    override fun onCreate(savedInstanceState: Bundle?) {
        AndroidInjection.inject(this)
        super.onCreate(savedInstanceState)
        viewModel.bindView(this)

        binding.ivBack.setOnClickListener { onBackPressedDispatcher.onBackPressed() }
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                isEnabled = false
                onBackPressedDispatcher.onBackPressed()
            }
        })
        binding.contacts.adapter = contactsAdapter
        binding.search.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_DONE) {
                dismissKeyboard()
                binding.search.hideKeyboard()
            }
            false
        }
    }

    override fun render(state: ContactsState) {
        binding.ivCancel.isVisible = state.query.length > 1
        contactsAdapter.data = state.composeItems
        contactsAdapter.emptyView = binding.empty

//        if (state.selectedContact != null && !phoneNumberDialog.isShowing) {
        if (state.selectedContact != null) {
            phoneNumberAdapter.data = state.selectedContact.numbers
//            phoneNumberDialog.subtitle = state.selectedContact.name
//            phoneNumberDialog.show()
            MyDialog()
                .show(
                    this,
                    getString(R.string.compose_number_picker_title),
                    state.selectedContact.name,
                    phoneNumberAdapter,
                    getString(R.string.compose_number_picker_always),
                    getString(R.string.compose_number_picker_once),
                    positiveActionCallback = { phoneNumberActionIntent.onNext(PhoneNumberAction.ALWAYS) },
                    negativeActionCallback = { phoneNumberActionIntent.onNext(PhoneNumberAction.JUST_ONCE) },
                    cancelListener = { phoneNumberActionIntent.onNext(PhoneNumberAction.CANCEL) }
                )
        }
//        else if (state.selectedContact == null && phoneNumberDialog.isShowing) {
//            phoneNumberDialog.dismiss()
//        }
    }

    override fun clearQuery() {
        binding.search.text = null
        Handler(Looper.myLooper()!!).postDelayed({
            try {
//                binding.contacts.smoothScrollToPosition(0)
                binding.contacts.scrollToPosition(0)
            } catch (e: Exception) {

            }
        }, 1000)
    }

    override fun openKeyboard() {
        dismissKeyboard()
        Handler(Looper.myLooper()!!).postDelayed({
            binding.search.requestFocus()
            binding.search.showKeyboard()
        }, 500)

    }

    override fun finish(result: HashMap<String, String?>) {
        binding.search.hideKeyboard()
        val intent = Intent().putExtra(ChipsKey, result)
        setResult(RESULT_OK, intent)
        super.finish()
    }

    override fun finish() {
        // Set empty result if no result was already set
        val intent = Intent().putExtra(ChipsKey, hashMapOf<String, String?>())
        setResult(RESULT_OK, intent)
        super.finish()
    }
}
