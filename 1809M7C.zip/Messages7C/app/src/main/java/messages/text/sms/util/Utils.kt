
package messages.text.sms.util

import android.util.Log

fun <T> tryOrNull(logOnError: Boolean = true, body: () -> T?): T? {
    return try {
        body()
    } catch (e: Exception) {
        if (logOnError) {
            Log.d("Timber",""+e)
        }

        null
    }
}
