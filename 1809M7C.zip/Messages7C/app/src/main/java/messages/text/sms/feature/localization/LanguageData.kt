package messages.text.sms.feature.localization

open class LanguageData(
    var language_name: String = "",
    var language_text: String = "",
    var language_first_latter: String = "",
    var language_code: String = "",
)