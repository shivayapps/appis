
package messages.text.sms.feature.compose.editing

import android.content.Context
import android.view.LayoutInflater
import android.view.ViewGroup
import io.reactivex.subjects.BehaviorSubject
import io.reactivex.subjects.Subject
import messages.text.sms.R
import messages.text.sms.common.base.MyAdapter
import messages.text.sms.common.base.MyViewHolder
import messages.text.sms.extensions.forwardTouches
import messages.text.sms.databinding.PhoneNumberListItemBinding
import messages.text.sms.extensions.Optional
import messages.text.sms.model.PhoneNumber
import javax.inject.Inject

class PhoneNumberPickerAdapter @Inject constructor(
    private val context: Context
) : MyAdapter<PhoneNumber, MyViewHolder>() {

    val selectedItemChanges: Subject<Optional<Long>> = BehaviorSubject.create()

    private var selectedItem: Long? = null
        set(value) {
            data.indexOfFirst { number -> number.id == field }.takeIf { it != -1 }
                ?.run(::notifyItemChanged)
            field = value
            data.indexOfFirst { number -> number.id == field }.takeIf { it != -1 }
                ?.run(::notifyItemChanged)
            selectedItemChanges.onNext(Optional(value))
        }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {
        val inflater = LayoutInflater.from(parent.context)
        val binding = PhoneNumberListItemBinding.inflate(inflater, parent, false)
        return MyViewHolder(binding.root).apply {
            binding.number.radioButton.forwardTouches(itemView)

            binding.root.setOnClickListener {
                val phoneNumber = getItem(adapterPosition)
                selectedItem = phoneNumber.id
            }
        }
    }

    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
        val phoneNumber = getItem(position)
        val binding = PhoneNumberListItemBinding.bind(holder.containerView)

//        binding.number.radioButton.setImageResource(
//            if (phoneNumber.id == selectedItem)
//                R.drawable.ic_radio_button_checked
//            else
//                R.drawable.ic_radio_button_unchecked
//        )
        binding.number.setChecked(phoneNumber.id == selectedItem)
        binding.number.titleView.text = phoneNumber.address
        binding.number.summaryView.text = when (phoneNumber.isDefault) {
            true -> context.getString(R.string.compose_number_picker_default, phoneNumber.type)
            false -> phoneNumber.type
        }
    }

    override fun onDatasetChanged() {
        super.onDatasetChanged()
        selectedItem = data.find { number -> number.isDefault }?.id ?: data.firstOrNull()?.id
    }

}
