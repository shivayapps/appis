package messages.text.sms.after_call.helpers

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.provider.Settings
import androidx.core.app.ActivityCompat
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import messages.text.sms.R
import messages.text.sms.after_call.activity.AfterCallHomeActivity

object AfterCallNotification {

    fun startNormalNotification(context: Context, title: String, description: String? = null) {
        if (ActivityCompat.checkSelfPermission(
                context,
                Manifest.permission.POST_NOTIFICATIONS
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            return
        }

        val CHANNEL_ID = "AFTERCALL_NORMAL_CHANNEL_ID"
        val notificationManager: NotificationManager =
            context.getSystemService(NotificationManager::class.java)

        val channel = NotificationChannel(
            CHANNEL_ID, "AfterCallNormal Channel", NotificationManager.IMPORTANCE_HIGH
        )
        notificationManager.createNotificationChannel(channel)

        val mScreenIntent = Intent(context, AfterCallHomeActivity::class.java)
        mScreenIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        val screenPendingIntent = PendingIntent.getActivity(
            context, 0,
            mScreenIntent, PendingIntent.FLAG_IMMUTABLE
        )


        if(description != null) {
            val notificationBuilder: NotificationCompat.Builder =
                NotificationCompat.Builder(context, CHANNEL_ID)
                    .setSmallIcon(R.drawable.after_call_notification_list)
                    .setContentTitle(title)
                    .setContentText(description)
                    .setAutoCancel(true)
                    .setSound(Settings.System.DEFAULT_NOTIFICATION_URI)
                    .setPriority(NotificationCompat.PRIORITY_HIGH)
                    .setContentIntent(screenPendingIntent)

            notificationManager.notify(450, notificationBuilder.build())

        }else{
            val notificationBuilder: NotificationCompat.Builder =
                NotificationCompat.Builder(context, CHANNEL_ID)
                    .setSmallIcon(R.drawable.after_call_notification_list)
                    .setContentTitle(title)
                    .setAutoCancel(true)
                    .setSound(Settings.System.DEFAULT_NOTIFICATION_URI)
                    .setPriority(NotificationCompat.PRIORITY_HIGH)
                    .setContentIntent(screenPendingIntent)

            notificationManager.notify(458, notificationBuilder.build())
        }
    }

    fun startIntentNoti(context: Context) {


        val fullScreenIntent = Intent(context, AfterCallHomeActivity::class.java)
        fullScreenIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        val fullScreenPendingIntent = PendingIntent.getActivity(
            context,
            0,
            fullScreenIntent,
            PendingIntent.FLAG_IMMUTABLE
        )

        val notificationManager = NotificationManagerCompat.from(context)
        val channel = NotificationChannel(
            "AFTERCALL_CHANNEL_ID",
            "After Call Channel",
            NotificationManager.IMPORTANCE_HIGH
        )
        notificationManager.createNotificationChannel(channel)

        val notificationBuilder = NotificationCompat.Builder(context, "AFTERCALL_CHANNEL_ID")
            .setSmallIcon(R.drawable.after_call_notification_list)
            .setContentTitle("See call information")
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setSound(Settings.System.DEFAULT_NOTIFICATION_URI)
            .setFullScreenIntent(fullScreenPendingIntent, true)

        if (ActivityCompat.checkSelfPermission(
                context,
                Manifest.permission.POST_NOTIFICATIONS
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            return
        }

        notificationManager.notify(298, notificationBuilder.build())
    }

}