package messages.text.sms.feature.settings

import android.content.Context
import com.uber.autodispose.android.lifecycle.scope
import com.uber.autodispose.autoDisposable
import com.uber.autodispose.autoDispose
import messages.text.sms.R
import messages.text.sms.common.Navigator
import messages.text.sms.common.base.MyPresenter
import messages.text.sms.common.util.Colors
import messages.text.sms.common.util.DateFormatter
import messages.text.sms.extensions.makeToast
import messages.text.sms.interactor.DeleteOldMessages
import messages.text.sms.interactor.SyncMessages
import messages.text.sms.repository.MessageRepository
import messages.text.sms.repository.SyncRepository
import messages.text.sms.service.AutoDeleteService
import messages.text.sms.util.NightModeManager
import messages.text.sms.util.Preferences
import io.reactivex.rxkotlin.plusAssign
import io.reactivex.schedulers.Schedulers
import kotlinx.coroutines.runBlocking
import messages.text.sms.util.Preferences.Companion.TEXT_SIZE_SMALL
import android.util.Log
import java.util.Calendar
import java.util.concurrent.TimeUnit
import javax.inject.Inject
import kotlin.text.get
import kotlin.text.set

class SettingsPresenter @Inject constructor(
    colors: Colors,
    syncRepo: SyncRepository,
    private val context: Context,
    private val dateFormatter: DateFormatter,
    private val deleteOldMessages: DeleteOldMessages,
    private val messageRepo: MessageRepository,
    private val navigator: Navigator,
    private val nightModeManager: NightModeManager,
    private val prefs: Preferences,
    private val syncMessages: SyncMessages
) : MyPresenter<SettingsView, SettingsState>(
    SettingsState(
        nightModeId = prefs.nightMode.get()
    )
) {

    init {
        disposables += colors.themeObservable()
            .subscribe { theme -> newState { copy(theme = theme.theme) } }

        val nightModeLabels = context.resources.getStringArray(R.array.night_modes)
        disposables += prefs.nightMode.asObservable()
            .subscribe { nightMode ->
                newState {
                    copy(
                        nightModeSummary = nightModeLabels[nightMode],
                        nightModeId = nightMode
                    )
                }
            }

        disposables += prefs.nightStart.asObservable()
            .map { time -> nightModeManager.parseTime(time) }
            .map { calendar -> calendar.timeInMillis }
            .map { millis -> dateFormatter.getTimestamp(millis) }
            .subscribe { nightStart -> newState { copy(nightStart = nightStart) } }

        disposables += prefs.nightEnd.asObservable()
            .map { time -> nightModeManager.parseTime(time) }
            .map { calendar -> calendar.timeInMillis }
            .map { millis -> dateFormatter.getTimestamp(millis) }
            .subscribe { nightEnd -> newState { copy(nightEnd = nightEnd) } }

        disposables += prefs.notifications().asObservable()
            .subscribe { enabled -> newState { copy(notificationsEnabled = enabled) } }

        disposables += prefs.autoEmoji.asObservable()
            .subscribe { enabled -> newState { copy(autoEmojiEnabled = enabled) } }

        val delayedSendingLabels = context.resources.getStringArray(R.array.delayed_sending_labels)
        disposables += prefs.sendDelay.asObservable()
            .subscribe { id ->
                newState {
                    copy(
                        sendDelaySummary = delayedSendingLabels[id],
                        sendDelayId = id
                    )
                }
            }

        disposables += prefs.delivery.asObservable()
            .subscribe { enabled -> newState { copy(deliveryEnabled = enabled) } }

        disposables += prefs.unreadAtTop.asObservable()
            .subscribe { enabled -> newState { copy(unreadAtTopEnabled = enabled) } }

        disposables += prefs.signature.asObservable()
            .subscribe { signature -> newState { copy(signature = signature) } }
        val textSizeLabels = context.resources!!.getStringArray(R.array.text_sizes)
//        val textSizeLabels = SettingsActivity.settingsActivity!!.resources!!.getStringArray(R.array.text_sizes)
        disposables += prefs.textSize.asObservable()
            .subscribe { textSize ->
                newState { copy(textSizeSummary = textSizeLabels[textSize], textSizeId = textSize) }
            }

//        disposables += prefs.systemFont.asObservable()
//            .subscribe { enabled -> newState { copy(systemFontEnabled = enabled) } }

        disposables += prefs.unicode.asObservable()
            .subscribe { enabled -> newState { copy(stripUnicodeEnabled = enabled) } }

        disposables += prefs.mobileOnly.asObservable()
            .subscribe { enabled -> newState { copy(mobileOnly = enabled) } }

        disposables += prefs.autoDelete.asObservable()
            .subscribe { autoDelete -> newState { copy(autoDelete = autoDelete) } }

        disposables += prefs.longAsMms.asObservable()
            .subscribe { enabled -> newState { copy(longAsMms = enabled) } }

        val mmsSizeLabels = context.resources.getStringArray(R.array.mms_sizes)
        val mmsSizeIds = context.resources.getIntArray(R.array.mms_sizes_ids)
        disposables += prefs.mmsSize.asObservable()
            .subscribe { maxMmsSize ->
                val index = mmsSizeIds.indexOf(maxMmsSize)
                newState {
                    copy(
                        maxMmsSizeSummary = mmsSizeLabels[index],
                        maxMmsSizeId = maxMmsSize
                    )
                }
            }

        val messageLinkHandlingLabels =
            context.resources.getStringArray(R.array.messageLinkHandlings)
        val messageLinkHandlingIds = context.resources.getIntArray(R.array.messageLinkHandling_ids)
        disposables += prefs.messageLinkHandling.asObservable()
            .subscribe { messageLinkHandlingId ->
                val index = messageLinkHandlingIds.indexOf(messageLinkHandlingId)
                newState {
                    copy(
                        messageLinkHandlingSummary = messageLinkHandlingLabels[index],
                        messageLinkHandlingId = messageLinkHandlingId
                    )
                }
            }
        disposables += prefs.disableScreenshots.asObservable()
            .subscribe { enabled -> newState { copy(disableScreenshotsEnabled = enabled) } }

        disposables += syncRepo.syncProgress
            .sample(16, TimeUnit.MILLISECONDS)
            .distinctUntilChanged()
            .subscribe { syncProgress -> newState { copy(syncProgress = syncProgress) } }

        disposables += syncMessages
    }

    override fun bindIntents(view: SettingsView) {
        super.bindIntents(view)

        view.preferenceClicks()
            .autoDispose(view.scope())
            .subscribe {
                Log.d("Timber", "Preference click: ${context.resources.getResourceName(it.id)}")

                when (it.id) {

                    R.id.language -> view.showLanguageSetting()
                    R.id.night -> view.showNightModeDialog()

//                    R.id.nightStart -> {
//                        val date = nightModeManager.parseTime(prefs.nightStart.get())
//                        view.showStartTimePicker(
//                            date.get(Calendar.HOUR_OF_DAY),
//                            date.get(Calendar.MINUTE)
//                        )
//                    }

//                    R.id.nightEnd -> {
//                        val date = nightModeManager.parseTime(prefs.nightEnd.get())
//                        view.showEndTimePicker(
//                            date.get(Calendar.HOUR_OF_DAY),
//                            date.get(Calendar.MINUTE)
//                        )
//                    }

                    R.id.autoEmoji -> prefs.autoEmoji.set(!prefs.autoEmoji.get())

                    R.id.notifications -> navigator.showNotificationSettings()

                    R.id.swipeActions -> view.showSwipeActions()
                    R.id.archived -> view.showArchivedConversations()
                    R.id.scheduled -> view.showScheduled()
                    R.id.private_chat -> view.showPrivateConversations()
                    R.id.other_setting -> view.showOtherSetting()
                    R.id.rating -> view.showInAppRating()
                    R.id.share_app -> view.shareOurApp()
                    R.id.privacy_policy -> view.showPrivacyPolicy()
                    R.id.blocking -> view.showBlocked()
                    R.id.backup_restore -> view.showBackupRestore()

                    R.id.delayed -> view.showDelayDurationDialog()

                    R.id.delivery -> prefs.delivery.set(!prefs.delivery.get())

                    R.id.unreadAtTop -> prefs.unreadAtTop.set(!prefs.unreadAtTop.get())

                    R.id.signature -> view.showSignatureDialog(prefs.signature.get())

                    R.id.unicode -> prefs.unicode.set(!prefs.unicode.get())

                    R.id.mobileOnly -> prefs.mobileOnly.set(!prefs.mobileOnly.get())

                    R.id.autoDelete -> view.showAutoDeleteDialog(prefs.autoDelete.get())

                    R.id.textSize -> {
                        view.showTextSizePicker()
                    }

                    R.id.longAsMms -> prefs.longAsMms.set(!prefs.longAsMms.get())

                    R.id.mmsSize -> view.showMmsSizePicker()

                    R.id.messsageLinkHandling -> view.showMessageLinkHandlingDialogPicker()

                    R.id.disableScreenshots -> prefs.disableScreenshots.set(!prefs.disableScreenshots.get())

                    R.id.sync -> syncMessages.execute(Unit)

                }
            }

//        view.aboutLongClicks()
//            .map { !prefs.logging.get() }
//            .doOnNext { enabled -> prefs.logging.set(enabled) }
//            .autoDispose(view.scope())
//            .subscribe { enabled ->
//                context.makeToast(
//                    when (enabled) {
//                        true -> R.string.settings_logging_enabled
//                        false -> R.string.settings_logging_disabled
//                    }
//                )
//            }

//        view.nightModeSelected()
//            .autoDispose(view.scope())
//            .subscribe { mode ->
//                nightModeManager.updateNightMode(mode)
//            }
        view.nightModeSelected()
            .doOnNext { mode ->
                nightModeManager.updateNightMode(mode)
            }
            .autoDispose(view.scope())
            .subscribe()

        view.nightStartSelected()
            .autoDispose(view.scope())
            .subscribe { nightModeManager.setNightStart(it.first, it.second) }

        view.nightEndSelected()
            .autoDispose(view.scope())
            .subscribe { nightModeManager.setNightEnd(it.first, it.second) }
        view.textSizeSelected()
            .autoDispose(view.scope())
            .subscribe {

                prefs.textSize.set(it)
            }
        view.sendDelaySelected()
            .doOnNext { duration ->
                prefs.sendDelay.set(duration)
            }
            .autoDispose(view.scope())
            .subscribe()

        view.signatureChanged()
            .doOnNext(prefs.signature::set)
            .autoDispose(view.scope())
            .subscribe()

        view.autoDeleteChanged()
            .observeOn(Schedulers.io())
            .filter { maxAge ->
                if (maxAge == 0) {
                    return@filter true
                }

                val counts = messageRepo.getOldMessageCounts(maxAge)
                if (counts.values.sum() == 0) {
                    return@filter true
                }

                runBlocking { view.showAutoDeleteWarningDialog(counts.values.sum()) }
            }
            .doOnNext { maxAge ->
                when (maxAge == 0) {
                    true -> AutoDeleteService.cancelJob(context)
                    false -> {
                        AutoDeleteService.scheduleJob(context)
                        deleteOldMessages.execute(Unit)
                    }
                }
            }
            .doOnNext(prefs.autoDelete::set)
            .autoDispose(view.scope())
            .subscribe()

        view.mmsSizeSelected()
            .autoDispose(view.scope())
            .subscribe(prefs.mmsSize::set)

        view.messageLinkHandlingSelected()
            .autoDispose(view.scope())
            .subscribe(prefs.messageLinkHandling::set)
    }

}
