
package messages.text.sms.repository

import messages.text.sms.model.MessageContentFilter
import messages.text.sms.model.MessageContentFilterData
import io.realm.RealmResults

interface MessageContentFilterRepository {

    fun createFilter(data: MessageContentFilterData)

    fun getMessageContentFilters(): RealmResults<MessageContentFilter>

    fun getMessageContentFilter(id: Long): MessageContentFilter?

    fun isBlocked(messageBody: String, address: String, contactsRepo: ContactRepository): Boolean

    fun removeFilter(id: Long)

}
