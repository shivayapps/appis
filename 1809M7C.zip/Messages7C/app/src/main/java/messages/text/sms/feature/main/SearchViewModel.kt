package messages.text.sms.feature.main

import android.util.Log
import androidx.recyclerview.widget.ItemTouchHelper
import com.uber.autodispose.android.lifecycle.scope
import com.uber.autodispose.autoDispose
import com.uber.autodispose.autoDispose
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.rxkotlin.plusAssign
import io.reactivex.rxkotlin.withLatestFrom
import io.reactivex.schedulers.Schedulers
import io.realm.Realm

import messages.text.sms.interactor.DeleteConversations
import messages.text.sms.interactor.MarkAllSeen
import messages.text.sms.interactor.MarkArchived
import messages.text.sms.interactor.MarkPinned
import messages.text.sms.interactor.MarkRead
import messages.text.sms.interactor.MarkUnarchived
import messages.text.sms.interactor.MarkUnpinned
import messages.text.sms.interactor.MarkUnread
import messages.text.sms.interactor.MigratePreferences
import messages.text.sms.interactor.SyncContacts
import messages.text.sms.interactor.SyncMessages
import com.uber.autodispose.autoDispose
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import messages.text.sms.common.Navigator
import messages.text.sms.common.base.MessagesViewModel
import messages.text.sms.interactor.SyncMessagesTemp
import messages.text.sms.listener.ContactAddedListener
import messages.text.sms.manager.PermissionManager
import messages.text.sms.manager.RatingManager
import messages.text.sms.model.SyncLog
import messages.text.sms.repository.ConversationRepository
import messages.text.sms.repository.SyncRepository
import messages.text.sms.util.Preferences
import java.util.concurrent.TimeUnit
import javax.inject.Inject

class SearchViewModel @Inject constructor(
    contactAddedListener: ContactAddedListener,
    markAllSeen: MarkAllSeen,
    migratePreferences: MigratePreferences,
    syncRepository: SyncRepository,
    private val conversationRepo: ConversationRepository,
    private val deleteConversations: DeleteConversations,
    private val markArchived: MarkArchived,
    private val markPinned: MarkPinned,
    private val markRead: MarkRead,
    private val markUnarchived: MarkUnarchived,
    private val markUnpinned: MarkUnpinned,
    private val markUnread: MarkUnread,
    private val navigator: Navigator,
    private val permissionManager: PermissionManager,
    private val prefs: Preferences,
    private val ratingManager: RatingManager,
    private val syncContacts: SyncContacts,
    private val syncMessages: SyncMessages,
    private val syncMessagesTemp: SyncMessagesTemp,
) : MessagesViewModel<SearchView, MainState>(MainState(page = Inbox(data = conversationRepo.getAllConversations(limit = 4)))) {

    init {
        disposables += deleteConversations
        disposables += markAllSeen
        disposables += markArchived
        disposables += markUnarchived
        disposables += migratePreferences
        disposables += syncContacts
        disposables += syncMessages
        disposables += syncMessagesTemp

        // Show the syncing UI
        disposables += syncRepository.syncProgress
            .sample(16, TimeUnit.MILLISECONDS)
            .distinctUntilChanged()
            .subscribe { syncing -> newState { copy(syncing = syncing) } }


        // Show the rating UI
        disposables += ratingManager.shouldShowRating
            .subscribe { show -> newState { copy(showRating = show) } }


        // Migrate the preferences from 2.7.3
        migratePreferences.execute(Unit)


        // If we have all permissions and we've never run a sync, run a sync. This will be the case
        // when upgrading from 2.7.3, or if the app's data was cleared
        try {
            val lastSync = Realm.getDefaultInstance()
                .use { realm -> realm.where(SyncLog::class.java)?.max("date") ?: 0 }
            if (lastSync == 0 && (permissionManager.isDefaultSms() || permissionManager.hasReadSms()) && permissionManager.hasContacts()) {

                CoroutineScope(Dispatchers.IO).launch {
                    Log.d("CoroutineCoroutine", "Starting syncMessagesTemp")
                    syncMessagesTemp.execute(Unit)
                    Log.d("CoroutineCoroutine", "Completed syncMessagesTemp")

                    withContext(Dispatchers.Main) {
                        Log.d("CoroutineCoroutine", "Starting syncMessages")
                        syncMessages.execute(Unit)
                        Log.d("CoroutineCoroutine", "Completed syncMessages")
                    }
                }

            }

//            val lastSync = Realm.getDefaultInstance().use { realm ->
//                realm.where(SyncLog::class.java)?.max("date") ?: 0
//            }
//            if (lastSync == 0 && permissionManager.isDefaultSms() && permissionManager.hasReadSms() && permissionManager.hasContacts()) {
//                syncMessages.execute(Unit)
//            }

            // Sync contacts when we detect a change
            if (permissionManager.hasContacts()) {
                disposables += contactAddedListener.listen()
                    .debounce(1, TimeUnit.SECONDS)
                    .subscribeOn(Schedulers.io())
                    .subscribe { syncContacts.execute(Unit) }
            }

            ratingManager.addSession()
            markAllSeen.execute(Unit)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    override fun bindView(view: SearchView) {
        super.bindView(view)

        when {
            !permissionManager.isDefaultSms() -> view.requestDefaultSms()
            !permissionManager.hasReadSms() || !permissionManager.hasContacts() -> view.requestPermissions()
        }

        val permissions = view.activityResumedIntent
            .filter { resumed -> resumed }
            .observeOn(Schedulers.io())
            .map {
                Triple(
                    permissionManager.isDefaultSms(),
                    permissionManager.hasReadSms(),
                    permissionManager.hasContacts()
                )
            }
            .distinctUntilChanged()
            .share()

        // If the default SMS state or permission states change, update the ViewState
        permissions
            .doOnNext { (defaultSms, smsPermission, contactPermission) ->
                newState {
                    copy(
                        defaultSms = defaultSms,
                        smsPermission = smsPermission,
                        contactPermission = contactPermission
                    )
                }
            }
            .autoDispose(view.scope())
            .subscribe()

        // If we go from not having all permissions to having them, sync messages
        permissions
            .skip(1)
            .filter { it.first && it.second && it.third }
            .take(1)
            .autoDispose(view.scope())
            .subscribe { syncMessages.execute(Unit) }

        // Launch screen from intent
        view.onNewIntentIntent
            .autoDispose(view.scope())
            .subscribe { intent ->
                when (intent.getStringExtra("screen")) {
                    "blocking" -> navigator.showBlockedConversations()
                }
            }
//        view.changelogMoreIntent
//            .autoDispose(view.scope())
//            .subscribe { }

        // Clear the query
        view.queryClearedIntent
            .autoDispose(view.scope())
            .subscribe { view.clearSearch() }

//
//        view.queryChangedIntent
//            .debounce(200, TimeUnit.MILLISECONDS)
//            .observeOn(AndroidSchedulers.mainThread())
//            .withLatestFrom(state) { query, state ->
//                newState { copy(query = query.toString().trim()) }
//                if (query.trim().isEmpty() && state.page is Searching) {
//                    newState {
//                        copy(
//                            page =  Inbox(data = conversationRepo.getAllConversations(limit = 4))
//                        )
//                    }
//                }
//                query.trim()
//            }
//            .filter { query -> query.trim().isNotEmpty() }
//            .doOnNext {
//                newState {
//                    val page = (page as? Searching) ?: Searching()
//                    copy(page = page.copy(loading = true))
//                }
//            }
//            .observeOn(Schedulers.io())
//            .map(conversationRepo::searchConversations)
//            .autoDispose(view.scope())
//            .subscribe { data -> newState { copy(page = Searching(loading = false, data = data)) } }

        view.onSearchIntent
            .debounce(200, TimeUnit.MILLISECONDS)
            .observeOn(AndroidSchedulers.mainThread())
            .withLatestFrom(state) { query, state ->
                newState { copy(query = query.toString()) }
                if (query.isEmpty() && state.page is Searching) {
                    newState {
                        copy(
                            page =  Inbox(data = conversationRepo.getAllConversations(limit = 4))
                        )
                    }
                }
                query
            }
            .filter { query -> query.isNotEmpty() }
            .doOnNext {
                newState {
                    val page = (page as? Searching) ?: Searching()
                    copy(page = page.copy(loading = true))
                }
            }
            .observeOn(Schedulers.io())
            .map(conversationRepo::searchConversations)
            .autoDispose(view.scope())
            .subscribe { data -> newState { copy(page = Searching(loading = false, data = data)) } }

        view.activityResumedIntent
            .filter { resumed -> !resumed }
            .switchMap {
                // Take until the activity is resumed
                prefs.keyChanges
                    .filter { key -> key.contains("theme") }
                    .map { true }
//                    .mergeWith(prefs.autoColor.asObservable().skip(1))
//                    .doOnNext { view.themeChanged() }
                    .takeUntil(view.activityResumedIntent.filter { resumed -> resumed })
            }
            .autoDispose(view.scope())
            .subscribe()

        view.homeIntent
            .withLatestFrom(state) { _, state ->
                when {
                    state.page is Searching -> view.clearSearch()
                    state.page is Inbox && state.page.selected > 0 -> view.clearSelection()
                    state.page is Archived && state.page.selected > 0 -> view.clearSelection()

                    else -> newState { copy(drawerOpen = true) }
                }
            }
            .autoDispose(view.scope())
            .subscribe()

       /* view.optionsItemIntent
            .filter { itemId -> itemId == R.id.archive }
            .withLatestFrom(view.conversationsSelectedIntent) { _, conversations ->
                markArchived.execute(conversations)
                view.clearSelection()
            }
            .autoDispose(view.scope())
            .subscribe()

        view.optionsItemIntent
            .filter { itemId -> itemId == R.id.unarchive }
            .withLatestFrom(view.conversationsSelectedIntent) { _, conversations ->
                markUnarchived.execute(conversations)
                view.clearSelection()
            }
            .autoDispose(view.scope())
            .subscribe()

        view.optionsItemIntent
            .filter { itemId -> itemId == R.id.delete }
            .filter { permissionManager.isDefaultSms().also { if (!it) view.requestDefaultSms() } }
            .withLatestFrom(view.conversationsSelectedIntent) { _, conversations ->
                view.showDeleteDialog(conversations)
            }
            .autoDispose(view.scope())
            .subscribe()

        view.optionsItemIntent
            .filter { itemId -> itemId == R.id.add }
            .withLatestFrom(view.conversationsSelectedIntent) { _, conversations -> conversations }
            .doOnNext { view.clearSelection() }
            .filter { conversations -> conversations.size == 1 }
            .map { conversations -> conversations.first() }
            .mapNotNull(conversationRepo::getConversation)
            .map { conversation -> conversation.recipients }
            .mapNotNull { recipients -> recipients[0]?.address?.takeIf { recipients.size == 1 } }
            .doOnNext(navigator::addContact)
            .autoDispose(view.scope())
            .subscribe()

        view.optionsItemIntent
            .filter { itemId -> itemId == R.id.pin }
            .withLatestFrom(view.conversationsSelectedIntent) { _, conversations ->
                markPinned.execute(conversations)
                view.clearSelection()
            }
            .autoDispose(view.scope())
            .subscribe()

        view.optionsItemIntent
            .filter { itemId -> itemId == R.id.unpin }
            .withLatestFrom(view.conversationsSelectedIntent) { _, conversations ->
                markUnpinned.execute(conversations)
                view.clearSelection()
            }
            .autoDispose(view.scope())
            .subscribe()

        view.optionsItemIntent
            .filter { itemId -> itemId == R.id.read }
            .filter { permissionManager.isDefaultSms().also { if (!it) view.requestDefaultSms() } }
            .withLatestFrom(view.conversationsSelectedIntent) { _, conversations ->
                markRead.execute(conversations)
                view.clearSelection()
            }
            .autoDispose(view.scope())
            .subscribe()

        view.optionsItemIntent
            .filter { itemId -> itemId == R.id.unread }
            .filter { permissionManager.isDefaultSms().also { if (!it) view.requestDefaultSms() } }
            .withLatestFrom(view.conversationsSelectedIntent) { _, conversations ->
                markUnread.execute(conversations)
                view.clearSelection()
            }
            .autoDispose(view.scope())
            .subscribe()

        view.optionsItemIntent
            .filter { itemId -> itemId == R.id.block }
            .withLatestFrom(view.conversationsSelectedIntent) { _, conversations ->
                view.showBlockingDialog(conversations, true) {
                    if (it)
                        view.clearSelection()
                }
            }
            .autoDispose(view.scope())
            .subscribe()


        view.conversationsSelectedIntent
            .withLatestFrom(state) { selection, state ->
                val conversations = selection.mapNotNull(conversationRepo::getConversation)
                val add = conversations.firstOrNull()
                    ?.takeIf { conversations.size == 1 }
                    ?.takeIf { conversation -> conversation.recipients.size == 1 }
                    ?.recipients?.first()
                    ?.takeIf { recipient -> recipient.contact == null } != null
                val pin = conversations.sumBy { if (it.pinned) -1 else 1 } >= 0
                val read = conversations.sumBy { if (!it.unread) -1 else 1 } >= 0
                val selected = selection.size

                when (state.page) {
                    is Inbox -> {
                        val page = state.page.copy(
                            addContact = add,
                            markPinned = pin,
                            markRead = read,
                            selected = selected
                        )
                        newState { copy(page = page) }
                    }

                    is Archived -> {
                        val page = state.page.copy(
                            addContact = add,
                            markPinned = pin,
                            markRead = read,
                            selected = selected
                        )
                        newState { copy(page = page) }
                    }
                    else -> {
                        LogE("bindView: ", "something went wrong")
                    }
                }
            }
            .autoDispose(view.scope())
            .subscribe()*/

        // Delete the conversation
        view.confirmDeleteIntent
            .autoDispose(view.scope())
            .subscribe { conversations ->
                deleteConversations.execute(conversations)
                view.clearSelection()
            }

       /* view.swipeConversationIntent
            .autoDispose(view.scope())
            .subscribe { (threadId, direction) ->
                val action =
                    if (direction == ItemTouchHelper.RIGHT) prefs.swipeRight.get() else prefs.swipeLeft.get()
                when (action) {
                    Preferences.SWIPE_ACTION_ARCHIVE -> markArchived.execute(listOf(threadId)) { view.showArchivedSnackbar() }
                    Preferences.SWIPE_ACTION_DELETE -> view.showDeleteDialog(listOf(threadId))
                    Preferences.SWIPE_ACTION_CALL -> conversationRepo.getConversation(threadId)?.recipients?.firstOrNull()?.address?.let(
                        navigator::makePhoneCall
                    )
                    Preferences.SWIPE_ACTION_READ -> markRead.execute(listOf(threadId))
                    Preferences.SWIPE_ACTION_UNREAD -> markUnread.execute(listOf(threadId))
                }
            }*/

       /* view.undoArchiveIntent
            .withLatestFrom(view.swipeConversationIntent) { _, pair -> pair.first }
            .autoDispose(view.scope())
            .subscribe { threadId -> markUnarchived.execute(listOf(threadId)) }*/

        view.snackbarButtonIntent
            .withLatestFrom(state) { _, state ->
                Log.w("messageApp : ", " snackbar Inrnn")
                when {
                    !state.defaultSms -> view.requestDefaultSms()
                    !state.smsPermission -> view.requestPermissions()
                    !state.contactPermission -> view.requestPermissions()
                }
            }
            .autoDispose(view.scope())
            .subscribe()


    }

}