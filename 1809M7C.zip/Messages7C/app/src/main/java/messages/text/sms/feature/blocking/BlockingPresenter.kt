
package messages.text.sms.feature.blocking

import android.content.Context
import com.uber.autodispose.android.lifecycle.scope
import com.uber.autodispose.autoDispose
import messages.text.sms.common.base.MyPresenter
import messages.text.sms.util.Preferences
import io.reactivex.rxkotlin.plusAssign
import javax.inject.Inject

class BlockingPresenter @Inject constructor(
    context: Context,
    private val blockingClient: BlockingClient,
    private val prefs: Preferences
) : MyPresenter<BlockingView, BlockingState>(BlockingState()) {

    init {
//        disposables += prefs.blockingManager.asObservable()
//                .map { client ->
//                    when (client) {
////                        Preferences.BLOCKING_MANAGER_CB -> R.string.blocking_manager_call_blocker_title
////                        Preferences.BLOCKING_MANAGER_CC -> R.string.blocking_manager_call_control_title
////                        Preferences.BLOCKING_MANAGER_SIA -> R.string.blocking_manager_sia_title
//                        else -> R.string.app_name
//                    }
//                }
//                .map(context::getString)
//                .subscribe { manager -> newState { copy(blockingManager = manager) } }

        disposables += prefs.drop.asObservable()
                .subscribe { enabled -> newState { copy(dropEnabled = enabled) } }
    }

    override fun bindIntents(view: BlockingView) {
        super.bindIntents(view)

//        view.blockingManagerIntent
//            .autoDispose(view.scope())
//            .subscribe { view.openBlockingManager() }

        view.blockedNumbersIntent
            .autoDispose(view.scope())
            .subscribe {
                view.openBlockedNumbers()
//                if (prefs.blockingManager.get() == Preferences.BLOCKING_MANAGER) {
//
//                } else {
//                    blockingClient.openSettings()
//                }
            }

        view.messageContentFiltersIntent
            .autoDispose(view.scope())
            .subscribe { view.openMessageContentFilters() }

        view.blockedMessagesIntent
            .autoDispose(view.scope())
            .subscribe { view.openBlockedMessages() }

        view.dropClickedIntent
            .autoDispose(view.scope())
            .subscribe { prefs.drop.set(!prefs.drop.get()) }
    }

}
