
package messages.text.sms.mapper

import android.database.Cursor
import messages.text.sms.model.ContactGroup

interface CursorToContactGroup : Mapper<Cursor, ContactGroup> {

    fun getContactGroupsCursor(): Cursor?

}
