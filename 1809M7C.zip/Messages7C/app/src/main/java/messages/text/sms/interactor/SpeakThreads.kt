
package messages.text.sms.interactor

import messages.text.sms.manager.SpeakManager
import messages.text.sms.extensions.mapNotNull
import messages.text.sms.repository.ConversationRepository
import messages.text.sms.repository.MessageRepository
import io.reactivex.Flowable
import io.reactivex.Single
import javax.inject.Inject

class SpeakThreads @Inject constructor(
    private val conversationRepo: ConversationRepository,
    private val messageRepo: MessageRepository,
) : Interactor<List<Long>>() {

    companion object {
        private var noMessagesStr = "No messages"       // default value

        fun setNoMessagesString(newNoMessagesString: String) {
            noMessagesStr = newNoMessagesString
        }
    }

    override fun buildObservable(threadIds: List<Long>): Flowable<*> {
        val speakManager = SpeakManager()

        if (threadIds.isEmpty())
              return Single.just(0)
                  .doOnSubscribe { speakManager.startSpeakSession(noMessagesStr) }
                  .map { speakManager.speak(noMessagesStr) }
                  .doOnTerminate { speakManager.endSpeakSession() }
                  .toFlowable()

        return Flowable.fromIterable(threadIds)
            .doOnSubscribe { speakManager.startSpeakSession("threads:" + threadIds.sorted().joinToString()) }
            .mapNotNull { threadId -> conversationRepo.getConversationAndLastSenderContactName(threadId) }
            .map { conversationAndSender ->
                    if (speakManager.speakConversationLastSms(conversationAndSender))
                        messageRepo.markSeen(conversationAndSender.first!!.id)
            }
            .doOnTerminate { speakManager.endSpeakSession() }
    }

}