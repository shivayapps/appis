
package messages.text.sms.interactor

import android.util.Log
import messages.text.sms.feature.blocking.BlockingClient
import messages.text.sms.extensions.mapNotNull
import messages.text.sms.manager.NotificationManager
import messages.text.sms.manager.ShortcutManager
import messages.text.sms.repository.ContactRepository
import messages.text.sms.repository.ConversationRepository
import messages.text.sms.repository.MessageContentFilterRepository
import messages.text.sms.repository.MessageRepository
import messages.text.sms.util.Preferences
import io.reactivex.Flowable
import javax.inject.Inject

class ReceiveSms @Inject constructor(
    private val conversationRepo: ConversationRepository,
    private val blockingClient: BlockingClient,
    private val prefs: Preferences,
    private val messageRepo: MessageRepository,
    private val notificationManager: NotificationManager,
    private val updateBadge: UpdateBadge,
    private val shortcutManager: ShortcutManager,
    private val filterRepo: MessageContentFilterRepository,
    private val contactsRepo: ContactRepository
) : Interactor<Long>() {

    override fun buildObservable(params: Long): Flowable<*> {
        return Flowable.just(params)
            .mapNotNull { messageRepo.getMessage(it) }
            .mapNotNull {
                val action = blockingClient.shouldBlock(it.address).blockingGet()

                Log.d("Timber","ReceiveSms.action:$action")

                when {
                    ((action is BlockingClient.Action.Block) && prefs.drop.get()) ->  {
                        // blocked and 'drop blocked.' remove from db and don't continue
                        Log.d("Timber","address is blocked and drop blocked is on. dropped")
                        messageRepo.deleteMessages(listOf(it.id))
                        return@mapNotNull null
                    }
                    action is BlockingClient.Action.Block -> {
                        // blocked
                        Log.d("Timber","address is blocked")
                        messageRepo.markRead(listOf(it.threadId))
                        conversationRepo.markBlocked(
                            listOf(it.threadId),
                            action.reason
                        )
                    }
                    action is BlockingClient.Action.Unblock -> {
                        // unblock
                        Log.d("Timber","unblock conversation if blocked")
                        conversationRepo.markUnblocked(it.threadId)
                    }
                }

                if (filterRepo.isBlocked(it.getText(), it.address, contactsRepo)) {
                    Log.d("Timber","message dropped based on content filters")
                    messageRepo.deleteMessages(listOf(it.id))
                    return@mapNotNull null
                }

                // update and fetch conversation
                conversationRepo.updateConversations(it.threadId)
                conversationRepo.getOrCreateConversation(it.threadId)
            }
            .mapNotNull {
                // don't notify (continue) for blocked conversations
                if (it.blocked) {
                    Log.d("Timber","no notifications for blocked")
                    return@mapNotNull null
                }

                // unarchive conversation if necessary
                if (it.archived) {
                    Log.d("Timber","conversation unarchived")
                    conversationRepo.markUnarchived(it.id)
                }

                // update/create notification
                Log.d("Timber","update/create notification")
                notificationManager.update(it.id)

                // update shortcuts
                Log.d("Timber","update shortcuts")
                shortcutManager.updateShortcuts()
                shortcutManager.reportShortcutUsed(it.id)

                // update the badge and widget
                Log.d("Timber","update badge and widget")
                updateBadge.buildObservable(Unit)
            }
    }

}
