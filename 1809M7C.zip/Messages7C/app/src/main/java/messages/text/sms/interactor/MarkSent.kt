
package messages.text.sms.interactor

import messages.text.sms.repository.MessageRepository
import io.reactivex.Flowable
import javax.inject.Inject

class MarkSent @Inject constructor(private val messageRepo: MessageRepository) : Interactor<Long>() {

    override fun buildObservable(params: Long): Flowable<Unit> {
        return Flowable.just(Unit)
                .doOnNext { messageRepo.markSent(params) }
    }

}