
package messages.text.sms.feature.compose.editing

import android.content.Context
import android.view.View
import android.view.animation.AlphaAnimation
import android.widget.RelativeLayout
import messages.text.sms.util.AnimationConfig
import messages.text.sms.common.util.Colors
import messages.text.sms.extensions.setBackgroundTint
import messages.text.sms.extensions.setTint
import messages.text.sms.databinding.ContactChipDetailedBinding
import messages.text.sms.injection.appComponent
import messages.text.sms.model.Recipient
import javax.inject.Inject

class DetailedChipView(context: Context) : RelativeLayout(context) {

    @Inject
    lateinit var colors: Colors

    private val binding: ContactChipDetailedBinding

    init {
        binding = ContactChipDetailedBinding.inflate(
            android.view.LayoutInflater.from(context),
            this,
            true
        )
        appComponent.inject(this)

        setOnClickListener { hide() }

        visibility = View.GONE

        isFocusable = true
        isFocusableInTouchMode = true
    }

    fun setRecipient(recipient: Recipient) {
        binding.avatar.setRecipient(recipient)
        binding.name.text = recipient.contact?.name?.takeIf { it.isNotBlank() } ?: recipient.address
        binding.info.text = recipient.address

        colors.theme(recipient).let { theme ->
            binding.card.setBackgroundTint(theme.theme)
            binding.name.setTextColor(theme.textPrimary)
            binding.info.setTextColor(theme.textTertiary)
            binding.delete.setTint(theme.textPrimary)
        }
    }

    fun show() {
        startAnimation(AlphaAnimation(0f, 1f).apply { duration = AnimationConfig.FADE_DURATION_MS })

        visibility = View.VISIBLE
        requestFocus()
        isClickable = true
    }

    fun hide() {
        startAnimation(AlphaAnimation(1f, 0f).apply { duration = AnimationConfig.FADE_DURATION_MS })

        visibility = View.GONE
        clearFocus()
        isClickable = false
    }

    fun setOnDeleteListener(listener: (View) -> Unit) {
        binding.delete.setOnClickListener(listener)
    }

}
