package messages.text.sms.feature.blocking.numbers

import android.app.Activity
import android.content.DialogInterface
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.LayoutInflater
import android.view.Window
import android.view.WindowManager
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.core.widget.doOnTextChanged
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.MainScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import messages.text.sms.R
import messages.text.sms.extensions.getColorCompat
import messages.text.sms.extensions.resolveThemeColor
import messages.text.sms.databinding.BlockedNumbersAddDialogBinding
import messages.text.sms.extensions.dismissKeyboard
import messages.text.sms.extensions.showKeyboard
import javax.inject.Inject

class AddBlockNumberDialog @Inject constructor(context: Activity) {

    fun show(
        activity: Activity,
        listener: (String) -> Unit
    ) = GlobalScope.launch {
        showDialog(activity, listener)
    }

    private val binding = BlockedNumbersAddDialogBinding.inflate(LayoutInflater.from(context))
    var msg = ""
    private suspend fun showDialog(
        activity: Activity,
        listener: (String) -> Unit
    ) = withContext(MainScope().coroutineContext) {


        val dialog = AlertDialog.Builder(activity)
            .setView(binding.root)
            .setCancelable(true)
            .create()

        binding.btnPositive.setOnClickListener {
            if (msg.isNotEmpty()) {
                listener(binding.input.text.toString())
                dialog.dismiss()
            } else {
                Toast.makeText(activity, "Please enter number", Toast.LENGTH_SHORT).show()
            }
        }
        binding.btnNegative.setOnClickListener {
            dialog.dismiss()
        }
        binding.ivClose.setOnClickListener {
            dialog.dismiss()
        }
        activity.dismissKeyboard()
        Handler(Looper.myLooper()!!).postDelayed({
            binding.input.requestFocus()
            binding.input.showKeyboard()
            binding.input.setText("")
        }, 500)

        binding.input.doOnTextChanged { text, start, before, count ->
            msg = text.toString().trim()
            if (msg.isEmpty()) {
                binding.btnPositive.alpha = 0.5f
//                binding.btnNegative.alpha = 0.5f
            } else {
                binding.btnPositive.alpha = 1.0f
//                binding.btnNegative.alpha = 1.0f
            }
        }

        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.window?.apply {
            setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            setGravity(Gravity.CENTER)
            setDimAmount(0.8f)
            attributes?.windowAnimations = android.R.style.Animation_Dialog
            setLayout(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.WRAP_CONTENT
            )
        }
        dialog.show()
    }
}