package messages.text.sms.feature.blocking.messages

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.appcompat.widget.Toolbar
import io.reactivex.subjects.PublishSubject
import io.reactivex.subjects.Subject
import messages.text.sms.R
import messages.text.sms.dialog.DeleteDialog
import messages.text.sms.common.base.MyController
import messages.text.sms.common.util.Colors
import messages.text.sms.databinding.BlockedMessagesControllerBinding
import messages.text.sms.feature.blocking.BlockingDialog
import messages.text.sms.injection.appComponent
import javax.inject.Inject


class BlockedMessagesController : MyController<BlockedMessagesControllerBinding, BlockedMessagesView, BlockedMessagesState, BlockedMessagesPresenter>(),
    BlockedMessagesView {

    override fun inflateBinding(inflater: LayoutInflater, container: ViewGroup): BlockedMessagesControllerBinding =
        BlockedMessagesControllerBinding.inflate(inflater, container, false)

    override val menuReadyIntent: Subject<Unit> = PublishSubject.create()
    override val optionsItemIntent: Subject<Int> = PublishSubject.create()
    override val conversationClicks by lazy { blockedMessagesAdapter.clicks }
    override val selectionChanges by lazy { blockedMessagesAdapter.selectionChanges }
    override val confirmDeleteIntent: Subject<List<Long>> = PublishSubject.create()
    override val backClicked: Subject<Unit> = PublishSubject.create()

    @Inject lateinit var blockedMessagesAdapter: BlockedMessagesAdapter
    @Inject lateinit var blockingDialog: BlockingDialog
    @Inject lateinit var deleteDialog: DeleteDialog
    @Inject lateinit var colors: Colors
    @Inject lateinit var context: Context
    @Inject override lateinit var presenter: BlockedMessagesPresenter

    init {
        appComponent.inject(this)
        retainViewMode = RetainViewMode.RETAIN_DETACH
    }

    override fun onViewCreated() {
        super.onViewCreated()
        blockedMessagesAdapter.emptyView = binding.empty
        binding.conversations.adapter = blockedMessagesAdapter
    }

    override fun onAttach(view: View) {
        super.onAttach(view)
        presenter.bindIntents(this)
        setTitle(R.string.blocked_messages_title)
//        showBackButton(true)
        setHasOptionsMenu(true)
    }

//    override fun onCreateOptionsMenu(menu: Menu, inflater: MenuInflater) {
//        super.onCreateOptionsMenu(menu, inflater)
//        inflater.inflate(R.menu.blocked_messages, menu)
//        menuReadyIntent.onNext(Unit)
//    }
//
//    override fun onOptionsItemSelected(item: MenuItem): Boolean {
//        optionsItemIntent.onNext(item.itemId)
//        return true
//    }

    override fun handleBack(): Boolean {
        backClicked.onNext(Unit)
        return true
    }

    override fun render(state: BlockedMessagesState) {
        blockedMessagesAdapter.updateData(state.data)
        val toolbarMenu = themedActivity?.findViewById<Toolbar>(R.id.toolbar)?.menu
        toolbarMenu?.findItem(R.id.block)?.isVisible = state.selected > 0
        toolbarMenu?.findItem(R.id.delete)?.isVisible = state.selected > 0

        setTitle(when (state.selected) {
            0 -> context.getString(R.string.blocked_messages_title)
            else -> context.getString(R.string.main_title_selected, state.selected)
        })
    }

    override fun clearSelection() = blockedMessagesAdapter.clearSelection()

    override fun showBlockingDialog(conversations: List<Long>, block: Boolean) {
        blockingDialog.show(activity!!, conversations, block)
    }

    override fun showDeleteDialog(conversations: List<Long>) {
        deleteDialog.show(activity!!, conversations)
//        val count = conversations.size
//        AlertDialog.Builder(activity!!)
//            .setTitle(R.string.dialog_delete_title)
//            .setMessage(resources?.getQuantityString(R.plurals.dialog_delete_message, count, count))
//            .setPositiveButton(R.string.button_delete) { _, _ -> confirmDeleteIntent.onNext(conversations) }
//            .setNegativeButton(R.string.button_cancel, null)
//            .show()
    }

    override fun goBack() {
        router.popCurrentController()
    }

}
