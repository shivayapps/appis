package messages.text.sms.common.widget

import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Color
import android.util.AttributeSet
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.widget.TextView
import androidx.appcompat.widget.LinearLayoutCompat
import androidx.appcompat.widget.TooltipCompat
import androidx.core.content.ContextCompat
import messages.text.sms.R
import messages.text.sms.extensions.resolveThemeAttribute
import messages.text.sms.extensions.resolveThemeColorStateList
import messages.text.sms.extensions.setVisible
import messages.text.sms.databinding.MenuViewBinding

class MenuView @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null
) : LinearLayoutCompat(context, attrs) {

    private var layout: MenuViewBinding

    val titleView: TextView get() = layout.titleView


    var title: String? = null
        set(value) {
            field = value

            if (isInEditMode) {
                findViewById<TextView>(R.id.titleView).text = value
            } else {
                layout.titleView.text = value
            }
        }

    var tooltipText: String? = null
        set(value) {
            field = value
            if (isInEditMode) return
            TooltipCompat.setTooltipText(this, value)
        }

    init {

        layout = MenuViewBinding.inflate(LayoutInflater.from(context), this, false)
        addView(layout.root)
        setBackgroundResource(context.resolveThemeAttribute(R.attr.selectableItemBackground))
        orientation = HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL

        context.obtainStyledAttributes(attrs, R.styleable.PreferenceView).run {
            title = getString(R.styleable.PreferenceView_title)
            tooltipText = getString(R.styleable.PreferenceView_tipText)

            // If an icon is being used, set up the icon view
            getResourceId(R.styleable.PreferenceView_icon, -1).takeIf { it != -1 }?.let { id ->
                layout.icon.setVisible(true)
                layout.icon.setImageResource(id)
            }

            recycle()
        }
    }

}
