package messages.text.sms.model

import android.telephony.PhoneNumberUtils
import io.realm.RealmObject
import io.realm.annotations.PrimaryKey
import java.util.Locale

open class Recipient(
    @PrimaryKey var id: Long = 0,
    var address: String = "",
    var contact: Contact? = null,
    var lastUpdate: Long = 0
) : RealmObject() {

    fun getDisplayName(): String {
        // Check if this contact actually belongs to this recipient's address
        val contactName = contact?.takeIf {
            it.numbers.any { number -> number.address == this.address }
        }?.name?.takeIf { it.isNotBlank() }

        // If the contact doesn't have this address, don't use it
        return contactName
            ?: PhoneNumberUtils.formatNumber(address, Locale.getDefault().country)
            ?: address
    }

}
