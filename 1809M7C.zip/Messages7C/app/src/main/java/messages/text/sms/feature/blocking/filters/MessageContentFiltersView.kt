
package messages.text.sms.feature.blocking.filters

import io.reactivex.Observable
import messages.text.sms.common.base.MyViewContract
import messages.text.sms.model.MessageContentFilterData

interface MessageContentFiltersView : MyViewContract<MessageContentFiltersState> {

    fun removeFilter(): Observable<Long>
    fun addFilter(): Observable<*>
    fun saveFilter(): Observable<MessageContentFilterData>

    fun showAddDialog()

}
