package messages.text.sms.feature.settings

import messages.text.sms.common.base.MyViewContract
import messages.text.sms.common.widget.PreferenceView
import io.reactivex.Observable

interface SettingsView : MyViewContract<SettingsState> {
    fun preferenceClicks(): Observable<PreferenceView>
    fun nightModeSelected(): Observable<Int>
    fun nightStartSelected(): Observable<Pair<Int, Int>>
    fun nightEndSelected(): Observable<Pair<Int, Int>>
    fun textSizeSelected(): Observable<Int>
    fun sendDelaySelected(): Observable<Int>
    fun signatureChanged(): Observable<String>
    fun autoDeleteChanged(): Observable<Int>
    fun mmsSizeSelected(): Observable<Int>
    fun messageLinkHandlingSelected(): Observable<Int>
    fun showLanguageSetting()
    fun showNightModeDialog()
    fun showStartTimePicker(hour: Int, minute: Int)
    fun showEndTimePicker(hour: Int, minute: Int)
    fun showTextSizePicker()
    fun showDelayDurationDialog()
    fun showSignatureDialog(signature: String)
    fun showAutoDeleteDialog(days: Int)
    suspend fun showAutoDeleteWarningDialog(messages: Int): Boolean
    fun showMmsSizePicker()
    fun showMessageLinkHandlingDialogPicker()
    fun showSwipeActions()
    fun showPrivateConversations()
    fun showOtherSetting()
    fun showArchivedConversations()
    fun showBlocked()
    fun showBackupRestore()
    fun showScheduled()

    fun showInAppRating()
    fun shareOurApp()
    fun showPrivacyPolicy()
}
