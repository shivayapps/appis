
package messages.text.sms.interactor

import messages.text.sms.repository.MessageRepository
import io.reactivex.Flowable
import javax.inject.Inject

class MarkUnread @Inject constructor(
    private val messageRepo: MessageRepository,
    private val updateBadge: UpdateBadge
) : Interactor<List<Long>>() {

    override fun buildObservable(params: List<Long>): Flowable<*> {
        return Flowable.just(params)
            .doOnNext { threadIds -> messageRepo.markUnread(threadIds) }
            .flatMap { updateBadge.buildObservable(Unit) } // Update the badge
    }

}