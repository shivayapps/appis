package messages.text.sms.feature.conversationinfo

import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.GridLayoutManager
import com.uber.autodispose.android.lifecycle.scope
import messages.text.sms.R
import messages.text.sms.common.Navigator
import messages.text.sms.common.base.MyController
import messages.text.sms.extensions.scrapViews
import messages.text.sms.common.widget.TextInputDialog
import messages.text.sms.feature.blocking.BlockingDialog
import messages.text.sms.feature.conversationinfo.injection.ConversationInfoModule
import messages.text.sms.injection.appComponent
import io.reactivex.Observable
import io.reactivex.subjects.PublishSubject
import io.reactivex.subjects.Subject
import com.jakewharton.rxbinding2.view.clicks
import com.uber.autodispose.autoDispose
import messages.text.sms.adhelper.NativeAdHelper
import messages.text.sms.adhelper.NativeLayoutType
import messages.text.sms.dialog.ArchiveDialog
import messages.text.sms.dialog.DeleteDialog
import messages.text.sms.extensions.baseConfig
import messages.text.sms.extensions.beGone
import messages.text.sms.extensions.beVisible
import messages.text.sms.extensions.beVisibleIf
import messages.text.sms.databinding.ConversationInfoControllerBinding
import javax.inject.Inject


class ConversationInfoController(
    val threadId: Long = 0
) : MyController<ConversationInfoControllerBinding, ConversationInfoView, ConversationInfoState, ConversationInfoPresenter>(),
    ConversationInfoView {

    override fun inflateBinding(
        inflater: LayoutInflater, container: ViewGroup
    ): ConversationInfoControllerBinding =
        ConversationInfoControllerBinding.inflate(inflater, container, false)

    @Inject
    override lateinit var presenter: ConversationInfoPresenter

    @Inject
    lateinit var blockingDialog: BlockingDialog

    @Inject
    lateinit var archiveDialog: ArchiveDialog

    @Inject
    lateinit var deleteDialog: DeleteDialog

    @Inject
    lateinit var navigator: Navigator

    @Inject
    lateinit var adapter: ConversationInfoAdapter


    private val nameChangeSubject: Subject<String> = PublishSubject.create()
    private val confirmDeleteSubject: Subject<Unit> = PublishSubject.create()

    init {
        appComponent.conversationInfoBuilder().conversationInfoModule(ConversationInfoModule(this))
            .build().inject(this)
    }

    override fun onViewCreated() {
        binding.recyclerView.adapter = adapter
//        binding.recyclerView.addItemDecoration(GridSpacingItemDecoration(adapter, activity!!))
        binding.recyclerView.layoutManager = GridLayoutManager(activity, 3).apply {
            spanSizeLookup = object : GridLayoutManager.SpanSizeLookup() {
                override fun getSpanSize(position: Int): Int =
                    if (adapter.getItemViewType(position) == 1) 1 else 3
            }
        }

//        binding.groupName.clicks().subscribe(nameClicks)
//        binding.notifications.clicks().subscribe(notificationClicks)
//        binding.markUnread.clicks().subscribe(markUnreadClicks)
//        binding.archive.clicks().subscribe(archiveClicks)
//        binding.block.clicks().subscribe(blockClicks)
//        binding.delete.clicks().subscribe(deleteClicks)

        binding.call.clicks().autoDispose(scope()).subscribe(callClicks)
        binding.ivRename.clicks().autoDispose(scope()).subscribe(nameClicks)

        binding.notifications.clicks().autoDispose(scope()).subscribe(notificationClicks)

        binding.markUnread.clicks().autoDispose(scope()).subscribe(markUnreadClicks)

        binding.archive.clicks().autoDispose(scope()).subscribe(archiveClicks)

        binding.block.clicks().autoDispose(scope()).subscribe(blockClicks)

        binding.delete.clicks().autoDispose(scope()).subscribe(deleteClicks)

        themedActivity?.theme?.autoDispose(scope())?.subscribe { binding.recyclerView.scrapViews() }
        loadAds()
    }

    fun loadAds() {
        NativeAdHelper(
            activity!!,
            binding.adsView,
            NativeLayoutType.NativeMedium,
            activity!!.baseConfig.nativeAdsId
        ).loadAd()
    }

    override fun onAttach(view: View) {
        super.onAttach(view)
        presenter.bindIntents(this)
        setTitle(R.string.info_title)
//        showBackButton(true)
    }

    override fun render(state: ConversationInfoState) {
        if (state.hasError) {
            activity?.finish()
            return
        }

//        setData(state.settings)
        state.settings?.let(::setSettings)
        adapter.data = state.data
    }

    private fun setSettings(infoSettings: ConversationInfoSettings) {
//        val infoSettings = data
//            .filterIsInstance<ConversationInfoSettings>()
//            .firstOrNull()

        Log.e("ConversationInfo", "infoSettings.name:${infoSettings.name}")
        Log.e("ConversationInfo", "infoSettings.title:${infoSettings.title}")
        Log.e("ConversationInfo", "infoSettings.recipients.size:${infoSettings.recipients.size}")
        Log.e("ConversationInfo", "infoSettings.recipients:${infoSettings.recipients}")

        infoSettings.let {
            if (infoSettings.recipients.size > 1) {
                binding.ivRename.beVisible()
                binding.call.isEnabled = false
                binding.call.alpha = 0.5f
            } else {
                binding.ivRename.beGone()
                binding.call.isEnabled = true
                binding.call.alpha = 1.0f
            }

            val mTitle = if (infoSettings.name.isNotEmpty()) {
                infoSettings.name
            } else {
                infoSettings.title
            }

            if (infoSettings.recipients.size > 1) {
                binding.tvDetailText.beGone()
                binding.ivGroupIcon.beVisible()
                binding.llRecipientHeader.beVisible()
                binding.tvRecipientCount.text = "${infoSettings.recipients.size}"
                binding.tvConversationRecipient.text =
                    activity!!.getString(R.string.people, infoSettings.recipients.size)
            } else {
                val firstLetter =
                    mTitle.firstOrNull {
                        it.isLetter()
                    }?.uppercaseChar()?.toString() ?: ""
                if (firstLetter.isNotEmpty()) {
                    binding.tvDetailText.text = firstLetter
                    binding.tvDetailText.beVisible()
                    binding.ivGroupIcon.beGone()
                } else {
                    binding.tvDetailText.beGone()
                    binding.ivGroupIcon.beVisible()
                    binding.ivGroupIcon.setImageResource(R.drawable.icon_avtar_single)
                }

                binding.llRecipientHeader.beGone()
                binding.tvConversationRecipient.text =
                    infoSettings.recipients.firstOrNull()?.address
            }


            binding.tvConversationTitle.text = mTitle
//            binding.notifications.isEnabled = !infoSettings.blocked
//            binding.archive.isEnabled = !infoSettings.blocked
            if (infoSettings.blocked) {
                binding.notifications.isEnabled = false
                binding.archive.isEnabled = false
                binding.notifications.alpha = 0.5f
                binding.archive.alpha = 0.5f
            } else {
                binding.notifications.isEnabled = true
                binding.archive.isEnabled = true
                binding.notifications.alpha = 1.0f
                binding.archive.alpha = 1.0f
            }

            binding.archiveTitle.text = activity!!.getString(
                when (infoSettings.archived) {
                    true -> R.string.info_unarchive
                    false -> R.string.info_archive
                }
            )

            binding.blockTitle.text = activity!!.getString(
                when (infoSettings.blocked) {
                    true -> R.string.info_unblock
                    false -> R.string.info_block
                }
            )
        }

    }

    override fun recipientInfoClicks(): Observable<Long> = adapter.recipientInfoClicks
    override fun recipientCallClicks(): Observable<Long> = adapter.recipientCallClicks
    override fun recipientLongClicks(): Observable<Long> = adapter.recipientLongClicks
    override fun nameClicks(): Observable<*> = nameClicks
    override fun callClicks(): Observable<*> = callClicks

    //    override fun nameClicks(): Observable<*> = binding.groupName.clicks()
    override fun nameChanges(): Observable<String> = nameChangeSubject
    override fun notificationClicks(): Observable<*> = notificationClicks//adapter
    override fun markUnreadClicks(): Observable<*> = markUnreadClicks//adapter
    override fun archiveClicks(): Observable<*> = archiveClicks//adapter
    override fun blockClicks(): Observable<*> = blockClicks//adapter
    override fun deleteClicks(): Observable<*> = deleteClicks//adapter
    override fun mediaClicks(): Observable<Long> = mediaClicks//adapter
    override fun confirmDelete(): Observable<*> = confirmDeleteSubject

    val nameClicks: Subject<Unit> = PublishSubject.create()
    val notificationClicks: Subject<Unit> = PublishSubject.create()
    val markUnreadClicks: Subject<Unit> = PublishSubject.create()
    val archiveClicks: Subject<Unit> = PublishSubject.create()
    val blockClicks: Subject<Unit> = PublishSubject.create()
    val deleteClicks: Subject<Unit> = PublishSubject.create()
    val mediaClicks: Subject<Long> = PublishSubject.create()
    val callClicks: Subject<Unit> = PublishSubject.create()

    override fun showRenameDialog(name: String) {
        TextInputDialog(activity!!).setText(name).show(
            activity!!, activity!!.getString(R.string.info_name), nameChangeSubject::onNext
        )
    }

//    override fun showThemePicker(recipientId: Long) {
//        router.pushController(RouterTransaction.with(ThemePickerController(recipientId))
//            .pushChangeHandler(MessageChangeHandler())
//            .popChangeHandler(MessageChangeHandler()))
//    }

    override fun showBlockingDialog(conversations: List<Long>, block: Boolean) {
        blockingDialog.show(activity!!, conversations, block)
    }

    override fun showArchiveDialog(conversations: List<Long>, archive: Boolean) {
        archiveDialog.show(activity!!, conversations, archive)
    }

    override fun requestDefaultSms() {
        navigator.showDefaultSmsDialog(activity!!)
    }

    override fun showDeleteDialog(conversations: List<Long>) {
        deleteDialog.show(activity!!, conversations)
//        AlertDialog.Builder(activity!!)
//            .setTitle(R.string.dialog_delete_title)
//            .setMessage(resources?.getQuantityString(R.plurals.dialog_delete_message, 1))
//            .setPositiveButton(R.string.button_delete) { _, _ -> confirmDeleteSubject.onNext(Unit) }
//            .setNegativeButton(R.string.button_cancel, null)
//            .show()
    }
}
