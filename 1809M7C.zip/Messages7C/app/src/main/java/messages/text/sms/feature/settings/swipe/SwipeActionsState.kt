
package messages.text.sms.feature.settings.swipe

import androidx.annotation.DrawableRes
import messages.text.sms.R

data class SwipeActionsState(
    @DrawableRes val rightIcon: Int = R.drawable.ic_archived,
    val rightLabel: String = "",

    @DrawableRes val leftIcon: Int = R.drawable.ic_archived,
    val leftLabel: String = ""
)