package messages.text.sms.common.widget

import android.content.Context
import android.util.AttributeSet
import android.view.LayoutInflater
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.core.view.isVisible
import messages.text.sms.R
import messages.text.sms.databinding.GroupAvatarViewBinding
import messages.text.sms.model.Recipient

class GroupAvatarView @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null
) : ConstraintLayout(context, attrs) {

    private var layout: GroupAvatarViewBinding =
        GroupAvatarViewBinding.inflate(LayoutInflater.from(context), this)

    var recipients: List<Recipient> = ArrayList()
        set(value) {
            field = value.sortedWith(compareByDescending { contact -> contact.contact?.lookupKey })
            updateView()
        }

    override fun onFinishInflate() {
        super.onFinishInflate()

        if (!isInEditMode) {
            updateView()
        }
    }

    private fun updateView() {
//        layout.avatar1Frame.setBackgroundTint(
//            when (recipients.size > 1) {
//                true -> context.resolveThemeColor(R.attr.windowBackground)
//                false -> context.getColorCompat(R.color.transparent)
//            }
//        )
//        layout.avatar1Frame.updateLayoutParams<LayoutParams> {
//            matchConstraintPercentWidth = if (recipients.size > 1) 0.75f else 1.0f
//        }
//        layout.avatar2.isVisible = recipients.size > 1

        if (recipients.size > 1) {
            layout.initial.isVisible = false
            layout.icon.isVisible = true
        } else {
            layout.initial.isVisible = true
            layout.icon.isVisible = false

//            val initials = recipients.getOrNull(0)?.contact?.name
//                ?.substringBefore(',')
//                ?.split(" ").orEmpty()
//                .filter { name -> name.isNotEmpty() }
//                .map { name -> name[0] }
//                .filter { initial -> initial.isLetterOrDigit() }
//                .map { initial -> initial.toString() }

            val initials = recipients.getOrNull(0)?.contact?.name
                ?.takeIf { it.isNotBlank() }
                ?.split(" ")
                ?.filter { it.isNotEmpty() }
                ?.map { it.first().toString() }
                ?: recipients.joinToString { recipient -> recipient.getDisplayName() }
                    .substringBefore(',')
                    .split(" ")
                    .filter { it.isNotEmpty() }
                    .map { it.first().toString() }

            if (initials.isNotEmpty()) {
                if (initials.first().all { it.isLetter() }) {
                    layout.initial.text = initials.first().trim()
                    layout.icon.visibility = GONE
                    layout.icon.setImageResource(R.drawable.icon_avtar_group)
                } else {
                    layout.initial.text = null
                    layout.icon.visibility = VISIBLE
                    layout.icon.setImageResource(R.drawable.icon_avtar_single)
                }
            } else {
                layout.initial.text = null
                layout.icon.visibility = VISIBLE
            }
        }


//        recipients.getOrNull(0).run(layout.avatar1::setRecipient)
//        recipients.getOrNull(1).run(layout.avatar2::setRecipient)
    }

}
