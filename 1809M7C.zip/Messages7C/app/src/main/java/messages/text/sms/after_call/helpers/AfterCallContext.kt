package messages.text.sms.after_call.helpers

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.drawable.Drawable
import android.net.Uri
import android.os.PowerManager
import android.provider.ContactsContract
import android.provider.Settings
import android.telecom.TelecomManager
import android.text.TextUtils
import android.widget.Toast
import androidx.annotation.Keep


fun Context.getSharedPrefs() = getSharedPreferences("AfterCallPrefsKey", Context.MODE_PRIVATE)
val Context.afterCallBaseConfig: AfterCallBaseConfig get() = AfterCallBaseConfig.newInstance(this)
val Context.telecomManager: TelecomManager get() = getSystemService(Context.TELECOM_SERVICE) as TelecomManager

fun createBitmapFromText(text: String): Bitmap {
    val size = 128 // Bitmap size in pixels
    val bitmap = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
    val canvas = Canvas(bitmap)
    canvas.drawColor(Color.WHITE) // Background color

    val paint = Paint().apply {
        color = Color.BLACK
        textSize = 64f
        textAlign = Paint.Align.CENTER
        isAntiAlias = true
    }

    val xPos = canvas.width / 2
    val yPos = (canvas.height / 2 - (paint.descent() + paint.ascent()) / 2).toInt()

    canvas.drawText(text, xPos.toFloat(), yPos.toFloat(), paint)
    return bitmap
}

private fun isBatteryOptimizationIgnored(context: Context): Boolean {
    val packageName = context.packageName
    val powerManager = context.getSystemService(Context.POWER_SERVICE) as PowerManager
    return powerManager.isIgnoringBatteryOptimizations(packageName)
}


private fun openBatterySettingsForPackage(context: Context) {
    val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
        data = Uri.fromParts("package", context.packageName, null)
        flags = Intent.FLAG_ACTIVITY_NEW_TASK
    }
    context.startActivity(intent)

    Toast.makeText(context, "Go to Battery usage -> Allow auto-launch", Toast.LENGTH_LONG).show()
}


private const val SYSTEM_PROPS_CLASS = "android.os.SystemProperties"
private const val MIUI_VERSION_PROPERTY = "ro.miui.ui.version.code"

@Keep
fun isOnMiui(): Boolean {
    Class.forName(SYSTEM_PROPS_CLASS).apply {
        return !TextUtils.isEmpty(
            getMethod("get", String::class.java)
                .invoke(this, MIUI_VERSION_PROPERTY) as String
        )
    }
}

fun drawableToBitmap(drawable: Drawable): Bitmap {
    val width = drawable.intrinsicWidth
    val height = drawable.intrinsicHeight

    // Create a bitmap with the same dimensions as the drawable
    val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)

    // Create a canvas to draw the drawable onto the bitmap
    val canvas = Canvas(bitmap)
    drawable.setBounds(0, 0, canvas.width, canvas.height)
    drawable.draw(canvas)

    return bitmap
}

// Function to retrieve user's photo from contacts based on phone number
@SuppressLint("Range")
fun getUserPhotoByPhoneNumber(phoneNumber: String?, context: Context): Bitmap? {
    val projection = arrayOf(ContactsContract.CommonDataKinds.Photo.PHOTO)

    // Query contacts based on phone number
    val cursor = context.contentResolver.query(
        ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
        null,
        ContactsContract.CommonDataKinds.Phone.NUMBER + " = ?",
        arrayOf(phoneNumber),
        null
    )

    cursor?.use {
        if (it.moveToFirst()) {
            // Get contact ID from the cursor
            val contactId =
                it.getString(it.getColumnIndex(ContactsContract.CommonDataKinds.Phone.CONTACT_ID))

            // Use the contact ID to query for the photo
            val photoCursor = context.contentResolver.query(
                ContactsContract.Data.CONTENT_URI,
                projection,
                ContactsContract.Data.CONTACT_ID + " = ? AND " + ContactsContract.Data.MIMETYPE + " = ?",
                arrayOf(contactId, ContactsContract.CommonDataKinds.Photo.CONTENT_ITEM_TYPE),
                null
            )
            var userPhoto: Bitmap?
            photoCursor?.use { photoCursorInner ->
                if (photoCursorInner.moveToFirst()) {
                    val photoData =
                        photoCursorInner.getBlob(
                            photoCursorInner.getColumnIndex(
                                ContactsContract.CommonDataKinds.Photo.PHOTO
                            )
                        )
                    try {
                        if (photoData != null) {
                            userPhoto =
                                BitmapFactory.decodeByteArray(photoData, 0, photoData.size)
                            return userPhoto
                        }
                    } catch (e: Exception) {

                    }
                }
            }
        }
    }
    return null
}