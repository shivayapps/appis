package messages.text.sms.feature.settings

import android.animation.ObjectAnimator
import android.app.TimePickerDialog
import android.content.Context
import android.content.Intent
import android.text.format.DateFormat
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.view.children
import com.bluelinelabs.conductor.RouterTransaction
import com.jakewharton.rxbinding2.view.clicks
import com.uber.autodispose.android.lifecycle.scope
import messages.text.sms.R
import messages.text.sms.common.MyChangeHandler
import messages.text.sms.dialog.OptionDialog
import messages.text.sms.common.base.MyController
import messages.text.sms.common.util.Colors
import messages.text.sms.extensions.animateLayoutChanges
import messages.text.sms.common.widget.PreferenceView
import messages.text.sms.common.widget.TextInputDialog
import messages.text.sms.dialog.AutoDeleteDialog
import messages.text.sms.feature.settings.swipe.SwipeActionsController
import messages.text.sms.injection.appComponent
import io.reactivex.Observable
import io.reactivex.subjects.PublishSubject
import io.reactivex.subjects.Subject
import android.widget.CompoundButton
import com.uber.autodispose.autoDispose
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import messages.text.sms.dialog.MessageDialog
import messages.text.sms.databinding.SettingsOtherControllerBinding
import messages.text.sms.feature.backup.BackupActivity
import messages.text.sms.feature.blocking.BlockingActivity
import messages.text.sms.feature.localization.LocalizationActivity
import messages.text.sms.feature.main.ArchivedActivity
import messages.text.sms.feature.scheduled.ScheduledActivity
import messages.text.sms.feature.secret.PasswordActivity
import javax.inject.Inject
import kotlin.coroutines.resume

class SettingsOtherController :
    MyController<SettingsOtherControllerBinding, SettingsView, SettingsState, SettingsPresenter>(),
    SettingsView {

    override fun inflateBinding(
        inflater: LayoutInflater,
        container: ViewGroup
    ): SettingsOtherControllerBinding =
        SettingsOtherControllerBinding.inflate(inflater, container, false)

    @Inject
    lateinit var context: Context

    @Inject
    lateinit var colors: Colors

    @Inject
    lateinit var textSizeDialog: OptionDialog

    @Inject
    lateinit var sendDelayDialog: OptionDialog

    @Inject
    lateinit var mmsSizeDialog: OptionDialog

    @Inject
    lateinit var messageLinkHandlingDialog: OptionDialog

    @Inject
    override lateinit var presenter: SettingsPresenter

    //    private val autoDeleteDialog: AutoDeleteDialog by lazy {
//        AutoDeleteDialog(activity!!, autoDeleteSubject::onNext)
//    }
    private val startTimeSelectedSubject: Subject<Pair<Int, Int>> = PublishSubject.create()
    private val endTimeSelectedSubject: Subject<Pair<Int, Int>> = PublishSubject.create()
    private val signatureSubject: Subject<String> = PublishSubject.create()

    private val autoDeleteSubject: Subject<Int> = PublishSubject.create()

//    private val progressAnimator by lazy {
//        ObjectAnimator.ofInt(
//            binding.syncingProgress,
//            "progress",
//            0,
//            0
//        )
//    }

    init {
        appComponent.inject(this)
        retainViewMode = RetainViewMode.RETAIN_DETACH

        colors.themeObservable()
            .autoDispose(scope())
            .subscribe { activity?.recreate() }
    }

    override fun onViewCreated() {
        binding.preferences.postDelayed({ binding.preferences.animateLayoutChanges = true }, 100)

//        when (Build.VERSION.SDK_INT >= 29) {
//            true -> nightModeDialog.adapter.setData(R.array.night_modes)
//            false -> nightModeDialog.adapter.data =
//                context.resources.getStringArray(R.array.night_modes)
//                    .mapIndexed { index, title -> MenuItem(title, index) }
//                    .drop(1)
//        }
        textSizeDialog.adapter.setData(R.array.text_sizes)
        sendDelayDialog.adapter.setData(R.array.delayed_sending_labels)
        mmsSizeDialog.adapter.setData(R.array.mms_sizes, R.array.mms_sizes_ids)
        messageLinkHandlingDialog.adapter.setData(
            R.array.messageLinkHandlings,
            R.array.messageLinkHandling_ids
        )

//        binding.about.summary = context.getString(R.string.settings_version, BuildConfig.VERSION_NAME)
    }

    override fun onAttach(view: View) {
        super.onAttach(view)
        presenter.bindIntents(this)
        setTitle(R.string.title_settings_extra)
//        showBackButton(true)
    }

    private fun ViewGroup.preferenceViews(): Sequence<PreferenceView> =
        children.flatMap {
            when (it) {
                is PreferenceView -> sequenceOf(it)
                is ViewGroup -> it.preferenceViews()
                else -> emptySequence()
            }
        }

    override fun preferenceClicks(): Observable<PreferenceView> =
        Observable.merge(
            binding.preferences.preferenceViews()
                .map { it.clicks().map { _ -> it } }
                .toList()
        )

//    override fun preferenceClicks(): Observable<PreferenceView> = (0 until binding.preferences.childCount)
//        .map { index -> binding.preferences.getChildAt(index) }
//        .mapNotNull { view -> view as? PreferenceView }
//        .map { preference -> preference.clicks().map { preference } }
//        .let { preferences -> Observable.merge(preferences) }


    //    override fun nightModeSelected(): Observable<Int> = nightModeDialog.adapter.menuItemClicks
    override fun nightModeSelected(): Observable<Int> = Observable.never()

    override fun nightStartSelected(): Observable<Pair<Int, Int>> = startTimeSelectedSubject

    override fun nightEndSelected(): Observable<Pair<Int, Int>> = endTimeSelectedSubject

    override fun textSizeSelected(): Observable<Int> = textSizeDialog.adapter.menuItemClicks

    override fun sendDelaySelected(): Observable<Int> = sendDelayDialog.adapter.menuItemClicks

    override fun signatureChanged(): Observable<String> = signatureSubject

    override fun autoDeleteChanged(): Observable<Int> = autoDeleteSubject

    override fun mmsSizeSelected(): Observable<Int> = mmsSizeDialog.adapter.menuItemClicks

    override fun messageLinkHandlingSelected(): Observable<Int> =
        messageLinkHandlingDialog.adapter.menuItemClicks

    private fun PreferenceView.checkbox(): CompoundButton? = findViewById(R.id.checkbox)

    override fun render(state: SettingsState) {
//        binding.theme.findViewById<View>(R.id.themePreview)?.setBackgroundTint(state.theme)
//        nightModeDialog.adapter.selectedItem = state.nightModeId

//        binding.black.setVisible(state.nightModeId != Preferences.NIGHT_MODE_OFF)
//        binding.black.checkbox?.isChecked = state.black

        binding.autoEmoji.checkbox()?.isChecked = state.autoEmojiEnabled

        binding.delayed.summary = state.sendDelaySummary
        sendDelayDialog.adapter.selectedItem = state.sendDelayId

        binding.delivery.checkbox()?.isChecked = state.deliveryEnabled

        binding.unreadAtTop.checkbox()?.isChecked = state.unreadAtTopEnabled

        binding.signature.summary = state.signature.takeIf { it.isNotBlank() }
            ?: ""//context.getString(R.string.settings_signature_summary)

//        binding.textSize.summary = state.textSizeSummary
        textSizeDialog.adapter.selectedItem = state.textSizeId

//        binding.autoColor.checkbox?.isChecked = state.autoColor
//
//        binding.systemFont.checkbox?.isChecked = state.systemFontEnabled
//
//        binding.showStt.checkbox?.isChecked = state.showStt

        binding.unicode.checkbox()?.isChecked = state.stripUnicodeEnabled
        binding.mobileOnly.checkbox()?.isChecked = state.mobileOnly

        binding.longAsMms.checkbox()?.isChecked = state.longAsMms

        binding.mmsSize.summary = state.maxMmsSizeSummary
        mmsSizeDialog.adapter.selectedItem = state.maxMmsSizeId

        binding.messsageLinkHandling.summary = state.messageLinkHandlingSummary
        messageLinkHandlingDialog.adapter.selectedItem = state.messageLinkHandlingId

        binding.disableScreenshots.checkbox()?.isChecked = state.disableScreenshotsEnabled

//        when (state.syncProgress) {
//            is SyncRepository.SyncProgress.Idle -> binding.syncingProgress.isVisible = false
//
//            is SyncRepository.SyncProgress.Running -> {
//                binding.syncingProgress.isVisible = true
//                binding.syncingProgress.max = state.syncProgress.max
//                progressAnimator.apply {
//                    setIntValues(
//                        binding.syncingProgress.progress,
//                        state.syncProgress.progress
//                    )
//                }.start()
//                binding.syncingProgress.isIndeterminate = state.syncProgress.indeterminate
//            }
//
////            is SyncRepository.SyncProgress.ParsingEmojis -> {
////                binding.syncingProgress.isVisible = true
////                binding.syncingProgress.max = state.syncProgress.max
////                progressAnimator.apply { setIntValues(binding.syncingProgress.progress, state.syncProgress.progress) }.start()
////                binding.syncingProgress.isIndeterminate = state.syncProgress.indeterminate
////            }
//        }
    }


    override fun showNightModeDialog() {

    }

    override fun showStartTimePicker(hour: Int, minute: Int) {
        TimePickerDialog(activity, { _, newHour, newMinute ->
            startTimeSelectedSubject.onNext(Pair(newHour, newMinute))
        }, hour, minute, DateFormat.is24HourFormat(activity)).show()
    }

    override fun showEndTimePicker(hour: Int, minute: Int) {
        TimePickerDialog(activity, { _, newHour, newMinute ->
            endTimeSelectedSubject.onNext(Pair(newHour, newMinute))
        }, hour, minute, DateFormat.is24HourFormat(activity)).show()
    }

    override fun showTextSizePicker() =
        textSizeDialog.show(activity!!, R.string.settings_text_size_title)

    override fun showDelayDurationDialog() =
        sendDelayDialog.show(activity!!, R.string.settings_delayed_title)

    override fun showSignatureDialog(signature: String) {
//        private val signatureDialog: TextInputDialog by lazy {
//            TextInputDialog(
//                activity!!,
//                context.getString(R.string.settings_signature_title),
//                signatureSubject::onNext
//            )
//        }
        //signatureDialog.setText(signature).show()

        TextInputDialog(activity!!)
            .setText(signature)
            .show(
                activity!!,
                activity!!.getString(R.string.settings_signature_title),
                signatureSubject::onNext
            )
    }

    override fun showAutoDeleteDialog(days: Int) {
        AutoDeleteDialog(activity!!)
            .show(
                activity!!,
                days,
                autoDeleteSubject::onNext
            )
//        autoDeleteDialog.setExpiry(days).show()
    }

    override suspend fun showAutoDeleteWarningDialog(messages: Int): Boolean =
        withContext(Dispatchers.Main) {
            suspendCancellableCoroutine { cont ->
                MessageDialog().show(
                    activity!!,
                    activity!!.getString(R.string.settings_auto_delete_warning),
                    context.resources.getString(
                        R.string.settings_auto_delete_warning_message,
                        messages
                    ),
                    activity!!.getString(R.string.button_yes),
                    positiveActionCallback = { if (cont.isActive) cont.resume(true) },
                    negativeActionCallback = { if (cont.isActive) cont.resume(false) },
                    dismissActionCallback = { if (cont.isActive) cont.resume(false) }
                )
            }
        }

    override fun showMmsSizePicker() =
        mmsSizeDialog.show(activity!!, R.string.settings_mms_size_label)

    override fun showMessageLinkHandlingDialogPicker() =
        messageLinkHandlingDialog.show(activity!!, R.string.settings_mms_weblink_title)

    override fun showSwipeActions() {
        router.pushController(
            RouterTransaction.with(SwipeActionsController())
                .pushChangeHandler(MyChangeHandler())
                .popChangeHandler(MyChangeHandler())
        )
    }


    override fun showLanguageSetting() {
        val intent = Intent(context, LocalizationActivity::class.java)
        startActivity(intent)
    }

    override fun showPrivateConversations() {
        val intent = Intent(context, PasswordActivity::class.java)
//        val intent = Intent(this, SearchActivity::class.java)
        startActivity(intent)
    }

    override fun showOtherSetting() {
//        val intent = Intent(context, PrivateConversationsActivity::class.java)
//        val intent = Intent(this, SearchActivity::class.java)
//        startActivity(intent)
    }

    override fun showArchivedConversations() {
        val intent = Intent(context, ArchivedActivity::class.java)
//        val intent = Intent(this, SearchActivity::class.java)
        startActivity(intent)
    }

    override fun showBlocked() {
        val intent = Intent(context, BlockingActivity::class.java)
        startActivity(intent)
    }

    override fun showBackupRestore() {
        startActivity(Intent(context, BackupActivity::class.java))
    }

    override fun showScheduled() {
        val intent = Intent(context, ScheduledActivity::class.java)
//        conversationId?.let { intent.putExtra("conversationId", it) }
        startActivity(intent)
    }

    override fun showInAppRating() {

    }

    override fun shareOurApp() {
    }

    override fun showPrivacyPolicy() {
    }

}
