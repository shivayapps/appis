
package messages.text.sms.interactor

import messages.text.sms.extensions.mapNotNull
import messages.text.sms.manager.NotificationManager
import messages.text.sms.model.Message
import messages.text.sms.repository.MessageRepository
import io.reactivex.Flowable
import javax.inject.Inject

class RetrySending @Inject constructor(
    private val messageRepo: MessageRepository,
    private val notificationManager: NotificationManager
) : Interactor<Long>() {

    override fun buildObservable(params: Long): Flowable<Message> {
        return Flowable.just(params)
                .doOnNext(messageRepo::markSending)
                .mapNotNull(messageRepo::getMessage)
                .doOnNext { message ->
                    when (message.isSms()) {
                        true -> messageRepo.sendSms(message)
                        false -> messageRepo.resendMms(message)
                    }
                    val threadId = message.threadId
                    notificationManager.cancel(threadId.toInt() + 100000)
                }
    }

}
