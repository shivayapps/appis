
package messages.text.sms.filter

import messages.text.sms.extensions.fuzzyMatch
import messages.text.sms.extensions.removeAccents
import messages.text.sms.model.Contact
import javax.inject.Inject

class ContactFilter @Inject constructor(private val phoneNumberFilter: PhoneNumberFilter) :
    Filter<Contact>() {

    override fun filter(item: Contact, query: CharSequence): Boolean {
        val normalizedName = item.name.removeAccents()
        return normalizedName.contains(query, true) || // exact/substring
                normalizedName.fuzzyMatch(query) || // fuzzy
                item.numbers.map { it.address }
                    .any { address -> phoneNumberFilter.filter(address, query) } // Number
    }

}
