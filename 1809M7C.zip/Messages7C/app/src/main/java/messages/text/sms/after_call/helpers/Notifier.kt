package messages.text.sms.after_call.helpers

import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.graphics.BitmapFactory
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.ExistingWorkPolicy
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.workDataOf
import com.bumptech.glide.Glide
import messages.text.sms.R
import messages.text.sms.common.NotificationChannels
import messages.text.sms.extensions.realScreenSize
import messages.text.sms.feature.main.MainActivity
import java.util.Calendar
import java.util.Date
import java.util.concurrent.TimeUnit


object Notifier {

    fun show(
        context: Context,
        title: String,
        body: String,
    ) {

        NotificationChannels.create(context)

        val intent = Intent(
            context,
            MainActivity::class.java
        ).apply {

            flags =
                Intent.FLAG_ACTIVITY_CLEAR_TOP or
                        Intent.FLAG_ACTIVITY_SINGLE_TOP
        }

        val pendingIntent =
            PendingIntent.getActivity(
                context,
                1001,
                intent,
                PendingIntent.FLAG_IMMUTABLE or
                        PendingIntent.FLAG_UPDATE_CURRENT
            )

        val builder =
            NotificationCompat.Builder(
                context,
                NotificationChannels.ENGAGEMENT
            )
                .setSmallIcon(R.drawable.ic_notification_logo)
                .setContentTitle(title)
                .setContentText(body)
                .setAutoCancel(true)
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setContentIntent(pendingIntent)

        val notificationManager =
            context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

        notificationManager.notify(System.currentTimeMillis().toInt(), builder.build())
    }

    fun scheduleWorker(
        context: Context,
        message: String,
        date: Date
    ) {
        val delay = (date.time - System.currentTimeMillis()).coerceAtLeast(0L)
        val request = OneTimeWorkRequestBuilder<NotificationWorker>()
            .setInputData(workDataOf("message" to message))
            .setInitialDelay(delay, TimeUnit.MILLISECONDS)
            .build()

        WorkManager.getInstance(context)
            .enqueueUniqueWork(
                "notification_${date.time}",
                ExistingWorkPolicy.REPLACE,
                request
            )
    }

//    fun scheduleWorker(
//        context: Context,
//        message: String,
//        date: java.util.Date,
//    ) {
//        val now = Calendar.getInstance()
//
//        val target = Calendar.getInstance().apply {
//            set(Calendar.HOUR_OF_DAY, date)
//            set(Calendar.MINUTE, date)
//            set(Calendar.SECOND, 0)
//            set(Calendar.MILLISECOND, 0)
//
//            if (before(now)) {
//                add(Calendar.DAY_OF_MONTH, 1)
//            }
//        }
//
//        val delay = target.timeInMillis - now.timeInMillis
//
//        val request = PeriodicWorkRequestBuilder<NotificationWorker>(1, TimeUnit.DAYS)
//            .setInputData(
//                workDataOf("message" to message)
//            )
//            .setInitialDelay(delay, TimeUnit.MILLISECONDS)
//            .build()
//
//        WorkManager.getInstance(context).enqueueUniquePeriodicWork(
//            message,
//            ExistingPeriodicWorkPolicy.UPDATE,
//            request
//        )
//    }
}