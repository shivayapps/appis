
package messages.text.sms.feature.compose.editing

import android.content.Context
import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.RelativeLayout
import androidx.recyclerview.widget.RecyclerView
import io.reactivex.subjects.PublishSubject
import messages.text.sms.R
import messages.text.sms.common.base.MyAdapter
import messages.text.sms.common.base.MyBindingViewHolder
import messages.text.sms.databinding.ContactChipBinding
import messages.text.sms.model.Recipient
import javax.inject.Inject

class ChipsAdapter @Inject constructor() :
    MyAdapter<Recipient, MyBindingViewHolder<ContactChipBinding>>() {

    var view: RecyclerView? = null
    val chipDeleted: PublishSubject<Recipient> = PublishSubject.create<Recipient>()

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): MyBindingViewHolder<ContactChipBinding> {
        val binding = ContactChipBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return MyBindingViewHolder(binding).apply {
            binding.root.setOnClickListener {
                val chip = getItem(adapterPosition)
                showDetailedChip(binding.root.context, chip)
            }
        }
    }

    override fun onBindViewHolder(holder: MyBindingViewHolder<ContactChipBinding>, position: Int) {
        val recipient = getItem(position)

//        holder.binding.avatar.setRecipient(recipient)
        holder.binding.name.text =
            recipient.contact?.name?.takeIf { it.isNotBlank() } ?: recipient.address
    }

    /**
     * The [context] has to come from a view, because we're inflating a view that used themed attrs
     */
    private fun showDetailedChip(context: Context, recipient: Recipient) {
        val detailedChipView = DetailedChipView(context)
        detailedChipView.setRecipient(recipient)

        val rootView = view?.rootView as ViewGroup

        val layoutParams = RelativeLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        )

        layoutParams.topMargin = context.resources.getDimensionPixelSize(R.dimen.margin_chip_top)
        layoutParams.marginStart = context.resources.getDimensionPixelSize(R.dimen.margin_chip_start)

        rootView.addView(detailedChipView, layoutParams)
        detailedChipView.show()

        detailedChipView.setOnDeleteListener {
            chipDeleted.onNext(recipient)
            detailedChipView.hide()
        }
    }
}
