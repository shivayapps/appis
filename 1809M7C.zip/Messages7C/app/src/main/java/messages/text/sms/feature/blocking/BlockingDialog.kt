package messages.text.sms.feature.blocking

import android.app.Activity
import android.content.Context
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.Window
import android.view.WindowManager
import androidx.appcompat.app.AlertDialog
import messages.text.sms.R
import messages.text.sms.interactor.MarkBlocked
import messages.text.sms.interactor.MarkUnblocked
import messages.text.sms.repository.ConversationRepository
import messages.text.sms.util.Preferences
import kotlinx.coroutines.launch
import kotlinx.coroutines.rx2.await
import kotlinx.coroutines.withContext
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.MainScope
import messages.text.sms.databinding.DialogBlockingBinding
import messages.text.sms.extensions.dismissKeyboard
import messages.text.sms.extensions.showKeyboard
import javax.inject.Inject

// TODO: Once we have a custom dialog based on conductor, turn this into a controller
class BlockingDialog @Inject constructor(
    private val blockingManager: BlockingClient,
    private val context: Context,
    private val conversationRepo: ConversationRepository,
    private val prefs: Preferences,
    private val markBlocked: MarkBlocked,
    private val markUnblocked: MarkUnblocked
) {

    fun show(activity: Activity, conversationIds: List<Long>, block: Boolean) = GlobalScope.launch {
        val addresses = conversationIds.toLongArray()
            .let { conversationRepo.getConversations(*it) }
            .flatMap { conversation -> conversation.recipients }
            .map { it.address }
            .distinct()

        if (addresses.isEmpty()) {
            return@launch
        }

        if (blockingManager.getClientCapability() == BlockingClient.Capability.BLOCK_WITHOUT_PERMISSION) {
            // If we can block/unblock in the external manager, then just fire that off and exit
            if (block) {
                markBlocked.execute(MarkBlocked.Params(conversationIds,  null))
                blockingManager.block(addresses).subscribe()
            } else {
                markUnblocked.execute(conversationIds)
                blockingManager.unblock(addresses).subscribe()
            }
        } else if (block == allBlocked(addresses)) {
            // If all of the addresses are already in their correct state in the blocking manager, just marked the
            // conversations blocked and exit
            when (block) {
                true -> markBlocked.execute(MarkBlocked.Params(conversationIds,  null))
                false -> markUnblocked.execute(conversationIds)
            }
        } else {
            // Otherwise, show the UI that lets the users know they need to mark the number as blocked in the client
            showDialog(activity, conversationIds, addresses, block)
        }
    }

//    fun show(activity: Activity, conversationIds: List<Long>, block: Boolean) =
//        activity.lifecycleScope.launch {
//            val addresses = conversationIds.toLongArray()
//                .let { conversationRepo.getConversations(*it) }
//                .flatMap { conversation -> conversation.recipients }
//                .map { it.address }
//                .distinct()
//
//            if (addresses.isEmpty()) {
//                return@launch
//            }
//
//            if (blockingManager.getClientCapability() == BlockingClient.Capability.BLOCK_WITHOUT_PERMISSION) {
//                // If we can block/unblock in the external manager, then just fire that off and exit
//                if (block) {
//                    markBlocked.execute(
//                        MarkBlocked.Params(
//                            conversationIds,
//                            null)
//                    )
//                    blockingManager.block(addresses).subscribeOn(Schedulers.io()).subscribe()
//                } else {
//                    markUnblocked.execute(conversationIds)
//                    blockingManager.unblock(addresses).subscribeOn(Schedulers.io()).subscribe()
//                }
//            } else if (block == allBlocked(addresses)) {
//                // If all of the addresses are already in their correct state in the blocking manager, just marked the
//                // conversations blocked and exit
//                when (block) {
//                    true -> markBlocked.execute(
//                        MarkBlocked.Params(
//                            conversationIds,
//                            null
//                        )
//                    )
//
//                    false -> markUnblocked.execute(conversationIds)
//                }
//            } else {
//                // Otherwise, show the UI that lets the users know they need to mark the number as blocked in the client
//                showDialog(activity, conversationIds, addresses, block)
//            }
//        }

    private suspend fun allBlocked(addresses: List<String>): Boolean = addresses.all { address ->
        blockingManager.isBlacklisted(address).await() is BlockingClient.Action.Block
    }

    private suspend fun showDialog(
        activity: Activity,
        conversationIds: List<Long>,
        addresses: List<String>,
        block: Boolean
    ) = withContext(MainScope().coroutineContext) {

        val res = when (block) {
            true -> R.plurals.blocking_block_external
            false -> R.plurals.blocking_unblock_external
        }

        val manager = context.getString(R.string.app_name)

        val message = context.resources.getQuantityString(res, addresses.size, manager)

        // Otherwise, show a dialog asking the user if they want to be directed to the external
        // blocking manager
        val binding = DialogBlockingBinding.inflate(activity.layoutInflater)
        if (block) {
            binding.tvTitle.setText(R.string.blocking_block_title)
            binding.btnPositive.setText(R.string.blocking_block_title)
        } else {
            binding.tvTitle.setText(R.string.blocking_unblock_title)
            binding.btnPositive.setText(R.string.blocking_unblock_title)
        }


        binding.tvMessage.text = message

        val dialog = AlertDialog.Builder(activity)
            .setView(binding.root)
            .setCancelable(true)
            .create()

        binding.btnPositive.setOnClickListener {

            if (block) {
                markBlocked.execute(MarkBlocked.Params(conversationIds, null))
                blockingManager.block(addresses).subscribe()
            } else {
                markUnblocked.execute(conversationIds)
                blockingManager.unblock(addresses).subscribe()
            }

            dialog.dismiss()
        }

        binding.ivClose.setOnClickListener {
            dialog.dismiss()
        }

        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.window?.apply {
            setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            setGravity(Gravity.CENTER)
            setDimAmount(0.8f)
            attributes?.windowAnimations = android.R.style.Animation_Dialog
            setLayout(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.WRAP_CONTENT
            )
        }

        dialog.show()

//        AlertDialog.Builder(activity)
//            .setTitle(
//                when (block) {
//                    true -> R.string.blocking_block_title
//                    false -> R.string.blocking_unblock_title
//                }
//            )
//            .setMessage(message)
//            .setPositiveButton(R.string.button_continue) { _, _ ->
//                if (block) {
//                    markBlocked.execute(MarkBlocked.Params(conversationIds, null))
//                    blockingManager.block(addresses).subscribe()
//                } else {
//                    markUnblocked.execute(conversationIds)
//                    blockingManager.unblock(addresses).subscribe()
//                }
//            }
//            .setNegativeButton(R.string.button_cancel) { _, _ -> }
//            .create()
//            .show()
    }


}
