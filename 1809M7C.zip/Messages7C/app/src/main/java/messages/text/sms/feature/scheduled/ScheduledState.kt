
package messages.text.sms.feature.scheduled

import messages.text.sms.model.ScheduledMessage
import io.realm.RealmResults

data class ScheduledState(
    val scheduledMessages: RealmResults<ScheduledMessage>? = null,
//    val upgraded: Boolean = true,
    val selectedMessages: Int = 0,
    val conversationId: Long? = null,
)
