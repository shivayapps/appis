
package messages.text.sms.feature.blocking

import messages.text.sms.common.base.MyViewContract
import io.reactivex.Observable

interface BlockingView : MyViewContract<BlockingState> {


    val blockedNumbersIntent: Observable<*>
    val messageContentFiltersIntent: Observable<*>
    val blockedMessagesIntent: Observable<*>
    val dropClickedIntent: Observable<*>

    fun openBlockedNumbers()
    fun openMessageContentFilters()
    fun openBlockedMessages()
}
