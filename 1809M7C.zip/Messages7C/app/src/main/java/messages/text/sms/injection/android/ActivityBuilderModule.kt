package messages.text.sms.injection.android

import dagger.Module
import dagger.android.ContributesAndroidInjector
import messages.text.sms.after_call.activity.AfterCallHomeActivity
import messages.text.sms.feature.backup.BackupActivity
import messages.text.sms.feature.blocking.BlockingActivity
import messages.text.sms.feature.compose.ComposeActivity
import messages.text.sms.feature.compose.ComposeActivityModule
import messages.text.sms.feature.compose.QuickSuggestionActivity
import messages.text.sms.feature.contacts.ContactsActivity
import messages.text.sms.feature.contacts.ContactsActivityModule
import messages.text.sms.feature.conversationinfo.ConversationInfoActivity
import messages.text.sms.feature.gallery.GalleryActivity
import messages.text.sms.feature.gallery.GalleryActivityModule
import messages.text.sms.feature.localization.LocalizationActivity
import messages.text.sms.feature.main.ArchivedActivity
import messages.text.sms.feature.main.MainActivity
import messages.text.sms.feature.main.MainActivityModule
import messages.text.sms.feature.startup.PermissionActivity
import messages.text.sms.feature.startup.OverlayPermissionActivity
import messages.text.sms.feature.secret.PrivateConversationsActivity
import messages.text.sms.feature.main.SearchActivity
import messages.text.sms.feature.startup.SplashActivity
import messages.text.sms.feature.notificationprefs.NotificationPrefsActivity
import messages.text.sms.feature.notificationprefs.NotificationPrefsActivityModule
import messages.text.sms.feature.quick_reply.QuickReplyActivity
import messages.text.sms.feature.quick_reply.MyReplyActivityModule
import messages.text.sms.feature.scheduled.ScheduledActivity
import messages.text.sms.feature.scheduled.ScheduledActivityModule
import messages.text.sms.feature.secret.PasswordActivity
import messages.text.sms.feature.secret.ResetPasswordActivity
import messages.text.sms.feature.secret.SecurityQuestionsActivity
import messages.text.sms.feature.settings.SettingsActivity
import messages.text.sms.feature.settings.SettingsOtherActivity
import messages.text.sms.injection.scope.ActivityScope

@Module
abstract class ActivityBuilderModule {

    @ActivityScope
    @ContributesAndroidInjector(modules = [MainActivityModule::class])
    abstract fun bindMainActivity(): MainActivity

//    @ActivityScope
//    @ContributesAndroidInjector(modules = [PlusActivityModule::class])
//    abstract fun bindPlusActivity(): PlusActivity
//    @ActivityScope
//    @ContributesAndroidInjector(modules = [SearchActivityModule::class])
//    abstract fun bindSearchActivity(): SearchActivity

    @ActivityScope
    @ContributesAndroidInjector(modules = [MainActivityModule::class])
    abstract fun bindSearchActivity(): SearchActivity

    @ActivityScope
    @ContributesAndroidInjector(modules = [MainActivityModule::class])
    abstract fun bindPrivateConversationsActivity(): PrivateConversationsActivity

    @ActivityScope
    @ContributesAndroidInjector(modules = [])
    abstract fun bindPasswordActivity(): PasswordActivity

    @ActivityScope
    @ContributesAndroidInjector(modules = [])
    abstract fun bindResetPasswordActivity(): ResetPasswordActivity

    @ActivityScope
    @ContributesAndroidInjector(modules = [])
    abstract fun bindSecurityQuestionsActivity(): SecurityQuestionsActivity

    @ActivityScope
    @ContributesAndroidInjector(modules = [MainActivityModule::class])
    abstract fun bindArchivedActivity(): ArchivedActivity

    @ActivityScope
    @ContributesAndroidInjector(modules = [])
    abstract fun bindOverlayPermissionActivity(): OverlayPermissionActivity

    @ActivityScope
    @ContributesAndroidInjector(modules = [])
    abstract fun bindLocalizationActivity(): LocalizationActivity

    @ActivityScope
    @ContributesAndroidInjector(modules = [])
    abstract fun bindAfterCallHomeActivity(): AfterCallHomeActivity

    @ActivityScope
    @ContributesAndroidInjector(modules = [])
    abstract fun bindQuickReplyActivity(): QuickSuggestionActivity

    @ActivityScope
    @ContributesAndroidInjector(modules = [])
    abstract fun bindPermissionActivity(): PermissionActivity

    @ActivityScope
    @ContributesAndroidInjector(modules = [])
    abstract fun bindSplashActivity(): SplashActivity

    @ActivityScope
    @ContributesAndroidInjector(modules = [])
    abstract fun bindBackupActivity(): BackupActivity

    @ActivityScope
    @ContributesAndroidInjector(modules = [ComposeActivityModule::class])
    abstract fun bindComposeActivity(): ComposeActivity

    @ActivityScope
    @ContributesAndroidInjector(modules = [ContactsActivityModule::class])
    abstract fun bindContactsActivity(): ContactsActivity

    @ActivityScope
    @ContributesAndroidInjector(modules = [])
    abstract fun bindConversationInfoActivity(): ConversationInfoActivity

    @ActivityScope
    @ContributesAndroidInjector(modules = [GalleryActivityModule::class])
    abstract fun bindGalleryActivity(): GalleryActivity

    @ActivityScope
    @ContributesAndroidInjector(modules = [NotificationPrefsActivityModule::class])
    abstract fun bindNotificationPrefsActivity(): NotificationPrefsActivity

    @ActivityScope
    @ContributesAndroidInjector(modules = [MyReplyActivityModule::class])
    abstract fun bindMainBaseReplyActivity(): QuickReplyActivity

    @ActivityScope
    @ContributesAndroidInjector(modules = [ScheduledActivityModule::class])
    abstract fun bindScheduledActivity(): ScheduledActivity

    @ActivityScope
    @ContributesAndroidInjector(modules = [])
    abstract fun bindSettingsActivity(): SettingsActivity

    @ActivityScope
    @ContributesAndroidInjector(modules = [])
    abstract fun bindSettingsOtherActivity(): SettingsOtherActivity

    @ActivityScope
    @ContributesAndroidInjector(modules = [])
    abstract fun bindBlockingActivity(): BlockingActivity
}
