
package messages.text.sms.manager

interface PermissionManager {

    fun isDefaultSms(): Boolean

    fun hasReadSms(): Boolean

    fun hasSendSms(): Boolean

    fun hasContacts(): Boolean

    fun hasNotifications(): Boolean

    fun hasPhone(): Boolean

    fun hasCalling(): Boolean

    fun hasStorage(): Boolean

    fun hasRecordAudio(): Boolean

    fun hasExactAlarms(): Boolean

}
