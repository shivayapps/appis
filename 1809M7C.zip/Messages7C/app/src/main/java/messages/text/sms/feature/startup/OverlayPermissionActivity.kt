package messages.text.sms.feature.startup

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.CountDownTimer
import android.provider.Settings
import android.util.Log
import dagger.android.AndroidInjection
import messages.text.sms.adhelper.BannerAdHelper
import messages.text.sms.common.base.MainBaseThemedActivity
import messages.text.sms.extensions.baseConfig
import messages.text.sms.databinding.ActivityOverlayPermissionBinding
import messages.text.sms.extensions.MiuiHelperUtils
import messages.text.sms.feature.localization.LocalizationActivity
import messages.text.sms.feature.main.MainActivity
import java.util.Locale

class OverlayPermissionActivity :
    MainBaseThemedActivity<ActivityOverlayPermissionBinding>(ActivityOverlayPermissionBinding::inflate) {

    private val TAG = "PermissionActivity"

    // Track which permissions are granted
    private var isOverlayGranted = false
    private var isBgStartGranted = false
    private var isProcessingResult = false

    override fun onCreate(savedInstanceState: Bundle?) {
        AndroidInjection.inject(this)
        super.onCreate(savedInstanceState)
        setContentView(binding.root)

        checkPermissionsAndStartFlow()
        loadAds()
    }

    private fun checkOverlayGranted(): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            Settings.canDrawOverlays(this)
        } else {
            true
        }
    }

    private fun checkPermissionsAndStartFlow() {
        // Check all permissions
        isOverlayGranted = checkOverlayGranted()
        isBgStartGranted = if (MiuiHelperUtils.isMiui()) {
            MiuiHelperUtils.isBgStartAllowed(this)
        } else {
            true // Not MIUI, so no need for this permission
        }

        Log.d(
            TAG,
            "Permissions - Overlay: $isOverlayGranted"
        )

        // Start the permission flow
        // Check if all permissions are already granted
        if (isOverlayGranted && isBgStartGranted) {
            moveNext()
            return
        }

        binding.btnNext.setOnClickListener {
            startPermissionFlow()
        }
        binding.ivBanner.setOnClickListener {
            startPermissionFlow()
        }

    }

    private fun startPermissionFlow() {
        // Re-check overlay permission first
        isOverlayGranted = checkOverlayGranted()

        if (!isOverlayGranted) {
            openOverlaySettings()
        } else if (MiuiHelperUtils.isMiui() && !isBgStartGranted) {
            // Overlay granted, now ask background start for MIUI
            openBgStartSettings()
        } else {
            // All permissions granted
            moveNext()
        }
    }

    var countDownTimerOverlay: CountDownTimer? = null

    private fun openOverlaySettings() {
        val intent = Intent(
            Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
            Uri.parse("package:$packageName")
        )
        startActivity(intent)

        startActivity(Intent(this, PermissionHintActivity::class.java).putExtra("type", "all"))

        countDownTimerOverlay?.cancel()
        countDownTimerOverlay = object : CountDownTimer(1000000L, 500) {
            override fun onTick(l: Long) {
                isProcessingResult = true
                isOverlayGranted = checkOverlayGranted()
                isProcessingResult = false
                if (isOverlayGranted) {
                    cancel()
                    // Overlay granted, now check if we need background start
                    if (MiuiHelperUtils.isMiui() && !isBgStartGranted) {
                        openBgStartSettings()
                    } else {
                        moveNext()
                    }
                }
            }

            override fun onFinish() {}
        }
        countDownTimerOverlay!!.start()
    }

    private fun openBgStartSettings() {
        if (MiuiHelperUtils.isMiui()) {
            val opened = MiuiHelperUtils.openBgStartSettings(this)
            if (!opened) {
                openAppSettings()
            }
            startActivity(
                Intent(this, PermissionHintActivity::class.java).putExtra(
                    "type",
                    "bg_start"
                )
            )
        }
    }

    private fun openAppSettings() {
        try {
            val intent = Intent(
                Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                Uri.parse("package:$packageName")
            )
            intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
            startActivity(intent)
        } catch (e: Exception) {
            // If everything fails, just move next
            moveNext()
        }
    }

    override fun onResume() {
        super.onResume()
        // Re-check permissions when returning to the app
        if (!isProcessingResult) {
            checkPermissionsAfterReturn()
        }
    }

    private fun checkPermissionsAfterReturn() {
        isProcessingResult = true

        // Re-check overlay permission
        isOverlayGranted = checkOverlayGranted()

        // Re-check background start permission for MIUI
        isBgStartGranted = if (MiuiHelperUtils.isMiui()) {
            MiuiHelperUtils.isBgStartAllowed(this)
        } else {
            true // Not MIUI, so no need for this permission
        }

        Log.d(
            TAG,
            "After return - Overlay: $isOverlayGranted, BgStart: $isBgStartGranted"
        )

        isProcessingResult = false

        // Check permissions and take appropriate action
        if (isOverlayGranted && isBgStartGranted) {
            // All permissions granted
            moveNext()
        } else if (isOverlayGranted && MiuiHelperUtils.isMiui() && !isBgStartGranted) {
            // Overlay granted, now open background start settings
            //openBgStartSettings()
        } else if (!isOverlayGranted) {
            // Overlay not granted - user needs to go back to overlay settings
            // We don't automatically open it here to avoid loop
            // User can click the button again
            Log.d(TAG, "Overlay permission still not granted")
        }
    }

    fun loadAds() {
        BannerAdHelper.showBanner(
            this,
            binding.adsView,
            baseConfig.bannerAdsId,
            { isLoaded, message ->

            })
    }

    private fun moveNext() {
        val locale = Locale.getDefault().language
        Log.e(TAG, "moveNext.locale:$locale")
        Log.e(TAG, "moveNext.selectedLanguage:${baseConfig.selectedLanguage}")
        Log.e(TAG, "moveNext.clickLangDone:${baseConfig.clickLangDone}")

        if (locale != "en"
            //|| baseConfig.selectedLanguage.isBlank()
            || !baseConfig.clickLangDone
        ) {
            startActivity(
                Intent(this, LocalizationActivity::class.java)
                    .putExtra("from_splash", true)
            )
        } else {
            startActivity(Intent(this, MainActivity::class.java))
        }

        finish()
    }

    override fun onDestroy() {
        super.onDestroy()
        countDownTimerOverlay?.cancel()
    }
}
