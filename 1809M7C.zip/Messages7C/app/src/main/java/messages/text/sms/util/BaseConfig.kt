package messages.text.sms.util

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.Base64
import messages.text.sms.extensions.getSharedPrefs
import java.io.ByteArrayOutputStream
import androidx.core.content.edit

open class BaseConfig(val context: Context) {
    protected val prefs = context.getSharedPrefs()

    companion object {
        fun newInstance(context: Context) = BaseConfig(context)
    }

    // Index of the selected Drive auto-reply
    var driveSelectedReplyIndex: Int
        get() = prefs.getInt("DRIVE_SELECTED_REPLY_INDEX_KEY", 0)
        set(value) = prefs.edit { putInt("DRIVE_SELECTED_REPLY_INDEX_KEY", value) }

    // Whether to reply only to contacts
    var onlyReplyContacts: Boolean
        get() = prefs.getBoolean("ONLY_REPLY_CONTACTS_KEY", false)
        set(value) = prefs.edit { putBoolean("ONLY_REPLY_CONTACTS_KEY", value) }
    var clickLangDone: Boolean
        get() = prefs.getBoolean("clickLangDone", false)
        set(value) = prefs.edit { putBoolean("clickLangDone", value) }
    var splashCounter: Int
        get() = prefs.getInt("splashCounter", 0)
        set(value) = prefs.edit { putInt("splashCounter", value) }
    var nativeAdsId: String
        get() = prefs.getString("nativeAdsId", "") ?: ""
        set(value) = prefs.edit { putString("nativeAdsId", value) }
    var bannerAdsId: String
        get() = prefs.getString("bannerAdsId", "") ?: ""
        set(value) = prefs.edit { putString("bannerAdsId", value) }
    var interstitialAdsId: String
        get() = prefs.getString("interstitialAdsId", "") ?: ""
        set(value) = prefs.edit { putString("interstitialAdsId", value) }
    var appopenAdsId: String
        get() = prefs.getString("appopenAdsId", "") ?: ""
        set(value) = prefs.edit { putString("appopenAdsId", value) }
    var rewardAdsId: String
        get() = prefs.getString("rewardAdsId", "") ?: ""
        set(value) = prefs.edit { putString("rewardAdsId", value) }
    var addButtonColor: String
        get() = prefs.getString("addButtonColor", "") ?: ""
        set(value) = prefs.edit { putString("addButtonColor", value) }

    var selectedLanguage: String
        get() = prefs.getString("selectedLanguage", "") ?: ""
        set(value) = prefs.edit { putString("selectedLanguage", value) }
    var systemLocalLanguage: String
        get() = prefs.getString("systemLocalLanguage", "") ?: ""
        set(value) = prefs.edit { putString("systemLocalLanguage", value) }
    var lastBackup: String
        get() = prefs.getString("lastBackup", "Never") ?: "Never"
        set(value) = prefs.edit { putString("lastBackup", value) }
    var quickNotes: String
        get() = prefs.getString("quickNotes", "") ?: ""
        set(value) = prefs.edit { putString("quickNotes", value) }
    var afterCallQuickNotes: String
        get() = prefs.getString("afterCallQuickNotes", "") ?: ""
        set(value) = prefs.edit { putString("afterCallQuickNotes", value) }

    var isSetQuestion: Boolean
        get() = prefs.getBoolean("isSetQuestion", false)
        set(value) = prefs.edit { putBoolean("isSetQuestion", value) }
    var privatePin: String
        get() = prefs.getString("privatePin", "") ?: ""
        set(value) = prefs.edit { putString("privatePin", value) }
    var securityAnswer: String
        get() = prefs.getString("securityAnswer", "") ?: ""
        set(value) = prefs.edit { putString("securityAnswer", value) }
    var securityQuestionPos: Int
        get() = prefs.getInt("securityQuestionPos", -1) ?: 0-1
        set(value) = prefs.edit { putInt("securityQuestionPos", value) }
    var privateContactsList: String
        get() = prefs.getString("PRIVATE_CONTACTS", "") ?: ""
        set(value) = prefs.edit { putString("PRIVATE_CONTACTS", value) }
    var isFirstTime: Boolean
        get() = prefs.getBoolean("isFirstTime", true)
        set(value) = prefs.edit { putBoolean("isFirstTime", value) }
    var useImageResource: Boolean
        get() = prefs.getBoolean("USE_IMAGE_RESOURCE", false)
        set(value) = prefs.edit { putBoolean("USE_IMAGE_RESOURCE", value) }
    var callUMP: Boolean
        get() = prefs.getBoolean("callUMP", false)
        set(value) = prefs.edit { putBoolean("callUMP", value) }
    var autoReplyEnable: Boolean
        get() = prefs.getBoolean("autoReplayEnable", false)
        set(value) = prefs.edit { putBoolean("autoReplayEnable", value) }
    var autoReplySelectedCard: Int
        get() = prefs.getInt("AUTOREPLYSELECTEDCARD", 1)
        set(value) = prefs.edit { putInt("AUTOREPLYSELECTEDCARD", value) }
    var storedImageResource: Int
        get() = prefs.getInt("storedImageResource", -1)
        set(value) = prefs.edit { putInt("storedImageResource", value) }
    var storedImageResourceGallery: Int
        get() = prefs.getInt("storedImageResourceGallery", -1)
        set(value) = prefs.edit { putInt("storedImageResourceGallery", value) }
    var quickMessagesList: List<String>
        get() {
            val savedMessages = prefs.getString("CALLER_QUICK_MESSAGES", null)
            return savedMessages?.split("|")
                ?.map { it.trim() } // Remove leading/trailing whitespace
                ?.filter { it.isNotEmpty() } // Filter out empty messages
                ?: listOf(
                    "What's up?", "I'll be running a bit late, but I’ll be there soon",
                    "Where is the meeting taking place?", "Where are you?", "How are things?",
                    "Please give me a call after receiving this message.", "When are we meeting?",
                    "I’ll let you know a bit.", "No problem. I missed your call."
                )
        }
        set(value) {
            prefs.edit {
                putString(
                    "CALLER_QUICK_MESSAGES",
                    value.filter { it.isNotEmpty() }.joinToString("|")
                )
            }
        }

    var selectedLanguage_default_name: String
        get() = prefs.getString("selectedLanguage_default_name", "System Default") ?: ""
        set(value) = prefs.edit {
            putString("selectedLanguage_default_name", value)
        }

    var archiveCheck: String
        get() = prefs.getString("ARCHIVE_CHECK", "archived") ?: ""
        set(value) = prefs.edit { putString("ARCHIVE_CHECK", value) }

    var privateChatCheck: String
        get() = prefs.getString("PRIVATE_CHECK", "isPrivateBox") ?: ""
        set(value) = prefs.edit { putString("PRIVATE_CHECK", value) }

    var enableOtpView: Boolean
        get() = prefs.getBoolean("SETTINGS_OTP_ICONS", true)
        set(value) = prefs.edit { putBoolean("SETTINGS_OTP_ICONS", value) }

    var settingsFingerprintOn: Boolean
        get() = prefs.getBoolean("SETTINGS_FINGERPRINT_ON", false)
        set(value) = prefs.edit {
            putBoolean("SETTINGS_FINGERPRINT_ON", value)
        }

    var privateNotification: Boolean
        get() = prefs.getBoolean("PRIVATE_NOTIFICATION", true)
        set(value) = prefs.edit {
            putBoolean("PRIVATE_NOTIFICATION", value)
        }

    var hideEntranceSwitchStatus: Boolean
        get() = prefs.getBoolean("HIDE_ENTRANCE_SWITCH_STATUS", false)
        set(value) = prefs.edit {
            putBoolean("HIDE_ENTRANCE_SWITCH_STATUS", value)
        }

    fun bitmapToBase64(bitmap: Bitmap): String {
        val byteArrayOutputStream = ByteArrayOutputStream()
        bitmap.compress(Bitmap.CompressFormat.PNG, 100, byteArrayOutputStream)
        val byteArray = byteArrayOutputStream.toByteArray()
        return Base64.encodeToString(byteArray, Base64.DEFAULT)
    }

    fun base64ToBitmap(base64String: String): Bitmap {
        val decodedString = Base64.decode(base64String, Base64.DEFAULT)
        return BitmapFactory.decodeByteArray(decodedString, 0, decodedString.size)
    }

}


