
package messages.text.sms.feature.scheduled

import androidx.lifecycle.ViewModel
import dagger.Module
import dagger.Provides
import dagger.multibindings.IntoMap
import messages.text.sms.injection.ViewModelKey
import javax.inject.Named

@Module
class ScheduledActivityModule {

    @Provides
    @IntoMap
    @ViewModelKey(ScheduledViewModel::class)
    fun provideScheduledViewModel(viewModel: ScheduledViewModel): ViewModel = viewModel

    @Provides
    @Named("conversationId")
    fun getConversationId(activity: ScheduledActivity):
            Long? = activity.intent.extras?.getLong("conversationId")

}
