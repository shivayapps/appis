
package messages.text.sms.feature.blocking.filters

import io.realm.RealmResults
import messages.text.sms.model.MessageContentFilter

data class MessageContentFiltersState(
    val filters: RealmResults<MessageContentFilter>? = null
)
