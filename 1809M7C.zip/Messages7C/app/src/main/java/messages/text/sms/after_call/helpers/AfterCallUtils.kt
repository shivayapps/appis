package messages.text.sms.after_call.helpers

import android.Manifest
import android.app.Application
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.drawable.Drawable
import androidx.annotation.Keep

@Keep
object AfterCallUtils {

    var openAfterCall = false


    fun hasPermissionInManifest(context: Context): Boolean {

        val packageInfo = context.packageManager.getPackageInfo(
            context.packageName,
            PackageManager.GET_PERMISSIONS
        )
        val permissions = packageInfo.requestedPermissions

        if (permissions.isNullOrEmpty())
            return false

        for (perm in permissions) {
            if (perm == Manifest.permission.READ_CONTACTS)
                return true
        }

        return false
    }

//    fun getLogoFromPackageManager(context: Context): Drawable? {
//        return try {
//            val packageManager = context.packageManager
//            val applicationInfo =
//                packageManager.getApplicationInfo(afterCallApplication?.packageName!!, 0)
//            packageManager.getApplicationIcon(applicationInfo)
//        } catch (e: PackageManager.NameNotFoundException) {
//            e.printStackTrace()
//            null
//        }
//    }

}