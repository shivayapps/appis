package messages.text.sms.feature.settings

import android.animation.ObjectAnimator
import android.app.Activity
import android.app.TimePickerDialog
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.text.format.DateFormat
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.view.children
import androidx.core.view.isVisible
import com.bluelinelabs.conductor.RouterTransaction
import com.jakewharton.rxbinding2.view.clicks
import com.uber.autodispose.android.lifecycle.scope
import messages.text.sms.R
import messages.text.sms.common.MyChangeHandler
import messages.text.sms.dialog.OptionDialog
import messages.text.sms.common.base.MyController
import messages.text.sms.common.util.Colors
import messages.text.sms.extensions.animateLayoutChanges
import messages.text.sms.common.widget.PreferenceView
import messages.text.sms.common.widget.TextInputDialog
import messages.text.sms.dialog.AutoDeleteDialog
import messages.text.sms.feature.settings.swipe.SwipeActionsController
import messages.text.sms.injection.appComponent
import messages.text.sms.repository.SyncRepository
import io.reactivex.Observable
import io.reactivex.subjects.PublishSubject
import io.reactivex.subjects.Subject
import android.widget.CompoundButton
import com.google.android.play.core.review.ReviewInfo
import com.google.android.play.core.review.ReviewManager
import com.google.android.play.core.review.ReviewManagerFactory
import com.uber.autodispose.autoDispose
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import messages.text.sms.BuildConfig
import messages.text.sms.adhelper.AdUtil
import messages.text.sms.dialog.MessageDialog
import messages.text.sms.dialog.ThemeControlDialog
import messages.text.sms.extensions.baseConfig
import messages.text.sms.extensions.launchUrl
import messages.text.sms.databinding.SettingsControllerBinding
import messages.text.sms.feature.backup.BackupActivity
import messages.text.sms.feature.blocking.BlockingActivity
import messages.text.sms.feature.localization.LocalizationActivity
import messages.text.sms.feature.main.ArchivedActivity
import messages.text.sms.feature.scheduled.ScheduledActivity
import messages.text.sms.feature.secret.PasswordActivity
import java.lang.ref.WeakReference
import javax.inject.Inject
import kotlin.coroutines.resume

class SettingsController :
    MyController<SettingsControllerBinding, SettingsView, SettingsState, SettingsPresenter>(),
    SettingsView {

    override fun inflateBinding(
        inflater: LayoutInflater,
        container: ViewGroup
    ): SettingsControllerBinding = SettingsControllerBinding.inflate(inflater, container, false)

    @Inject
    lateinit var context: Context

    @Inject
    lateinit var colors: Colors

    @Inject
    lateinit var nightModeDialog: ThemeControlDialog

    @Inject
    lateinit var textSizeDialog: OptionDialog

    @Inject
    override lateinit var presenter: SettingsPresenter

    //    private val autoDeleteDialog: AutoDeleteDialog by lazy {
//        AutoDeleteDialog(activity!!, autoDeleteSubject::onNext)
//    }
    private val startTimeSelectedSubject: Subject<Pair<Int, Int>> = PublishSubject.create()
    private val endTimeSelectedSubject: Subject<Pair<Int, Int>> = PublishSubject.create()
    private val signatureSubject: Subject<String> = PublishSubject.create()

    private val autoDeleteSubject: Subject<Int> = PublishSubject.create()

    private val progressAnimator by lazy {
        ObjectAnimator.ofInt(
            binding.syncingProgress,
            "progress",
            0,
            0
        )
    }

    init {
        appComponent.inject(this)
        retainViewMode = RetainViewMode.RETAIN_DETACH

        colors.themeObservable()
            .autoDispose(scope())
            .subscribe { activity?.recreate() }
    }

    override fun onViewCreated() {
        binding.preferences.postDelayed({ binding.preferences.animateLayoutChanges = true }, 100)
//        when (Build.VERSION.SDK_INT >= 29) {
//            true -> nightModeDialog.adapter.setData(R.array.night_modes)
//            false -> nightModeDialog.adapter.data =
//                context.resources.getStringArray(R.array.night_modes)
//                    .mapIndexed { index, title -> MenuItem(title, index) }
//                    .drop(1)
//        }
        textSizeDialog.adapter.setData(R.array.text_sizes)
//        sendDelayDialog.adapter.setData(R.array.delayed_sending_labels)
//        mmsSizeDialog.adapter.setData(R.array.mms_sizes, R.array.mms_sizes_ids)
//        messageLinkHandlingDialog.adapter.setData(
//            R.array.messageLinkHandlings,
//            R.array.messageLinkHandling_ids
//        )

//        binding.about.summary = context.getString(R.string.settings_version, BuildConfig.VERSION_NAME)
        binding.language.summary = getLanguageString(activity!!.baseConfig.selectedLanguage)
    }

    fun getLanguageString(langeCode: String): String {
        return when (langeCode) {
            "en" -> "English"
            "hi" -> "हिंदी"
            "es" -> "Español"
            "de" -> "Deutsch"
            "fr" -> "Français"
            "zh" -> "中文"
            "tr" -> "Türkçe"
            "pt" -> "Português"
            "ar" -> "العربية"
            else -> "English"
        }
    }

    override fun onAttach(view: View) {
        super.onAttach(view)
        presenter.bindIntents(this)
        setTitle(R.string.title_settings)
//        showBackButton(true)
    }

    //    override fun showBackButton(show: Boolean) {
//        if (show) binding.ivClose.visibility = View.VISIBLE
//        else binding.ivClose.visibility = View.GONE
//    }
    private fun ViewGroup.preferenceViews(): Sequence<PreferenceView> =
        children.flatMap {
            when (it) {
                is PreferenceView -> sequenceOf(it)
                is ViewGroup -> it.preferenceViews()
                else -> emptySequence()
            }
        }

    override fun preferenceClicks(): Observable<PreferenceView> =
        Observable.merge(
            binding.preferences.preferenceViews()
                .map { it.clicks().map { _ -> it } }
                .toList()
        )

//    override fun preferenceClicks(): Observable<PreferenceView> = (0 until binding.preferences.childCount)
//        .map { index -> binding.preferences.getChildAt(index) }
//        .mapNotNull { view -> view as? PreferenceView }
//        .map { preference -> preference.clicks().map { preference } }
//        .let { preferences -> Observable.merge(preferences) }


    override fun nightModeSelected(): Observable<Int> = nightModeDialog.menuItemClicks

    override fun nightStartSelected(): Observable<Pair<Int, Int>> = startTimeSelectedSubject

    override fun nightEndSelected(): Observable<Pair<Int, Int>> = endTimeSelectedSubject

    override fun textSizeSelected(): Observable<Int> = textSizeDialog.adapter.menuItemClicks

    override fun sendDelaySelected(): Observable<Int> = Observable.never()

    override fun signatureChanged(): Observable<String> = signatureSubject

    override fun autoDeleteChanged(): Observable<Int> = autoDeleteSubject

    override fun mmsSizeSelected(): Observable<Int> = Observable.never()

    override fun messageLinkHandlingSelected(): Observable<Int> = Observable.never()

    private fun PreferenceView.checkbox(): CompoundButton? = findViewById(R.id.checkbox)

    override fun render(state: SettingsState) {
//        binding.theme.findViewById<View>(R.id.themePreview)?.setBackgroundTint(state.theme)
        binding.night.summary = state.nightModeSummary
        nightModeDialog.selectedItem = state.nightModeId

//        binding.nightStart.setVisible(state.nightModeId == Preferences.NIGHT_MODE_AUTO)
//        binding.nightStart.summary = state.nightStart
//        binding.nightEnd.setVisible(state.nightModeId == Preferences.NIGHT_MODE_AUTO)
//        binding.nightEnd.summary = state.nightEnd

//        binding.black.setVisible(state.nightModeId != Preferences.NIGHT_MODE_OFF)
//        binding.black.checkbox?.isChecked = state.black

//        binding.autoEmoji.checkbox()?.isChecked = state.autoEmojiEnabled
//        binding.delayed.summary = state.sendDelaySummary
//        sendDelayDialog.adapter.selectedItem = state.sendDelayId
//        binding.delivery.checkbox()?.isChecked = state.deliveryEnabled
//        binding.unreadAtTop.checkbox()?.isChecked = state.unreadAtTopEnabled
//        binding.signature.summary = state.signature.takeIf { it.isNotBlank() }
//            ?: context.getString(R.string.settings_signature_summary)

        binding.textSize.summary = state.textSizeSummary
        textSizeDialog.adapter.selectedItem = state.textSizeId

//        binding.autoColor.checkbox?.isChecked = state.autoColor
//
//        binding.systemFont.checkbox?.isChecked = state.systemFontEnabled
//
//        binding.showStt.checkbox?.isChecked = state.showStt

//        binding.unicode.checkbox()?.isChecked = state.stripUnicodeEnabled
//        binding.mobileOnly.checkbox()?.isChecked = state.mobileOnly
//        binding.longAsMms.checkbox()?.isChecked = state.longAsMms
//        binding.mmsSize.summary = state.maxMmsSizeSummary
//        mmsSizeDialog.adapter.selectedItem = state.maxMmsSizeId

//        binding.messsageLinkHandling.summary = state.messageLinkHandlingSummary
//        messageLinkHandlingDialog.adapter.selectedItem = state.messageLinkHandlingId

//        binding.disableScreenshots.checkbox()?.isChecked = state.disableScreenshotsEnabled

        when (state.syncProgress) {
            is SyncRepository.SyncProgress.Idle -> binding.syncingProgress.isVisible = false

            is SyncRepository.SyncProgress.Running -> {
                binding.syncingProgress.isVisible = true
                binding.syncingProgress.max = state.syncProgress.max
                progressAnimator.apply {
                    setIntValues(
                        binding.syncingProgress.progress,
                        state.syncProgress.progress
                    )
                }.start()
                binding.syncingProgress.isIndeterminate = state.syncProgress.indeterminate
            }

//            is SyncRepository.SyncProgress.ParsingEmojis -> {
//                binding.syncingProgress.isVisible = true
//                binding.syncingProgress.max = state.syncProgress.max
//                progressAnimator.apply { setIntValues(binding.syncingProgress.progress, state.syncProgress.progress) }.start()
//                binding.syncingProgress.isIndeterminate = state.syncProgress.indeterminate
//            }
        }
    }

    override fun showNightModeDialog() = nightModeDialog.show(activity!!)

    override fun showStartTimePicker(hour: Int, minute: Int) {
        TimePickerDialog(activity, { _, newHour, newMinute ->
            startTimeSelectedSubject.onNext(Pair(newHour, newMinute))
        }, hour, minute, DateFormat.is24HourFormat(activity)).show()
    }

    override fun showEndTimePicker(hour: Int, minute: Int) {
        TimePickerDialog(activity, { _, newHour, newMinute ->
            endTimeSelectedSubject.onNext(Pair(newHour, newMinute))
        }, hour, minute, DateFormat.is24HourFormat(activity)).show()
    }

    override fun showTextSizePicker() =
        textSizeDialog.show(activity!!, R.string.settings_text_size_title)

    override fun showDelayDurationDialog() {

    }

    override fun showSignatureDialog(signature: String) {
//        private val signatureDialog: TextInputDialog by lazy {
//            TextInputDialog(
//                activity!!,
//                context.getString(R.string.settings_signature_title),
//                signatureSubject::onNext
//            )
//        }
        //signatureDialog.setText(signature).show()

        TextInputDialog(activity!!)
            .setText(signature)
            .show(
                activity!!,
                activity!!.getString(R.string.settings_signature_title),
                signatureSubject::onNext
            )
    }

    override fun showAutoDeleteDialog(days: Int) {
        AutoDeleteDialog(activity!!)
            .show(
                activity!!,
                days,
                autoDeleteSubject::onNext
            )
//        autoDeleteDialog.setExpiry(days).show()
    }

    override suspend fun showAutoDeleteWarningDialog(messages: Int): Boolean =
        withContext(Dispatchers.Main) {
            suspendCancellableCoroutine<Boolean> { cont ->
                MessageDialog()
                    .show(
                        activity!!,
                        activity!!.getString(R.string.settings_auto_delete_warning),
                        context.resources.getString(
                            R.string.settings_auto_delete_warning_message,
                            messages
                        ),
                        activity!!.getString(R.string.button_yes),
                        positiveActionCallback = { if (cont.isActive) cont.resume(true) },
                        negativeActionCallback = { if (cont.isActive) cont.resume(false) },
                        dismissActionCallback = { if (cont.isActive) cont.resume(false) }
                    )

//                val dialog = AlertDialog.Builder(activity!!, R.style.AppThemeDialog)
//                    .setTitle(R.string.settings_auto_delete_warning)
//                    .setMessage(
//                        context.resources.getString(
//                            R.string.settings_auto_delete_warning_message,
//                            messages
//                        )
//                    )
//                    .setOnCancelListener { cont.resume(false) }
//                    .setNegativeButton(R.string.button_cancel) { _, _ -> cont.resume(false) }
//                    .setPositiveButton(R.string.button_yes) { _, _ -> cont.resume(true) }
//                    .create()
//
//                dialog.show()
//
//                themedActivity?.theme?.take(1)
//                    ?.autoDispose(scope())
//                    ?.subscribe { theme ->
//                        dialog.getButton(AlertDialog.BUTTON_POSITIVE)?.setTextColor(theme.theme)
//                        dialog.getButton(AlertDialog.BUTTON_NEGATIVE)?.setTextColor(theme.theme)
//                    }
            }
        }

    override fun showMmsSizePicker() {
        //mmsSizeDialog.show(activity!!)
    }

    override fun showMessageLinkHandlingDialogPicker() {
        //messageLinkHandlingDialog.show(activity!!)
    }

    override fun showSwipeActions() {
        router.pushController(
            RouterTransaction.with(SwipeActionsController())
                .pushChangeHandler(MyChangeHandler())
                .popChangeHandler(MyChangeHandler())
        )
    }


    override fun showLanguageSetting() {
        val intent = Intent(context, LocalizationActivity::class.java)
        startActivity(intent)
    }

    override fun showPrivateConversations() {
//        val intent = Intent(context, PrivateConversationsActivity::class.java)
        val intent = Intent(context, PasswordActivity::class.java)
        startActivity(intent)
    }

    override fun showOtherSetting() {
        val intent = Intent(context, SettingsOtherActivity::class.java)
        startActivity(intent)
    }

    override fun showArchivedConversations() {
        val intent = Intent(context, ArchivedActivity::class.java)
        startActivity(intent)
    }

    override fun showBlocked() {
        val intent = Intent(context, BlockingActivity::class.java)
        startActivity(intent)
    }

    override fun showBackupRestore() {
        startActivity(Intent(context, BackupActivity::class.java))
    }

    override fun showScheduled() {
        val intent = Intent(context, ScheduledActivity::class.java)
        startActivity(intent)
    }


    override fun showInAppRating() {
        AdUtil.isSystemDialogOpen = true
        Log.e("RatingDialog", "showInAppRateDialog")
        val reviewManager = ReviewManagerFactory.create(activity!!)
        val activityRef = WeakReference(activity)
        val requestReview = reviewManager.requestReviewFlow()
        requestReview.addOnCompleteListener { task ->
            Log.e("RatingDialog", "showInAppRateDialog.task:${task.isSuccessful}")
            if (task.isSuccessful) {
                val fragmentActivity = activityRef.get()
                if (fragmentActivity != null) {
                    showInAppRateDialogInternal(
                        reviewManager,
                        fragmentActivity,
                        task.result
                    )
                }
            } else {
                Log.e("RatingDialog", "showInAppRateDialog.exception:${task.exception}")
//                log.error(task.exception)
            }
        }
    }

    private fun showInAppRateDialogInternal(
        reviewManager: ReviewManager,
        activity: Activity,
        reviewInfo: ReviewInfo,
    ) {
        Log.e("RatingDialog", "showInAppRateDialogInternal")
        val reviewFlow = reviewManager.launchReviewFlow(activity, reviewInfo)
//        val activityRef = WeakReference(activity)
        reviewFlow.addOnCompleteListener { task ->
            Log.e("RatingDialog", "showInAppRateDialogInternal.task:${task.isSuccessful}")
            if (task.isSuccessful) {
                Log.e("RatingDialog", "showInAppRateDialogInternal.isSuccessful")
//                val fragmentActivity = activityRef.get()
//                if (fragmentActivity != null) {
//                    launchAppStore()
//                    Log.e("RatingDialog", "showInAppRateDialogInternal.RateUsState.IGNORED")
//                }
            } else {
                Log.e("RatingDialog", "showInAppRateDialogInternal.exception:${task.exception}")
            }
        }
    }

    private fun launchAppStore() {
        val intent = Intent(
            Intent.ACTION_VIEW,
            Uri.parse("http://play.google.com/store/apps/details?id=${BuildConfig.APPLICATION_ID}")
        )
        startActivity(intent)
    }

    override fun shareOurApp() {
        AdUtil.isSystemDialogOpen = true
        val shareIntent = Intent(Intent.ACTION_SEND)
        shareIntent.setType("text/plain")
        val shareMessage =
            "Check out this amazing app: https://play.google.com/store/apps/details?id=${BuildConfig.APPLICATION_ID}"
        shareIntent.putExtra(Intent.EXTRA_TEXT, shareMessage)
        startActivity(Intent.createChooser(shareIntent, "Share App via"))

    }

    override fun showPrivacyPolicy() {
        AdUtil.isSystemDialogOpen = true
        activity!!.launchUrl(activity!!.getString(R.string.privacy_policy_url))
    }

}
