package messages.text.sms.feature.localization

import android.content.Intent
import android.content.res.Configuration
import android.content.res.Resources
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import dagger.android.AndroidInjection

import messages.text.sms.R
import messages.text.sms.adhelper.NativeAdHelper
import messages.text.sms.adhelper.NativeLayoutType
import messages.text.sms.common.base.MainBaseThemedActivity
import messages.text.sms.extensions.baseConfig
import messages.text.sms.extensions.beVisible
import messages.text.sms.databinding.ActivityLocalizationBinding
import messages.text.sms.feature.main.MainActivity
import java.util.*
import kotlin.collections.ArrayList

class LocalizationActivity :
    MainBaseThemedActivity<ActivityLocalizationBinding>(ActivityLocalizationBinding::inflate) {

    private var selectedLanguage = Locale.getDefault().language
    lateinit var adapter: LanguageSelectionAdapter
    var languageList: ArrayList<LanguageData> = ArrayList()
    var selectedLang = "en"
    var isOpenFromSplash: Boolean = false

    override fun onCreate(savedInstanceState: Bundle?) {
        AndroidInjection.inject(this)
        super.onCreate(savedInstanceState)

        setContentView(binding.root)


        if (intent != null)
            isOpenFromSplash = intent.getBooleanExtra("from_splash", false)

        selectedLanguage = baseConfig.selectedLanguage
        languageList = getLanguageList(baseConfig.systemLocalLanguage)


        selectedLang = baseConfig.selectedLanguage
        var selectPos = languageList.indexOfFirst { it.language_code == selectedLang }

//        val defaultLanguage: String = Locale.getDefault().language
//        preferences.systemLocalLanguage = defaultLanguage
        if (selectPos <= 0) selectPos = 0
        if (selectedLang == "0") selectedLang = baseConfig.systemLocalLanguage

        Log.e("LanguageActivity", "systemLocalLanguage:${baseConfig.systemLocalLanguage}")
        Log.e("LanguageActivity", "selectedLang:$selectedLang")
        Log.e("LanguageActivity", "selectPos:$selectPos")

        val gridLayoutManager = GridLayoutManager(this, 1, RecyclerView.VERTICAL, false)
        binding.rvLanguage.layoutManager = gridLayoutManager

        adapter = LanguageSelectionAdapter(
            this,
            languageList,
            clickListener = {
                selectedLang = it
                Log.e("LanguageActivity", "selectedLangClick:$selectedLang")
            })
        adapter.selectPos = selectPos
        adapter.selectLang = selectedLang
        binding.rvLanguage.adapter = adapter
        binding.rvLanguage.scrollToPosition(selectPos)
        if (selectPos >= 0) {
            binding.rvLanguage.scrollToPosition(selectPos)
        }
        binding.ivBack.setOnClickListener { onBackPressedDispatcher.onBackPressed() }
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                isEnabled = false
                if (isOpenFromSplash) moveNext()
                else onBackPressedDispatcher.onBackPressed()
            }
        })
//        setTitle(R.string.choose_your_language)
        setupViews()
        loadAds()
    }

    fun loadAds() {
        NativeAdHelper(
            this,
            binding.adsView,
            NativeLayoutType.NativeBig,
            baseConfig.nativeAdsId
        ).loadAd()
    }

    private var lastClickTime = 0L
    private fun setupViews() {
        binding.ivBack.beVisible()
        binding.ivDone.beVisible()

        binding.ivDone.setOnClickListener {
            moveNext()
        }

    }

    fun moveNext() {

        val currentTime = System.currentTimeMillis()
        if (currentTime - lastClickTime >= 800) {
            lastClickTime = currentTime

            baseConfig.clickLangDone = true
            baseConfig.selectedLanguage = selectedLang

            if (selectedLang == "0") {
                setLocale(baseConfig.systemLocalLanguage)
            } else {
                setLocale(selectedLang)
            }
            if (isOpenFromSplash) {
                val intent = Intent(this, MainActivity::class.java)
                startActivity(intent)
                finish()
            } else {
//                    setResult(RESULT_OK)
//                    finish()
                val intent = Intent(this, MainActivity::class.java)
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP)
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK)
                startActivity(intent)
            }
        }
    }


    fun getLanguageList(defaultLanguage: String): ArrayList<LanguageData> {
        val languageList: ArrayList<LanguageData> = ArrayList()
//        languageList.add(LanguageData("System Default", "Default", "0", "0"))
        languageList.add(LanguageData("English", "English", "EN", "en"))
        languageList.add(LanguageData("Hindi", "हिंदी", "HI", "hi"))
        languageList.add(LanguageData("Spanish", "Español", "ES", "es"))
        languageList.add(LanguageData("German", "Deutsch", "DE", "de"))
        languageList.add(LanguageData("French", "Français", "FR", "fr"))
        languageList.add(LanguageData("Chinese", "中文", "ZH", "zh"))
        languageList.add(LanguageData("Turkish", "Türkçe", "TR", "tr"))
        languageList.add(LanguageData("Portuguese", "Português", "PT", "pt"))
        languageList.add(LanguageData("Arabic", "العربية", "AR", "ar"))

        return languageList
    }

}