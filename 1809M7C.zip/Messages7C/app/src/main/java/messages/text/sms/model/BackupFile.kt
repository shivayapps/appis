
package messages.text.sms.model

data class BackupFile(
    val date: Long,
    val messages: Int
)
