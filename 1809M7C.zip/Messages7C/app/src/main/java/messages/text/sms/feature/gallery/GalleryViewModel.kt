
package messages.text.sms.feature.gallery

import android.content.Context
import messages.text.sms.contentproviders.MmsPartProvider
import com.uber.autodispose.android.lifecycle.scope
import com.uber.autodispose.autoDispose
import io.reactivex.Flowable
import io.reactivex.rxkotlin.plusAssign
import messages.text.sms.R
import messages.text.sms.common.Navigator
import messages.text.sms.common.base.MessagesViewModel
import messages.text.sms.util.FileNamingConfig
import messages.text.sms.extensions.makeToast
import messages.text.sms.extensions.mapNotNull
import messages.text.sms.interactor.SaveImage
import messages.text.sms.manager.PermissionManager
import messages.text.sms.repository.ConversationRepository
import messages.text.sms.repository.MessageRepository
import javax.inject.Inject
import javax.inject.Named

class GalleryViewModel @Inject constructor(
    conversationRepo: ConversationRepository,
    @Named("partId") private val partId: Long,
    private val context: Context,
    private val messageRepo: MessageRepository,
    private val navigator: Navigator,
    private val saveImage: SaveImage,
    private val permissions: PermissionManager
) : MessagesViewModel<GalleryView, GalleryState>(GalleryState()) {
    companion object {
        const val DEFAULT_SHARE_FILENAME = FileNamingConfig.DEFAULT_GALLERY_SHARE_FILENAME
    }

    init {
        disposables += Flowable.just(partId)
            .mapNotNull(messageRepo::getMessageForPart)
            .mapNotNull { message -> message.threadId }
            .doOnNext { threadId ->
                newState {
                    copy(
                        parts = messageRepo.getPartsForConversation(
                            threadId
                        )
                    )
                }
            }
            .doOnNext { threadId ->
                newState {
                    copy(title = conversationRepo.getConversation(threadId)?.getTitle())
                }
            }
            .subscribe()
    }

    override fun bindView(view: GalleryView) {
        super.bindView(view)

        // When the screen is touched, toggle the visibility of the navigation UI
        view.screenTouched()
            .withLatestFrom(state) { _, state -> state.navigationVisible }
            .map { navigationVisible -> !navigationVisible }
            .autoDispose(view.scope())
            .subscribe { navigationVisible -> newState { copy(navigationVisible = navigationVisible) } }

        // Save image to device
        view.optionsItemSelected()
            .filter { it == R.id.save }
            .filter { permissions.hasStorage().also { if (!it) view.requestStoragePermission() } }
            .withLatestFrom(view.pageChanged()) { _, part -> part.id }
            .autoDispose(view.scope())
            .subscribe { partId -> saveImage.execute(partId) { context.makeToast(R.string.gallery_toast_saved) } }

        // Share image externally
        view.optionsItemSelected()
            .filter { it == R.id.share }
            .withLatestFrom(view.pageChanged()) { _, part -> part }
            .autoDispose(view.scope())
            .subscribe {
                navigator.shareFile(
                    MmsPartProvider.getUriForMmsPartId(it.id, it.getBestFilename()),
                    it.type
                )
            }

        // message part context menu item selected - forward
        view.optionsItemSelected()
            .filter { it == R.id.forward }
            .withLatestFrom(view.pageChanged()) { _, part -> part }
            .autoDispose(view.scope())
            .subscribe { navigator.showCompose("", listOf(it.getUri())) }

        // message part context menu item selected - open externally
        view.optionsItemSelected()
            .filter { it == R.id.openExternally }
            .withLatestFrom(view.pageChanged()) { _, part -> part }
            .autoDispose(view.scope())
            .subscribe {
                navigator.viewFile(
                    MmsPartProvider.getUriForMmsPartId(it.id, it.getBestFilename()),
                    it.type
                )
            }
    }

}
