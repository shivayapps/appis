package messages.text.sms.common.widget

import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Color
import android.util.AttributeSet
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.widget.TextView
import androidx.appcompat.widget.LinearLayoutCompat
import androidx.appcompat.widget.TooltipCompat
import androidx.core.content.ContextCompat
import messages.text.sms.R
import messages.text.sms.extensions.resolveThemeAttribute
import messages.text.sms.extensions.resolveThemeColorStateList
import messages.text.sms.extensions.setVisible
import messages.text.sms.databinding.PreferenceViewBinding
import messages.text.sms.injection.appComponent

class PreferenceView @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null
) : LinearLayoutCompat(context, attrs) {

    private var layout: PreferenceViewBinding

    val titleView: TextView get() = layout.titleView
    val subTitleView: TextView get() = layout.subTitleView
//    val widget: View? get() = layout.widgetFrame.getChildAt(0)
//    val checkbox: MySwitch? get() = widget as? MySwitch
    val checkbox: MySwitch
        get() = layout.checkbox

    companion object {
        private const val WIDGET_NONE = 0
        private const val WIDGET_ARROW = 1
        private const val WIDGET_SWITCH = 2
    }


    var title: String? = null
        set(value) {
            field = value

            if (isInEditMode) {
                findViewById<TextView>(R.id.titleView).text = value
            } else {
                layout.titleView.text = value
            }
        }

    var subtitle: String? = null
        set(value) {
            field = value


            if (isInEditMode) {
                findViewById<TextView>(R.id.subTitleView).run {
                    text = value
                    setVisible(value?.isNotEmpty() == true)
                }
            } else {
                layout.subTitleView.text = value
                layout.subTitleView.setVisible(value?.isNotEmpty() == true)
            }
        }
    var summary: String? = null
        set(value) {
            field = value


            if (isInEditMode) {
                findViewById<TextView>(R.id.summaryView).run {
                    text = value
                    setVisible(value?.isNotEmpty() == true)
                }
            } else {
                layout.summaryView.text = value
                layout.summaryView.setVisible(value?.isNotEmpty() == true)
            }
        }
    var tooltipText: String? = null
        set(value) {
            field = value
            if (isInEditMode) return
            TooltipCompat.setTooltipText(this, value)
        }

    init {
        if (!isInEditMode) {
            appComponent.inject(this)
        }

        layout = PreferenceViewBinding.inflate(LayoutInflater.from(context), this, false)
        addView(layout.root)
        setBackgroundResource(context.resolveThemeAttribute(R.attr.selectableItemBackground))
        orientation = HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL

//        val textSecondary = ContextCompat.getColor(context, R.color.textSecondary)
//        layout.icon.imageTintList = ColorStateList.valueOf(textSecondary)
//            context.resolveThemeColorStateList(android.R.attr.textColorSecondary)

        context.obtainStyledAttributes(attrs, R.styleable.PreferenceView).run {
            title = getString(R.styleable.PreferenceView_title)
            summary = getString(R.styleable.PreferenceView_summary)
            subtitle = getString(R.styleable.PreferenceView_subtitle)
            tooltipText = getString(R.styleable.PreferenceView_tipText)

            // If there's a custom view used for the preference's widget, inflate it
//            getResourceId(R.styleable.PreferenceView_widget, -1).takeIf { it != -1 }?.let { id ->
//                View.inflate(context, id, layout.widgetFrame)
//            }
            when (getInt(R.styleable.PreferenceView_widget, WIDGET_NONE)) {
                WIDGET_NONE -> {
                    layout.widgetFrame.visibility = View.GONE
                }

                WIDGET_ARROW -> {
                    layout.themePreview.visibility = View.VISIBLE
                    layout.checkbox.visibility = View.GONE
                }

                WIDGET_SWITCH -> {
                    layout.themePreview.visibility = View.GONE
                    layout.checkbox.visibility = View.VISIBLE
                }
            }

            // If an icon is being used, set up the icon view
            getResourceId(R.styleable.PreferenceView_icon, -1).takeIf { it != -1 }?.let { id ->
                layout.icon.setVisible(true)
                layout.icon.setImageResource(id)
            }

            recycle()
        }
    }

}
