
package messages.text.sms.feature.conversationinfo

import messages.text.sms.common.base.MyViewContract
import io.reactivex.Observable

interface ConversationInfoView : MyViewContract<ConversationInfoState> {

    fun recipientInfoClicks(): Observable<Long>
    fun recipientCallClicks(): Observable<Long>
    fun recipientLongClicks(): Observable<Long>
    fun nameClicks(): Observable<*>
    fun callClicks(): Observable<*>
    fun nameChanges(): Observable<String>
    fun notificationClicks(): Observable<*>
    fun markUnreadClicks(): Observable<*>
    fun archiveClicks(): Observable<*>
    fun blockClicks(): Observable<*>
    fun deleteClicks(): Observable<*>
    fun confirmDelete(): Observable<*>
    fun mediaClicks(): Observable<Long>

    fun showRenameDialog(name: String)
    fun showBlockingDialog(conversations: List<Long>, block: Boolean)
    fun showArchiveDialog(conversations: List<Long>, archive: Boolean)
    fun showDeleteDialog(conversations: List<Long>)
    fun requestDefaultSms()

}
