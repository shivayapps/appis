
package messages.text.sms.feature.compose.editing

import android.view.LayoutInflater
import android.view.ViewGroup
import messages.text.sms.common.base.MyAdapter
import messages.text.sms.common.base.MyBindingViewHolder
import messages.text.sms.databinding.ContactNumberListItemBinding
import messages.text.sms.model.PhoneNumber

class PhoneNumberAdapter :
    MyAdapter<PhoneNumber, MyBindingViewHolder<ContactNumberListItemBinding>>() {

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): MyBindingViewHolder<ContactNumberListItemBinding> {
        val binding =
            ContactNumberListItemBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return MyBindingViewHolder(binding)
    }

    override fun onBindViewHolder(
        holder: MyBindingViewHolder<ContactNumberListItemBinding>,
        position: Int
    ) {
        val number = getItem(position)

        holder.binding.address.text = number.address
        holder.binding.type.text = number.type
    }

    override fun areItemsTheSame(old: PhoneNumber, new: PhoneNumber): Boolean {
        return old.type == new.type && old.address == new.address
    }

    override fun areContentsTheSame(old: PhoneNumber, new: PhoneNumber): Boolean {
        return old.type == new.type && old.address == new.address
    }

}