package messages.text.sms.worker

import android.content.Context
import androidx.work.Worker
import androidx.work.WorkerParameters
import messages.text.sms.interactor.ReceiveSms
import android.util.Log
import javax.inject.Inject

class ReceiveSmsWorker(appContext: Context, workerParams: WorkerParameters)
    : Worker(appContext, workerParams) {
    companion object {
        const val INPUT_DATA_KEY_MESSAGE_ID = "messageId"
    }

    @Inject lateinit var receiveSms: ReceiveSms

    override fun doWork(): Result {
        Log.d("Timber","started")

        val messageId = inputData.getLong(INPUT_DATA_KEY_MESSAGE_ID, -1)
        if (messageId == -1L) {
            Log.d("Timber","failed. message id was -1")
            return Result.failure(inputData)
        }

        // process the new message
        receiveSms.execute(messageId)

        Log.d("Timber","finished")

        return Result.success()
    }

}
