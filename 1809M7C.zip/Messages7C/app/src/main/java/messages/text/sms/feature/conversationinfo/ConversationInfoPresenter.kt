
package messages.text.sms.feature.conversationinfo

import android.content.Context
import androidx.lifecycle.Lifecycle
import com.uber.autodispose.android.lifecycle.scope
import com.uber.autodispose.autoDispose
import messages.text.sms.R
import messages.text.sms.common.Navigator
import messages.text.sms.common.base.MyPresenter
import messages.text.sms.common.util.ClipboardUtils
import messages.text.sms.extensions.makeToast
import messages.text.sms.extensions.asObservable
import messages.text.sms.extensions.mapNotNull
import messages.text.sms.feature.conversationinfo.ConversationInfoItem.ConversationInfoMedia
import messages.text.sms.feature.conversationinfo.ConversationInfoItem.ConversationInfoRecipient
import messages.text.sms.interactor.DeleteConversations
import messages.text.sms.interactor.MarkArchived
import messages.text.sms.interactor.MarkUnarchived
import messages.text.sms.interactor.MarkUnread
import messages.text.sms.manager.PermissionManager
import messages.text.sms.model.Conversation
import messages.text.sms.repository.ConversationRepository
import messages.text.sms.repository.MessageRepository
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.rxkotlin.Observables
import io.reactivex.rxkotlin.plusAssign
import io.reactivex.rxkotlin.withLatestFrom
import io.reactivex.schedulers.Schedulers
import io.reactivex.subjects.BehaviorSubject
import io.reactivex.subjects.Subject
import javax.inject.Inject
import javax.inject.Named

class ConversationInfoPresenter @Inject constructor(
    @Named("threadId") threadId: Long,
    messageRepo: MessageRepository,
    private val context: Context,
    private val conversationRepo: ConversationRepository,
    private val deleteConversations: DeleteConversations,
    private val markUnread: MarkUnread,
    private val markArchived: MarkArchived,
    private val markUnarchived: MarkUnarchived,
    private val navigator: Navigator,
    private val permissionManager: PermissionManager
) : MyPresenter<ConversationInfoView, ConversationInfoState>(
        ConversationInfoState(threadId = threadId)
) {

    private val conversation: Subject<Conversation> = BehaviorSubject.create()

    init {
        disposables += conversationRepo.getConversationAsync(threadId)
                .asObservable()
                .filter { conversation -> conversation.isLoaded }
                .doOnNext { conversation ->
                    if (!conversation.isValid) {
                        newState { copy(hasError = true) }
                    }
                }
                .filter { conversation -> conversation.isValid }
                .filter { conversation -> conversation.id != 0L }
                .subscribe(conversation::onNext)

        disposables += markArchived
        disposables += markUnarchived
        disposables += deleteConversations

        disposables += Observables
                .combineLatest(
                        conversation,
                        messageRepo.getPartsForConversation(threadId).asObservable()
                ) { conversation, parts ->
                    val data = mutableListOf<ConversationInfoItem>()

                    // If some data was deleted, this isn't the place to handle it
                    if (!conversation.isLoaded || !conversation.isValid || !parts.isLoaded || !parts.isValid) {
                        return@combineLatest
                    }

                    data += conversation.recipients.map(::ConversationInfoRecipient)


                    val settings = ConversationInfoSettings(
                        name = conversation.name,
                        title = conversation.getTitle(),
                        recipients = conversation.recipients,
                        archived = conversation.archived,
                        blocked = conversation.blocked
                    )
//                    data += ConversationInfoItem.ConversationInfoSettings(
//                            name = conversation.name,
//                            recipients = conversation.recipients,
//                            archived = conversation.archived,
//                            blocked = conversation.blocked)
                    data += parts.map(::ConversationInfoMedia)

                    newState { copy(
                        settings = settings,
                        data = data
                    ) }
                }
                .subscribe()
    }



    override fun bindIntents(view: ConversationInfoView) {
        super.bindIntents(view)

        // Add or display the contact
        view.recipientInfoClicks()
            .mapNotNull(conversationRepo::getRecipient)
            .doOnNext { recipient ->
                // Validate the contact actually belongs to this recipient
                val validContact = recipient.contact?.takeIf { contact ->
                    contact.numbers.any { number -> number.address == recipient.address }
                }

                validContact?.lookupKey?.let(navigator::showContact)
                    ?: navigator.addContact(recipient.address)
            }
            .autoDispose(view.scope(Lifecycle.Event.ON_DESTROY))
            .subscribe()

        view.recipientCallClicks()
            .mapNotNull(conversationRepo::getRecipient)
            .doOnNext { recipient ->
               navigator.makePhoneCall(recipient.address)
            }
            .autoDispose(view.scope(Lifecycle.Event.ON_DESTROY)) // ... this should be the default
            .subscribe()

        // Copy phone number
        view.recipientLongClicks()
            .mapNotNull(conversationRepo::getRecipient)
            .map { recipient -> recipient.address }
            .observeOn(AndroidSchedulers.mainThread())
            .autoDispose(view.scope())
            .subscribe { address ->
                ClipboardUtils.copy(context, address)
                context.makeToast(R.string.info_copied_address)
            }

        // Show the conversation title dialog
        view.nameClicks()
            .withLatestFrom(conversation) { _, conversation -> conversation }
            .map { conversation -> conversation.name }
            .autoDispose(view.scope())
            .subscribe(view::showRenameDialog)

        view.callClicks()
            .withLatestFrom(conversation) { _, conversation -> conversation }
            .map { conversation ->
                conversation.recipients.firstOrNull()?.address  // first recipient in convo
            }
            .autoDispose(view.scope())
            .subscribe { it?.let(navigator::makePhoneCall) }

//        view.optionsItemIntent
//            .filter { it == R.id.call }
//            .withLatestFrom(state, conversation)
//            .mapNotNull { (_, state, conversation) ->
//                state.messages?.second?.lastOrNull { !it.isMe() }?.address // most recent non-me msg address
//                    ?: conversation.recipients.firstOrNull()?.address  // first recipient in convo
//            }
//            .autoDispose(view.scope())
//            .subscribe { navigator.makePhoneCall(it) }

        // Set the conversation title
        view.nameChanges()
            .withLatestFrom(conversation) { name, conversation ->
                conversationRepo.setConversationName(conversation.id, name)
                    .subscribeOn(Schedulers.io())
                    .observeOn(AndroidSchedulers.mainThread())
            }
            .flatMapCompletable { it }
            .autoDispose(view.scope())
            .subscribe()

        // Show the notifications settings for the conversation
        view.notificationClicks()
            .withLatestFrom(conversation) { _, conversation -> conversation }
            .autoDispose(view.scope())
            .subscribe { conversation -> navigator.showNotificationSettings(conversation.id) }

        view.markUnreadClicks()
            .withLatestFrom(conversation) { _, conversation -> conversation }
            .autoDispose(view.scope())
            .subscribe { conversation ->
                markUnread.execute(listOf(conversation.id))
                navigator.showMainActivity()
            }

        // Toggle the archived state of the conversation
        view.archiveClicks()
            .withLatestFrom(conversation) { _, conversation -> conversation }
            .autoDispose(view.scope())
            .subscribe { conversation ->
                view.showArchiveDialog(
                    listOf(conversation.id),
                    !conversation.archived
                )
//                when (conversation.archived) {
//                    true -> markUnarchived.execute(listOf(conversation.id))
//                    false -> markArchived.execute(listOf(conversation.id))
//                }
            }

        // Toggle the blocked state of the conversation
        view.blockClicks()
            .withLatestFrom(conversation) { _, conversation -> conversation }
            .autoDispose(view.scope())
            .subscribe { conversation ->
                view.showBlockingDialog(
                    listOf(conversation.id),
                    !conversation.blocked
                )
            }

        // Show the delete confirmation dialog
        view.deleteClicks()
            .filter { permissionManager.isDefaultSms().also { if (!it) view.requestDefaultSms() } }
            .withLatestFrom(conversation) { _, conversation -> conversation }
            .autoDispose(view.scope())
            .subscribe { conversation ->
                view.showDeleteDialog(
                    listOf(conversation.id)
                )
//                view.showDeleteDialog()
            }

        // Delete the conversation
        view.confirmDelete()
            .withLatestFrom(conversation) { _, conversation -> conversation }
            .autoDispose(view.scope())
            .subscribe { conversation -> deleteConversations.execute(listOf(conversation.id)) }

        // Media
        view.mediaClicks()
            .autoDispose(view.scope())
            .subscribe(navigator::showMedia)
    }

}