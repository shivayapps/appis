package messages.text.sms.feature.startup

import android.annotation.SuppressLint
import android.graphics.Color
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.view.WindowManager
import android.view.animation.AlphaAnimation
import androidx.activity.SystemBarStyle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import messages.text.sms.extensions.beGone
import messages.text.sms.extensions.beVisible
import messages.text.sms.extensions.navigationBarHeight
import messages.text.sms.extensions.viewBinding
import messages.text.sms.databinding.ActivityPermissionHintBinding

class PermissionHintActivity : AppCompatActivity() {
    private val binding by viewBinding(ActivityPermissionHintBinding::inflate)

    var permissionType = "all"

    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(navigationBarStyle = SystemBarStyle.auto(Color.WHITE, Color.WHITE))
        setFinishOnTouchOutside(true)
        setContentView(binding.root)
        window.setLayout(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT
        )

        fadeContent(binding.root)
        binding.flMain.setOnClickListener { finish() }
        permissionType = intent.getStringExtra("type") ?: "all"

        if (permissionType == "all") {
            binding.framePermissionBg.beGone()
            binding.framePermissionAll.beVisible()
        } else {
            binding.framePermissionBg.beVisible()
            binding.framePermissionAll.beGone()
        }
    }

    private fun fadeContent(view: View) {
        val fadeIn = AlphaAnimation(0f, 1f).apply {
            duration = 500 // Duration in milliseconds
            fillAfter = true
        }
        view.startAnimation(fadeIn)
    }
}