package messages.text.sms.feature.conversationinfo

import android.content.Context
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.core.view.isVisible
import io.reactivex.subjects.PublishSubject
import io.reactivex.subjects.Subject
import messages.text.sms.common.base.MyAdapter
import messages.text.sms.common.base.MyViewHolder
import messages.text.sms.common.util.Colors
import messages.text.sms.extensions.setVisible
import messages.text.sms.databinding.ConversationMediaListItemBinding
import messages.text.sms.databinding.ConversationRecipientListItemBinding
import messages.text.sms.extensions.isVideo
import messages.text.sms.feature.conversationinfo.ConversationInfoItem.ConversationInfoMedia
import messages.text.sms.feature.conversationinfo.ConversationInfoItem.ConversationInfoRecipient
import messages.text.sms.util.GlideApp
import javax.inject.Inject

class ConversationInfoAdapter @Inject constructor(
    private val context: Context,
    private val colors: Colors
) : MyAdapter<ConversationInfoItem, MyViewHolder>() {

    val recipientInfoClicks: Subject<Long> = PublishSubject.create()
    val recipientCallClicks: Subject<Long> = PublishSubject.create()
    val recipientLongClicks: Subject<Long> = PublishSubject.create()
    val mediaClicks: Subject<Long> = PublishSubject.create()

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {
        val inflater = LayoutInflater.from(parent.context)
        return when (viewType) {
            0 -> {
                val binding = ConversationRecipientListItemBinding.inflate(inflater, parent, false)
                MyViewHolder(binding.root).apply {

                    binding.add.setOnClickListener {
                        val item = getItem(adapterPosition) as? ConversationInfoRecipient
                        item?.value?.id?.run(recipientInfoClicks::onNext)
                    }
                    binding.call.setOnClickListener {
                        val item = getItem(adapterPosition) as? ConversationInfoRecipient
                        item?.value?.id?.run(recipientCallClicks::onNext)
                    }

                    binding.root.setOnLongClickListener {
                        val item = getItem(adapterPosition) as? ConversationInfoRecipient
                        item?.value?.id?.run(recipientLongClicks::onNext)
                        true
                    }
                }
            }

//            1 -> {
//                val binding = ConversationInfoSettingsBinding.inflate(inflater, parent, false)
//                MyViewHolder(binding.root).apply {
////                    binding.groupName.clicks().subscribe(nameClicks)
////                    binding.notifications.clicks().subscribe(notificationClicks)
////                    binding.markUnread.clicks().subscribe(markUnreadClicks)
////                    binding.archive.clicks().subscribe(archiveClicks)
////                    binding.block.clicks().subscribe(blockClicks)
////                    binding.delete.clicks().subscribe(deleteClicks)
//                }
//            }

            1 -> {
                val binding = ConversationMediaListItemBinding.inflate(inflater, parent, false)
                MyViewHolder(binding.root).apply {
                    binding.root.setOnClickListener {
                        val item = getItem(adapterPosition) as? ConversationInfoMedia
                        item?.value?.id?.run(mediaClicks::onNext)
                    }
                }
            }

            else -> throw IllegalStateException()
        }
    }

    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
        when (val item = getItem(position)) {
            is ConversationInfoRecipient -> {
                val binding = ConversationRecipientListItemBinding.bind(holder.containerView)
                val recipient = item.value
                binding.avatar.setRecipient(recipient)
//                binding.name.text = recipient.contact?.name ?: recipient.address
                binding.name.text = recipient.getDisplayName()

                binding.address.text = recipient.address
                binding.address.setVisible(recipient.contact != null)
//                binding.add.setVisible(recipient.contact == null)
            }

//            is ConversationInfoSettings -> {
//                val binding = ConversationInfoSettingsBinding.bind(holder.containerView)
////                binding.groupName.summary = item.name
//                binding.notifications.isEnabled = !item.blocked
//                binding.archive.isEnabled = !item.blocked
//                binding.archiveTitle.text = context.getString(when (item.archived) {
//                    true -> R.string.info_unarchive
//                    false -> R.string.info_archive
//                })
//
//                binding.blockTitle.text = context.getString(when (item.blocked) {
//                    true -> R.string.info_unblock
//                    false -> R.string.info_block
//                })
//            }

            is ConversationInfoMedia -> {
                val binding = ConversationMediaListItemBinding.bind(holder.containerView)
                val part = item.value

                GlideApp.with(context)
                        .load(part.getUri())
                        .fitCenter()
                        .into(binding.thumbnail)

                binding.video.isVisible = part.isVideo()
            }
        }
    }

    override fun getItemViewType(position: Int): Int {
        return when (data[position]) {
            is ConversationInfoRecipient -> 0
//            is ConversationInfoSettings -> 1
            is ConversationInfoMedia -> 1
        }
    }

    override fun areItemsTheSame(old: ConversationInfoItem, new: ConversationInfoItem): Boolean {
        return when {
            old is ConversationInfoRecipient && new is ConversationInfoRecipient -> {
               old.value.id == new.value.id
            }

//            old is ConversationInfoSettings && new is ConversationInfoSettings -> {
//                true
//            }

            old is ConversationInfoMedia && new is ConversationInfoMedia -> {
                old.value.id == new.value.id
            }

            else -> false
        }
    }

}
