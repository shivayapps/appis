
package messages.text.sms.common.base

import androidx.lifecycle.LifecycleOwner

interface MyViewContract<in State> : LifecycleOwner {

    fun render(state: State)

}