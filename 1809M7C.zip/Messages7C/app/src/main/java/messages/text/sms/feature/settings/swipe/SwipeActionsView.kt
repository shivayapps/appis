
package messages.text.sms.feature.settings.swipe

import messages.text.sms.common.base.MyViewContract
import io.reactivex.Observable

interface SwipeActionsView : MyViewContract<SwipeActionsState> {

    enum class Action { LEFT, RIGHT }

    fun actionClicks(): Observable<Action>
    fun actionSelected(): Observable<Int>

    fun showSwipeActions(selected: Int)

}