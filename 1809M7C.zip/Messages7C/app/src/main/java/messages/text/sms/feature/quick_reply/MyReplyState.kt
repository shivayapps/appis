
package messages.text.sms.feature.quick_reply

import io.realm.RealmResults
import messages.text.sms.compat.SubscriptionInfoCompat
import messages.text.sms.model.Conversation
import messages.text.sms.model.Message

data class MyReplyState(
    val hasError: Boolean = false,
    val threadId: Long = 0,
    val title: String = "",
    val expanded: Boolean = false,
    val data: Pair<Conversation, RealmResults<Message>>? = null,
    val remaining: String = "",
    val subscription: SubscriptionInfoCompat? = null,
    val canSend: Boolean = false
)