package messages.text.sms.feature.main

import android.Manifest
import android.annotation.SuppressLint
import android.app.Dialog
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Log
import androidx.activity.OnBackPressedCallback
import androidx.core.app.ActivityCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.isVisible
import androidx.core.widget.doOnTextChanged
import androidx.lifecycle.ViewModelProvider
import com.jakewharton.rxbinding2.view.clicks
import dagger.android.AndroidInjection

import io.reactivex.Observable
import io.reactivex.disposables.CompositeDisposable
import io.reactivex.subjects.PublishSubject
import io.reactivex.subjects.Subject
import messages.text.sms.R
import messages.text.sms.dialog.DeleteDialog
import messages.text.sms.dialog.MessageDialog
import messages.text.sms.common.Navigator
import messages.text.sms.common.base.MainBaseThemedActivity
import messages.text.sms.extensions.dismissKeyboard
import messages.text.sms.extensions.scrapViews
import messages.text.sms.databinding.SearchActivityBinding
import messages.text.sms.feature.blocking.BlockingDialog
import messages.text.sms.extensions.beGone
import messages.text.sms.extensions.beVisible
import messages.text.sms.extensions.showKeyboard
import messages.text.sms.feature.startup.PermissionHintActivity
import javax.inject.Inject

class SearchActivity :
    MainBaseThemedActivity<SearchActivityBinding>(SearchActivityBinding::inflate), SearchView {
    private val TAG = "SearchActivity"

    @Inject
    lateinit var blockingDialog: BlockingDialog

    @Inject
    lateinit var deleteDialog: DeleteDialog

    @Inject
    lateinit var disposables: CompositeDisposable

    @Inject
    lateinit var navigator: Navigator

    @Inject
    lateinit var searchAdapter: SearchAdapter


    @Inject
    lateinit var viewModelFactory: ViewModelProvider.Factory

    var state: MainState? = null

    var dialog: Dialog? = null

    override val onNewIntentIntent: Subject<Intent> = PublishSubject.create()
    override val onSearchIntent: Subject<String> = PublishSubject.create()
    override val activityResumedIntent: Subject<Boolean> = PublishSubject.create()
    override val queryClearedIntent: Observable<*> by lazy { binding.ivCancel.clicks() }
    override val homeIntent: Subject<Unit> = PublishSubject.create()
    override val optionsItemIntent: Subject<Int> = PublishSubject.create()
    override val confirmDeleteIntent: Subject<List<Long>> = PublishSubject.create()
    override val undoArchiveIntent: Subject<Unit> = PublishSubject.create()
    override val snackbarButtonIntent: Subject<Unit> = PublishSubject.create()

    private val viewModel by lazy {
        ViewModelProvider(
            this,
            viewModelFactory
        )[SearchViewModel::class.java]
    }

    @SuppressLint("NewApi")
    override fun onCreate(savedInstanceState: Bundle?) {
        AndroidInjection.inject(this)
        super.onCreate(savedInstanceState)
        setContentView(binding.root)
        viewModel.bindView(this)
        onNewIntentIntent.onNext(intent)

        binding.toolbarSearch.doOnTextChanged { text, start, before, count ->
            text.toString().trim().run(onSearchIntent::onNext)
        }

        ViewCompat.setOnApplyWindowInsetsListener(binding.root) { _, insets ->
            val keyboardVisible = insets.isVisible(WindowInsetsCompat.Type.ime())
            if (!keyboardVisible && binding.toolbarSearch.hasFocus()) {
                binding.toolbarSearch.clearFocus()
                // or editText.isCursorVisible = false
            }
            insets
        }

        binding.ivBack.setOnClickListener { onBackPressedDispatcher.onBackPressed() }
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                dismissKeyboard()
                binding.toolbarSearch.clearFocus()
                if (binding.toolbarSearch.text.isNullOrEmpty()) {
                    finish()
                } else {
                    binding.toolbarSearch.setText("")
                    binding.toolbarSearch.clearFocus()
                }
            }
        })
//        val imm: InputMethodManager =
//            getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
//        imm.showSoftInput(binding.toolbarSearch, InputMethodManager.SHOW_IMPLICIT)

        dismissKeyboard()
        Handler(Looper.myLooper()!!).postDelayed({
            binding.toolbarSearch.requestFocus()
            binding.toolbarSearch.showKeyboard()
        }, 500)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        intent.run(onNewIntentIntent::onNext)
    }


    override fun render(state: MainState) {
        binding.ivCancel.isVisible = state.query.length > 1
        try {
            this.state = state
            if (state.hasError) {
                finish()
                return
            }
            searchAdapter.emptyView =
                binding.empty.takeIf { state.page is Searching }

            when (state.page) {
                is Inbox -> {
                    showBackButton(state.page.selected > 0)
                    title = if (state.page.selected > 0) {
                        state.page.selected.toString() + " selected"
                    } else {
                        "Messages"
                    }
                    binding.empty.beVisible()
                }

                is Searching -> {
                    showBackButton(true)
                    if (binding.recyclerView1.adapter !== searchAdapter) binding.recyclerView1.adapter =
                        searchAdapter
                    searchAdapter.data = state.page.data ?: listOf()

                    if (binding.toolbarSearch.text!!.trim().isNotEmpty()) {
                        binding.recyclerView1.beVisible()
                    } else {
                        binding.recyclerView1.beGone()
                    }
                }

                is Archived -> {}
                else -> {}
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }


    override fun onPause() {
        super.onPause()
        activityResumedIntent.onNext(false)
    }

    override fun onDestroy() {
        super.onDestroy()
        disposables.dispose()
    }

    override fun showBackButton(show: Boolean) {
    }

    override fun requestDefaultSms() {
        navigator.showDefaultSmsDialog(this@SearchActivity)
    }

    override fun requestPermissions() {
        ActivityCompat.requestPermissions(
            this, arrayOf(
                Manifest.permission.READ_SMS,
                Manifest.permission.SEND_SMS,
                Manifest.permission.READ_CONTACTS
            ), 0
        )
    }

    override fun clearSearch() {
        dismissKeyboard()
        binding.toolbarSearch.setText("")
        binding.toolbarSearch.clearFocus()
    }

    override fun clearSelection() {
//        conversationsAdapter.clearSelection()
    }

    override fun themeChanged() {
        binding.recyclerView1.scrapViews()
    }


    override fun showBlockingDialog(
        conversations: List<Long>,
        block: Boolean,
        isTrue: (Boolean) -> Unit
    ) {
        Log.w("messageApp : ", "message showBlockingDialog   11")
        var title: Int = 0
        var btnText: Int = 0
        var msgText: String = ""
        if (block) {
            title = R.string.blocking_block_title
            btnText = R.string.blocking_block_title
            msgText = "Do you want to Block messages?"
        } else {
            title = R.string.blocking_unblock_title
            btnText = R.string.blocking_unblock_title
            msgText = "Do you want to Unblock messages?"
        }

        MessageDialog()
            .show(
                this,
                getString(title),
                msgText,
                getString(btnText),
                positiveActionCallback = {
                    blockingDialog.show(this@SearchActivity, conversations, block)
                },
                negativeActionCallback = { },
                dismissActionCallback = {}
            )

//        CommonDialog(this).show(
//            this,
//            title = getString(title),
//            message = msgText,
//            positive = getString(btnText),
//            getString(R.string.button_cancel),
//            "",
//            onPositive = {
//                blockingDialog.show(this@SearchActivity, conversations, block)
//            })
    }

    override fun showDeleteDialog(conversations: List<Long>) {
//        val count = conversations.size
        deleteDialog.show(this@SearchActivity, conversations)
//        CommonDialog(this).show(
//            this,
//            title = getString(R.string.dialog_delete_title),
//            message = resources.getQuantityString(R.plurals.dialog_delete_message, count, count),
//            positive = getString(R.string.button_delete),
//            getString(R.string.button_cancel),
//            "",
//            onPositive = {
//                confirmDeleteIntent.onNext(
//                    conversations
//                )
//            })
    }

    override fun showArchivedSnackbar() {
    }


//    @SuppressLint("NewApi")
//    override fun onBackPressed() {
//        dismissKeyboard()
//        if (binding.toolbarSearch.text!!.isEmpty()) {
//            finish()
////            overridePendingTransition(android.R.anim.fade_out, android.R.anim.fade_in)
//        } else {
////            conversationsAdapter.clearSelection()
//            binding.toolbarSearch.setText("")
//        }
//    }

    override fun onResume() {
        super.onResume()
        activityResumedIntent.onNext(true)
        //clearSearch()
        Handler(Looper.myLooper()!!).postDelayed({
            binding.toolbarSearch.text.toString().trim().run(onSearchIntent::onNext)
        }, 500)

//        binding.toolbarSearch.doOnTextChanged { text, start, before, count ->
//            text.toString().trim().run(onSearchIntent::onNext)
//        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
    }
}

