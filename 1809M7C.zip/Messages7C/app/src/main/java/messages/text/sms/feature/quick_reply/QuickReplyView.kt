
package messages.text.sms.feature.quick_reply

import io.reactivex.Observable
import messages.text.sms.common.base.MainBaseMsgView

interface QuickReplyView : MainBaseMsgView<MyReplyState> {

    val menuItemIntent: Observable<Int>
    val textChangedIntent: Observable<CharSequence>
    val changeSimIntent: Observable<*>
    val sendIntent: Observable<Unit>

    fun setDraft(draft: String)
    fun finish()

}