
package messages.text.sms.feature.blocking.numbers

import messages.text.sms.model.BlockedNumber
import io.realm.RealmResults

data class BlockedNumbersState(
    val numbers: RealmResults<BlockedNumber>? = null
)
