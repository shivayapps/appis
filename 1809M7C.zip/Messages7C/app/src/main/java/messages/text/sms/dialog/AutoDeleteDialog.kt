package messages.text.sms.dialog

import android.R
import android.app.Activity
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.view.Gravity
import android.view.LayoutInflater
import android.view.Window
import android.view.WindowManager
import androidx.appcompat.app.AlertDialog
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.MainScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import messages.text.sms.databinding.SettingsAutoDeleteDialogBinding
import javax.inject.Inject

class AutoDeleteDialog @Inject constructor(context: Activity) {

    fun show(
        activity: Activity,
        days: Int,
        listener: (Int) -> Unit
    ) = GlobalScope.launch {
        showDialog(activity, days, listener)
    }

    private val binding = SettingsAutoDeleteDialogBinding.inflate(LayoutInflater.from(context))
    private suspend fun showDialog(
        activity: Activity,
        days: Int,
        listener: (Int) -> Unit
    ) = withContext(MainScope().coroutineContext) {

        when (days) {
            0 -> binding.field.text = null
            else -> binding.field.setText(days.toString())
        }

        val dialog = AlertDialog.Builder(activity)
            .setView(binding.root)
            .setCancelable(true)
            .create()

        binding.btnPositive.setOnClickListener {
            listener(binding.field.text.toString().toIntOrNull() ?: 0)
            dialog.dismiss()
        }
        binding.btnNegative.setOnClickListener {
            listener(0)
            dialog.dismiss()
        }
        binding.ivClose.setOnClickListener {
            dialog.dismiss()
        }

        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.window?.apply {
            setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            setGravity(Gravity.CENTER)
            setDimAmount(0.8f)
            attributes?.windowAnimations = R.style.Animation_Dialog
            setLayout(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.WRAP_CONTENT
            )
        }
        dialog.show()

    }


}
//class AutoDeleteDialog(context: Activity, listener: (Int) -> Unit) : AlertDialog(context) {
//
//    private val layout = SettingsAutoDeleteDialogBinding.inflate(LayoutInflater.from(context))
//
//    init {
//        setView(layout.root)
//        setTitle(R.string.settings_auto_delete)
//        setMessage(context.getString(R.string.settings_auto_delete_dialog_message))
//        setButton(DialogInterface.BUTTON_NEUTRAL, context.getString(R.string.button_cancel)) { _, _ -> }
//        setButton(DialogInterface.BUTTON_NEGATIVE, context.getString(R.string.settings_auto_delete_never)) { _, _ -> listener(0) }
//        setButton(DialogInterface.BUTTON_POSITIVE, context.getString(R.string.button_save)) { _, _ ->
//            listener(layout.field.text.toString().toIntOrNull() ?: 0)
//        }
//
//        val buttonColor = context.resolveThemeColor(
//            android.R.attr.textColorPrimary,
//            context.getColorCompat(R.color.textPrimary)
//        )
//        setOnShowListener {
//            listOf(
//                DialogInterface.BUTTON_POSITIVE,
//                DialogInterface.BUTTON_NEGATIVE,
//                DialogInterface.BUTTON_NEUTRAL
//            ).forEach { type ->
//                getButton(type)?.setTextColor(buttonColor)
//            }
//        }
//    }
//
//    fun setExpiry(days: Int): AutoDeleteDialog {
//        when (days) {
//            0 -> layout.field.text = null
//            else -> layout.field.setText(days.toString())
//        }
//        return this
//    }
//
//}
