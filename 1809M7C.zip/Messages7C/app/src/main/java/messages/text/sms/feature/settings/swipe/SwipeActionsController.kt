package messages.text.sms.feature.settings.swipe

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.view.isVisible
import com.jakewharton.rxbinding2.view.clicks
import com.uber.autodispose.android.lifecycle.scope
import messages.text.sms.R
import messages.text.sms.dialog.OptionDialog
import messages.text.sms.common.base.MyController
import messages.text.sms.common.util.Colors
import messages.text.sms.extensions.animateLayoutChanges
import messages.text.sms.injection.appComponent
import io.reactivex.Observable
import io.reactivex.subjects.PublishSubject
import io.reactivex.subjects.Subject
import com.uber.autodispose.autoDispose
import messages.text.sms.databinding.SwipeActionsControllerBinding
import javax.inject.Inject

class SwipeActionsController :
    MyController<SwipeActionsControllerBinding, SwipeActionsView, SwipeActionsState, SwipeActionsPresenter>(),
    SwipeActionsView {

    override fun inflateBinding(
        inflater: LayoutInflater,
        container: ViewGroup
    ): SwipeActionsControllerBinding =
        SwipeActionsControllerBinding.inflate(inflater, container, false)

    @Inject
    override lateinit var presenter: SwipeActionsPresenter
    @Inject
    lateinit var actionsDialog: OptionDialog
    @Inject
    lateinit var colors: Colors

    /**
     * Allows us to subscribe to [actionClicks] more than once
     */
    private val actionClicks: Subject<SwipeActionsView.Action> = PublishSubject.create()

    init {
        appComponent.inject(this)

        actionsDialog.adapter.setData(R.array.settings_swipe_actions)
    }

    override fun onViewCreated() {
//        colors.theme().let { theme ->
//            binding.rightIcon.setBackgroundTint(theme.theme)
//            binding.rightIcon.setTint(theme.textPrimary)
//            binding.leftIcon.setBackgroundTint(theme.theme)
//            binding.leftIcon.setTint(theme.textPrimary)
//        }

        binding.right.postDelayed({ binding.right.animateLayoutChanges = true }, 100)
        binding.left.postDelayed({ binding.left.animateLayoutChanges = true }, 100)

        Observable.merge(
            binding.right.clicks().map { SwipeActionsView.Action.RIGHT },
            binding.left.clicks().map { SwipeActionsView.Action.LEFT })
            .autoDispose(scope())
            .subscribe(actionClicks)
    }

    override fun onAttach(view: View) {
        super.onAttach(view)
        presenter.bindIntents(this)
        setTitle(R.string.settings_swipe_actions)
        //showBackButton(true)
    }

    override fun actionClicks(): Observable<SwipeActionsView.Action> = actionClicks

    override fun actionSelected(): Observable<Int> = actionsDialog.adapter.menuItemClicks

    override fun showSwipeActions(selected: Int) {
        actionsDialog.adapter.selectedItem = selected
        actionsDialog.show(activity!!, R.string.settings_swipe_actions)
//        activity?.let(actionsDialog::show)
    }

    override fun render(state: SwipeActionsState) {
        binding.rightIcon.isVisible = state.rightIcon != 0
        binding.rightIcon.setImageResource(state.rightIcon)
        binding.rightLabel.text = state.rightLabel

        binding.leftIcon.isVisible = state.leftIcon != 0
        binding.leftIcon.setImageResource(state.leftIcon)
        binding.leftLabel.text = state.leftLabel
    }

}
