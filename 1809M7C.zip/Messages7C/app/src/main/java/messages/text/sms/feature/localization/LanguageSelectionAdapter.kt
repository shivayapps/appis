package messages.text.sms.feature.localization

import android.content.Context
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import messages.text.sms.R
import messages.text.sms.databinding.LanguageItemBinding

class LanguageSelectionAdapter(
    private val mContext: Context,
    private val languages: List<LanguageData>,
    val clickListener: (selectLang: String) -> Unit
) : RecyclerView.Adapter<LanguageSelectionAdapter.ViewHolder>() {

    var selectPos = 0
    var selectLang = "en"

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): ViewHolder {

        return ViewHolder(
            LanguageItemBinding.inflate(
                LayoutInflater.from(parent.context),
                parent,
                false
            )
        )
    }

    override fun getItemCount() = languages.size

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.binding.tvLanguage.text = languages[position].language_name
        holder.binding.tvSec.text = languages[position].language_text

        holder.binding.startText.text = languages[position].language_first_latter

        if (selectPos == position) {
            holder.binding.radio.setImageDrawable(
                ContextCompat.getDrawable(
                    mContext,
                    R.drawable.ic_box_selected
                )
            )
//            holder.binding.clLang.background = context.resources.getDrawable(R.drawable.bg_lang_select)
        } else {
            holder.binding.radio.setImageDrawable(
                ContextCompat.getDrawable(
                    mContext,
                    R.drawable.ic_box_unselected
                )
            )
//            holder.binding.clLang.background = context.resources.getDrawable(R.drawable.bg_lang_unselect)
        }

        holder.binding.root.setOnClickListener {
            val p = selectPos
            selectPos = position
            selectLang = languages[position].language_code
            clickListener(selectLang)
            notifyItemChanged(selectPos)
            if (p != -1)
                notifyItemChanged(p)
        }
    }


    class ViewHolder(
        val binding: LanguageItemBinding
    ) : RecyclerView.ViewHolder(binding.root)
}