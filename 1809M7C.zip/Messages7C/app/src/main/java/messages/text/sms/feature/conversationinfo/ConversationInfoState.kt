
package messages.text.sms.feature.conversationinfo

data class ConversationInfoState(
    val threadId: Long = 0,
//    val data: List<ConversationInfoItem> = listOf(),
    val settings: ConversationInfoSettings? = null,
    val data: List<ConversationInfoItem> = listOf(),
    val hasError: Boolean = false
)
