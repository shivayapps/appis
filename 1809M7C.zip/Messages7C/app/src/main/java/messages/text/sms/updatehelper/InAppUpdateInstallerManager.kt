package messages.text.sms.updatehelper

import android.app.Activity
import android.content.Intent
import android.content.IntentSender
import android.util.Log
import com.google.android.play.core.appupdate.AppUpdateManager
import com.google.android.play.core.appupdate.AppUpdateManagerFactory
import com.google.android.play.core.install.InstallState
import com.google.android.play.core.install.InstallStateUpdatedListener
import com.google.android.play.core.install.model.AppUpdateType
import com.google.android.play.core.install.model.InstallStatus
import com.google.android.play.core.install.model.UpdateAvailability
import com.messenger.sms.text.inapp_helper.AppUpdateInstallerListener
import com.messenger.sms.text.inapp_helper.AppUpdateInstallerManager

class InAppUpdateInstallerManager(
    private val activity: Activity,
    private val appUpdateRequestCode: Int = APP_UPDATE_REQUEST_CODE
) : AppUpdateInstallerManager {

    private var listener: AppUpdateInstallerListener? = null

    private val appUpdateManager: AppUpdateManager by lazy { AppUpdateManagerFactory.create(activity) }

    private val appUpdatedListener: InstallStateUpdatedListener by lazy {
        object : InstallStateUpdatedListener {
            override fun onStateUpdate(installState: InstallState) {
                when {
                    installState.installStatus() == InstallStatus.DOWNLOADED -> {
                        Log.e("UpdateListener", "appUpdatedListener.DOWNLOADED")
                        listener?.onDownloadedButNotInstalled()
                    }
                    installState.installStatus() == InstallStatus.INSTALLED -> {
                        Log.e("UpdateListener", "appUpdatedListener.INSTALLED")
                        appUpdateManager.unregisterListener(this)
                    }
                    else -> {
                        Log.e("UpdateListener", "appUpdatedListener.installStatus:${installState.installStatus()}")
                        listener?.onStatus(installState.installStatus())
                    }
                }
            }
        }
    }

    override fun addAppUpdateListener(listener: AppUpdateInstallerListener?) {
        this.listener = listener
    }

//    override fun completeUpdate(): Task<Void> {
//        return appUpdateManager.completeUpdate()
//    }
    override fun completeUpdate() = appUpdateManager.completeUpdate()

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        Log.e("UpdateListener", "onActivityResult.requestCode:$requestCode, resultCode:$resultCode")
        if (requestCode == appUpdateRequestCode) {
            if (resultCode != Activity.RESULT_OK) {
                // App Update failed, please try again on the next app launch.
                listener?.onCancelled()
            }
        }
    }

    override fun startCheckUpdate() {
        Log.e("UpdateListener", "startCheckUpdate")

        // Returns an intent object that you use to check for an update.
        val appUpdateInfoTask = appUpdateManager.appUpdateInfo

        appUpdateInfoTask.addOnFailureListener {
            Log.e("UpdateListener", "startChaddOnFailureListener.onFailure:${it.message}")
            listener?.onFailure(it)
        }

        // Checks that the platform will allow the specified type of update.
        appUpdateInfoTask.addOnSuccessListener { appUpdateInfo ->
            Log.e("UpdateListener", "startCheckUpdate:${appUpdateInfo.updateAvailability()}")
            if (appUpdateInfo.updateAvailability() == UpdateAvailability.UPDATE_AVAILABLE) {
                Log.e("UpdateListener", "startCheckUpdate.UPDATE_AVAILABLE")
                // Request the update.
                try {
                    val installType = when {
                        appUpdateInfo.isUpdateTypeAllowed(AppUpdateType.FLEXIBLE) -> AppUpdateType.FLEXIBLE
                        appUpdateInfo.isUpdateTypeAllowed(AppUpdateType.IMMEDIATE) -> AppUpdateType.IMMEDIATE
                        else -> null
                    }

                    if (installType == AppUpdateType.FLEXIBLE) {
                        appUpdateManager.registerListener(appUpdatedListener)
                    }

                    installType?.let {
                        appUpdateManager.startUpdateFlowForResult(
                            appUpdateInfo,
                            installType,
                            activity,
                            appUpdateRequestCode
                        )
                    }
                } catch (e: IntentSender.SendIntentException) {
                    Log.e("UpdateListener", "SendIntentException:${e.message}")
                    listener?.onFailure(e)
                } catch (e: Exception) {
                    Log.e("UpdateListener", "Exception:${e.message}")
                    listener?.onFailure(e)
                }
            } else {
                Log.e("UpdateListener", "startCheckUpdate.onNotUpdate")
                listener?.onNotUpdate()
            }
        }
    }

    override fun resumeCheckUpdate(@AppUpdateType updateType: Int) {
        appUpdateManager
            .appUpdateInfo
            .addOnSuccessListener { appUpdateInfo ->

                // If the update is downloaded but not installed, notify the user to complete the update.
                if (appUpdateInfo.installStatus() == InstallStatus.DOWNLOADED) {
                    Log.e("UpdateListener", "resumeCheckUpdate.DOWNLOADED")
                    listener?.onDownloadedButNotInstalled()
                }

                // Check if Immediate update is required
                try {

                    if (appUpdateInfo.updateAvailability() == UpdateAvailability.DEVELOPER_TRIGGERED_UPDATE_IN_PROGRESS) {
                        Log.e("UpdateListener", "resumeCheckUpdate.DEVELOPER_TRIGGERED_UPDATE_IN_PROGRESS")
                        // If an in-app update is already running, resume the update.
                        appUpdateManager.startUpdateFlowForResult(
                            appUpdateInfo,
                            updateType,
                            activity,
                            appUpdateRequestCode
                        )
                    }

                } catch (e: IntentSender.SendIntentException) {
                    Log.e("UpdateListener", "resumeCheckUpdate.SendIntentException:${e.message}")
                    listener?.onFailure(e)
                }

            }
    }



    companion object {
        const val APP_UPDATE_REQUEST_CODE = 1991
    }
}