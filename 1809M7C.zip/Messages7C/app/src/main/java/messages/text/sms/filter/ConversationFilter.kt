
package messages.text.sms.filter

import messages.text.sms.extensions.fuzzyMatch
import messages.text.sms.extensions.removeAccents
import messages.text.sms.model.Conversation
import javax.inject.Inject

class ConversationFilter @Inject constructor(private val recipientFilter: RecipientFilter) :
    Filter<Conversation>() {

    override fun filter(item: Conversation, query: CharSequence): Boolean {
        val normalizedName = item.name.removeAccents()
        if (normalizedName.contains(query, ignoreCase = true) || normalizedName.fuzzyMatch(query)) {
            return true
        }
        val normalizedSnippet = item.snippet?.removeAccents().orEmpty()
        if (normalizedSnippet.isNotEmpty() &&
            (normalizedSnippet.contains(query, ignoreCase = true) || normalizedSnippet.fuzzyMatch(
                query
            ))
        ) {
            return true
        }
        return item.recipients.any { recipient -> recipientFilter.filter(recipient, query) }
    }
}
