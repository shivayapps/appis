package messages.text.sms.feature.secret

import android.Manifest
import android.animation.ObjectAnimator
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.util.Log
import android.view.View
import android.view.ViewStub
import android.widget.ProgressBar
import androidx.activity.OnBackPressedCallback
import androidx.core.app.ActivityCompat
import androidx.core.view.isVisible
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.snackbar.Snackbar
import com.jakewharton.rxbinding2.view.clicks
import com.uber.autodispose.android.lifecycle.scope
import com.uber.autodispose.autoDispose
import dagger.android.AndroidInjection
import io.reactivex.Observable
import io.reactivex.disposables.CompositeDisposable
import io.reactivex.subjects.PublishSubject
import io.reactivex.subjects.Subject
import messages.text.sms.R
import messages.text.sms.dialog.DeleteDialog
import messages.text.sms.common.Navigator
import messages.text.sms.common.PopupWindowHelper
import messages.text.sms.common.base.MainBaseThemedActivity
import messages.text.sms.extensions.autoScrollToStart
import messages.text.sms.extensions.beGone
import messages.text.sms.extensions.beVisibleIf
import messages.text.sms.extensions.dismissKeyboard
import messages.text.sms.extensions.scrapViews
import messages.text.sms.extensions.setVisible
import messages.text.sms.common.widget.TextInputDialog
import messages.text.sms.databinding.ActivityPrivateConversationsBinding
import messages.text.sms.databinding.MainPermissionHintBinding
import messages.text.sms.databinding.MainSyncingBinding
import messages.text.sms.databinding.MenuHomeBinding
import messages.text.sms.feature.blocking.BlockingDialog
import messages.text.sms.feature.conversations.ConversationItemTouchCallback
import messages.text.sms.feature.conversations.ConversationsAdapter
import messages.text.sms.feature.main.Archived
import messages.text.sms.feature.main.DrawerBadgesExperiment
import messages.text.sms.feature.main.Inbox
import messages.text.sms.feature.main.MainState
import messages.text.sms.feature.main.MainView
import messages.text.sms.feature.main.MainViewModel
import messages.text.sms.feature.main.MessageCategory
import messages.text.sms.feature.main.NavItem
import messages.text.sms.feature.main.SearchActivity
import messages.text.sms.repository.SyncRepository
import javax.inject.Inject
import kotlin.collections.plusAssign

class PrivateConversationsActivity :
    MainBaseThemedActivity<ActivityPrivateConversationsBinding>(ActivityPrivateConversationsBinding::inflate),
    MainView {

    @Inject
    lateinit var blockingDialog: BlockingDialog

    @Inject
    lateinit var deleteDialog: DeleteDialog

    @Inject
    lateinit var disposables: CompositeDisposable

    @Inject
    lateinit var navigator: Navigator

    @Inject
    lateinit var conversationsAdapter: ConversationsAdapter

    @Inject
    lateinit var drawerBadgesExperiment: DrawerBadgesExperiment

//    @Inject
//    lateinit var searchAdapter: SearchAdapter

    @Inject
    lateinit var itemTouchCallback: ConversationItemTouchCallback

    @Inject
    lateinit var viewModelFactory: ViewModelProvider.Factory

    override val onNewIntentIntent: Subject<Intent> = PublishSubject.create()
    override val activityResumedIntent: Subject<Boolean> = PublishSubject.create()

    override val composeIntent: Observable<Unit> = Observable.never()
    override val filterSelectedIntent: Observable<MessageCategory> = Observable.never()

    override val homeIntent: Subject<Unit> = PublishSubject.create()

    private val menuClickSubject: Subject<NavItem> = PublishSubject.create()
    override val navigationIntent: Observable<NavItem> by lazy {
        Observable.merge(listOf(menuClickSubject))
    }

    override val optionsItemIntent: Subject<Int> = PublishSubject.create()

    //    override val plusBannerIntent by lazy { plusBanner.clicks() }
//    override val dismissRatingIntent by lazy { binding.messagesText.clicks() }
//    override val rateIntent by lazy { binding.messagesText.clicks() }
    override val conversationsSelectedIntent by lazy { conversationsAdapter.selectionChanges }
    override val confirmDeleteIntent: Subject<List<Long>> = PublishSubject.create()
    override val renameConversationIntent: Subject<String> = PublishSubject.create()
    override val swipeConversationIntent: Observable<Pair<Long, Int>> = Observable.never()

    override val undoArchiveIntent: Subject<Unit> = PublishSubject.create()
    override val snackbarButtonIntent: Subject<Unit> = PublishSubject.create()

    private val viewModel by lazy {
        ViewModelProvider(this, viewModelFactory)[MainViewModel::class.java]
    }

    private lateinit var snackbarBinding: MainPermissionHintBinding
    private lateinit var syncingBinding: MainSyncingBinding

    private lateinit var menuBinding: MenuHomeBinding
    private lateinit var popupWindow: PopupWindowHelper

    private var hasSelection = false

    override fun onCreate(savedInstanceState: Bundle?) {
        AndroidInjection.inject(this)
        super.onCreate(savedInstanceState)
        viewModel.bindView(this)
        onNewIntentIntent.onNext(intent)

        snackbarBinding = MainPermissionHintBinding.bind(binding.snackbar.inflate()).also {
            it.snackbarButton.clicks()
                .autoDispose(scope(Lifecycle.Event.ON_DESTROY))
                .subscribe(snackbarButtonIntent)
        }

        syncingBinding = MainSyncingBinding.bind(binding.syncing.inflate())
//            .also {
//                it.syncingProgress.progressTintList =
//                    ColorStateList.valueOf(theme.blockingFirst().theme)
//                it.syncingProgress.indeterminateTintList =
//                    ColorStateList.valueOf(theme.blockingFirst().theme)
//            }

        binding.ivClose.setOnClickListener {
            clearSelection()
        }

//        binding.btnChangeDefaultSms.setOnClickListener {
//            requestDefaultSms()
//        }

        menuBinding = MenuHomeBinding.inflate(layoutInflater)
        popupWindow = PopupWindowHelper(menuBinding.root)

        menuBinding.selectAll.setOnClickListener {
            optionsItemIntent.onNext(menuBinding.selectAll.id).let { true }; popupWindow.dismiss()
        }
        menuBinding.unarchive.setOnClickListener {
            optionsItemIntent.onNext(menuBinding.unarchive.id).let { true }; popupWindow.dismiss()
        }
        menuBinding.add.setOnClickListener {
            optionsItemIntent.onNext(menuBinding.add.id).let { true }; popupWindow.dismiss()
        }
        menuBinding.read.setOnClickListener {
            optionsItemIntent.onNext(menuBinding.read.id).let { true }; popupWindow.dismiss()
        }
        menuBinding.unread.setOnClickListener {
            optionsItemIntent.onNext(menuBinding.unread.id).let { true }; popupWindow.dismiss()
        }
//        menuBinding.lock.setOnClickListener { optionsItemIntent.onNext(menuBinding.lock.id).let { true }; popupWindow.dismiss() }
        menuBinding.unlock.setOnClickListener {
            optionsItemIntent.onNext(menuBinding.unlock.id).let { true }; popupWindow.dismiss()
        }
        menuBinding.block.setOnClickListener {
            optionsItemIntent.onNext(menuBinding.block.id).let { true }; popupWindow.dismiss()
        }
        menuBinding.rename.setOnClickListener {
            optionsItemIntent.onNext(menuBinding.rename.id).let { true }; popupWindow.dismiss()
        }

        menuBinding.schedule.setOnClickListener { menuClickSubject.onNext(NavItem.SCHEDULED); popupWindow.dismiss() }
        menuBinding.blocking.setOnClickListener { menuClickSubject.onNext(NavItem.BLOCKING); popupWindow.dismiss() }
        menuBinding.privateChat.setOnClickListener { menuClickSubject.onNext(NavItem.PRIVATE); popupWindow.dismiss() }
        menuBinding.setting.setOnClickListener { menuClickSubject.onNext(NavItem.SETTINGS); popupWindow.dismiss() }

        title = ""
        binding.ivBack.setOnClickListener {
            onBackPressedDispatcher.onBackPressed()
        }
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (!menuClickSubject.hasObservers()) {
                    isEnabled = false
                    onBackPressedDispatcher.onBackPressed()
                    isEnabled = true
                } else {
                    if (hasSelection) conversationsAdapter.clearSelection()
                    else finish()
                }
            }
        })

        binding.menuIcon.clicks()
            .autoDispose(scope())
            .subscribe {
                showDrawerMenu(binding.menuIcon)
            }
        itemTouchCallback.adapter = conversationsAdapter
        conversationsAdapter.autoScrollToStart(binding.recyclerView)

        binding.recyclerView.addOnScrollListener(object : RecyclerView.OnScrollListener() {
            override fun onScrolled(recyclerView: RecyclerView, dx: Int, dy: Int) {
                super.onScrolled(recyclerView, dx, dy)

//                if (dy > 0 && binding.cVTopBar2.translationY == 0f) {
//                    // Hide
//                    val translationY =
//                        -binding.cVTopBar2.height.toFloat() - 8f * resources.displayMetrics.density
//                    binding.cVTopBar2.animate().translationY(translationY).setDuration(200).start()
//                    binding.menuIcon.animate().translationY(translationY).setDuration(200).start()
//
//                    binding.recyclerView.animate().translationY(translationY).setDuration(200)
//                        .start()
//                } else if (dy < 0 && binding.cVTopBar2.translationY != 0f) {
//                    // Show
//                    binding.cVTopBar2.animate().translationY(0f).setDuration(200).start()
//                    binding.menuIcon.animate().translationY(0f).setDuration(200).start()
//                    binding.recyclerView.animate().translationY(0f).setDuration(200).start()
//                }
            }
        })


        theme
            .autoDispose(scope())
            .subscribe { theme ->
                // Set the color for the drawer icons
//                val states = arrayOf(
//                    intArrayOf(android.R.attr.state_activated),
//                    intArrayOf(-android.R.attr.state_activated)
//                )
//                ColorStateList(
//                    states, intArrayOf(
//                        theme.theme,
//                        resolveThemeColor(android.R.attr.textColorSecondary)
//                    )
//                )
//                    .let { tintList ->
//                        binding.drawer.inboxIcon.imageTintList = tintList
//                        binding.drawer.archivedIcon.imageTintList = tintList
//                    }

                // Miscellaneous views
//                listOf(binding.drawer.plusBadge1, binding.drawer.plusBadge2).forEach { badge ->
//                    badge.setBackgroundTint(theme.theme)
//                    badge.setTextColor(theme.textPrimary)
//                }
                (binding.syncing as? ViewStub)?.findViewById<ProgressBar>(R.id.syncingProgress)
//                    ?.let {
//                        it.progressTintList = ColorStateList.valueOf(theme.theme)
//                        it.indeterminateTintList = ColorStateList.valueOf(theme.theme)
//                    }
//                binding.drawer.plusIcon.setTint(theme.theme)
//                binding.drawer.rateIcon.setTint(theme.theme)

//                val primaryTextColor = resolveThemeColor(android.R.attr.textColorPrimary)
//                val secondaryTextColor = resolveThemeColor(android.R.attr.textColorSecondary)
//                binding.searchIcon.setTint(primaryTextColor)
//                binding.clearSearch.setTint(primaryTextColor)
//                binding.toolbarSearch.setTextColor(primaryTextColor)
//                binding.toolbarSearch.setHintTextColor(secondaryTextColor)

//                binding.messagesText.setTextColor(primaryTextColor)
//                binding.menuIcon.setTint(primaryTextColor)

            }

        viewModel.newState {
            val conv = conversationRepo.getPrivateConversations()
            copy(page = Archived(data = conv))
        }
    }

    override fun onNewIntent(intent: Intent) =
        intent.let {
            super.onNewIntent(intent)
            it.run(onNewIntentIntent::onNext)
        } ?: Unit

    override fun render(state: MainState) {
        if (state.hasError) {
            finish()
            return
        }

//        if (!state.defaultSms) {
//            binding.notDefaultSmsView.setVisible(true)
//            binding.recyclerView.setVisible(false)
//            binding.empty.setVisible(false)
//            return
//        } else {
//            binding.notDefaultSmsView.setVisible(false)
//        }

        val addContact = when (state.page) {
            is Inbox -> state.page.addContact
            is Archived -> state.page.addContact
            else -> false
        }

        val markPinned = when (state.page) {
            is Inbox -> state.page.markPinned
            is Archived -> state.page.markPinned
            else -> true
        }

        val markRead = when (state.page) {
            is Inbox -> state.page.markRead
            is Archived -> state.page.markRead
            else -> true
        }

        val selectedConversations = when (state.page) {
            is Inbox -> state.page.selected
            is Archived -> state.page.selected
            else -> 0
        }

        if (selectedConversations == conversationsAdapter.itemCount) {
            menuBinding.selectAll.title = getString(R.string.main_menu_remove_selection)
        } else {
            menuBinding.selectAll.title = getString(R.string.main_menu_select_all)
        }

        hasSelection = selectedConversations > 0
//        binding.toolbar.setVisible(hasSelection)
//        binding.cVTopBar2.setVisible(!hasSelection)

        binding.groupToolbarSelection.setVisible(hasSelection)
        binding.groupToolbarHeader.setVisible(!hasSelection)

//        binding.menuIcon.setVisible(!hasSelection)

//        binding.toolbarSearch.setVisible(
//            (state.page is Inbox && state.page.selected == 0) ||
//                    (state.page is Archived && state.page.selected == 0) ||
//                    state.page is Searching
//        )
//        binding.toolbarTitle.setVisible(true)

//        binding.toolbar.menu.apply {
//            findItem(R.id.select_all)?.isVisible =
//                (conversationsAdapter.itemCount > 1) && selectedConversations != 0
//            findItem(R.id.archive)?.isVisible = false
//            findItem(R.id.unarchive)?.isVisible = false
//            findItem(R.id.delete)?.isVisible = selectedConversations != 0
//            findItem(R.id.add)?.isVisible = addContact && selectedConversations != 0
//            findItem(R.id.pin)?.isVisible = markPinned && selectedConversations != 0
//            findItem(R.id.unpin)?.isVisible = !markPinned && selectedConversations != 0
//            findItem(R.id.read)?.isVisible = (markRead && selectedConversations != 0) ||
//                    selectedConversations > 1
//            findItem(R.id.unread)?.isVisible = (!markRead && selectedConversations != 0) ||
//                    selectedConversations > 1
//            findItem(R.id.lock)?.isVisible = false
//            findItem(R.id.unlock)?.isVisible = selectedConversations != 0
//            findItem(R.id.block)?.isVisible = selectedConversations != 0
//            findItem(R.id.rename)?.isVisible = selectedConversations == 1
//        }

        menuBinding.selectionMenuView.beVisibleIf(hasSelection)
//        menuBinding.menuView.beVisibleIf(!hasSelection)
        menuBinding.menuView.beGone()

        binding.pin.beVisibleIf(markPinned && selectedConversations != 0)
        binding.unpin.beVisibleIf(!markPinned && selectedConversations != 0)
        binding.delete.beVisibleIf(selectedConversations != 0)
        binding.archive.beVisibleIf(state.page is Inbox && selectedConversations != 0)

        menuBinding.selectAll.beVisibleIf((conversationsAdapter.itemCount > 1) && selectedConversations != 0)
        menuBinding.unarchive.beGone()
        menuBinding.add.beGone()
        menuBinding.read.beVisibleIf((markRead && selectedConversations != 0) || selectedConversations > 1)
        menuBinding.unread.beVisibleIf((!markRead && selectedConversations != 0) || selectedConversations > 1)
        menuBinding.lock.beGone()
        menuBinding.unlock.beVisibleIf(selectedConversations != 0)
        menuBinding.block.beVisibleIf(selectedConversations != 0)
        menuBinding.rename.beVisibleIf(selectedConversations == 1)

        binding.pin.setOnClickListener { optionsItemIntent.onNext(binding.pin.id).let { true } }
        binding.unpin.setOnClickListener { optionsItemIntent.onNext(binding.unpin.id).let { true } }
        binding.delete.setOnClickListener {
            optionsItemIntent.onNext(binding.delete.id).let { true }
        }
        binding.archive.setOnClickListener {
            optionsItemIntent.onNext(binding.archive.id).let { true }
        }

        conversationsAdapter.emptyView = binding.empty
//            .takeIf {
//            state.page is Inbox || state.page is Archived
//        }
//        searchAdapter.emptyView = binding.empty.takeIf { state.page is Searching }
        0
        binding.ivEmpty.setImageResource(R.drawable.ic_lock)
        binding.emptyTitle.setText(R.string.no_private_chats)
        binding.emptyText.setText(R.string.private_empty_text)

        when (state.page) {
            is Inbox -> {
                Log.e("PageState", "Inbox")
                showBackButton(state.page.selected > 0)
                binding.toolbarTitle.text = when {
                    state.page.selected > 0 -> getString(
                        messages.text.sms.R.string.main_title_selected,
                        state.page.selected
                    )

                    else -> getString(messages.text.sms.R.string.app_name)
                }
                if (binding.recyclerView.adapter !== conversationsAdapter)
                    binding.recyclerView.adapter = conversationsAdapter
                conversationsAdapter.updateData(state.page.data)
//                itemTouchHelper.attachToRecyclerView(binding.recyclerView)
                binding.emptyText.setText(messages.text.sms.R.string.inbox_empty_text)
            }

//            is Searching -> {
//                Log.e("PageState","Searching")
//                showBackButton(true)
//                binding.toolbarTitle.text = getString(messages.text.sms.R.string.title_conversations)
//                if (binding.recyclerView.adapter !== searchAdapter) binding.recyclerView.adapter =
//                    searchAdapter
//                searchAdapter.data = state.page.data ?: listOf()
////                itemTouchHelper.attachToRecyclerView(null)
//                binding.emptyText.setText(messages.text.sms.R.string.inbox_search_empty_text)
//            }

            is Archived -> {
                Log.e("PageState", "Archived")
                showBackButton(state.page.selected > 0)
                binding.toolbarTitle.text = when {
                    state.page.selected > 0 -> getString(
                        messages.text.sms.R.string.main_title_selected,
                        state.page.selected
                    )

                    else -> getString(messages.text.sms.R.string.title_archived)
                }
                if (binding.recyclerView.adapter !== conversationsAdapter)
                    binding.recyclerView.adapter = conversationsAdapter
                conversationsAdapter.updateData(state.page.data)
//                itemTouchHelper.attachToRecyclerView(null)
                binding.emptyText.setText(messages.text.sms.R.string.private_empty_text)
            }

            else -> {
                binding.toolbarTitle.text = getString(messages.text.sms.R.string.app_name)
            }
        }

        binding.emptyTitle.setText(R.string.no_private_chats)
        binding.emptyText.setText(R.string.private_empty_text)
        when (state.syncing) {
            is SyncRepository.SyncProgress.Idle -> {
                binding.syncing.isVisible = false
                binding.snackbar.isVisible = (!state.defaultSms ||
                        !state.smsPermission ||
                        !state.contactPermission ||
                        !state.notificationPermission)
            }

            is SyncRepository.SyncProgress.Running -> {
                binding.syncing.isVisible = true
                findViewById<ProgressBar>(messages.text.sms.R.id.syncingProgress)?.let { progress ->
                    progress.max = state.syncing.max
                    ObjectAnimator.ofInt(
                        progress,
                        "progress",
                        progress.progress,
                        state.syncing.progress
                    ).start()
                    progress.isIndeterminate = state.syncing.indeterminate
                }
                binding.snackbar.isVisible = false
            }
        }

        when {
            !state.defaultSms -> {
                snackbarBinding.snackbarTitle.setText(messages.text.sms.R.string.main_default_sms_title)
                snackbarBinding.snackbarMessage.setText(messages.text.sms.R.string.main_default_sms_message)
                snackbarBinding.snackbarButton.setText(messages.text.sms.R.string.main_default_sms_change)
            }

            !state.smsPermission -> {
                snackbarBinding.snackbarTitle.setText(messages.text.sms.R.string.main_permission_required)
                snackbarBinding.snackbarMessage.setText(messages.text.sms.R.string.main_permission_sms)
                snackbarBinding.snackbarButton.setText(messages.text.sms.R.string.main_permission_allow)
            }

            !state.contactPermission -> {
                snackbarBinding.snackbarTitle.setText(messages.text.sms.R.string.main_permission_required)
                snackbarBinding.snackbarMessage.setText(messages.text.sms.R.string.main_permission_contacts)
                snackbarBinding.snackbarButton.setText(messages.text.sms.R.string.main_permission_allow)
            }

            !state.notificationPermission -> {
                snackbarBinding.snackbarTitle.setText(messages.text.sms.R.string.main_permission_required)
                snackbarBinding.snackbarMessage.setText(messages.text.sms.R.string.main_permission_notifications)
                snackbarBinding.snackbarButton.setText(messages.text.sms.R.string.main_permission_allow)
            }
        }
    }

    override fun onResume() {
        super.onResume().also { activityResumedIntent.onNext(true) }

        viewModel.newState {
            val conv = conversationRepo.getPrivateConversations()
            copy(page = Archived(data = conv))
        }
    }


    override fun onPause() =
        super.onPause().also { activityResumedIntent.onNext(false) }

    override fun onDestroy() =
        super.onDestroy().also { disposables.dispose() }

    override fun showBackButton(show: Boolean) {
        if (show) binding.ivClose.visibility = View.VISIBLE
        else binding.ivClose.visibility = View.GONE
    }
//    =toggle.let {
//            it.onDrawerSlide(binding.drawer.root, if (show) 1f else 0f)
//            it.drawerArrowDrawable.color = when (show) {
//                true -> resolveThemeColor(android.R.attr.textColorSecondary)
//                false -> resolveThemeColor(android.R.attr.textColorPrimary)
//            }
//        }

    override fun requestDefaultSms() =
        navigator.showDefaultSmsDialog(this)

    override fun restartActivity() {
        finish()
        startActivity(intent)
    }

    override fun requestPermissions() {
        val permissions = mutableListOf(
            Manifest.permission.READ_SMS,
            Manifest.permission.SEND_SMS,
            Manifest.permission.READ_CONTACTS
        )

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU)
            permissions += Manifest.permission.POST_NOTIFICATIONS

        ActivityCompat.requestPermissions(this, permissions.toTypedArray(), 0)
    }

    override fun clearSearch() {
        dismissKeyboard()
//        binding.toolbarSearch.text = null
//        binding.clearSearch.isVisible = false
    }

    override fun clearSelection() = conversationsAdapter.clearSelection()

    override fun toggleSelectAll() = conversationsAdapter.toggleSelectAll()

    override fun themeChanged() = binding.recyclerView.scrapViews()

    override fun showBlockingDialog(conversations: List<Long>, block: Boolean) {
        blockingDialog.show(this, conversations, block)
    }

    override fun showDeleteDialog(conversations: List<Long>) {
        deleteDialog.show(this, conversations)
//        val dialog = AlertDialog.Builder(this, messages.text.sms.R.style.AppThemeDialog)
//            .setTitle(messages.text.sms.R.string.dialog_delete_title)
//            .setMessage(
//                resources.getQuantityString(
//                    messages.text.sms.R.plurals.dialog_delete_message,
//                    conversations.size,
//                    conversations.size
//                )
//            )
//            .setPositiveButton(messages.text.sms.R.string.button_delete) { _, _ ->
//                confirmDeleteIntent.onNext(
//                    conversations
//                )
//            }
//            .setNegativeButton(messages.text.sms.R.string.button_cancel, null)
//            .create()
//
//        dialog.show()

//        theme.take(1)
//            .autoDispose(scope())
//            .subscribe { theme ->
//                dialog.getButton(AlertDialog.BUTTON_POSITIVE)
//                    ?.setTextColor(theme.theme)
//                dialog.getButton(AlertDialog.BUTTON_NEGATIVE)
//                    ?.setTextColor(theme.theme)
//            }
    }

    override fun showRenameDialog(conversationName: String) {
        TextInputDialog(this)
            .setText(conversationName)
            .show(
                this,
                getString(messages.text.sms.R.string.info_name),
                renameConversationIntent::onNext
            )
    }


    override fun showArchivedSnackbar(countConversationsArchived: Int, isArchiving: Boolean) =
        Snackbar.make(
            binding.mainView,
            if (isArchiving) {
                resources.getQuantityString(
                    messages.text.sms.R.plurals.toast_archived,
                    countConversationsArchived,
                    countConversationsArchived
                )
            } else {
                resources.getQuantityString(
                    messages.text.sms.R.plurals.toast_unarchived,
                    countConversationsArchived,
                    countConversationsArchived
                )
            },
            if (countConversationsArchived < 10) Snackbar.LENGTH_LONG
            else Snackbar.LENGTH_INDEFINITE
        ).let {
            it.setAction(messages.text.sms.R.string.button_undo) { undoArchiveIntent.onNext(Unit) }
            it.setActionTextColor(colors.theme().theme)
            it.show()
        }

//    override fun onCreateOptionsMenu(menu: Menu?) =
//        menu?.let {
//            menuInflater.inflate(messages.text.sms.R.menu.main, it)
//            super.onCreateOptionsMenu(it)
//        } ?: false
//
//    override fun onOptionsItemSelected(item: MenuItem) =
//        optionsItemIntent.onNext(item.itemId).let { true }

//    override fun onBackPressed() = menuClickSubject.onNext(NavItem.BACK)

    override fun drawerToggled(opened: Boolean) {
        if (opened) {
            dismissKeyboard()
//            if (!binding.drawer.inbox.isInTouchMode)
//                binding.drawer.inbox.requestFocus()
        }
        //else
//            binding.toolbarSearch.requestFocus()
    }

    private fun openSearch() {
        val intent = Intent(this, SearchActivity::class.java)
        startActivity(intent)
    }

    private fun showDrawerMenu(anchorView: View) {
        popupWindow.showFromTopRight(anchorView)

    }

}