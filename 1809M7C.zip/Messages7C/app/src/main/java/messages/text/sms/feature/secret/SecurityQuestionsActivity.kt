package messages.text.sms.feature.secret

import android.app.Activity
import android.os.Bundle
import android.util.Log
import androidx.activity.addCallback
import dagger.android.AndroidInjection
import messages.text.sms.R
import messages.text.sms.common.base.MainBaseThemedActivity
import messages.text.sms.databinding.SecurityQuestionsActivityBinding
import messages.text.sms.extensions.baseConfig
import messages.text.sms.extensions.makeToast

class SecurityQuestionsActivity :
    MainBaseThemedActivity<SecurityQuestionsActivityBinding>(SecurityQuestionsActivityBinding::inflate) {

    var activityResult = Activity.RESULT_CANCELED
    var isForget: Boolean = false

    override fun onCreate(savedInstanceState: Bundle?) {
        AndroidInjection.inject(this)
        super.onCreate(savedInstanceState)
//        binding.ivBack.setOnClickListener { onBackPressed() }
        if (intent != null)
            isForget = intent.getBooleanExtra("is_forget", false)

        if (isForget) {
            //binding.toolbarTitle.text=""
        }

        binding.ivBack.setOnClickListener {
            onBackPressedDispatcher.onBackPressed()
        }
        onBackPressedDispatcher.addCallback(this) {
            isEnabled = false
            setResult(activityResult)
            onBackPressedDispatcher.onBackPressed()
        }
        initListener()
    }

    private fun initListener() {

        binding.btnNext.setOnClickListener {

            val tempAnswer = binding.edtAnswer.text.toString()
            if (isForget) {
                if (tempAnswer.trim().isEmpty()) {
                    makeToast("Please type security Answer")
                    binding.edtAnswer.requestFocus()
                } else if (baseConfig.securityAnswer == tempAnswer && baseConfig.securityQuestionPos == tempSecurityQuestionPos) {
                    activityResult = Activity.RESULT_OK
                    setResult(activityResult)
                    finish()
                } else {
                    setResult(activityResult)
                    finish()
                }
            } else {
                if (tempSecurityQuestionPos == -1) {
                    makeToast("Please select security questions")
                } else if (tempAnswer.trim().isEmpty()) {
                    makeToast("Please type security Answer")
                    binding.edtAnswer.requestFocus()
                } else {
                    baseConfig.securityQuestionPos = tempSecurityQuestionPos
                    baseConfig.securityAnswer = tempAnswer
                    activityResult = Activity.RESULT_OK
                    setResult(activityResult)
                    finish()
                }
            }

        }

        initQuestionsListeners()
    }

    var tempSecurityQuestionPos = -1
    private lateinit var dropdownPopup: DropdownPopupWithRecyclerView
    private fun initQuestionsListeners() {

        val questions = resources.getStringArray(R.array.security_questions)

        tempSecurityQuestionPos = if (isForget) baseConfig.securityQuestionPos else -1
        if (isForget) {
            tempSecurityQuestionPos = baseConfig.securityQuestionPos
            binding.edtQuestion.text = questions[tempSecurityQuestionPos]
        } else {
            tempSecurityQuestionPos = -1
        }
        Log.d("Dropdown", "isForget:$isForget")
        Log.d("Dropdown", "selectedItemPos:$tempSecurityQuestionPos")

        dropdownPopup = DropdownPopupWithRecyclerView(this, binding.edtQuestion)
            .setItems(questions)
            .setMaxVisibleItems(4)
            .setItemHeight(60)
            .setCustomAnimationEnabled(true)
            .setSelectedPosition(tempSecurityQuestionPos)
            .setOffset(0, 4)
            .setOnItemSelectedListener { position, item ->
                tempSecurityQuestionPos = position
                binding.edtQuestion.text = item
                Log.d("Dropdown", "setOnItemSelectedListener:$tempSecurityQuestionPos")
            }
            .setOnDismissListener {
                Log.d(
                    "Dropdown",
                    "Popup dismissed, tempSecurityQuestionPos:$tempSecurityQuestionPos"
                )
            }
            .build()

        binding.edtQuestion.setOnClickListener {
            Log.d("Dropdown", "Click - tempSecurityQuestionPos:$tempSecurityQuestionPos")
            dropdownPopup.updateSelectedPosition(tempSecurityQuestionPos)
            dropdownPopup.toggle()
        }
    }

}