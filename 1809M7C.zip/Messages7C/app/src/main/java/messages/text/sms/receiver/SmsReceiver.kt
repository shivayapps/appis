
package messages.text.sms.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.provider.Telephony.Sms
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.OutOfQuotaPolicy
import androidx.work.WorkManager
import androidx.work.workDataOf
import dagger.android.AndroidInjection
import messages.text.sms.repository.MessageRepository
import messages.text.sms.worker.ReceiveSmsWorker
import messages.text.sms.worker.ReceiveSmsWorker.Companion.INPUT_DATA_KEY_MESSAGE_ID
import io.reactivex.Single
import io.reactivex.schedulers.Schedulers
import android.util.Log
import javax.inject.Inject

class SmsReceiver : BroadcastReceiver() {
    @Inject lateinit var messageRepo: MessageRepository

    override fun onReceive(context: Context, intent: Intent) {
        AndroidInjection.inject(this, context)

        Sms.Intents.getMessagesFromIntent(intent)?.let { messages ->
            // reduce list of messages to single message and save in db
            val messageId = Single.just(messages)
                .observeOn(Schedulers.io())
                .map {
                    Log.d("Timber","onReceive() new sms")  // here so runs on io thread

                    messageRepo.insertReceivedSms(
                        intent.extras?.getInt("subscription", -1) ?: -1,
                        messages[0].displayOriginatingAddress,
                        messages.mapNotNull { it.displayMessageBody }.reduce { body, new -> body + new },
                        messages[0].timestampMillis
                    ).id
                }
                .blockingGet()

            // start worker with message id as param
            WorkManager.getInstance(context).enqueue(
                OneTimeWorkRequestBuilder<ReceiveSmsWorker>()
                    .setInputData(workDataOf(INPUT_DATA_KEY_MESSAGE_ID to messageId))
                    .setExpedited(OutOfQuotaPolicy.RUN_AS_NON_EXPEDITED_WORK_REQUEST)
                    .build()
            )
        }
    }

}