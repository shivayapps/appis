package messages.text.sms.extensions

import com.google.android.mms.ContentType
import messages.text.sms.model.MmsPart

fun MmsPart.isSmil() = ContentType.APP_SMIL.lowercase() == type.lowercase()

fun MmsPart.isImage() = ContentType.isImageType(type.lowercase())

fun MmsPart.isVideo() = ContentType.isVideoType(type.lowercase())

fun MmsPart.isAudio() = ContentType.isAudioType(type.lowercase())

fun MmsPart.isText() = ContentType.TEXT_PLAIN.lowercase() == type.lowercase()

fun MmsPart.isVCard() = ContentType.TEXT_VCARD.lowercase() == type.lowercase()
