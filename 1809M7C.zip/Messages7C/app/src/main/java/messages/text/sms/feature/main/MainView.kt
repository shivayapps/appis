package messages.text.sms.feature.main

import android.content.Intent
import io.reactivex.Observable
import messages.text.sms.common.base.MainBaseMsgView

interface MainView : MainBaseMsgView<MainState> {
    val onNewIntentIntent: Observable<Intent>
    val activityResumedIntent: Observable<Boolean>
    val composeIntent: Observable<Unit>
    val homeIntent: Observable<*>
    val navigationIntent: Observable<NavItem>
    val optionsItemIntent: Observable<Int>
    val filterSelectedIntent: Observable<MessageCategory>

    //    val plusBannerIntent: Observable<*>
//    val dismissRatingIntent: Observable<*>
//    val rateIntent: Observable<*>
    val conversationsSelectedIntent: Observable<List<Long>>
    val confirmDeleteIntent: Observable<List<Long>>
    val renameConversationIntent: Observable<String>
    val swipeConversationIntent: Observable<Pair<Long, Int>>
    val undoArchiveIntent: Observable<Unit>
    val snackbarButtonIntent: Observable<Unit>

    fun requestDefaultSms()
    fun requestPermissions()
    fun restartActivity()
    fun clearSearch()
    fun clearSelection()
    fun toggleSelectAll()
    fun themeChanged()
    fun showBlockingDialog(conversations: List<Long>, block: Boolean)
    fun showDeleteDialog(conversations: List<Long>)
    fun showRenameDialog(conversationName: String)
    fun showArchivedSnackbar(countConversationsArchived: Int, isArchiving: Boolean)
    fun drawerToggled(opened: Boolean)
}

enum class NavItem { BACK, INBOX, ARCHIVED, BACKUP, SCHEDULED, BLOCKING, PRIVATE, SETTINGS, HELP }
