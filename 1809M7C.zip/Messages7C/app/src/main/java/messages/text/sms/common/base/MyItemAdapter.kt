package messages.text.sms.common.base

import android.view.View
import androidx.core.view.isVisible
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.RecyclerView
import io.reactivex.subjects.BehaviorSubject
import io.reactivex.subjects.Subject
import messages.text.sms.extensions.setVisible

/**
 * Base RecyclerView.Adapter that provides some convenience when creating a new Adapter, such as
 * data list handing and item animations
 */
abstract class MyItemAdapter<T, VHT : RecyclerView.ViewHolder> : RecyclerView.Adapter<VHT>() {

    var data: List<T> = ArrayList()
        set(value) {
            if (field === value) return

            val diff = DiffUtil.calculateDiff(getDiffUtilCallback(field, value))
            field = value
            diff.dispatchUpdatesTo(this)
            onDatasetChanged()
            emptyView?.setVisible(value.isEmpty())
        }

    var emptyView: View? = null
        set(value) {
            field = value
            field?.isVisible = data.isEmpty()
        }

    val selectionChanges: Subject<List<T>> = BehaviorSubject.create()
    private val selection = mutableListOf<T>()

    // Add these to expose selection state to activity
    val selectedItems: List<T> get() = selection.toList()
    val isSelectionMode: Boolean get() = selection.isNotEmpty()

    protected fun toggleSelection(item: T, force: Boolean = true): Boolean {
        if (!force && selection.isEmpty()) return false

        when (selection.contains(item)) {
            true -> selection.remove(item)
            false -> selection.add(item)
        }

        selectionChanges.onNext(selection)
        return true
    }

    protected fun isSelected(item: T): Boolean {
        return selection.contains(item)
    }

    fun clearSelection() {
        selection.clear()
        selectionChanges.onNext(selection)
        notifyDataSetChanged()
    }

    fun getItem(position: Int): T {
        return data[position]
    }

    override fun getItemCount(): Int {
        return data.size
    }

    open fun onDatasetChanged() {}

    private fun getDiffUtilCallback(oldData: List<T>, newData: List<T>): DiffUtil.Callback {
        return object : DiffUtil.Callback() {
            override fun areItemsTheSame(oldItemPosition: Int, newItemPosition: Int) =
                areItemsTheSame(oldData[oldItemPosition], newData[newItemPosition])

            override fun areContentsTheSame(oldItemPosition: Int, newItemPosition: Int) =
                areContentsTheSame(oldData[oldItemPosition], newData[newItemPosition])

            override fun getOldListSize() = oldData.size

            override fun getNewListSize() = newData.size
        }
    }

    protected open fun areItemsTheSame(old: T, new: T): Boolean {
        return old == new
    }

    protected open fun areContentsTheSame(old: T, new: T): Boolean {
        return old == new
    }
}