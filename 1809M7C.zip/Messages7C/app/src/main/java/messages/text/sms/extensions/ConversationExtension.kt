package messages.text.sms.extensions

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.view.LayoutInflater
import android.view.View.GONE
import android.view.View.MeasureSpec
import android.view.View.VISIBLE
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.TextView
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.core.graphics.createBitmap
import androidx.core.graphics.drawable.IconCompat
import androidx.core.view.isVisible
import androidx.core.view.updateLayoutParams
import messages.text.sms.R
import messages.text.sms.common.widget.AvatarView
import messages.text.sms.common.widget.MessagesTextView
import messages.text.sms.model.Conversation
import android.util.Log

fun Conversation.getThemedIcon(context: Context, width: Int, height: Int): IconCompat {
    return try {
        val inflater = LayoutInflater.from(context)
        val parent = ConstraintLayout(context).apply {
            layoutParams = ConstraintLayout.LayoutParams(width, height)
        }
        val view = inflater.inflate(R.layout.group_avatar_view, parent, true).apply {
            layoutParams = ConstraintLayout.LayoutParams(width, height)
        }

        val multipleRecipients = recipients.size > 1
        val icon = view.findViewById<ImageView>(R.id.icon)
        val initial = view.findViewById<TextView>(R.id.initial)
        val avatarFrame = view.findViewById<FrameLayout>(R.id.avatarFrame)
        avatarFrame.updateLayoutParams<ConstraintLayout.LayoutParams> {
            matchConstraintPercentWidth = if (multipleRecipients) 0.75f else 1.0f
        }

        if (recipients.size > 1) {
            initial.isVisible = false
            icon.isVisible = true
        } else {
            initial.isVisible = true
            icon.isVisible = false

            val initials = recipients.getOrNull(0)?.contact?.name
                ?.substringBefore(',')
                ?.split(" ").orEmpty()
                .filter { name -> name.isNotEmpty() }
                .map { name -> name[0] }
                .filter { initial -> initial.isLetterOrDigit() }
                .map { initial -> initial.toString() }
            if (initials.isNotEmpty()) {
                initial.text =
                    if (initials.size > 1) initials.first() + initials.last() else initials.first()
                icon.visibility = GONE
            } else {
                initial.text = null
                icon.visibility = VISIBLE
            }
        }

//        val avatar1 = view.findViewById<AvatarView>(R.id.avatar1)
//        val avatar2 = view.findViewById<AvatarView>(R.id.avatar2)
//        val avatar1Frame = view.findViewById<FrameLayout>(R.id.avatar1Frame)
//        val multipleRecipients = recipients.size > 1
//        avatar1Frame.setBackgroundTint(
//            if (multipleRecipients)
//                context.resolveThemeColor(android.R.attr.windowBackground)
//            else
//                context.getColorCompat(android.R.color.transparent)
//        )
//        avatar1Frame.updateLayoutParams<ConstraintLayout.LayoutParams> {
//            matchConstraintPercentWidth = if (multipleRecipients) 0.75f else 1.0f
//        }
//        avatar2.isVisible = multipleRecipients
//
//        recipients.getOrNull(0)?.let(avatar1::setRecipient)
//        recipients.getOrNull(1)?.let(avatar2::setRecipient)

        view.measure(
            MeasureSpec.makeMeasureSpec(width, MeasureSpec.EXACTLY),
            MeasureSpec.makeMeasureSpec(height, MeasureSpec.EXACTLY)
        )
        view.layout(0, 0, view.measuredWidth, view.measuredHeight)

        Log.d("Timber","w: ${view.measuredWidth}; h: ${view.measuredHeight}")

        val bitmap = createBitmap(view.measuredWidth, view.measuredHeight, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        view.draw(canvas)

        IconCompat.createWithBitmap(bitmap)
    } catch (e: Exception) {
        Log.d("Timber", "Error creating default icon"+e)
        IconCompat.createWithResource(context, R.mipmap.ic_shortcut_people)
    }
}
