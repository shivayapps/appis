package messages.text.sms.after_call.adapter

import android.content.Context
import android.graphics.Typeface
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.core.view.isVisible
import androidx.recyclerview.widget.RecyclerView
import messages.text.sms.R
import messages.text.sms.extensions.getColorCompat
import messages.text.sms.common.util.DateFormatter
import messages.text.sms.databinding.ItemAfterCallBinding
import messages.text.sms.model.Conversation

class AfterCallConversationAdapter(
    private val context: Context,
    val conversations: List<Conversation>,
    private val onItemClick: (conversationId: Long) -> Unit
) : RecyclerView.Adapter<AfterCallConversationAdapter.ConversationViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ConversationViewHolder {
        return ConversationViewHolder(
            ItemAfterCallBinding.inflate(
                LayoutInflater.from(parent.context),
                parent,
                false
            )
        )
    }


    override fun onBindViewHolder(
        holder: ConversationViewHolder,
        position: Int
    ) {
        val conversation = conversations[position]
        holder.binding.avatars.recipients = conversation.recipients
        holder.binding.name.text = conversation.getTitle()
        val timestamp = DateFormatter(context).getFormatter("h:mm a").format(conversation.date)
        holder.binding.date.text = timestamp
        val snippet = when {
            conversation.draft.isNotEmpty() -> context.getString(
                R.string.main_sender_draft,
                conversation.draft
            )

            conversation.me -> context.getString(R.string.main_sender_you, conversation.snippet)
            else -> conversation.snippet
        }

        val processedText = snippet

        holder.binding.snippet.text = processedText
        if(conversation.draft.isNotEmpty()) {
            holder.binding.snippet.setTypeface(null, Typeface.ITALIC)
        }
        holder.binding.root.setOnClickListener {
            onItemClick(conversation.id)
        }

        if (conversation.unread) {
            val textColorPrimary = context.getColorCompat(R.color.textPrimary)
            holder.binding.snippet.setTypeface(holder.binding.snippet.typeface, Typeface.BOLD)
            holder.binding.snippet.setTextColor(textColorPrimary)
            holder.binding.snippet.maxLines = 3

            holder.binding.unread.isVisible = true
            holder.binding.date.setTypeface(holder.binding.date.typeface, Typeface.BOLD)
            holder.binding.date.setTextColor(textColorPrimary)
        }
    }

    override fun getItemCount(): Int = conversations.size

    inner class ConversationViewHolder(val binding: ItemAfterCallBinding) :
        RecyclerView.ViewHolder(binding.root)

}