package messages.text.sms.feature.startup

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.util.Log
import androidx.activity.OnBackPressedCallback
import androidx.core.content.ContextCompat
import com.android.volley.Request
import com.android.volley.RequestQueue
import com.android.volley.toolbox.StringRequest
import com.android.volley.toolbox.Volley
import com.google.gson.reflect.TypeToken
import com.google.gson.Gson
import dagger.android.AndroidInjection
import messages.text.sms.R
import messages.text.sms.adhelper.OpenAdHelper
import messages.text.sms.adhelper.OpenAdHelper.showOpenAd
import messages.text.sms.common.ApiData
import messages.text.sms.common.base.MainBaseThemedActivity
import messages.text.sms.extensions.baseConfig
import messages.text.sms.databinding.ActivitySplashBinding
import messages.text.sms.extensions.MiuiHelperUtils
import messages.text.sms.extensions.hasPermission
import messages.text.sms.extensions.hideStatusBars
import messages.text.sms.extensions.hideSystemBars
import messages.text.sms.extensions.updateStatusBarColor
import messages.text.sms.feature.localization.LocalizationActivity
import messages.text.sms.feature.main.MainActivity
import messages.text.sms.manager.PermissionManagerImpl
import messages.text.sms.util.Constants
import messages.text.sms.util.PERMISSION_POST_NOTIFICATIONS
import messages.text.sms.util.PERMISSION_READ_PHONE_STATE
import java.io.File

@SuppressLint("CustomSplashScreen")
class SplashActivity :
    MainBaseThemedActivity<ActivitySplashBinding>(ActivitySplashBinding::inflate) {

    private var handler = Handler(Looper.getMainLooper())

    lateinit var permissionManager: PermissionManagerImpl


//    private val binding by viewBinding(ActivitySplashBinding::inflate)

    override fun onCreate(savedInstanceState: Bundle?) {
        AndroidInjection.inject(this)
        super.onCreate(savedInstanceState)
        Log.e("startup", "Splash enter")
        setContentView(binding.root)
        updateStatusBarColor(ContextCompat.getColor(this, R.color.ripple_color))
        window.hideSystemBars()
        window.hideStatusBars()

        permissionManager = PermissionManagerImpl(this@SplashActivity)
        callAPI()
        var sessionCounter = baseConfig.splashCounter
        sessionCounter++
        baseConfig.splashCounter = sessionCounter
        loadQuickReply()
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                // DoNothing
//                isEnabled = false
//                onBackPressedDispatcher.onBackPressed()
            }
        })

        handler.postDelayed({
            navigateNext()
        }, 1000)
    }

    private fun callAPI() {
        Log.e("ApiCall", "callAPI")
        val requestQueue: RequestQueue = Volley.newRequestQueue(this)
        val request = StringRequest(
            Request.Method.GET,
            Constants.BASE_URL,
            { apiResponse: String ->
//                val typeToken = object : TypeToken<ApiData>() {}
//                val gson = Gson()
                try {
//                    val apiData: ApiData = gson.fromJson(apiResponse, typeToken.type)
                    val apiData = Gson().fromJson(apiResponse, ApiData::class.java)
                    baseConfig.bannerAdsId = apiData.bannerId
                    baseConfig.nativeAdsId = apiData.nativeId
                    baseConfig.interstitialAdsId = apiData.interstialId
                    baseConfig.appopenAdsId = apiData.appopenId
                    baseConfig.rewardAdsId = apiData.rewardId
                    baseConfig.addButtonColor = apiData.addButtonColor

                    Log.e("ApiCall", "ApiData:$apiData")
                } catch (e: Exception) {
                    Log.e("ApiCall", "ErrorApiException:$e")
                }
            }, { error ->
                Log.e("ApiCall", "ErrorApiCalling:$error")
            }
        )
        requestQueue.add(request)
    }

    private lateinit var notesFile: File
    private val notes = mutableListOf<String>()

    fun loadQuickReply() {
        Log.e("startup", "loadQuickReply")
        val path = baseConfig.quickNotes
        notesFile = if (path.isNotEmpty()) {
            File(path)
        } else {
            File(filesDir, "quick_reply_notes.txt").also {
                baseConfig.quickNotes = it.absolutePath
            }
        }

        notes.clear()

        if (!notesFile.exists() || notesFile.length() == 0L) {
            notes.addAll(
                listOf(
                    "Ok 👍",
                    "Can I call you later?",
                    "Busy right now",
                    "Please Call me back",
                    "Please call back when you are available",
                )
            )
            saveNotes() // Persist defaults only once
        } else {
            notes.addAll(notesFile.readLines())
        }
    }

    private fun saveNotes() {
        notesFile.parentFile?.mkdirs()
        notesFile.printWriter().use { writer ->
            notes.forEach(writer::println)
        }
    }


    private var isAutoStartGranted = false
    private var isBgStartGranted = false
    private fun navigateNext() {
        isAutoStartGranted = MiuiHelperUtils.isAutoStartEnabled(this)
        isBgStartGranted = if (MiuiHelperUtils.isMiui()) {
            MiuiHelperUtils.isBgStartAllowed(this)
        } else {
            true // Not MIUI, so no need for this permission
        }

        Log.e("startup", "navigateNext")
        val permissionManager = PermissionManagerImpl(this)
        when {
            !permissionManager.isDefaultSms() ||
                    !hasPermission(PERMISSION_POST_NOTIFICATIONS) ||
                    !hasPermission(PERMISSION_READ_PHONE_STATE) ||
                    !isAutoStartGranted
                -> {
                Log.e("startup", "navigateNext.001")
                val intent = Intent(this, PermissionActivity::class.java)
                startActivity(intent)
                finish()
            }

//            // SMS permission removed
//            !permissionManager.hasReadSms() ||
//                    !permissionManager.hasSendSms() ||
//                    !permissionManager.hasContacts() -> {
//                Log.e("startup", "navigateNext.002")
//                val intent = Intent(this, PermissionActivity::class.java)
//                startActivity(intent)
//                finish()
//            }

            // Overlay permission removed
            !canDrawOverlays() ||
                    !isBgStartGranted -> {
                Log.e("startup", "navigateNext.003")
                val intent = Intent(this, OverlayPermissionActivity::class.java)
                startActivity(intent)
                finish()
            }

            // Language not selected yet
            baseConfig.selectedLanguage.isBlank() && !baseConfig.clickLangDone -> {
                Log.e("startup", "navigateNext.004")
                val intent = Intent(this, LocalizationActivity::class.java)
                    .putExtra("from_splash", true)
                startActivity(intent)
                finish()
            }

            // Everything OK
            else -> {
                Log.e("startup", "loadOpenAd")
                OpenAdHelper.loadOpenAd(this, onAdLoad = {
                    Log.e("startup", "onAdLoad")
                    showOpenAd {
                        Log.e("startup", "showOpenAd")
                        gotoHomeScreen()
                    }
                }, onAdFailed = {
                    Log.e("startup", "onAdFailed")
                    gotoHomeScreen()
                }, onAdShow = {
                    Log.e("startup", "onAdShow")
                })
            }
        }

    }

    fun gotoHomeScreen() {
        val intent = Intent(this, MainActivity::class.java)
        startActivity(intent)
        finish()
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        super.onDestroy()
    }

    private fun canDrawOverlays(): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            Settings.canDrawOverlays(this)
        } else {
            true
        }
    }

    override fun onPause() {
        super.onPause()
        Log.e("startup", "launchHomeScreen: onPause")
    }
}