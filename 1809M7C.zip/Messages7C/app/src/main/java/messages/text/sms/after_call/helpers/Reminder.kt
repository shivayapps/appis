package messages.text.sms.after_call.helpers

import java.util.Date

data class Reminder(
    val message: String,
    val date: Long, // Store as timestamp
    val color: String, // Hex color string
    val id: Long
)