package messages.text.sms.common

import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.drawable.Drawable
import android.util.AttributeSet
import android.view.LayoutInflater
import android.view.View
import android.widget.FrameLayout
import androidx.core.content.ContextCompat
import messages.text.sms.databinding.CustomChipViewBinding
import messages.text.sms.R
import messages.text.sms.extensions.resolveThemeColor

class CustomChipView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyle: Int = 0
) : FrameLayout(context, attrs, defStyle) {

    private val binding =
        CustomChipViewBinding.inflate(LayoutInflater.from(context), this, true)

    var isChipEnabled = true
    fun setToggleEnabled(enabled: Boolean) {
        isChipEnabled = enabled
        isClickable = enabled
        isEnabled = enabled
        alpha = if (enabled) 1f else 0.8f
    }
    var isChecked = false
        private set

    init {

        attrs?.let {

            val a = context.obtainStyledAttributes(
                it,
                R.styleable.CustomChipView
            )

            binding.text.text =
                a.getString(R.styleable.CustomChipView_chipText)

            val icon =
                a.getDrawable(R.styleable.CustomChipView_chipIcon)

            if (icon != null) {
                binding.icon.visibility = View.VISIBLE
                binding.icon.setImageDrawable(icon)
            }

            binding.text.setTextColor(
                a.getColor(
                    R.styleable.CustomChipView_chipTextColor,
                    ContextCompat.getColor(context, R.color.textPrimaryDisabled)
                )
            )

            isChecked =
                a.getBoolean(
                    R.styleable.CustomChipView_chipChecked,
                    false
                )

            a.recycle()
        }

        refreshState()

        setOnClickListener {
            if (isChipEnabled) {
                toggle()
            }
        }
    }

    fun toggle() {
        isChecked = !isChecked
        refreshState()
    }

    fun setChecked(checked: Boolean) {
        isChecked = checked
        refreshState()
    }

    private fun refreshState() {

        if (isChecked) {
            binding.card.setCardBackgroundColor(
                ContextCompat.getColor(context, R.color.chip_active)
            )
            val colorActive = ContextCompat.getColor(context, R.color.textPrimary)
            binding.icon.imageTintList = ColorStateList.valueOf(colorActive)
            binding.text.setTextColor(colorActive)

        } else {
            binding.card.setCardBackgroundColor(
                ContextCompat.getColor(context, R.color.chip_bg)
            )
            val colorDisable = ContextCompat.getColor(context, R.color.textPrimaryDisabled)
            binding.icon.imageTintList = ColorStateList.valueOf(colorDisable)
            binding.text.setTextColor(colorDisable)
        }
    }

    fun setText(text: String) {
        binding.text.text = text
    }

    fun setIcon(drawable: Drawable?) {
        binding.icon.visibility =
            if (drawable == null) View.GONE else View.VISIBLE

        binding.icon.setImageDrawable(drawable)
    }
}