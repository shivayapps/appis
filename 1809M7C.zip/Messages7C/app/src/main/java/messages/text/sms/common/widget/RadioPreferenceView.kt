package messages.text.sms.common.widget

import android.content.Context
import android.content.res.ColorStateList
import android.util.AttributeSet
import android.view.LayoutInflater
import android.view.View
import android.widget.TextView
import androidx.appcompat.widget.TooltipCompat
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.core.content.ContextCompat
import messages.text.sms.R
import messages.text.sms.common.util.Colors
import messages.text.sms.extensions.forwardTouches
import messages.text.sms.extensions.resolveThemeAttribute
import messages.text.sms.extensions.resolveThemeColor
import messages.text.sms.extensions.setVisible
import messages.text.sms.databinding.RadioPreferenceViewBinding
import messages.text.sms.injection.appComponent
import javax.inject.Inject

class RadioPreferenceView @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null
) : ConstraintLayout(context, attrs) {

    @Inject
    lateinit var colors: Colors
    private var layout: RadioPreferenceViewBinding

    val radioButton get() = layout.radioButton
    val titleView get() = layout.titleView
    val summaryView get() = layout.summaryView
    private var checked = false


    fun setChecked(isChecked: Boolean) {
        checked = isChecked
        layout.radioButton.setImageResource(
            if (isChecked) R.drawable.ic_radio_button_checked
            else R.drawable.ic_radio_button_unchecked
        )
    }

    fun isChecked(): Boolean = checked
    companion object {
        private const val WIDGET_NONE = 0
        private const val WIDGET_ARROW = 1
        private const val WIDGET_SWITCH = 2
    }


    var title: String? = null
        set(value) {
            field = value

            if (isInEditMode) {
                findViewById<TextView>(R.id.titleView).text = value
            } else {
                layout.titleView.text = value
            }
        }

    var summary: String? = null
        set(value) {
            field = value


            if (isInEditMode) {
                findViewById<TextView>(R.id.summaryView).run {
                    text = value
                    setVisible(value?.isNotEmpty() == true)
                }
            } else {
                layout.summaryView.text = value
                layout.summaryView.setVisible(value?.isNotEmpty() == true)
            }
        }
    var tooltipText: String? = null
        set(value) {
            field = value

            if (isInEditMode) return

            TooltipCompat.setTooltipText(this, value)
        }

    init {
        if (!isInEditMode) {
            appComponent.inject(this)
        }

        layout = RadioPreferenceViewBinding.inflate(LayoutInflater.from(context), this, false)
        addView(layout.root)
        setBackgroundResource(context.resolveThemeAttribute(R.attr.selectableItemBackground))

        val states = arrayOf(
            intArrayOf(android.R.attr.state_checked),
            intArrayOf(-android.R.attr.state_checked)
        )

//        val themeColor = when (isInEditMode) {
//            true -> context.resources.getColor(R.color.tools_theme)
//            false -> colors.theme().theme
//        }
//        val textSecondary = context.resolveThemeColor(android.R.attr.textColorTertiary)
//        val textTertiary = ContextCompat.getColor(context, R.color.textTertiary)
//        layout.radioButton.buttonTintList = ColorStateList(states, intArrayOf(themeColor, textTertiary))

        layout.radioButton.forwardTouches(this)

        context.obtainStyledAttributes(attrs, R.styleable.RadioPreferenceView)?.run {
            title = getString(R.styleable.RadioPreferenceView_title)
            summary = getString(R.styleable.RadioPreferenceView_summary)
            tooltipText = getString(R.styleable.PreferenceView_tipText)

            // If there's a custom view used for the preference's widget, inflate it
//            getResourceId(R.styleable.RadioPreferenceView_widget, -1).takeIf { it != -1 }
//                ?.let { id ->
//                    View.inflate(context, id, layout.widgetFrame)
//                }

            when (getInt(R.styleable.PreferenceView_widget, WIDGET_NONE)) {
                WIDGET_NONE -> {
                    layout.widgetFrame.visibility = View.GONE
                }

                WIDGET_ARROW -> {
                    layout.themePreview.visibility = View.VISIBLE
                    layout.checkbox.visibility = View.GONE
                }

                WIDGET_SWITCH -> {
                    layout.themePreview.visibility = View.GONE
                    layout.checkbox.visibility = View.VISIBLE
                }
            }

            recycle()
        }
    }

}
