package messages.text.sms.dialog

import android.R
import android.app.Activity
import android.app.Dialog
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.view.Gravity
import android.view.Window
import android.view.WindowManager
import messages.text.sms.databinding.DialogDeleteBinding

class DeleteMessageDialog {
    private lateinit var dialog: Dialog

    fun show(
        activity: Activity,
        titleText: String,
        messageText: String,
        positiveActionCallback: () -> Unit,
        negativeActionCallback: (() -> Unit)? = null,
    ) {
        dialog = Dialog(activity)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.window?.apply {
            setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            setGravity(Gravity.CENTER)
            setDimAmount(0.8f)
            attributes?.windowAnimations = R.style.Animation_Dialog
            setLayout(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.WRAP_CONTENT
            )
        }

        val binding = DialogDeleteBinding.inflate(activity.layoutInflater)
        dialog.setContentView(binding.root)

        dialog.window?.setLayout(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.WRAP_CONTENT
        )

        binding.tvTitle.text = titleText
        binding.tvMessage.text = messageText

        binding.btnPositive.setOnClickListener {
            positiveActionCallback()
            dialog.dismiss()
        }
        binding.ivClose.setOnClickListener {
            negativeActionCallback?.invoke()
            dialog.dismiss()
        }
        dialog.setOnDismissListener {
            negativeActionCallback?.invoke()
        }
        dialog.show()
    }

}