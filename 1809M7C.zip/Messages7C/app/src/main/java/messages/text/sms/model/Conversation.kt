
package messages.text.sms.model

import io.realm.RealmList
import io.realm.RealmObject
import io.realm.annotations.Index
import io.realm.annotations.PrimaryKey

open class Conversation(
    @PrimaryKey var id: Long = 0,
    @Index var archived: Boolean = false,
    @Index var isRecycle: Boolean = false,
    @Index var isPrivate: Boolean = false,
    @Index var blocked: Boolean = false,
    @Index var pinned: Boolean = false,
    var recipients: RealmList<Recipient> = RealmList(),
    var lastMessage: Message? = null,
    var draft: String = "",
    var draftDate: Long = 0,

    var blockReason: String? = null,

    var name: String = "" // For group chats, the user is allowed to set a custom title for the conversation
) : RealmObject() {

    val date: Long get() = lastMessage?.date ?: if (draft.isNotEmpty()) draftDate else 0
    val snippet: String? get() = lastMessage?.getSummary()
    val unread: Boolean get() = lastMessage?.read == false
    val me: Boolean get() = lastMessage?.isMe() == true

//    fun getTitle(): String {
//        return name.takeIf { it.isNotBlank() } ?: recipients.joinToString { recipient -> recipient.getDisplayName() }
//    }

    fun getTitle(): String {
        val title = name.takeIf { it.isNotBlank() }

        if (title != null) return title

        // Get unique display names to avoid duplicates
        val displayNames = recipients.map { it.getDisplayName() }.distinct()

        // If all recipients have the same display name, include addresses to differentiate
        return if (displayNames.size == 1 && recipients.size > 1) {
            recipients.joinToString { recipient ->
                val name = recipient.getDisplayName()
                val address = recipient.address
                // Only show address if it's different from the name
                if (name != address) "$name ($address)" else name
            }
        } else {
            displayNames.joinToString()
        }
    }
}
