plugins {
    alias(libs.plugins.android.library)
    alias(libs.plugins.kotlin.android)
    alias(libs.plugins.ksp)
}

android {
    namespace = "com.klinker.android.send_message"
    compileSdk {
        version = release(36)
    }

    defaultConfig {
        minSdk = 23
    }

    useLibrary("org.apache.http.legacy")

    lint {
        abortOnError = false
    }
}

dependencies {
    implementation(libs.androidx.ktx)
    implementation(libs.okhttp)
    implementation(libs.okhttp.urlconnection)
    implementation(libs.kotlin.stdlib)

    // testing
//    testImplementation(libs.junit)
//    testImplementation(libs.mockito.core)
//    testImplementation(libs.mockito.kotlin)
//    testImplementation(libs.robolectric)
//    testImplementation(libs.truth)
//    testImplementation(libs.androidx.test.core)
}