# Messages

"en","hi","es","de","fr","zh","tr","pt","ar"

## Features
- Intuitive UI
- Scheduled Messages
- Message Backup
- Message Blocking and Archiving
- Voice Messages
- Attachments of any type of file
- Message Sorting
- Delayed Sending
- Automatic OTP Detection

## Helpful Tips

### Set Java Version

When building Messages, make sure to download JDK 17 and specify an installation path for it. In Android Studio, you can do that in Settings > Build, Execution, Deployment > Build Tools > Gradle.
