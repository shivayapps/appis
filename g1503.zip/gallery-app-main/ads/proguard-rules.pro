# Add project specific ProGuard rules here.
# You can control the set of applied configuration files using the
# proguardFiles setting in build.gradle.
#
# For more details, see
#   http://developer.android.com/guide/developing/tools/proguard.html

# If your project uses WebView with JS, uncomment the following
# and specify the fully qualified class name to the JavaScript interface
# class:
#-keepclassmembers class fqcn.of.javascript.interface.for.webview {
#   public *;
#}

# Uncomment this to preserve the line number information for
# debugging stack traces.
#-keepattributes SourceFile,LineNumberTable

# If you keep the line number information, uncomment this to
# hide the original source file name.
#-renamesourcefileattribute SourceFile

# Firebase
-keep class com.google.firebase.** { *; }
-dontwarn com.google.firebase.**

# Measurement SDK
-keep class com.google.android.gms.measurement.** { *; }
-dontwarn com.google.android.gms.measurement.**

# Dynamite modules
-keep class * extends java.util.ListResourceBundle
-keep public class com.google.android.gms.** { public *; }


##########  AdsConfig core ##########
# Keep AdsConfig and its companion object
-keep class com.adconfig.AdsConfig {
    public static final com.adconfig.AdsConfig$Companion Companion;
    *;
}
-keep class com.adconfig.AdsConfig$Companion { *; }

# Keep AdsConfig.Builder
-keep class com.adconfig.AdsConfig$Builder { *; }

# Keep AdmobInitializer if used
-keep class com.adconfig.AdmobInitializer { *; }

##########  adsutil package ##########
-keep class com.adconfig.adsutil.** { *; }

##########  open ad helpers ##########
-keep class com.adconfig.adsutil.openad.AppOpenApplication { *; }
-keep class com.adconfig.adsutil.openad.AppOpenApplication$AppLifecycleListener { *; }
-keep class com.adconfig.adsutil.openad.OpenAdHelper { *; }

##########  admob implementations ##########
-keep class com.adconfig.adsutil.admob.AdmobIntersAdImpl { *; }
-keep class com.adconfig.adsutil.admob.AdmobNative { *; }
-keep class com.adconfig.adsutil.admob.BannerAdHelper { *; }
-keep class com.adconfig.adsutil.admob.NativeAdHelper { *; }
-keep class com.adconfig.adsutil.admob.NativeLayoutType { *; }

##########  utils ##########
-keep class com.adconfig.adsutil.utils.** { *; }

##########  view binding (if used) ##########
-keep class com.adconfig.databinding.LayoutShimmerAdBannerBinding { *; }
-keep class com.adconfig.databinding.LayoutShimmerGoogleNativeAdBigBinding { *; }

##########  Kotlin companion objects (safe rule) ##########
# Generic rule to keep ALL Kotlin companion objects so you don’t have to write each one
-keepclassmembers class * {
    public static final <fields>;
    companion object;
}
-keep class com.adconfig.AdsConfig { *; }
-keep class com.adconfig.AdsConfig$Companion { *; }

# Please add these rules to your existing keep rules in order to suppress warnings.
# This is generated automatically by the Android Gradle plugin.
-dontwarn com.adconfig.AdsConfig$Builder
-dontwarn com.adconfig.AdsConfig$Companion
-dontwarn com.adconfig.adsutil.AdsParameters
-dontwarn com.adconfig.adsutil.Config
-dontwarn com.adconfig.adsutil.abstract.IntersAd
-dontwarn com.adconfig.adsutil.admob.AdmobIntersAdImpl
-dontwarn com.adconfig.adsutil.admob.AdmobNative
-dontwarn com.adconfig.adsutil.admob.BannerAdHelper
-dontwarn com.adconfig.adsutil.admob.NativeAdHelper
-dontwarn com.adconfig.adsutil.admob.NativeLayoutType
-dontwarn com.adconfig.adsutil.openad.OpenAdHelper
-dontwarn com.adconfig.adsutil.utils.ExtContextKt
-dontwarn com.adconfig.adsutil.utils.ExtensionsKt
-dontwarn com.adconfig.databinding.LayoutShimmerAdBannerBinding
-dontwarn com.adconfig.databinding.LayoutShimmerGoogleNativeAdBigBinding