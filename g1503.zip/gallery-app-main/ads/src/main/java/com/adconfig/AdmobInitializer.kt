package com.adconfig

import android.content.Context
import androidx.startup.Initializer
import com.google.android.gms.ads.MobileAds

class AdmobInitializer : Initializer<Unit> {
    override fun create(context: Context) {
        try {

        } catch (e:Exception) {
            MobileAds.initialize(context)
        }
    }

    override fun dependencies(): MutableList<Class<out Initializer<*>>> {
        return mutableListOf()
    }
}
