package com.adconfig

import android.app.Activity
import android.app.Application
import android.util.Log
import com.google.android.gms.ads.RequestConfiguration
import com.adconfig.adsutil.Config
import com.adconfig.adsutil.Config.showInterTime
import com.adconfig.adsutil.abstract.IntersAd
import com.adconfig.adsutil.admob.AdmobIntersAdImpl
import com.adconfig.adsutil.openad.OpenAdHelper
import com.adconfig.adsutil.utils.AdsError
import com.adconfig.adsutil.utils.AdsListener
import com.adconfig.adsutil.utils.isAnyAdShowing
import com.adconfig.adsutil.openad.AppOpenApplication
import com.adconfig.adsutil.utils.isAppForeground
import java.util.Date
import kotlin.contracts.ExperimentalContracts
import kotlin.contracts.contract

class AdsConfig private constructor(
    context: Application,
    testId: String,
//    admobInterstitialAdId: String,
//    admobInterClick: Int,
    admobAppOpenId: String,
//    admobBannerId: String,
//    admobNativeId: String,
//    admobRewardId: String
) {

    class Builder {
        private lateinit var context: Application
        private var testDeviceId: String = ""
//        private var isDebug: Boolean = false

//        private var admobInterstitialAdId: String = ""
        private var admobAppOpenId: String = ""
//        private var admobBannerId: String = ""
//        private var admobNativeId: String = ""
//        private var admobRewardId: String = ""
//        private var adNetwork: AdNetwork = AdNetwork.ADMOB

        fun setTestDeviceId(testDeviceId: String): Builder {
            this.testDeviceId = testDeviceId
            return this
        }

//        fun setIsDebug(isDebug: Boolean): Builder {
//            this.isDebug = isDebug
//            return this
//        }

//        fun setAdmobInterstitialAdId(admobInterstitialAdId: String): Builder {
//            this.admobInterstitialAdId = admobInterstitialAdId
//            return this
//        }

//        fun setAdmobInterClick(admobInterClick: Int): Builder {
//            this.admobInterClick = admobInterClick
//            return this
//        }

        fun setAdmobAppOpenId(admobAppOpenId: String): Builder {
            this.admobAppOpenId = admobAppOpenId
            return this
        }

//        fun setAdmobBannerId(admobBannerId: String): Builder {
//            this.admobBannerId = admobBannerId
//            return this
//        }
//
//        fun setAdmobNativeId(admobNativeId: String): Builder {
//            this.admobNativeId = admobNativeId
//            return this
//        }
//
//        fun setAdmobRewardId(admobRewardId: String): Builder {
//            this.admobRewardId = admobRewardId
//            return this
//        }

//        fun setAdNetwork(adNetwork: AdNetwork): Builder {
//            this.adNetwork = adNetwork
//            return this
//        }

        fun build(context: AppOpenApplication): AdsConfig {
            if(isAppForeground) {
                OpenAdHelper.destroy()
                OpenAdHelper.loadOpenAd(context)
            }
            return AdsConfig(
                context = context,
                testId = testDeviceId,
//                admobInterstitialAdId = admobInterstitialAdId,
                admobAppOpenId = admobAppOpenId,
            )
        }
    }

    companion object {

        var isSystemDialogOpen=false

        fun builder(): Builder {
            return Builder()
        }

        //        private val intersAd: IntersAd by lazy {
        //            AdmobIntersAdImpl()
        //        }
        private val intersAd: IntersAd = AdmobIntersAdImpl()

        fun showInterstitialAd(
            activity: Activity,
            onAdClosed: (isLoaded:Boolean) -> Unit = {}
        ) {
                checkLibrary()
                intersAd.adListener(object : AdsListener {
                    override fun onAdClicked() {
                        Log.i("ADCONFIG_showInter", "onAdClicked")
                    }

                    override fun onAdDismissed() {
                        Log.i("ADCONFIG_showInter", "onAdDismissed")
//                    super.onAdDismissed()
                        isAnyAdShowing = false
                        intersAd.destroy()
//                        intersAd.load(activity)
                        onAdClosed.invoke(true)
                    }

                    override fun onAdLoaded(appOpenAd: Any) {
                        Log.i("ADCONFIG_showInter", "onAdLoaded.appOpenAd")
                    }

                    override fun onAdLoaded() {
                        Log.i("ADCONFIG_showInter", "onAdLoaded")
                    }

                    override fun onAdFailedToShow(adsError: AdsError) {
                        isAnyAdShowing = false
                        Log.i(
                            "ADCONFIG_showInter",
                            "onAdFailedToShow:${adsError.code}:${adsError.error}"
                        )
//                    super.onAdFailedToShow(p0)
                        onAdClosed.invoke(false)
                    }

                    override fun onAdImpression() {
//                        intersAd.destroy()
//                        intersAd.load(activity)
//                        onAdClosed.invoke()
                        Log.i("ADCONFIG_showInter", "onAdImpression")
                    }

                    override fun onAdShowed() {
                        Log.i("ADCONFIG_showInter", "onAdShowed")
                    }
                })
                Log.i("ADCONFIG_showInter", "isAnyAdShowing:$isAnyAdShowing")
//                Log.i("ADCONFIG_showInter", "admobInterClick:${Config.admobInterClick}")
//            intersAd.load(activity)
//                if (!isAnyAdShowing && clickCounter % Config.admobInterClick == 0) {
                try {
                    if (!isAnyAdShowing) {
                        intersAd.show(activity)
                        showInterTime = Date().time
                        isAnyAdShowing = true
                    } else {
                        onAdClosed.invoke(false)
                    }
                } catch (e: Exception) {
                    onAdClosed.invoke(true)
                }
        }

//        @JvmStatic
//        fun showInterstitialAd(
//            activity: Activity,
//            adListener: IntersAd.AdListener
//        ) {
//            checkLibrary()
//            intersAd.adListener(adListener)
//            intersAd.show(activity)
//        }
    }

    init {
        RequestConfiguration.Builder().setTestDeviceIds(listOf(testId))
//        Config.admobInterstitialAdId = admobInterstitialAdId
//        Config.admobInterClick = admobInterClick
        Config.admobAppOpenId = admobAppOpenId
//        Config.admobBannerId = admobBannerId
//        Config.admobNativeId = admobNativeId
//        Config.admobRewardId = admobRewardId
        Config.isLibraryInitialized = true
//        intersAd.load(context)
    }
}

fun checkLibrary() {
    requireLibraryInitialized(Config.isLibraryInitialized) { "Ads library not initialized" }
}

@OptIn(ExperimentalContracts::class)
inline fun requireLibraryInitialized(flag: Boolean, lazyMessage: () -> String): Boolean {
    contract {
        returns() implies (flag)
    }

    if (Config.isLibraryInitialized.not()) {
        val message = lazyMessage()
        throw IllegalArgumentException(message)
    } else {
        return Config.isLibraryInitialized
    }
}
