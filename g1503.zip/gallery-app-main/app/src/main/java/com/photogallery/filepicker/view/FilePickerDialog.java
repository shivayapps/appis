package com.photogallery.filepicker.view;

import android.Manifest;
import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.CheckBox;
import android.widget.TextView;
import android.widget.Toast;

import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.photogallery.filepicker.controller.DialogSelectionListener;
import com.photogallery.filepicker.controller.NotifyItemChecked;
import com.photogallery.filepicker.controller.adapters.FileAdapter;
import com.photogallery.filepicker.model.DialogConfigs;
import com.photogallery.filepicker.model.DialogProperties;
import com.photogallery.filepicker.model.FileListItem;
import com.photogallery.filepicker.model.MarkedItemList;
import com.photogallery.filepicker.utils.ExtensionFilter;
import com.photogallery.filepicker.utils.Utility;

import com.photogallery.R;
import com.photogallery.filepicker.controller.DialogSelectionListener;
import com.photogallery.filepicker.controller.NotifyItemChecked;
import com.photogallery.filepicker.controller.adapters.FileAdapter;
import com.photogallery.filepicker.model.DialogConfigs;
import com.photogallery.filepicker.model.DialogProperties;
import com.photogallery.filepicker.model.FileListItem;
import com.photogallery.filepicker.model.MarkedItemList;
import com.photogallery.filepicker.utils.ExtensionFilter;
import com.photogallery.filepicker.utils.Utility;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import kotlin.Unit;
import kotlin.jvm.functions.Function1;


public class FilePickerDialog extends Dialog {
    private Context context;
    private RecyclerView listView;
    private TextView dname;
    private TextView dirpath;
    private TextView title;
    private DialogProperties properties;
    private DialogSelectionListener callbacks;
    private ArrayList<FileListItem> internalList;
    private ExtensionFilter filter;
    //    private FileListAdapter mFileListAdapter;
    private FileAdapter mFileListAdapter;
    //    private Button select;
    private TextView btnChoose;
    private String titleStr = null;
    private String positiveBtnNameStr = null;
    private String negativeBtnNameStr = null;

    public static final int EXTERNAL_READ_PERMISSION_GRANT = 112;

    public FilePickerDialog(Context context) {
        super(context);
        this.context = context;
        properties = new DialogProperties();
        filter = new ExtensionFilter(properties);
        internalList = new ArrayList<>();
    }

    public FilePickerDialog(Context context, DialogProperties properties) {
        super(context);
        this.context = context;
        this.properties = properties;
        filter = new ExtensionFilter(properties);
        internalList = new ArrayList<>();
    }

    public FilePickerDialog(Context context, DialogProperties properties, int themeResId) {
        super(context, themeResId);
        this.context = context;
        this.properties = properties;
        filter = new ExtensionFilter(properties);
        internalList = new ArrayList<>();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.dialog_file_picker);
        listView = findViewById(R.id.fileList);
        btnChoose = findViewById(R.id.btnChoose);
        int size = MarkedItemList.getFileCount();
        if (size == 0) {
            btnChoose.setEnabled(false);
//            int color = ContextCompat.getColor(context, R.color.color_accent);
//            btnChoose.setTextColor(Color.argb(128, Color.red(color), Color.green(color), Color.blue(color)));
        }
        dname = findViewById(R.id.dname);
        title = findViewById(R.id.title);
        dirpath = findViewById(R.id.dir_path);
        TextView btnCancel = findViewById(R.id.btnCancel);

        if (negativeBtnNameStr != null) {
            btnCancel.setText(negativeBtnNameStr);
        }
        if (positiveBtnNameStr != null) {
            btnChoose.setText(positiveBtnNameStr);
        }

        btnChoose.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                /*  Select Button is clicked. Get the array of all selected items
                 *  from MarkedItemList singleton.
                 */
                String[] paths = MarkedItemList.getSelectedPaths();
                if (callbacks != null) {
                    callbacks.onSelectedFilePaths(paths);
                }
                dismiss();
            }
        });
        setDialogImage();
        btnCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dismiss();
            }
        });

//        mFileListAdapter = new FileListAdapter(internalList, context, properties);
        mFileListAdapter = new FileAdapter(internalList, context, properties, new Function1<Integer, Unit>() {
            @Override
            public Unit invoke(Integer i) {
                if (internalList.size() > i) {
                    FileListItem fitem = internalList.get(i);
                    if (fitem.isDirectory()) {
                        if (new File(fitem.getLocation()).canRead()) {
                            File currLoc = new File(fitem.getLocation());
                            dname.setText(currLoc.getName());
                            setTitle();
                            dirpath.setText(currLoc.getAbsolutePath());
                            internalList.clear();
                            if (!currLoc.getName().equals(properties.getRoot().getName()))
                                addParent(currLoc);
                            internalList = Utility.prepareFileListEntries(internalList, currLoc, filter,
                                    properties.areHiddenFilesShown());
                            mFileListAdapter.notifyDataSetChanged();
                        } else {
                            Toast.makeText(context, R.string.error_dir_access, Toast.LENGTH_SHORT).show();
                        }
                    } else {
                        CheckBox fmark = findViewById(R.id.cbCheck);
                        fmark.performClick();
                    }
                }
                return null;
            }
        }, new NotifyItemChecked() {
            @Override
            public void notifyCheckBoxIsClicked() {
                positiveBtnNameStr = positiveBtnNameStr == null ?
                        context.getResources().getString(R.string.choose_button_label) : positiveBtnNameStr;

                int size = MarkedItemList.getFileCount();
//                int color = ContextCompat.getColor(context, R.color.color_accent);
                if (size == 0) {
                    btnChoose.setEnabled(false);
//                    btnChoose.setTextColor(Color.argb(128, Color.red(color), Color.green(color), Color.blue(color)));
                    btnChoose.setText(positiveBtnNameStr);
                } else {
                    btnChoose.setEnabled(true);
//                    btnChoose.setTextColor(color);
                    String buttonLabel = positiveBtnNameStr;
                    if (properties.getSelectionMode() == DialogConfigs.MULTI_MODE) {
                        buttonLabel += " (" + size + ") ";
                    }
                    btnChoose.setText(buttonLabel);
                }
                if (properties.getSelectionMode() == DialogConfigs.SINGLE_MODE) {
                    /*  If a single file has to be selected, clear the previously checked
                     *  checkbox from the list.
                     */
                    mFileListAdapter.notifyDataSetChanged();
                }
            }
        });
//        mFileListAdapter.setNotifyItemCheckedListener(new NotifyItemChecked() {
//            @Override
//            public void notifyCheckBoxIsClicked() {
//            }
//        });
        listView.setLayoutManager(new LinearLayoutManager(context));
        listView.setAdapter(mFileListAdapter);
        setTitle();
    }

    private void setDialogImage() {
//        ImageView dimage = findViewById(R.id.dimage);
//        if(properties.getSelectionType() == 0) {
//            dimage.setImageResource(R.drawable.ic_file_view);
//        } else {
//            dimage.setImageResource(R.drawable.ic_folder_opened);
//        }
//        dimage.setColorFilter(ContextCompat.getColor(context, R.color.colorIcons));
    }

    private void setTitle() {
        if (title == null || dname == null) {
            return;
        }
        if (titleStr != null) {
            if (title.getVisibility() == View.INVISIBLE) {
                title.setVisibility(View.VISIBLE);
            }
            title.setText(titleStr);
            if (dname.getVisibility() == View.VISIBLE) {
                dname.setVisibility(View.INVISIBLE);
            }
        } else {
            if (title.getVisibility() == View.VISIBLE) {
                title.setVisibility(View.INVISIBLE);
            }
            if (dname.getVisibility() == View.INVISIBLE) {
                dname.setVisibility(View.VISIBLE);
            }
        }
    }

    private void addParent(File currLoc) {
        FileListItem parent = new FileListItem();
        parent.setFilename(context.getString(R.string.label_parent_dir));
        parent.setDirectory(true);
        parent.setTime(currLoc.lastModified());
        File currParent = currLoc.getParentFile();
        if (currParent != null) {
            parent.setLocation(currParent.getAbsolutePath());
        }
        internalList.add(parent);
    }

    @Override
    protected void onStart() {
        super.onStart();
        positiveBtnNameStr = (
                positiveBtnNameStr == null ?
                        context.getResources().getString(R.string.choose_button_label) :
                        positiveBtnNameStr
        );

        btnChoose.setText(positiveBtnNameStr);
//        if (Utility.checkStorageAccessPermissions(context)) {
            File currLoc;
            internalList.clear();
            File offset = properties.getOffset();
            File root = properties.getRoot();
            if (offset.isDirectory() && validateOffsetPath()) {
                currLoc = new File(offset.getAbsolutePath());
                addParent(currLoc);
            } else if (root.exists() && root.isDirectory()) {
                currLoc = new File(root.getAbsolutePath());
            } else {
                currLoc = new File(properties.getErrorDir().getAbsolutePath());
            }
            dname.setText(currLoc.getName());
            dirpath.setText(currLoc.getAbsolutePath());
            setTitle();
            internalList = Utility.prepareFileListEntries(internalList, currLoc, filter,
                    properties.areHiddenFilesShown());
            mFileListAdapter.notifyDataSetChanged();
//            listView.setOnItemClickListener(this);
//        }
    }

    private boolean validateOffsetPath() {
        String offsetPath = properties.getOffset().getAbsolutePath();
        String rootPath = properties.getRoot().getAbsolutePath();
        return !offsetPath.equals(rootPath) && offsetPath.contains(rootPath);
    }

//    @Override
//    public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
//        if(internalList.size() > i) {
//            FileListItem fitem = internalList.get(i);
//            if(fitem.isDirectory()) {
//                if(new File(fitem.getLocation()).canRead()) {
//                    File currLoc = new File(fitem.getLocation());
//                    dname.setText(currLoc.getName());
//                    setTitle();
//                    dirpath.setText(currLoc.getAbsolutePath());
//                    internalList.clear();
//                    if(!currLoc.getName().equals(properties.getRoot().getName()))
//                        addParent(currLoc);
//                    internalList = Utility.prepareFileListEntries(internalList, currLoc, filter,
//                            properties.areHiddenFilesShown());
//                    mFileListAdapter.notifyDataSetChanged();
//                } else {
//                    Toast.makeText(context, R.string.error_dir_access, Toast.LENGTH_SHORT).show();
//                }
//            } else {
//                CheckBox fmark = view.findViewById(R.id.cbCheck);
//                fmark.performClick();
//            }
//        }
//    }

    public DialogProperties getProperties() {
        return properties;
    }

    public void setProperties(DialogProperties properties) {
        this.properties = properties;
        filter = new ExtensionFilter(properties);
    }

    public void setDialogSelectionListener(DialogSelectionListener callbacks) {
        this.callbacks = callbacks;
    }

    @Override
    public void setTitle(CharSequence titleStr) {
        if (titleStr != null) {
            this.titleStr = titleStr.toString();
        } else {
            this.titleStr = null;
        }
        setTitle();
    }

    public void setPositiveBtnName(CharSequence positiveBtnNameStr) {
        if (positiveBtnNameStr != null) {
            this.positiveBtnNameStr = positiveBtnNameStr.toString();
        } else {
            this.positiveBtnNameStr = null;
        }
    }

    public void setNegativeBtnName(CharSequence negativeBtnNameStr) {
        if (negativeBtnNameStr != null) {
            this.negativeBtnNameStr = negativeBtnNameStr.toString();
        } else {
            this.negativeBtnNameStr = null;
        }
    }

    public void markFiles(List<String> paths) {
        if (paths != null && paths.isEmpty()) {
            if (properties.getSelectionMode() == DialogConfigs.SINGLE_MODE) {
                File temp = new File(paths.get(0));
                switch (properties.getSelectionType()) {
                    case DialogConfigs.DIR_SELECT:
                        if (temp.exists() && temp.isDirectory()) {
                            FileListItem item = new FileListItem();
                            item.setFilename(temp.getName());
                            item.setDirectory(temp.isDirectory());
                            item.setMarked(true);
                            item.setTime(temp.lastModified());
                            item.setLocation(temp.getAbsolutePath());
                            MarkedItemList.addSelectedItem(item);
                        }
                        break;

                    case DialogConfigs.FILE_AND_DIR_SELECT:
                        if (temp.exists()) {
                            FileListItem item = new FileListItem();
                            item.setFilename(temp.getName());
                            item.setDirectory(temp.isDirectory());
                            item.setMarked(true);
                            item.setTime(temp.lastModified());
                            item.setLocation(temp.getAbsolutePath());
                            MarkedItemList.addSelectedItem(item);
                        }
                        break;

                    default:
                        if (temp.exists() && temp.isFile()) {
                            FileListItem item = new FileListItem();
                            item.setFilename(temp.getName());
                            item.setDirectory(temp.isDirectory());
                            item.setMarked(true);
                            item.setTime(temp.lastModified());
                            item.setLocation(temp.getAbsolutePath());
                            MarkedItemList.addSelectedItem(item);
                        }
                        break;
                }
            } else {
                for (String path : paths) {
                    switch (properties.getSelectionType()) {
                        case DialogConfigs.DIR_SELECT:
                            File temp = new File(path);
                            if (temp.exists() && temp.isDirectory()) {
                                FileListItem item = new FileListItem();
                                item.setFilename(temp.getName());
                                item.setDirectory(temp.isDirectory());
                                item.setMarked(true);
                                item.setTime(temp.lastModified());
                                item.setLocation(temp.getAbsolutePath());
                                MarkedItemList.addSelectedItem(item);
                            }
                            break;

                        case DialogConfigs.FILE_AND_DIR_SELECT:
                            temp = new File(path);
                            if (temp.exists() && (temp.isFile() || temp.isDirectory())) {
                                FileListItem item = new FileListItem();
                                item.setFilename(temp.getName());
                                item.setDirectory(temp.isDirectory());
                                item.setMarked(true);
                                item.setTime(temp.lastModified());
                                item.setLocation(temp.getAbsolutePath());
                                MarkedItemList.addSelectedItem(item);
                            }
                            break;

                        default:
                            temp = new File(path);
                            if (temp.exists() && temp.isFile()) {
                                FileListItem item = new FileListItem();
                                item.setFilename(temp.getName());
                                item.setDirectory(temp.isDirectory());
                                item.setMarked(true);
                                item.setTime(temp.lastModified());
                                item.setLocation(temp.getAbsolutePath());
                                MarkedItemList.addSelectedItem(item);
                            }
                            break;
                    }
                }
            }
        }
    }

    @Override
    public void show() {
//        if (!Utility.checkStorageAccessPermissions(context)) {
//            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
//                ((Activity) context).requestPermissions(new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, EXTERNAL_READ_PERMISSION_GRANT);
//            }
//        } else {
            super.show();
            positiveBtnNameStr = positiveBtnNameStr == null ?
                    context.getResources().getString(R.string.choose_button_label) : positiveBtnNameStr;
            btnChoose.setText(positiveBtnNameStr);
            int size = MarkedItemList.getFileCount();
            if (size == 0) {
                btnChoose.setText(positiveBtnNameStr);
            } else {
                String buttonLabel = positiveBtnNameStr;
                if (properties.getSelectionMode() == DialogConfigs.MULTI_MODE) {
                    buttonLabel += " (" + size + ") ";
                }
                btnChoose.setText(buttonLabel);
            }
//        }
    }

    @Override
    public void onBackPressed() {
        //currentDirName is dependent on dname
        String currentDirName = dname.getText().toString();
        if (!internalList.isEmpty()) {
            FileListItem fitem = internalList.get(0);
            File currLoc = new File(fitem.getLocation());
            File root = properties.getRoot();
            if (currentDirName.equals(root.getName())) {
                super.onBackPressed();
            } else {
                dname.setText(currLoc.getName());
                dirpath.setText(currLoc.getAbsolutePath());
                internalList.clear();
                if (!currLoc.getName().equals(root.getName()))
                    addParent(currLoc);
                internalList = Utility.prepareFileListEntries(internalList, currLoc, filter,
                        properties.areHiddenFilesShown());
                mFileListAdapter.notifyDataSetChanged();
            }
            setTitle();
        } else {
            super.onBackPressed();
        }
    }

    @Override
    public void dismiss() {
        MarkedItemList.clearSelectionList();
        internalList.clear();
        super.dismiss();
    }
}
