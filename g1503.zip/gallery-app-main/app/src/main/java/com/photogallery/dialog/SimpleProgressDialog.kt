package com.photogallery.dialog

import android.app.Activity
import android.app.Dialog
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.view.View
import android.view.Window
import android.view.WindowManager
import com.photogallery.databinding.DialogProgressSimpleBinding
import com.photogallery.utils.Constant


class SimpleProgressDialog(
    val activity: Activity,
    val txtTopTitle: String,
) : Dialog(activity) {

    lateinit var bindingDialog: DialogProgressSimpleBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestWindowFeature(Window.FEATURE_NO_TITLE)
        window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        window?.attributes?.windowAnimations = android.R.style.Animation_Dialog
//        window?.decorView!!.systemUiVisibility = View.SYSTEM_UI_FLAG_LAYOUT_STABLE or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION

        val navigationBarColor = if (Constant.themeType == Constant.THEME_LIGHT) {
            Color.parseColor("#FFFFFFFF")
        } else {
            Color.parseColor("#1F1F1F")
        }

        window?.navigationBarColor = navigationBarColor

        bindingDialog = DialogProgressSimpleBinding.inflate(layoutInflater)
        setContentView(bindingDialog.root)
//        window?.setLayout(
//            WindowManager.LayoutParams.MATCH_PARENT,
//            WindowManager.LayoutParams.WRAP_CONTENT
//        )
        intView()
    }

    private fun intView() {
        bindingDialog.txtTitle.text = txtTopTitle
        bindingDialog.progressBar.isIndeterminate = true
    }

}