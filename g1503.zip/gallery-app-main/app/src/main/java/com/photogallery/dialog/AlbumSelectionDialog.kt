package com.photogallery.dialog

import android.app.Activity
import android.app.Dialog
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.android.material.bottomsheet.BottomSheetDialogFragment
import com.photogallery.R
import com.photogallery.adapter.AlbumCreationAdapter
import com.photogallery.databinding.DialogAddAlbumBinding
import com.photogallery.extension.toast
import com.photogallery.model.AlbumData


class AlbumSelectionDialog(
    var mContext: Activity,
    var albumDataList: ArrayList<AlbumData>,
    var selectedAlbum: ArrayList<AlbumData>,
    var isCopy: Boolean,
    val selectPathListener: (path: String) -> Unit,
    val createAlbumListener: () -> Unit,
) : BottomSheetDialogFragment() {

    lateinit var binding: DialogAddAlbumBinding
    lateinit var albumAdapter: AlbumCreationAdapter
    var albumList: ArrayList<AlbumData> = ArrayList()

    var selectPos = 0


    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = DialogAddAlbumBinding.inflate(layoutInflater, container, false)
        intView()
        return binding.root
    }

    private fun intView() {

        if (isCopy)
            binding.txtTitle.text = mContext.getString(R.string.copy_to_album)
        else
            binding.txtTitle.text = mContext.getString(R.string.move_to_album)

        albumList.add(AlbumData(mContext.getString(R.string.create_an_album), isCustomAlbum = true))
        albumDataList.removeAll(selectedAlbum)
        albumList.addAll(albumList.size, albumDataList)

        initAdapter()
        initListener()
    }

    private fun initListener() {
        binding.btnClose.setOnClickListener { dismiss() }
        binding.btnDone.setOnClickListener {
            if (selectPos >= 0) {
                val albumData = albumList[selectPos]
                if (albumData.isCustomAlbum) {
                    if (albumData.title == mContext.getString(R.string.add)) {
                        dismiss()
                        createAlbumListener()
                    } else if (albumData.folderPath.isNotEmpty()) {
                        dismiss()
                        selectPathListener(albumData.folderPath)
                    }
                } else {
                    dismiss()
                    selectPathListener(albumData.folderPath)
                }
            } else {
                mContext.toast(getString(R.string.PleaseSelectAlbum))
            }
//            dismiss()
        }
    }

    private fun initAdapter() {

        albumAdapter = AlbumCreationAdapter(mContext, albumList, clickListener = {
            selectPos = it

        })
//        albumAdapter = AddAlbumAdapter(mContext, albumList, clickListener = {
//            selectPos = it
//            val albumData = albumList[selectPos]
//            if (albumData.isCustomAlbum) {
//                if (albumData.title == mContext.getString(R.string.add)) {
//                    dismiss()
//                    createAlbumListener()
//                }
//            } else {
//                dismiss()
//                selectPathListener(albumData.folderPath)
//            }
//        })
        val gridLayoutManager = GridLayoutManager(mContext, 4, RecyclerView.VERTICAL, false)
        binding.albumRecycler.layoutManager = gridLayoutManager
        binding.albumRecycler.adapter = albumAdapter
    }

    override fun getTheme(): Int = R.style.BottomSheetDialogTheme
    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog =
        BottomSheetDialog(requireContext(), theme)

}