package com.photogallery.views.bottomnav

/**
 * This is a static class to hold constants
 */
object Constants {

    val THEME_LIGHT = 0
    val THEME_DARK = 1

    val EXTRA_RESET_PASS: String = "RESET_PASS"
    val EXTRA_CHANGE_PASS: String = "CHANGE_PASS"
    val EXTRA_CHANGE_LOCK_STYLE: String = "ChangeLockStyle"
    val EXTRA_LOCK_STYLE: String = "LockStyle"

    const val ITEM_TAG = "item"
    const val ICON_ATTRIBUTE = "icon"
    const val TITLE_ATTRIBUTE = "title"
    const val WHITE_COLOR_HEX = "#FFFFFF"

    const val DEFAULT_INDICATOR_COLOR = "#426dfe"
    const val DEFAULT_TEXT_COLOR = "#444444"
    const val DEFAULT_TEXT_COLOR_ACTIVE = "#426dfe"
}
