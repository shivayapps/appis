package com.photogallery.adapter

import android.annotation.SuppressLint
import android.app.Activity
import android.graphics.Bitmap
import android.text.format.Formatter
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.bumptech.glide.Priority
import com.bumptech.glide.load.DecodeFormat
import com.bumptech.glide.load.engine.DiskCacheStrategy
import com.bumptech.glide.request.RequestOptions
import com.photogallery.utils.Preferences
import com.photogallery.R
import com.photogallery.databinding.ItemDocuBinding
import com.photogallery.databinding.ItemHeaderBinding
import com.photogallery.databinding.ItemPictureBinding
import com.photogallery.extension.beGone
import com.photogallery.extension.beVisible
import com.photogallery.extension.beVisibleIf
import com.photogallery.model.AlbumData
import com.photogallery.model.MediaData
import com.photogallery.utils.Constant
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

class StorageJunkAdapter(
    var context: Activity,
    var category: String,
    val clickListener: (pos: Int) -> Unit,
    val longClickListener: (pos: Int) -> Unit,
    val headerSelectListener: (pos: Int) -> Unit
) : ListAdapter<Any, RecyclerView.ViewHolder>(DiffCallBack()) {

    val ITEM_PHOTOS_TYPE = 2
    val ITEM_HEADER_TYPE = 1
    var preferences: Preferences = Preferences(context)

    private class DiffCallBack : DiffUtil.ItemCallback<Any>() {
        override fun areItemsTheSame(oldItem: Any, newItem: Any) = oldItem == newItem

        @SuppressLint("DiffUtilEquals")
        override fun areContentsTheSame(oldItem: Any, newItem: Any) = oldItem == newItem
    }

    override fun getItemViewType(position: Int): Int {
        return if (position in 0..<itemCount) {
            if (getItem(position) is AlbumData) {
                ITEM_HEADER_TYPE
            } else {
                ITEM_PHOTOS_TYPE
            }
        } else -1
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        return if (viewType == ITEM_HEADER_TYPE) {
            val binding =
                ItemHeaderBinding.inflate(LayoutInflater.from(parent.context), parent, false)
            HeaderViewHolder(binding)
        } else {
            if (category == "duplicate_document" || category == "duplicate_audio") {
                val binding = ItemDocuBinding.inflate(LayoutInflater.from(parent.context), parent, false)
                DocumentViewHolder(binding)
            } else {
                val binding = ItemPictureBinding.inflate(LayoutInflater.from(parent.context), parent, false)
                PictureViewHolder(binding)
            }
        }

    }

    private var enableSelection = true
    override fun onBindViewHolder(pictureViewHolder: RecyclerView.ViewHolder, position: Int, payloads: MutableList<Any>) {
        if (payloads.isNotEmpty()) {
            if (payloads[0] == "showCheckBox") {
                if (pictureViewHolder is PictureViewHolder) {
                    val albumData = getItem(position) as MediaData
                    if (enableSelection) {
//                        pictureViewHolder.binding.ivPin.visibility = View.VISIBLE
                        if (albumData.isSelected) {
                            pictureViewHolder.binding.icUnSelect.visibility = View.GONE
                            pictureViewHolder.binding.icSelect.visibility = View.VISIBLE
                        } else {
                            pictureViewHolder.binding.icUnSelect.visibility = View.VISIBLE
                            pictureViewHolder.binding.icSelect.visibility = View.GONE
                        }

                        pictureViewHolder.binding.icFavourite.visibility = View.GONE
                    } else {
//                        pictureViewHolder.binding.ivPin.visibility = View.GONE
                        pictureViewHolder.binding.icUnSelect.visibility = View.GONE
                        pictureViewHolder.binding.icSelect.visibility = View.GONE

                        pictureViewHolder.binding.icFavourite.visibility = View.GONE
                    }
                } else if (pictureViewHolder is DocumentViewHolder) {
                    val albumData = getItem(position) as MediaData
                    if (enableSelection) {
//                        pictureViewHolder.binding.ivPin.visibility = View.VISIBLE
                        if (albumData.isSelected) {
                            pictureViewHolder.binding.icUnSelect.visibility = View.GONE
                            pictureViewHolder.binding.icSelect.visibility = View.VISIBLE
                        } else {
                            pictureViewHolder.binding.icUnSelect.visibility = View.VISIBLE
                            pictureViewHolder.binding.icSelect.visibility = View.GONE
                        }
                        pictureViewHolder.binding.icFavourite.visibility = View.GONE
                    } else {
//                        pictureViewHolder.binding.ivPin.visibility = View.GONE
                        pictureViewHolder.binding.icUnSelect.visibility = View.GONE
                        pictureViewHolder.binding.icSelect.visibility = View.GONE

                        pictureViewHolder.binding.icFavourite.visibility = View.GONE
                    }
                } else if (pictureViewHolder is HeaderViewHolder) {
                    val albumData = getItem(position) as AlbumData
                    pictureViewHolder.binding.btnSelect.setImageDrawable(
                        if (albumData.isSelected) ContextCompat.getDrawable(
                            context,
                            R.drawable.ic_check_right
                        )
                        else ContextCompat.getDrawable(
                            context,
                            R.drawable.ic_check_off
                        )
                    )
                }
            }
        } else {
            super.onBindViewHolder(pictureViewHolder, position, payloads)
        }
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        holder.itemView.tag = holder
        if (position >= 0 && position < itemCount)
            if (getItemViewType(position) == ITEM_HEADER_TYPE) {
                val headerViewHolder: HeaderViewHolder =
                    holder as HeaderViewHolder

                val albumData = getItem(position) as AlbumData
//            headerViewHolder.itemView.tag=albumData.folderPath
//            holder.itemView.tag = holder

                var strDate: String = albumData.title
                val calendar = Calendar.getInstance()
                var format = SimpleDateFormat(Constant.dateFormat, Locale.ENGLISH)
                val today = format.format(calendar.timeInMillis)
                calendar.add(Calendar.DATE, -1)
                val yesterday = format.format(calendar.timeInMillis)

                if (albumData.title == today) strDate = context.getString(R.string.Today)
                else if (albumData.title == yesterday) strDate =
                    context.getString(R.string.Yesterday)

                if (preferences.getShowFileCount()) {
                    strDate += " (${albumData.mediaData.size})"
                }

                headerViewHolder.binding.txtHeader.text = strDate
                headerViewHolder.binding.btnSelect.beVisible()
                headerViewHolder.binding.txtSelect.beGone()

                headerViewHolder.binding.btnSelect.setImageDrawable(
                    if (albumData.isSelected) ContextCompat.getDrawable(
                        context,
                        R.drawable.ic_check_right
                    )
                    else ContextCompat.getDrawable(
                        context,
                        R.drawable.ic_check_off
                    )
                )
                headerViewHolder.binding.btnSelect.setOnClickListener {
                    headerSelectListener(position)
                }

            } else {
                if (holder is PictureViewHolder) {
                    val pictureViewHolder = holder as PictureViewHolder
                    val mediaData: MediaData = getItem(position) as MediaData

                    val glideOptions = RequestOptions()
                        .diskCacheStrategy(DiskCacheStrategy.AUTOMATIC)
                        .override(200, 200)
                        .centerCrop()
                        .dontAnimate()
                        .dontTransform()
                        .skipMemoryCache(false)
                        .priority(Priority.IMMEDIATE)
                        .encodeFormat(Bitmap.CompressFormat.PNG)
                        .format(DecodeFormat.DEFAULT)

                    Glide.with(context.application)
                        .asBitmap()
                        .apply(glideOptions)
                        .override(180)
                        .diskCacheStrategy(DiskCacheStrategy.ALL)
                        .load(mediaData.filePath)
                        .into(pictureViewHolder.binding.image)

                    try {
                        pictureViewHolder.binding.ivGif.beVisibleIf(
                            mediaData.filePath.endsWith(
                                "gif",
                                true
                            )
                        )
                    } catch (e: Exception) {
                    }
                    pictureViewHolder.binding.icVideo.visibility =
                        if (mediaData.isVideo) View.VISIBLE else View.GONE

                    val size = Formatter.formatShortFileSize(pictureViewHolder.itemView.context, mediaData.fileSize)
                    pictureViewHolder.binding.tvDuration.text = size
                    try {
//                    if (mediaData.isCheckboxVisible) {
                        pictureViewHolder.binding.tvDuration.visibility = View.VISIBLE
                        pictureViewHolder.binding.icDetail.visibility = View.VISIBLE

                        if (mediaData.isSelected){
                            pictureViewHolder.binding.icUnSelect.beGone()
                            pictureViewHolder.binding.icSelect.beVisible()
                        }else {
                            pictureViewHolder.binding.icUnSelect.beVisible()
                            pictureViewHolder.binding.icSelect.beGone()
                        }
//                        pictureViewHolder.binding.icUnSelect.visibility = View.VISIBLE
//                        pictureViewHolder.binding.icSelect.visibility =
//                            if (mediaData.isSelected) View.VISIBLE else View.GONE
                        pictureViewHolder.binding.icFavourite.visibility = View.GONE
                    } catch (e: Exception) {
                    }

                    holder.binding.loutMain.setOnClickListener {
                        try {
                            clickListener(position)
                        } catch (e: Exception) {
                        }
                    }

                    holder.binding.icDetail.setOnClickListener {
                        try {
                            longClickListener(position)
                        } catch (e: Exception) {
                        }
                    }
                } else if (holder is DocumentViewHolder) {
                    val pictureViewHolder = holder as DocumentViewHolder
                    val mediaData: MediaData = getItem(position) as MediaData

                    val glideOptions = RequestOptions()
                        .diskCacheStrategy(DiskCacheStrategy.AUTOMATIC)
                        .override(200, 200)
                        .centerCrop()
                        .dontAnimate()
                        .dontTransform()
                        .skipMemoryCache(false)
                        .priority(Priority.IMMEDIATE)
                        .encodeFormat(Bitmap.CompressFormat.PNG)
                        .format(DecodeFormat.DEFAULT)

                    Glide.with(context.application)
                        .asBitmap()
                        .apply(glideOptions)
                        .override(180)
                        .diskCacheStrategy(DiskCacheStrategy.ALL)
                        .placeholder(R.drawable.ic_document)
                        .load(mediaData.filePath)
                        .into(pictureViewHolder.binding.image)

                    try {
                        pictureViewHolder.binding.ivGif.beVisibleIf(
                            mediaData.filePath.endsWith(
                                "gif",
                                true
                            )
                        )
                    } catch (e: Exception) {
                    }
                    pictureViewHolder.binding.icVideo.visibility =
                        if (mediaData.isVideo) View.VISIBLE else View.GONE

                    pictureViewHolder.binding.tvName.text = mediaData.fileName
                    pictureViewHolder.binding.tvName.isSelected=true

                    pictureViewHolder.binding.tvFolder.text = mediaData.folderName

                    val size = Formatter.formatShortFileSize(pictureViewHolder.itemView.context, mediaData.fileSize)
                    pictureViewHolder.binding.tvDuration.text = size
                    try {
//                    if (mediaData.isCheckboxVisible) {
                        pictureViewHolder.binding.tvDuration.visibility = View.VISIBLE
                        pictureViewHolder.binding.icDetail.visibility = View.VISIBLE

                        if (mediaData.isSelected){
                            pictureViewHolder.binding.icUnSelect.beGone()
                            pictureViewHolder.binding.icSelect.beVisible()
                        }else {
                            pictureViewHolder.binding.icUnSelect.beVisible()
                            pictureViewHolder.binding.icSelect.beGone()
                        }
//                        pictureViewHolder.binding.icUnSelect.visibility = View.VISIBLE
//                        pictureViewHolder.binding.icSelect.visibility =
//                            if (mediaData.isSelected) View.VISIBLE else View.GONE
                        pictureViewHolder.binding.icFavourite.visibility = View.GONE
                    } catch (e: Exception) {
                    }

                    holder.binding.loutMain.setOnClickListener {
                        try {
                            clickListener(position)
                        } catch (e: Exception) {
                        }
                    }

                    holder.binding.icDetail.setOnClickListener {
                        try {
                            longClickListener(position)
                        } catch (e: Exception) {
                        }
                    }
                }
            }
    }

    class HeaderViewHolder(var binding: ItemHeaderBinding) : RecyclerView.ViewHolder(binding.root)

    class PictureViewHolder(var binding: ItemPictureBinding) : RecyclerView.ViewHolder(binding.root)
    class DocumentViewHolder(var binding: ItemDocuBinding) : RecyclerView.ViewHolder(binding.root)

//    var dateFormat = Constant.dateFormat
//    var timeFormat = if (preferences.use24HourFormat) TIME_FORMAT_24 else TIME_FORMAT_12

}