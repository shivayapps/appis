package com.photogallery.adapter

import android.annotation.SuppressLint
import android.content.Context
import android.os.Bundle
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.model.LatLng
import com.photogallery.R
import com.photogallery.databinding.ItemAlbumBinding
import com.photogallery.extension.beGone
import com.photogallery.extension.beVisible
import com.photogallery.model.AlbumData
import com.photogallery.utils.Preferences


class TimeLineAdapter(
    var context: Context,
    val clickListener: (albumData: AlbumData) -> Unit
) : ListAdapter<AlbumData, RecyclerView.ViewHolder>(DiffCallBack()) {

    private class DiffCallBack : DiffUtil.ItemCallback<AlbumData>() {
        override fun areItemsTheSame(oldItem: AlbumData, newItem: AlbumData) = oldItem == newItem

        @SuppressLint("DiffUtilEquals")
        override fun areContentsTheSame(oldItem: AlbumData, newItem: AlbumData) = oldItem == newItem
    }

    var preferences: Preferences = Preferences(context)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        val binding = ItemAlbumBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return AlbumGridViewHolder(binding)
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        holder.itemView.tag = holder

        val albumGridViewHolder = holder as AlbumGridViewHolder

        val albumData: AlbumData = getItem(position) as AlbumData
//        val albumData: AlbumData = albumList[position] as AlbumData

        albumGridViewHolder.binding.viewFront.setOnClickListener {
            clickListener(albumData)
        }
//        albumGridViewHolder.binding.cardImage.setOnClickListener {
//            clickListener(albumList[position])
//        }
//        albumGridViewHolder.binding.mapImage.setOnClickListener {
//            clickListener(albumList[position])
//        }

        albumGridViewHolder.binding.txtTitle.text = albumData.title
        if (albumData.mediaData.isNotEmpty()) {
            albumGridViewHolder.binding.txtCount.text = "${albumData.mediaData.size}"
            if(albumData.lati>0 && albumData.long>0) {

                albumGridViewHolder.binding.image.beVisible()
                Glide.with(context.applicationContext)
                    .load(albumData.mediaData[0].filePath)
                    .into(albumGridViewHolder.binding.image)
            } else {
//                albumGridViewHolder.binding.mapImage.beGone()
                albumGridViewHolder.binding.image.beVisible()
                Glide.with(context.applicationContext)
                    .load(albumData.mediaData[0].filePath)
                    .into(albumGridViewHolder.binding.image)
            }
        } else {
            albumGridViewHolder.binding.txtCount.text = "0"
            albumGridViewHolder.binding.image.setImageDrawable(
                ContextCompat.getDrawable(
                    context,
                    R.drawable.ic_image_placeholder
                )
            )
        }

    }

//    override fun getItemCount(): Int {
//        return albumList.size
//    }

    class AlbumGridViewHolder(var binding: ItemAlbumBinding) :
        RecyclerView.ViewHolder(binding.root)



}