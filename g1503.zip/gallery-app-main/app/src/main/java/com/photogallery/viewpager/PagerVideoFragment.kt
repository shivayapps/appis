package com.photogallery.viewpager

import android.content.res.Configuration
import android.graphics.Color
import android.graphics.Point
import android.graphics.SurfaceTexture
import android.graphics.drawable.ColorDrawable
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.util.DisplayMetrics
import android.util.Log
import android.view.GestureDetector
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.Surface
import android.view.TextureView
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.ImageView
import android.widget.RelativeLayout
import android.widget.SeekBar
import android.widget.TextView
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.common.VideoSize
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.ContentDataSource
import androidx.media3.datasource.DataSource
import androidx.media3.datasource.DataSpec
import androidx.media3.datasource.FileDataSource
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.SeekParameters
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.exoplayer.source.MediaSource
import androidx.media3.exoplayer.source.ProgressiveMediaSource
import com.bumptech.glide.Glide
import com.photogallery.R
import com.photogallery.databinding.FragmentPagerVideoBinding
import com.photogallery.extension.beGone
import com.photogallery.extension.beGoneIf
import com.photogallery.extension.isGone
import com.photogallery.extension.beInvisible
import com.photogallery.extension.beInvisibleIf
import com.photogallery.extension.beVisible
import com.photogallery.extension.beVisibleIf
import com.photogallery.extension.getDuration
import com.photogallery.extension.getFormattedDuration
import com.photogallery.extension.getVideoResolution
import com.photogallery.extension.isVisible
import com.photogallery.extension.navigationBarHeight
import com.photogallery.extension.onGlobalLayout
import com.photogallery.extension.realScreenSize
import com.photogallery.extension.showErrorToast
import com.photogallery.model.MediaData
import com.photogallery.utils.FAST_FORWARD_VIDEO_MS
import com.photogallery.utils.Preferences
import com.photogallery.utils.ensureBackgroundThread
import com.photogallery.views.MediaSideScroll
import java.io.File
import kotlin.math.roundToInt

@UnstableApi
class PagerVideoFragment() : ViewPagerFragment(), TextureView.SurfaceTextureListener, SeekBar.OnSeekBarChangeListener {

//    private val mMedium: PictureData
    lateinit var mMedium: MediaData
    companion object {
        @JvmStatic
        fun newInstance(param: MediaData) =
            PagerVideoFragment().apply {
                arguments = Bundle().apply {
                    putParcelable(VIEW_PAGER_PARAM, param)
                }
            }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        arguments?.let {
            mMedium = it.getParcelable<MediaData>(VIEW_PAGER_PARAM)!!
        }
    }


    private val PROGRESS = "progress"

    private var mIsFullscreen = false
    private var mWasFragmentInit = false
    private var mIsPanorama = false
    private var mIsFragmentVisible = false
    private var mIsDragged = false
    private var mWasVideoStarted = false
    private var mWasPlayerInited = false
    private var mWasLastPositionRestored = false
    private var mPlayOnPrepared = false
    private var mIsPlayerPrepared = false
    private var mCurrTime = 0
    private var mDuration = 0
    private var mPositionWhenInit = 0
    private var mPositionAtPause = 0L
    var mIsPlaying = false

    private var mExoPlayer: ExoPlayer? = null
    private var mVideoSize = Point(1, 1)
    private var mTimerHandler = Handler()

    private var mStoredShowExtendedDetails = false
    private var mStoredHideExtendedDetails = false
//    private var mStoredBottomActions = true
    private var mStoredExtendedDetails = 0
    private var mStoredRememberLastVideoPosition = false

    private lateinit var mTimeHolder: View
    private lateinit var mBrightnessSideScroll: MediaSideScroll
    private lateinit var mVolumeSideScroll: MediaSideScroll

    private lateinit var mView: View
//    private lateinit var mMedium: PictureData
    private lateinit var mTextureView: TextureView
    private lateinit var mCurrTimeView: TextView
    private lateinit var mPlayPauseButton: ImageView
    private lateinit var mSeekBar: SeekBar


    lateinit var binding: FragmentPagerVideoBinding

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding = FragmentPagerVideoBinding.inflate(layoutInflater, container, false)
        mView = binding.root
        val context = requireContext()
        val activity = requireActivity()
        preferences= Preferences(context)

        binding.apply {

            panoramaOutline.setOnClickListener { openPanorama() }
            videoCurrTime.setOnClickListener { skip(false) }
            videoDuration.setOnClickListener { skip(true) }
            videoHolder.setOnClickListener { toggleFullscreen() }
            videoPreview.setOnClickListener { toggleFullscreen() }
//            videoSurfaceFrame.controller.settings.swallowDoubleTaps = true

//            videoPlayOutline.setOnClickListener {
////                if (preferences.openVideosOnSeparateScreen) {
////                    launchVideoPlayer()
////                } else {
//                    togglePlayPause()
////                }
//            }

            mPlayPauseButton = videoTogglePlayPause
            mPlayPauseButton.setOnClickListener {
                togglePlayPause()
            }

            mSeekBar = videoSeekbar
            mSeekBar.setOnSeekBarChangeListener(this@PagerVideoFragment)
            // adding an empty click listener just to avoid ripple animation at toggling fullscreen
            mSeekBar.setOnClickListener { }

            mTimeHolder = videoTimeHolder
            mCurrTimeView = videoCurrTime
            mBrightnessSideScroll = videoBrightnessController
            mVolumeSideScroll = videoVolumeController
            mTextureView = videoSurface
            mTextureView.surfaceTextureListener = this@PagerVideoFragment

            val gestureDetector = GestureDetector(context, object : GestureDetector.SimpleOnGestureListener() {
                override fun onSingleTapConfirmed(e: MotionEvent): Boolean {
                    if (!preferences.allowInstantChange) {
                        toggleFullscreen()
                        return true
                    }

                    val viewWidth = root.width
                    val instantWidth = viewWidth / 7
                    val clickedX = e.rawX
                    when {
                        clickedX <= instantWidth -> listener?.goToPrevItem()
                        clickedX >= viewWidth - instantWidth -> listener?.goToNextItem()
                        else -> toggleFullscreen()
                    }
                    return true
                }

                override fun onDoubleTap(e: MotionEvent): Boolean {
                    handleDoubleTap(e.rawX)
                    return true
                }
            })

            videoPreview.setOnTouchListener { view, event ->
                handleEvent(event)
                false
            }

            videoSurfaceFrame.setOnTouchListener { view, event ->
                if (videoSurfaceFrame.controller.state.zoom == 1f) {
                    handleEvent(event)
                }

                gestureDetector.onTouchEvent(event)
                false
            }
        }

        if (preferences.blackBackground) {
            binding.root.background = ColorDrawable(Color.BLACK)
        }

        storeStateVariables()
        Glide.with(context).load(mMedium.filePath).into(binding.videoPreview)

        // setMenuVisibility is not called at VideoActivity (third party intent)
//        if (!mIsFragmentVisible && activity is VideoActivity) {
//            mIsFragmentVisible = true
//        }

        mIsFullscreen = activity.window.decorView.systemUiVisibility and View.SYSTEM_UI_FLAG_FULLSCREEN == View.SYSTEM_UI_FLAG_FULLSCREEN
        initTimeHolder()

        ensureBackgroundThread {
            activity.getVideoResolution(mMedium.filePath)?.apply {
                mVideoSize.x = x
                mVideoSize.y = y
            }
        }

        if (mIsPanorama) {
            binding.apply {
                panoramaOutline.beVisible()
//                videoPlayOutline.beGone()
                mPlayPauseButton.beGone()
                mVolumeSideScroll.beGone()
                mBrightnessSideScroll.beGone()
                Glide.with(context).load(mMedium.filePath).into(videoPreview)
            }
        }

        if (!mIsPanorama) {
            if (savedInstanceState != null) {
                mCurrTime = savedInstanceState.getInt(PROGRESS)
            }

            mWasFragmentInit = true
            setVideoSize()

            binding.apply {
                mBrightnessSideScroll.initialize(activity, slideInfo, true, container, singleTap = { x, y ->
                    if (preferences.allowInstantChange) {
                        listener?.goToPrevItem()
                    } else {
                        toggleFullscreen()
                    }
                }, doubleTap = { x, y ->
                    doSkip(false)
                })

                mVolumeSideScroll.initialize(activity, slideInfo, false, container, singleTap = { x, y ->
                    if (preferences.allowInstantChange) {
                        listener?.goToNextItem()
                    } else {
                        toggleFullscreen()
                    }
                }, doubleTap = { x, y ->
                    doSkip(true)
                })

                videoSurface.onGlobalLayout {
//                    if (mIsFragmentVisible && preferences.autoplayVideos && !preferences.openVideosOnSeparateScreen) {
                    if (mIsFragmentVisible && preferences.autoplayVideos) {
                        playVideo()
                    }
                }
            }
        }

        setupVideoDuration()
        if (mStoredRememberLastVideoPosition) {
            restoreLastVideoSavedPosition()
        }

        return binding.root
    }
    override fun onResume() {
        super.onResume()
//        mConfig = requireContext().config      // make sure we get a new config, in case the user changed something in the app settings
//        requireActivity().updateTextColors(binding.videoHolder)
        val allowVideoGestures = preferences.allowVideoGestures
//        mTextureView.beGoneIf(preferences.openVideosOnSeparateScreen || mIsPanorama)
        mTextureView.beGoneIf(mIsPanorama)
        binding.videoSurfaceFrame.beGoneIf(mTextureView.isGone())

        mVolumeSideScroll.beVisibleIf(allowVideoGestures && !mIsPanorama)
        mBrightnessSideScroll.beVisibleIf(allowVideoGestures && !mIsPanorama)

        checkExtendedDetails()
        initTimeHolder()
        storeStateVariables()
    }

    override fun onPause() {
        super.onPause()
        storeStateVariables()
        pauseVideo()
        if (mStoredRememberLastVideoPosition && mIsFragmentVisible && mWasVideoStarted) {
            saveVideoProgress()
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        if (activity?.isChangingConfigurations == false) {
            cleanup()
        }
    }
    override fun setMenuVisibility(menuVisible: Boolean) {
        super.setMenuVisibility(menuVisible)
        if (mIsFragmentVisible && !menuVisible) {
            pauseVideo()
        }

        mIsFragmentVisible = menuVisible
//        if (mWasFragmentInit && menuVisible && preferences.autoplayVideos && !preferences.openVideosOnSeparateScreen) {
        if (mWasFragmentInit && menuVisible && preferences.autoplayVideos) {
            playVideo()
        }
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        setVideoSize()
        initTimeHolder()
        checkExtendedDetails()
        binding.videoSurfaceFrame.onGlobalLayout {
            binding.videoSurfaceFrame.controller.resetState()
        }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putInt(PROGRESS, mCurrTime)
    }

    private fun storeStateVariables() {
        preferences.apply {
            mStoredShowExtendedDetails = showExtendedDetails
            mStoredHideExtendedDetails = hideExtendedDetails
            mStoredExtendedDetails = extendedDetails
//            mStoredBottomActions = bottomActions
            mStoredRememberLastVideoPosition = rememberLastVideoPosition
        }
    }
    private fun saveVideoProgress() {
        if (!videoEnded()) {
            if (mExoPlayer != null) {
                preferences.saveLastVideoPosition(mMedium.filePath, mExoPlayer!!.currentPosition.toInt() / 1000)
            } else {
                preferences.saveLastVideoPosition(mMedium.filePath, mPositionAtPause.toInt() / 1000)
            }
        }
    }



    private fun restoreLastVideoSavedPosition() {
        val pos = preferences.getLastVideoPosition(mMedium.filePath)
        if (pos > 0) {
            mPositionAtPause = pos * 1000L
            setPosition(pos)
        }
    }

    private fun setupTimeHolder() {
        mSeekBar.max = mDuration
        binding.videoDuration.text = mDuration.getFormattedDuration()
        Log.e("getFormattedDuration","getFormattedDuration.004")
        setupTimer()
    }

    private fun setupTimer() {
        activity?.runOnUiThread(object : Runnable {
            override fun run() {
                if (mExoPlayer != null && !mIsDragged && mIsPlaying) {
                    mCurrTime = (mExoPlayer!!.currentPosition / 1000).toInt()
                    mSeekBar.progress = mCurrTime
                    mCurrTimeView.text = mCurrTime.getFormattedDuration()
                    Log.e("getFormattedDuration","getFormattedDuration.005")
                }

                mTimerHandler.postDelayed(this, 1000)
            }
        })
    }

    private fun initExoPlayer() {
//        if (activity == null || preferences.openVideosOnSeparateScreen || mIsPanorama || mExoPlayer != null) {
        if (activity == null || mIsPanorama || mExoPlayer != null) {
            return
        }

        val isContentUri = mMedium.filePath.startsWith("content://")
        val uri = if (isContentUri) Uri.parse(mMedium.filePath) else Uri.fromFile(File(mMedium.filePath))
        val dataSpec = DataSpec(uri)
        val fileDataSource = if (isContentUri) {
            ContentDataSource(requireContext())
        } else {
            FileDataSource()
        }

        try {
            fileDataSource.open(dataSpec)
        } catch (e: Exception) {
            fileDataSource.close()
            activity?.showErrorToast(e)
            return
        }

        val factory = DataSource.Factory { fileDataSource }
        val mediaSource: MediaSource = ProgressiveMediaSource.Factory(factory)
            .createMediaSource(MediaItem.fromUri(fileDataSource.uri!!))

        fileDataSource.close()

        mPlayOnPrepared = true

        mExoPlayer = ExoPlayer.Builder(requireContext())
            .setMediaSourceFactory(DefaultMediaSourceFactory(requireContext()))
            .setSeekParameters(SeekParameters.CLOSEST_SYNC)
            .build()
            .apply {
//                if (preferences.loopVideos) {
//                    repeatMode = Player.REPEAT_MODE_ONE
//                }
                setMediaSource(mediaSource)
                setAudioAttributes(
                    AudioAttributes
                        .Builder()
                        .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
                        .build(), false
                )
                prepare()

                if (mTextureView.surfaceTexture != null) {
                    setVideoSurface(Surface(mTextureView.surfaceTexture))
                }

                initListeners()
            }
    }



    private fun ExoPlayer.initListeners() {
        addListener(object : Player.Listener {
            override fun onPositionDiscontinuity(
                oldPosition: Player.PositionInfo,
                newPosition: Player.PositionInfo,
                @Player.DiscontinuityReason reason: Int
            ) {
                // Reset progress views when video loops.
                if (reason == Player.DISCONTINUITY_REASON_AUTO_TRANSITION) {
                    mSeekBar.progress = 0
                    mCurrTimeView.text = 0.getFormattedDuration()
                    Log.e("getFormattedDuration","getFormattedDuration.006")
                }
            }

            override fun onPlaybackStateChanged(@Player.State playbackState: Int) {
                when (playbackState) {
                    Player.STATE_READY -> videoPrepared()
                    Player.STATE_ENDED -> videoCompleted()
                }
            }

            override fun onVideoSizeChanged(videoSize: VideoSize) {
                mVideoSize.x = videoSize.width
                mVideoSize.y = (videoSize.height / videoSize.pixelWidthHeightRatio).toInt()
                setVideoSize()
            }
        })
    }

    private fun launchVideoPlayer() {
        listener?.launchViewVideoIntent(mMedium.filePath)
    }

    private fun toggleFullscreen() {
        listener?.fragmentClicked()
    }

    private fun handleDoubleTap(x: Float) {
        val viewWidth = mView.width
        val instantWidth = viewWidth / 7
        when {
            x <= instantWidth -> doSkip(false)
            x >= viewWidth - instantWidth -> doSkip(true)
            else -> togglePlayPause()
        }
    }

    private fun checkExtendedDetails() {
        if (preferences.showExtendedDetails) {
            binding.videoDetails.apply {
                beInvisible()   // make it invisible so we can measure it, but not show yet
                text = getMediumExtendedDetails(mMedium)
                onGlobalLayout {
                    if (isAdded) {
                        val realY = getExtendedDetailsY(height)
                        if (realY > 0) {
                            y = realY
                            beVisibleIf(text.isNotEmpty())
                            alpha = if (!preferences.hideExtendedDetails || !mIsFullscreen) 1f else 0f
                        }
                    }
                }
            }
        } else {
            binding.videoDetails.beGone()
        }
    }

    private fun initTimeHolder() {
//        var right = 0
//        var bottom = requireContext().navigationBarHeight
        var top = resources.getDimension(R.dimen.bottom_actions_height)
//        if (preferences.bottomActions) {
//            bottom += resources.getDimension(R.dimen.bottom_actions_height).toInt()
//        }

//        if (resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE && activity?.hasNavBar() == true) {
        if (resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE) {
            top=0f
//            right += requireActivity().navigationBarWidth
        }

        (mTimeHolder.layoutParams as RelativeLayout.LayoutParams).apply {
            topMargin = top.roundToInt()
//            rightMargin = right
        }
        mTimeHolder.beInvisibleIf(mIsFullscreen)
    }

    private fun checkIfPanorama() {
//        try {
//            val fis = FileInputStream(File(mMedium.filePath))
//            fis.use {
//                requireContext().parseFileChannel(mMedium.path, it.channel, 0, 0, 0) {
//                    mIsPanorama = true
//                }
//            }
//        } catch (ignored: Exception) {
//        } catch (ignored: OutOfMemoryError) {
//        }
    }

    private fun openPanorama() {
        TODO("Panorama is not yet implemented.")
    }

    override fun fullscreenToggled(isFullscreen: Boolean) {

        mIsFullscreen = isFullscreen
        val newAlpha = if (isFullscreen) 0f else 1f
        if (!mIsFullscreen) {
            mTimeHolder.beVisible()
        }

        mSeekBar.setOnSeekBarChangeListener(if (mIsFullscreen) null else this)
        arrayOf(
            binding.videoCurrTime,
            binding.videoDuration,
            binding.videoTogglePlayPause
        ).forEach {
            it.isClickable = !mIsFullscreen
        }

        mTimeHolder.animate().alpha(newAlpha).start()
        binding.videoDetails.apply {
            if (mStoredShowExtendedDetails && isVisible() && context != null && resources != null) {
                animate().y(getExtendedDetailsY(height))

                if (mStoredHideExtendedDetails) {
                    animate().alpha(newAlpha).start()
                }
            }
        }
    }

    private fun getExtendedDetailsY(height: Int): Float {
        val smallMargin = context?.resources?.getDimension(R.dimen.small_margin) ?: return 0f
        val fullscreenOffset = smallMargin + if (mIsFullscreen) 0 else requireContext().navigationBarHeight
        var actionsHeight = 0f
        if (!mIsFullscreen) {
            actionsHeight += resources.getDimension(R.dimen.video_player_play_pause_size)
//            if (preferences.bottomActions) {
//                actionsHeight += resources.getDimension(R.dimen.bottom_actions_height)
//            }
        }
        return requireContext().realScreenSize.y - height - actionsHeight - fullscreenOffset
    }

    private fun skip(forward: Boolean) {
        if (mIsPanorama) {
            return
        } else if (mExoPlayer == null) {
            playVideo()
            return
        }
        mPositionAtPause = 0L
        doSkip(forward)
    }

    private fun doSkip(forward: Boolean) {
        if (mExoPlayer == null) {
            return
        }

        val curr = mExoPlayer!!.currentPosition
        val newProgress = if (forward) curr + FAST_FORWARD_VIDEO_MS else curr - FAST_FORWARD_VIDEO_MS
        val roundProgress = Math.round(newProgress / 1000f)
        val limitedProgress = Math.max(Math.min(mExoPlayer!!.duration.toInt() / 1000, roundProgress), 0)
        setPosition(limitedProgress)
        if (!mIsPlaying) {
            togglePlayPause()
        }
    }

    override fun onProgressChanged(seekBar: SeekBar, progress: Int, fromUser: Boolean) {
        if (fromUser) {
            if (mExoPlayer != null) {
                if (!mWasPlayerInited) {
                    mPositionWhenInit = progress
                }
                setPosition(progress)
            }

            if (mExoPlayer == null) {
                mPositionAtPause = progress * 1000L
                playVideo()
            }
        }
    }

    override fun onStartTrackingTouch(seekBar: SeekBar) {
        if (mExoPlayer == null) {
            return
        }

        mExoPlayer!!.playWhenReady = false
        mIsDragged = true
    }

    override fun onStopTrackingTouch(seekBar: SeekBar) {
        if (mIsPanorama) {
            openPanorama()
            return
        }

        if (mExoPlayer == null) {
            return
        }

        if (mIsPlaying) {
            mExoPlayer!!.playWhenReady = true
        } else {
            playVideo()
        }

        mIsDragged = false
    }

    private fun togglePlayPause() {
        if (activity == null || !isAdded) {
            return
        }

        if (mIsPlaying) {
            pauseVideo()
        } else {
            playVideo()
        }
    }

    fun playVideo() {
        if (mExoPlayer == null) {
            initExoPlayer()
            return
        }

        if (binding.videoPreview.isVisible()) {
            binding.videoPreview.beGone()
            initExoPlayer()
        }

        val wasEnded = videoEnded()
        if (wasEnded) {
            setPosition(0)
        }

        if (mStoredRememberLastVideoPosition && !mWasLastPositionRestored) {
            mWasLastPositionRestored = true
            restoreLastVideoSavedPosition()
        }

//        if (!wasEnded || !preferences.loopVideos) {
        if (!wasEnded) {
            mPlayPauseButton.setImageResource(R.drawable.ic_pause_outline_vector)
        }

        if (!mWasVideoStarted) {
//            binding.videoPlayOutline.beGone()
            mPlayPauseButton.beVisible()
//            mPlayPauseButton.beVisible()
        }

        mWasVideoStarted = true
        if (mIsPlayerPrepared) {
            mIsPlaying = true
        }
        mExoPlayer?.playWhenReady = true
        activity?.window?.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
    }

    private fun pauseVideo() {
        if (mExoPlayer == null) {
            return
        }

        mIsPlaying = false
        if (!videoEnded()) {
            mExoPlayer?.playWhenReady = false
        }

        mPlayPauseButton.setImageResource(R.drawable.ic_play_outline_vector)
        activity?.window?.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        mPositionAtPause = mExoPlayer?.currentPosition ?: 0L
    }

    private fun videoEnded(): Boolean {
        val currentPos = mExoPlayer?.currentPosition ?: 0
        val duration = mExoPlayer?.duration ?: 0
        return currentPos != 0L && currentPos >= duration
    }

    private fun setPosition(seconds: Int) {
        mSeekBar.progress = seconds
        mCurrTimeView.text = seconds.getFormattedDuration()
        Log.e("getFormattedDuration","getFormattedDuration.003")
        mExoPlayer?.seekTo(seconds * 1000L)

        if (!mIsPlaying) {
            mPositionAtPause = mExoPlayer?.currentPosition ?: 0L
        }
    }

    private fun setupVideoDuration() {
        ensureBackgroundThread {
            mDuration = context?.getDuration(mMedium.filePath) ?: 0

            activity?.runOnUiThread {
                setupTimeHolder()
                setPosition(0)
            }
        }
    }

    private fun videoPrepared() {
        if (mDuration == 0) {
            mDuration = (mExoPlayer!!.duration / 1000).toInt()
            setupTimeHolder()
            setPosition(mCurrTime)

            if (mIsFragmentVisible && (preferences.autoplayVideos)) {
                playVideo()
            }
        }

        if (mPositionWhenInit != 0 && !mWasPlayerInited) {
            setPosition(mPositionWhenInit)
            mPositionWhenInit = 0
        }

        mIsPlayerPrepared = true
        if (mPlayOnPrepared && !mIsPlaying) {
            if (mPositionAtPause != 0L) {
                mExoPlayer?.seekTo(mPositionAtPause)
                mPositionAtPause = 0L
            }
            playVideo()
        }
        mWasPlayerInited = true
        mPlayOnPrepared = false
    }

    private fun videoCompleted() {
        if (!isAdded || mExoPlayer == null) {
            return
        }

        mCurrTime = (mExoPlayer!!.duration / 1000).toInt()
        //if (listener?.videoEnded() == false && preferences.loopVideos) {
        if (listener?.videoEnded() == false) {
            playVideo()
        } else {
            mSeekBar.progress = mSeekBar.max
            mCurrTimeView.text = mDuration.getFormattedDuration()
            Log.e("getFormattedDuration","getFormattedDuration.007")
            pauseVideo()
        }
    }

    private fun cleanup() {
        pauseVideo()
        releaseExoPlayer()

        if (mWasFragmentInit) {
            mCurrTimeView.text = 0.getFormattedDuration()
            Log.e("getFormattedDuration","getFormattedDuration.008")
            mSeekBar.progress = 0
            mTimerHandler.removeCallbacksAndMessages(null)
        }
    }

    private fun releaseExoPlayer() {
        mIsPlayerPrepared = false
        mExoPlayer?.apply {
            stop()
            release()
        }
        mExoPlayer = null
    }

    override fun onSurfaceTextureSizeChanged(surface: SurfaceTexture, width: Int, height: Int) {}

    override fun onSurfaceTextureUpdated(surface: SurfaceTexture) {}

    override fun onSurfaceTextureDestroyed(surface: SurfaceTexture) = false

    override fun onSurfaceTextureAvailable(surface: SurfaceTexture, width: Int, height: Int) {
        mExoPlayer?.setVideoSurface(Surface(mTextureView.surfaceTexture))
    }

    private fun setVideoSize() {
//        if (activity == null || preferences.openVideosOnSeparateScreen) {
        if (activity == null ) {
            return
        }

        try {
            val videoProportion = mVideoSize.x.toFloat() / mVideoSize.y.toFloat()
            val display = requireActivity().windowManager.defaultDisplay
            val screenWidth: Int
            val screenHeight: Int

            val realMetrics = DisplayMetrics()
            display.getRealMetrics(realMetrics)
            screenWidth = realMetrics.widthPixels
            screenHeight = realMetrics.heightPixels

            val screenProportion = screenWidth.toFloat() / screenHeight.toFloat()

            mTextureView.layoutParams.apply {
                if (videoProportion > screenProportion) {
                    width = screenWidth
                    height = (screenWidth.toFloat() / videoProportion).toInt()
                } else {
                    width = (videoProportion * screenHeight.toFloat()).toInt()
                    height = screenHeight
                }
                mTextureView.layoutParams = this
            }
        } catch (e:Exception) {
            Log.e("printStackTrace","printStackTrace:$e")
        }
    }
}