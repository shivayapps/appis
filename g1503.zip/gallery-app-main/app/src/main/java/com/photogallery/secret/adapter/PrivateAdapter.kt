package com.photogallery.secret.adapter

import android.app.Activity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.photogallery.R
import com.photogallery.databinding.ItemHeaderBinding
import com.photogallery.databinding.ItemHeaderDarkBinding
import com.photogallery.databinding.ItemPictureBinding
import com.photogallery.databinding.ItemPictureDarkBinding
import com.photogallery.extension.beGone
import com.photogallery.extension.beVisible
import com.photogallery.extension.beVisibleIf
import com.photogallery.model.AlbumData
import com.photogallery.model.MediaData
import com.photogallery.utils.Preferences
import java.text.SimpleDateFormat
import java.util.Locale

class PrivateAdapter(
    var context: Activity,
    var pictures: ArrayList<Any>,
    val clickListener: (pos: Int) -> Unit,
    val longClickListener: (pos: Int) -> Unit,
    val headerSelectListener: (pos: Int) -> Unit,
) :
    RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    val ITEM_PHOTOS_TYPE = 2
    val ITEM_HEADER_TYPE = 1

    val format = SimpleDateFormat("dd MMM yyyy", Locale.ENGLISH)

    override fun getItemViewType(position: Int): Int {
        return if (position >= 0 && position < pictures.size) {
            if (pictures[position] is AlbumData) {
                ITEM_HEADER_TYPE
            } else {
                ITEM_PHOTOS_TYPE
            }
        } else
            -1
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        return if (viewType == ITEM_HEADER_TYPE) {
            val binding =
                ItemHeaderDarkBinding.inflate(LayoutInflater.from(parent.context), parent, false)
            HeaderViewHolder(binding)
        } else {
            val binding =
                ItemPictureDarkBinding.inflate(LayoutInflater.from(parent.context), parent, false)
            PictureViewHolder(binding)
        }
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        if (position >= 0 && position < pictures.size)
            if (getItemViewType(position) == ITEM_HEADER_TYPE) {
                val headerViewHolder: HeaderViewHolder =
                    holder as HeaderViewHolder
                val albumData = pictures[position] as AlbumData
                var strDate: String = albumData.title
//                val calendar = Calendar.getInstance()
//                val today = format.format(calendar.timeInMillis)
//                calendar.add(Calendar.DATE, -1)
//                val yesterday = format.format(calendar.timeInMillis)

//                if (albumData.title == today)
//                    strDate = context.getString(R.string.Today)
//                else if (albumData.title == yesterday)
//                    strDate = context.getString(R.string.Yesterday)

                headerViewHolder.binding.txtHeader.text = strDate
                headerViewHolder.binding.txtSelect.beGone()


//                headerViewHolder.binding.btnSelect.visibility = if (albumData.isCheckboxVisible) View.VISIBLE else View.GONE

//                headerViewHolder.binding.btnSelect.text = if (albumData.isSelected) context.getString(R.string.deselect) else context.getString(
//                        R.string.select_all
//                    )
                if (albumData.isSelected)
                    headerViewHolder.binding.btnSelect.setImageDrawable(
                        ContextCompat.getDrawable(
                            context, R.drawable.ic_select
                        )
                    )
                else headerViewHolder.binding.btnSelect.setImageDrawable(
                    ContextCompat.getDrawable(
                        context, R.drawable.ic_un_select
                    )
                )
//
                headerViewHolder.binding.btnSelect.setOnClickListener {
                    headerSelectListener(position)
                }
            } else {
                val pictureViewHolder = holder as PictureViewHolder
                val pictureData: MediaData = pictures[position] as MediaData
                Glide.with(context.application)
                    .asBitmap().load(pictureData.filePath)
                    .into(pictureViewHolder.binding.image)

                pictureViewHolder.binding.ivGif!!.beVisibleIf(
                    pictureData.filePath.endsWith(
                        "gif",
                        true
                    )
                )
                pictureViewHolder.binding.icVideo.visibility =
                    if (pictureData.isVideo) View.VISIBLE else View.GONE


                if (pictureData.isCheckboxVisible) {

                    if (pictureData.isSelected){
                        pictureViewHolder.binding.icUnSelect.beGone()
                        pictureViewHolder.binding.icSelect.beVisible()
                    }else {
                        pictureViewHolder.binding.icUnSelect.beVisible()
                        pictureViewHolder.binding.icSelect.beGone()
                    }
//                    pictureViewHolder.binding.icUnSelect.visibility = View.VISIBLE
//                    pictureViewHolder.binding.icSelect.visibility =
//                        if (pictureData.isSelected) View.VISIBLE else View.GONE
                    pictureViewHolder.binding.icFavourite.visibility = View.GONE
                } else {
                    pictureViewHolder.binding.icUnSelect.visibility = View.GONE
                    pictureViewHolder.binding.icSelect.visibility = View.GONE

                    pictureViewHolder.binding.icFavourite.visibility =
                        if (pictureData.isFavorite) View.VISIBLE else View.GONE
                }

                holder.binding.loutMain.setOnClickListener {
                    clickListener(position)
                }
                holder.binding.loutMain.setOnLongClickListener {
                    longClickListener(position)
                    true
                }
            }
    }

    override fun getItemCount(): Int {
        return pictures.size
    }

    class HeaderViewHolder(var binding: ItemHeaderDarkBinding) :
        RecyclerView.ViewHolder(binding.root)

    class PictureViewHolder(var binding: ItemPictureDarkBinding) :
        RecyclerView.ViewHolder(binding.root)

    var preferences: Preferences = Preferences(context)

}