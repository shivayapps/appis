package com.photogallery.views

import android.content.Context
import android.util.AttributeSet
import android.view.MotionEvent
import com.photogallery.views.rtlviewpager.RtlViewPager


class MyViewPager : RtlViewPager {

    private var enabled = false

    fun setPagingEnabled(enabled: Boolean) {
        this.enabled = enabled
    }
    init {
        enabled = true
    }
    constructor(context: Context) : super(context)

    constructor(context: Context, attrs: AttributeSet) : super(context, attrs)


    override fun onInterceptTouchEvent(ev: MotionEvent): Boolean {
        return try {
            if(enabled) super.onInterceptTouchEvent(ev)
            else false
        } catch (ignored: Exception) {
            false
        }
    }

    override fun onTouchEvent(ev: MotionEvent): Boolean {
        return try {
            if(enabled) super.onTouchEvent(ev)
            else false
        } catch (ignored: Exception) {
            false
        }
    }
}
