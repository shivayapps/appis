package com.photogallery.secret

import android.os.Bundle
import android.util.Log
import android.view.View
import android.view.animation.Animation
import android.view.animation.AnimationUtils
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.widget.AppCompatImageView
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.widget.addTextChangedListener
import com.andrognito.patternlockview.PatternLockView
import com.andrognito.patternlockview.listener.PatternLockViewListener
import com.andrognito.patternlockview.utils.PatternLockUtils
import com.photogallery.R
import com.photogallery.base.BaseActivity
import com.photogallery.databinding.ActivityLockBinding
import com.photogallery.extension.showBiometricPrompt
import com.photogallery.utils.Preferences
import com.photogallery.views.bottomnav.Constants


class LockChangeActivity : BaseActivity() {

    private val TAG = "LockActivity"


    private var tempStep = 0
    private var passcode = ""
    var isResetPass = false
    var isShowPinLock = false
    var isChangePass = false
    lateinit var animation: Animation
    lateinit var preferences: Preferences
    private val lockListener: (Boolean) -> Unit = { isUnlock ->
        if (isUnlock) setSuccess() else finish()
    }

    private fun setSuccess() {
        setResult(RESULT_OK)
        finish()
    }

    private lateinit var binding: ActivityLockBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        binding = ActivityLockBinding.inflate(layoutInflater)
        setContentView(binding.root)
        ViewCompat.setOnApplyWindowInsetsListener(binding.root) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
        preferences= Preferences(this)
        animation = AnimationUtils.loadAnimation(this, R.anim.anim_shake)

        //setTheme(getThemeId())
        intView()
        initListeners()
    }

    private fun intView() {
        isResetPass = intent.getBooleanExtra(Constants.EXTRA_RESET_PASS, false)
        isChangePass = intent.getBooleanExtra(Constants.EXTRA_CHANGE_PASS, false)

        isShowPinLock = intent.getBooleanExtra(Constants.EXTRA_LOCK_STYLE, false)

        binding.pass.setText("")
        binding.patterLockView.clearPattern()

        updateLockView()
        binding.llSwitch.visibility = View.GONE
        binding.forgot.visibility = View.GONE

        binding.title.text = if (isShowPinLock) {
            getString(R.string.set_your_pin)
        } else {
            getString(R.string.draw_an_unlock_pattern)
        }

//        try {
//                loadFragment(ChangeLockFragment(this, isPinLock, lockListener = {
//                    setResult(RESULT_OK)
//                    finish()
//                }))
//        } catch (e:Exception) {
//            Log.e("printStackTrace","printStackTrace:$e")
//        }
    }




//    private fun setPasswordSuccess() {
//        runOnUiThread {
//            setResult(RESULT_OK)
//            (this@LockChangeActivity).finish()
//        }
//    }

    // ---------------------------------------
    // Success
    // ---------------------------------------

    private fun setPasswordSuccess() {
        if (isShowPinLock) {
            preferences.isPasscode = true
            preferences.isSetLock = true
        } else {
            preferences.isPatternSet = true
            preferences.isSetLock = true
        }

        preferences.isPinLock = isShowPinLock
        lockListener(true)
    }

    private fun startAndroidxBiometricManager() {
        showBiometricPrompt(successCallback = { icSuccess ->
            if (icSuccess) {
                setPasswordSuccess()
            }
        }, failureCallback = { icFailed: Boolean, errorCode: Int, errString: CharSequence ->
            Log.e("BiometricManager","\nicFailed:$icFailed,\nerrorCode:$errorCode,errString:$errString")
            //showToast(getString(R.string.authentication_failed))
        })
    }

    private fun updateLockView() {
        if (isShowPinLock) {
            binding.patterLockView.visibility = View.GONE
            binding.tvErrorMsg.visibility = View.GONE
            binding.loutPinNumber.visibility = View.VISIBLE
            binding.loutPinDots.visibility = View.VISIBLE
        } else {
            binding.patterLockView.visibility = View.VISIBLE
            binding.tvErrorMsg.visibility = View.INVISIBLE
            binding.loutPinNumber.visibility = View.INVISIBLE
            binding.loutPinDots.visibility = View.GONE
        }
    }

    // ---------------------------------------
    // Listeners
    // ---------------------------------------

    private fun initListeners() {
        setupPinButtons()
        setupPatternListener()
        setupPinTextWatcher()
    }

    private fun setupPinButtons() {
        val buttons = listOf(
            binding.btnZero to "0",
            binding.btnNo1 to "1",
            binding.btnNo2 to "2",
            binding.btnNo3 to "3",
            binding.btnNo4 to "4",
            binding.btnNo5 to "5",
            binding.btnNo6 to "6",
            binding.btnNo7 to "7",
            binding.btnNo8 to "8",
            binding.btnNo9 to "9"
        )

        buttons.forEach { (button, number) ->
            button.setOnClickListener { appendPin(number) }
        }

        binding.btnNoClear.setOnClickListener {
            val text = binding.pass.text.toString()
            if (text.isNotEmpty()) {
                binding.pass.setText(text.dropLast(1))
                binding.pass.setSelection(binding.pass.text?.length ?: 0)
            }
        }
    }

    private fun setupPatternListener() {
        binding.patterLockView.addPatternLockListener(object : PatternLockViewListener {

            override fun onStarted() {
                binding.tvErrorMsg.visibility = View.INVISIBLE
            }

            override fun onProgress(progressPattern: List<PatternLockView.Dot>) {}

            override fun onComplete(pattern: List<PatternLockView.Dot>) {
                val patternString =
                    PatternLockUtils.patternToString(binding.patterLockView, pattern)

                if (patternString.length < 4) {
                    showPatternError(getString(R.string.patter_validation))
                } else {
                    handlePatternStep(patternString)
                }
            }

            override fun onCleared() {}
        })
    }

    private fun setupPinTextWatcher() {
        binding.pass.addTextChangedListener {
            val length = it?.length ?: 0
            updatePinDots(length)

            if (length == 4) {
                handlePinStep()
            }
        }
    }

    // ---------------------------------------
    // PIN Logic
    // ---------------------------------------

    private fun appendPin(value: String) {
        binding.pass.append(value)
    }

    private fun updatePinDots(length: Int) {
        val dots = listOf(binding.dot1, binding.dot2, binding.dot3, binding.dot4)

        dots.forEachIndexed { index, imageView ->
            if (index < length) selectDot(imageView)
            else unSelectDot(imageView)
        }
    }

    private fun handlePinStep() {
        if (tempStep == 0) {
            passcode = binding.pass.text.trim().toString()
            tempStep = 1

            binding.root.postDelayed({
                binding.title.text = getString(R.string.confirm_your_pin)
                binding.pass.setText("")
            }, 300)

        } else {
            if (passcode == binding.pass.text.trim().toString()) {
                preferences.pincode = passcode
                showToast(getString(R.string.pin_set_successfully))
                setPasswordSuccess()
            } else {
                binding.root.postDelayed({
                    binding.pass.setText("")
                }, 300)

                showToast(getString(R.string.pin_not_match))
                setErrorAnimation(binding.loutPinDots)
            }
        }
    }

    // ---------------------------------------
    // Pattern Logic
    // ---------------------------------------

    private fun handlePatternStep(pattern: String) {
        if (tempStep == 0) {
            passcode = pattern
            tempStep = 1

            binding.patterLockView.setViewMode(
                PatternLockView.PatternViewMode.CORRECT
            )

            binding.root.postDelayed({
                binding.title.text = getString(R.string.draw_pattern_again)
                binding.patterLockView.clearPattern()
            }, 300)

        } else {
            if (passcode == pattern) {
                preferences.pattern = passcode
                showToast(getString(R.string.pattern_set_successfully))
                setPasswordSuccess()
            } else {
                showPatternError(getString(R.string.pattern_not_match))
            }
        }
    }

    private fun showPatternError(message: String) {
        binding.patterLockView.setViewMode(
            PatternLockView.PatternViewMode.WRONG
        )
        binding.tvErrorMsg.visibility = View.VISIBLE
        binding.tvErrorMsg.text = message
        setErrorAnimation(binding.tvErrorMsg)
    }


    // ---------------------------------------
    // Utilities
    // ---------------------------------------

    private fun setErrorAnimation(view: View) {
        view.startAnimation(animation)
    }

    private fun selectDot(image: AppCompatImageView) {
        image.setImageDrawable(
            ContextCompat.getDrawable(this, R.drawable.ic_pass_dot_fill)
        )
    }

    private fun unSelectDot(image: AppCompatImageView) {
        image.setImageDrawable(
            ContextCompat.getDrawable(this, R.drawable.ic_pass_dot_unfill)
        )
    }

    private fun showToast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }
}