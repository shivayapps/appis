package com.photogallery.model

data class PlaceData(
    var pictureData: ArrayList<MediaData> = ArrayList(),
//    var path: String = "",
    var place: String = "",
    var lati: Float = 0F,
    var long: Float = 0F
)