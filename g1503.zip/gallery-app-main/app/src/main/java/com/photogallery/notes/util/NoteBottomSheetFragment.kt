package com.photogallery.notes.util

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.localbroadcastmanager.content.LocalBroadcastManager
import com.photogallery.R
import com.photogallery.databinding.FragmentNotesBottomSheetBinding
import com.google.android.material.bottomsheet.BottomSheetDialogFragment

class NoteBottomSheetFragment : BottomSheetDialogFragment() {

    var selectedColor = "#3e434e"

    companion object {

        var noteId = -1

        fun newInstance(id: Int): NoteBottomSheetFragment {
            val args = Bundle()
            val fragment = NoteBottomSheetFragment()
            fragment.arguments = args
            noteId = id
            return fragment
        }

    }

    private var _binding : FragmentNotesBottomSheetBinding? = null
    private val binding get() = _binding!!


    private fun setupDialog() {

//        val view = LayoutInflater.from(context).inflate(R.layout.fragment_notes_bottom_sheet, null)
//        dialog.setContentView(view)

//        val param = (binding.root.parent as View).layoutParams as CoordinatorLayout.LayoutParams
//        val behavior = param.behavior

//        if (behavior is BottomSheetBehavior<*>) {
//
//            behavior.setBottomSheetCallback(object : BottomSheetBehavior.BottomSheetCallback() {
//
//                override fun onStateChanged(bottomSheet: View, newState: Int) {
//                    var state = ""
//                    while (newState == newState) {
//                        BottomSheetBehavior.STATE_DRAGGING.apply {
//                            state = "DRAGGING"
//                        }
//                        BottomSheetBehavior.STATE_SETTLING.apply {
//                            state = "SETTILING"
//                        }
//                        BottomSheetBehavior.STATE_EXPANDED.apply {
//                            state = "EXPANDED"
//                        }
//                        BottomSheetBehavior.STATE_COLLAPSED.apply {
//                            state = "COLLAPSED"
//                        }
//                        BottomSheetBehavior.STATE_HIDDEN.apply {
//                            state = "HIDDEN"
//                            dismiss()
//                            behavior.state = BottomSheetBehavior.STATE_COLLAPSED
//                        }
//                    }
//                }
//
//                override fun onSlide(bottomSheet: View, slideOffset: Float) {
//
//                }
//            })
//        }
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        _binding = FragmentNotesBottomSheetBinding.inflate(inflater, container, false)
        setupDialog()
        return binding.root
    }


    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        if (noteId != -1) {
            binding.llDeleteNote.visibility = View.VISIBLE
        } else {
            binding.llDeleteNote.visibility = View.GONE
        }
        setListener()
    }


    private fun setListener() {

        binding.fNoteBlue.setOnClickListener {

            binding.imgNoteBlue.setImageResource(R.drawable.donecheck)
            binding.imgNoteCyan.setImageResource(0)
            binding.imgNoteGreen.setImageResource(0)
            binding.imgNoteOrange.setImageResource(0)
            binding.imgNotePurple.setImageResource(0)
            binding.imgNoteRed.setImageResource(0)
            binding.imgNoteYellow.setImageResource(0)
            binding.imgNoteBrown.setImageResource(0)
            binding.imgNoteIndigo.setImageResource(0)
            selectedColor = "#2196f3"

            val intent = Intent("bottom_sheet_action")
            intent.putExtra("action", "Blue")
            intent.putExtra("selectedColor", selectedColor)
            LocalBroadcastManager.getInstance(requireContext()).sendBroadcast(intent)

        }

        binding.fNoteCyan.setOnClickListener {

            binding.imgNoteBlue.setImageResource(0)
            binding.imgNoteCyan.setImageResource(R.drawable.donecheck)
            binding.imgNoteGreen.setImageResource(0)
            binding.imgNoteOrange.setImageResource(0)
            binding.imgNotePurple.setImageResource(0)
            binding.imgNoteRed.setImageResource(0)
            binding.imgNoteYellow.setImageResource(0)
            binding.imgNoteBrown.setImageResource(0)
            binding.imgNoteIndigo.setImageResource(0)
            selectedColor = "#00e5ff"

            val intent = Intent("bottom_sheet_action")
            intent.putExtra("action", "Cyan")
            intent.putExtra("selectedColor", selectedColor)
            LocalBroadcastManager.getInstance(requireContext()).sendBroadcast(intent)

        }

        binding.fNoteGreen.setOnClickListener {

            binding.imgNoteBlue.setImageResource(0)
            binding.imgNoteCyan.setImageResource(0)
            binding.imgNoteGreen.setImageResource(R.drawable.donecheck)
            binding.imgNoteOrange.setImageResource(0)
            binding.imgNotePurple.setImageResource(0)
            binding.imgNoteRed.setImageResource(0)
            binding.imgNoteYellow.setImageResource(0)
            binding.imgNoteBrown.setImageResource(0)
            binding.imgNoteIndigo.setImageResource(0)
            selectedColor = "#00c853"

            val intent = Intent("bottom_sheet_action")
            intent.putExtra("action", "Green")
            intent.putExtra("selectedColor", selectedColor)
            LocalBroadcastManager.getInstance(requireContext()).sendBroadcast(intent)

        }

        binding.fNoteOrange.setOnClickListener {

            binding.imgNoteBlue.setImageResource(0)
            binding.imgNoteCyan.setImageResource(0)
            binding.imgNoteGreen.setImageResource(0)
            binding.imgNoteOrange.setImageResource(R.drawable.donecheck)
            binding.imgNotePurple.setImageResource(0)
            binding.imgNoteRed.setImageResource(0)
            binding.imgNoteYellow.setImageResource(0)
            binding.imgNoteBrown.setImageResource(0)
            binding.imgNoteIndigo.setImageResource(0)
            selectedColor = "#ff6d00"

            val intent = Intent("bottom_sheet_action")
            intent.putExtra("action", "Orange")
            intent.putExtra("selectedColor", selectedColor)
            LocalBroadcastManager.getInstance(requireContext()).sendBroadcast(intent)

        }

        binding.fNotePurple.setOnClickListener {

            binding.imgNoteBlue.setImageResource(0)
            binding.imgNoteCyan.setImageResource(0)
            binding.imgNoteGreen.setImageResource(0)
            binding.imgNoteOrange.setImageResource(0)
            binding.imgNotePurple.setImageResource(R.drawable.donecheck)
            binding.imgNoteRed.setImageResource(0)
            binding.imgNoteYellow.setImageResource(0)
            binding.imgNoteBrown.setImageResource(0)
            binding.imgNoteIndigo.setImageResource(0)
            selectedColor = "#aa00ff"

            val intent = Intent("bottom_sheet_action")
            intent.putExtra("action", "Purple")
            intent.putExtra("selectedColor", selectedColor)
            LocalBroadcastManager.getInstance(requireContext()).sendBroadcast(intent)

        }

        binding.fNoteRed.setOnClickListener {

            binding.imgNoteBlue.setImageResource(0)
            binding.imgNoteCyan.setImageResource(0)
            binding.imgNoteGreen.setImageResource(0)
            binding.imgNoteOrange.setImageResource(0)
            binding.imgNotePurple.setImageResource(0)
            binding.imgNoteRed.setImageResource(R.drawable.donecheck)
            binding.imgNoteYellow.setImageResource(0)
            binding.imgNoteBrown.setImageResource(0)
            binding.imgNoteIndigo.setImageResource(0)
            selectedColor = "#d50000"

            val intent = Intent("bottom_sheet_action")
            intent.putExtra("action", "Red")
            intent.putExtra("selectedColor", selectedColor)
            LocalBroadcastManager.getInstance(requireContext()).sendBroadcast(intent)

        }

        binding.fNoteYellow.setOnClickListener {

            binding.imgNoteBlue.setImageResource(0)
            binding.imgNoteCyan.setImageResource(0)
            binding.imgNoteGreen.setImageResource(0)
            binding.imgNoteOrange.setImageResource(0)
            binding.imgNotePurple.setImageResource(0)
            binding.imgNoteRed.setImageResource(0)
            binding.imgNoteYellow.setImageResource(R.drawable.donecheck)
            binding.imgNoteBrown.setImageResource(0)
            binding.imgNoteIndigo.setImageResource(0)
            selectedColor = "#ffeb3b"

            val intent = Intent("bottom_sheet_action")
            intent.putExtra("action", "Yellow")
            intent.putExtra("selectedColor", selectedColor)
            LocalBroadcastManager.getInstance(requireContext()).sendBroadcast(intent)

        }

        binding.fNoteBrown.setOnClickListener {

            binding.imgNoteBlue.setImageResource(0)
            binding.imgNoteCyan.setImageResource(0)
            binding.imgNoteGreen.setImageResource(0)
            binding.imgNoteOrange.setImageResource(0)
            binding.imgNotePurple.setImageResource(0)
            binding.imgNoteRed.setImageResource(0)
            binding.imgNoteYellow.setImageResource(0)
            binding.imgNoteBrown.setImageResource(R.drawable.donecheck)
            binding.imgNoteIndigo.setImageResource(0)
            selectedColor = "#3e434e"

            val intent = Intent("bottom_sheet_action")
            intent.putExtra("action", "Brown")
            intent.putExtra("selectedColor", selectedColor)
            LocalBroadcastManager.getInstance(requireContext()).sendBroadcast(intent)

        }

        binding.fNoteIndigo.setOnClickListener {

            binding.imgNoteBlue.setImageResource(0)
            binding.imgNoteCyan.setImageResource(0)
            binding.imgNoteGreen.setImageResource(0)
            binding.imgNoteOrange.setImageResource(0)
            binding.imgNotePurple.setImageResource(0)
            binding.imgNoteRed.setImageResource(0)
            binding.imgNoteYellow.setImageResource(0)
            binding.imgNoteBrown.setImageResource(0)
            binding.imgNoteIndigo.setImageResource(R.drawable.donecheck)
            selectedColor = "#3e434e"

            val intent = Intent("bottom_sheet_action")
            intent.putExtra("action", "Indigo")
            intent.putExtra("selectedColor", selectedColor)
            LocalBroadcastManager.getInstance(requireContext()).sendBroadcast(intent)

        }
        // FINISH COLORS

        // ADD IMAGE
        binding.llAddImage.setOnClickListener {

            val intent = Intent("bottom_sheet_action")
            intent.putExtra("action", "Image")
            LocalBroadcastManager.getInstance(requireContext()).sendBroadcast(intent)
            dismiss()

        }

        // ADD URL
        binding.llAddUrl.setOnClickListener {

            val intent = Intent("bottom_sheet_action")
            intent.putExtra("action", "WebUrl")
            LocalBroadcastManager.getInstance(requireContext()).sendBroadcast(intent)
            dismiss()

        }

        // Delete Notes
        binding.llDeleteNote.setOnClickListener {

            val intent = Intent("bottom_sheet_action")
            intent.putExtra("action", "DeleteNote")
            LocalBroadcastManager.getInstance(requireContext()).sendBroadcast(intent)
            dismiss()

        }


    }

}