package com.photogallery.secret.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.core.content.ContextCompat
import com.bumptech.glide.Glide
import com.google.android.material.imageview.ShapeableImageView
import com.photogallery.R
import com.photogallery.model.AlbumData

import androidx.recyclerview.widget.RecyclerView

class SelectAlbumAdapter(
    private val context: Context,
    private val albumList: ArrayList<AlbumData>,
    val clickListener: (pos: Int) -> Unit,
) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    fun setSelection(position: Int) {
        clickListener.invoke(position)
    }

    override fun getItemCount(): Int = albumList.size

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        val inflater = LayoutInflater.from(context)

        //when (viewType) {
//            VIEW_TYPE_HEADER -> {
//                val view = inflater.inflate(R.layout.item_select_header, parent, false)
//                HeaderViewHolder(view)
//            }
//            else -> {
        val view = inflater.inflate(R.layout.item_select_image_folder, parent, false)
        return ItemViewHolder(view)
//            }
        //}
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        val albumData = albumList[position]

        when (holder) {
//            is HeaderViewHolder -> {
//                holder.itemTextView.text = albumData.title
//                holder.itemTextView.setTextColor(
//                    ContextCompat.getColor(context, R.color.black_text)
//                )
//                holder.itemTextView.visibility = View.VISIBLE
//            }

            is ItemViewHolder -> {
                holder.txtTitle.text = albumData.title
                holder.txtCount.text = albumData.mediaData.size.toString()

                if (albumData.mediaData.isNotEmpty()) {
                    Glide.with(context.applicationContext)
                        .load(albumData.mediaData[0].filePath)
                        .into(holder.image)
                }
                holder.itemView.setOnClickListener {
                    clickListener.invoke(position)
                }

//                holder.topView.visibility = if (position == 0) View.VISIBLE else View.GONE
//                holder.bottomView.visibility = if (position == albumList.size - 1) View.VISIBLE else View.GONE
            }
        }
    }

//    class HeaderViewHolder(view: View) : RecyclerView.ViewHolder(view) {
//        val itemTextView: TextView = view.findViewById(R.id.txtItem)
//    }

    class ItemViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val txtTitle: TextView = view.findViewById(R.id.txtTitle)
        val txtCount: TextView = view.findViewById(R.id.txtCount)
        val image: ShapeableImageView = view.findViewById(R.id.image)
//        val topView: View = view.findViewById(R.id.topView)
//        val bottomView: View = view.findViewById(R.id.bottomView)
    }
}


//class SelectAlbumAdapter(
//    private val context: Context,
//    private val albumList: ArrayList<AlbumData>
//) : BaseAdapter() {
//    override fun getCount(): Int {
//        return albumList.size
//    }
//
//    override fun getItem(position: Int): Any {
//        return albumList[position]
//    }
//
//    override fun getItemId(position: Int): Long {
//        return position.toLong()
//    }
//
//    override fun getDropDownView(position: Int, convertView: View?, parent: ViewGroup?): View {
//        val view: View
//        val viewHolder: ViewHolderView
//
//        if (convertView == null) {
//            view = LayoutInflater.from(context).inflate(R.layout.item_select_image_folder, parent, false)
//            viewHolder = ViewHolderView(view)
//            view.tag = viewHolder
//        } else {
//            view = convertView
//            viewHolder = view.tag as ViewHolderView
//        }
//
//        val albumData = albumList[position]
//        viewHolder.txtTitle.text = albumData.title
//
//        if (albumData.mediaData.isNotEmpty()) {
//            viewHolder.txtCount.text = "${albumData.mediaData.size}"
//
//            Glide.with(context.applicationContext).load(albumData.mediaData[0].filePath)
//               .into(viewHolder.image)
//
//        } else {
//            viewHolder.txtCount.text  = "0"
//        }
//
//        viewHolder.topView.visibility =  if (position == 0) View.VISIBLE else View.GONE
//        viewHolder.bottomView.visibility =  if (position == albumList.size -1) View.VISIBLE else View.GONE
//
////        val params = convertView.layoutParams
////        params.height = 250
////        convertView.layoutParams = params
//
//        return view
//
//    }
//
//    override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
//        val view: View
//        val viewHolder: ViewHolder
//
//        if (convertView == null) {
//            view = LayoutInflater.from(context).inflate(R.layout.item_select_header, parent, false)
//            viewHolder = ViewHolder(view)
//            view.tag = viewHolder
//        } else {
//            view = convertView
//            viewHolder = view.tag as ViewHolder
//        }
//
//        val item = albumList[position]
//        viewHolder.itemTextView.text = item.title
//        viewHolder.itemTextView.setTextColor(
//            ContextCompat.getColor(
//                context,
//                R.color.black_text
//            )
//        )
//        viewHolder.itemTextView.visibility = View.VISIBLE
//
//
//        return view
//    }
//
//
//    private class ViewHolder(view: View) {
//        val itemTextView: TextView = view.findViewById(R.id.txtItem)
//    }
//
//    private class ViewHolderView(view: View) {
//        val txtTitle: TextView = view.findViewById(R.id.txtTitle)
//        val txtCount: TextView = view.findViewById(R.id.txtCount)
//        val image: ShapeableImageView = view.findViewById(R.id.image)
//        val topView: View = view.findViewById(R.id.topView)
//        val bottomView: View = view.findViewById(R.id.bottomView)
//    }
//}