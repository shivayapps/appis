package com.messenger.sms.text.feature.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import androidx.recyclerview.widget.RecyclerView
import com.messenger.sms.text.utils.gone
import com.messenger.sms.text.utils.visible
import com.messenger.sms.text.R
import com.messenger.sms.text.common.PreferanceData.AppPreference
import com.messenger.sms.text.databinding.ItemFilterCategoryBinding

class FilterCategoryAdapter(
    var list: MutableList<Pair<String, Int>>,
    var mContext: android.content.Context,
    private val listener: (Int) -> Unit
) : RecyclerView.Adapter<FilterCategoryAdapter.HolderCategory>() {


    class HolderCategory(
        var mItemBind: ItemFilterCategoryBinding,
        var categoryHomeAdapter: FilterCategoryAdapter
    ) :
        RecyclerView.ViewHolder(mItemBind.root) {
        fun setData(position: Int, listener: (Int) -> Unit) {
            val pair = categoryHomeAdapter.list[position]
            mItemBind.tvCatName.text = pair.first
            if (position == AppPreference(mItemBind.viewSelect.context).selectFilterPos
            ) {
                mItemBind.viewSelect.visible()
            } else {
                mItemBind.viewSelect.gone()
            }
            mItemBind.lnrCatItem.setOnClickListener {
                listener(position)
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): HolderCategory {
        val mItemBind: ItemFilterCategoryBinding = DataBindingUtil.inflate(
            LayoutInflater.from(parent.context),
            R.layout.item_filter_category,
            parent,
            false
        )
        return HolderCategory(mItemBind, this)
    }

    override fun onBindViewHolder(holder: HolderCategory, position: Int) {
        holder.setData(position, listener)
    }

    override fun getItemCount(): Int {
        return list.size
    }

}