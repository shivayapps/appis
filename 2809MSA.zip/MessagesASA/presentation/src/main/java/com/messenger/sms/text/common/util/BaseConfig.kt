package com.messenger.sms.text.common.util

import android.content.Context
import gallery.app.picasa.web.albums.photo.folder.gallery.commons.extensions.getSharedPrefs
import com.messenger.sms.text.common.PreferanceData.PreferenceKeys.is_ads_remove

open class BaseConfig(val context: Context) {
    protected val prefs = context.getSharedPrefs()

    companion object {
        fun newInstance(context: Context) = BaseConfig(context)
    }

//    var isNeedInterAd: Boolean
//        get() = prefs.getBoolean("isNeedInterAd", true)
//        set(allowVideoGestures) = prefs.edit().putBoolean("isNeedInterAd", allowVideoGestures).apply()

    var ads_free: Boolean
        get() = prefs.getBoolean(is_ads_remove, false)
        set(show) = prefs.edit().putBoolean(is_ads_remove, show).apply()
//    var ads_free = true


}