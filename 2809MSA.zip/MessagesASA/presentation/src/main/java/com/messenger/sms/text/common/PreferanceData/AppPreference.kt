package com.messenger.sms.text.common.PreferanceData

import android.content.Context
import android.content.SharedPreferences
import com.messenger.sms.text.common.util.extensions.LogE
import java.util.Locale
import javax.inject.Inject

class AppPreference @Inject constructor(private val context: Context) {

    companion object {
        lateinit var sharedPreferences: SharedPreferences

        fun isInitSharedPref() = ::sharedPreferences.isInitialized
    }

    fun initPrefs() {
        sharedPreferences = context.getSharedPreferences("Prefs", Context.MODE_PRIVATE)
    }

    var sessionCounter: Int
        get() = sharedPreferences.getInt("sessionCounter", 0)
        set(splashCounter) = sharedPreferences.edit().putInt("sessionCounter", splashCounter).apply()

    var isFirstTime: Boolean
        get() = sharedPreferences.getBoolean("for_first_time", true)
        set(value) = sharedPreferences.edit().putBoolean("for_first_time", value).apply()
    var isSetLanguage: Boolean
        get() = sharedPreferences.getBoolean("isSetLanguage", true)
        set(value) = sharedPreferences.edit().putBoolean("isSetLanguage", value).apply()
    var isContactChange: Boolean
        get() = sharedPreferences.getBoolean("contact_change", true)
        set(value) = sharedPreferences.edit().putBoolean("contact_change", value).apply()
    var isScheduledClick: Boolean
        get() = sharedPreferences.getBoolean("scheduledClick", true)
        set(value) = sharedPreferences.edit().putBoolean("scheduledClick", value).apply()
    var isFirstSync: Boolean
        get() = sharedPreferences.getBoolean("first_time_sync", false)
        set(value) = sharedPreferences.edit().putBoolean("first_time_sync", value).apply()
    var isWidgetEnable: Boolean
        get() = sharedPreferences.getBoolean("widgetEnable", false)
        set(value) = sharedPreferences.edit().putBoolean("widgetEnable", value).apply()

    var selectFilterPos: Int
        get() = sharedPreferences.getInt("select_filter_pos", 0)
        set(value) = sharedPreferences.edit().putInt("select_filter_pos", value).apply()
    var selectCatPos: Int
        get() = sharedPreferences.getInt("select_cat_pos", 0)
        set(value) = sharedPreferences.edit().putInt("select_cat_pos", value).apply()
    var localeCountryCode: String
        get() = sharedPreferences.getString("localeCountryCode", "en")?: Locale.getDefault().language
        set(value) = sharedPreferences.edit().putString("localeCountryCode", value).apply()
    var localeCountryName: String
        get() = sharedPreferences.getString("localization_country_name", "en")?: Locale.getDefault().language
        set(value) = sharedPreferences.edit().putString("localization_country_name", value).apply()
    var selectedTitle: String
        get() = sharedPreferences.getString("selected_title", "")?: ""
        set(value) = sharedPreferences.edit().putString("selected_title", value).apply()
    var fcmToken: String
        get() = sharedPreferences.getString("fcm_token", "")?: ""
        set(value) = sharedPreferences.edit().putString("fcm_token", value).apply()


    var updateCancelCounter: Int
        get() = sharedPreferences.getInt("updateCancelCounter", 0)
        set(value) = sharedPreferences.edit().putInt("updateCancelCounter", value).apply()

//    fun getBooleanData(key: String?, def: Boolean): Boolean {
//        return try {
//            sharedPreferences.getBoolean(key, def)
//        } catch (e: Exception) {
//            false
//        }
//    }

    fun getIntData(key: String?): Int {
        return try {
            sharedPreferences.getInt(key, 1) ?: 0
        } catch (e: Exception) {
            0
        }
    }

    fun getIntData(key: String?, def: Int): Int {
        return try {
            sharedPreferences
                .getInt(key, def)
                ?: 0
        } catch (e: Exception) {
            0
        }
    }

    fun getStringData(key: String): String? {
        return if (key.contains("app_version_code")) {
            try {
                sharedPreferences.getString(key, "")
            } catch (e: Exception) {
                ""
            }
        } else {
            sharedPreferences.getString(key, "")
        }
    }

    fun saveData(key: String?, `val`: String?) {

        sharedPreferences.edit().putString(key, `val`)
            .apply()
    }

    fun saveData(key: String?, `val`: Int) {
        sharedPreferences.edit().putInt(key, `val`)
            .apply()
    }




    fun saveData(key: String?, boolean: Boolean) {

        LogE("saveData: ", "--------if")
        sharedPreferences.edit()
            .putBoolean(key, boolean)
            .apply()
    }

    fun saveData(key: String?, `val`: Float) {
        sharedPreferences
            .edit()
            .putFloat(key, `val`)
            .apply()
    }

    fun saveData(key: String?, `val`: Long) {
        sharedPreferences
            .edit()
            .putLong(key, `val`)
            .apply()
    }
}