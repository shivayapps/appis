package com.messenger.sms.text.common.PreferanceData;

public class PreferenceKeys {

    public static  String IS_MODE_CHANGE = "IS_MODE_CHANGE";

    public static boolean Is_Reload = false;
    public static String is_ads_remove = "ads_free";

}
