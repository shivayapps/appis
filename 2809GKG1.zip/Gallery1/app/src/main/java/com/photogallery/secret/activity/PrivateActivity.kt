package com.photogallery.secret.activity

import android.annotation.SuppressLint
import android.content.Intent
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.ActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.FileProvider
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.RecyclerView
import com.adconfig.AdsConfig
import com.adconfig.adsutil.Config.checkReInter
import com.adconfig.adsutil.admob.AdmobBanner
import com.adconfig.adsutil.admob.AdmobIntersAdImpl
import com.adconfig.adsutil.admob.AdmobNative
import com.photogallery.R
import com.photogallery.activities.SettingActivity
import com.photogallery.customview.MyGridLayoutManager
import com.photogallery.customview.MyRecyclerView
import com.photogallery.database.AppDatabase
import com.photogallery.databinding.ActivityPrivateBinding
import com.photogallery.databinding.PopBottomMenuBinding

import com.photogallery.dialog.ChangLockStyleDialog
import com.photogallery.dialog.ActionConfirmationDialog
import com.photogallery.dialog.CreateAlbumDialog
import com.photogallery.dialog.DeleteDialog
import com.photogallery.dialog.PrivateOptionsDialog
import com.photogallery.dialog.ProgressDialog
import com.photogallery.dialog.SecurityMailDialog
import com.photogallery.event.DeleteEvent
import com.photogallery.event.DisplayDeleteEvent
import com.photogallery.event.HideEvent
import com.photogallery.event.RestoreDataEvent
import com.photogallery.extension.beGone
import com.photogallery.extension.toast
import com.photogallery.model.AlbumData
import com.photogallery.model.MediaData
import com.photogallery.secret.LockQuestionActivity
import com.photogallery.secret.LockSetActivity
import com.photogallery.secret.adapter.PrivateAlbumAdapter
import com.photogallery.utils.AdUtils
import com.photogallery.utils.Constant
import com.photogallery.utils.MAX_COLUMN_COUNT_ALBUM
import com.photogallery.utils.PopupWindowHelper
import com.photogallery.utils.Preferences
import com.photogallery.utils.Utils
import io.reactivex.Observable
import io.reactivex.schedulers.Schedulers
import org.greenrobot.eventbus.Subscribe
import org.greenrobot.eventbus.ThreadMode
import java.io.File
import java.util.Collections
import kotlin.collections.ArrayList
import kotlin.math.max
import kotlin.math.min

class PrivateActivity : AppCompatActivity() {

    var allList = ArrayList<MediaData>()
    var pictures = ArrayList<Any>()
    var albumList = ArrayList<AlbumData>()

    var pictureAdapter: PrivateAlbumAdapter? = null
    lateinit var preferences: Preferences
    lateinit var dataBase: AppDatabase
    lateinit var activity: AppCompatActivity
    var mSelectedItem = 0
    var selectedItem = 0

    lateinit var binding: ActivityPrivateBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        preferences = Preferences(this)
        if (preferences.isNeedInterAd) {
            AdmobIntersAdImpl().load(this, getString(R.string.inter_all))
        } else {
            checkReInter {
                if (it) {
                    AdmobIntersAdImpl().load(this, getString(R.string.inter_all))
                    preferences.isNeedInterAd = true
                }
            }
        }
        binding = ActivityPrivateBinding.inflate(layoutInflater)
        enableEdgeToEdge()
        setContentView(binding.root)
        ViewCompat.setOnApplyWindowInsetsListener(binding.root) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
//        WindowCompat.getInsetsController(window, window.decorView).apply {
//            isAppearanceLightStatusBars = false
//            isAppearanceLightNavigationBars = true
//        }
        //updateStatusBarColor(Color.parseColor("#161616"))
        loadPriorityAds()

        activity = this@PrivateActivity

        intView()

    }

    private fun loadPriorityAds() {
        if (preferences.bannerPriority == "native") {
            AdmobNative().preLoad(this, AdUtils.getNativeID(this)) { isLoaded ->
                if (isLoaded) {
                    AdmobNative().showNativeAd(this, binding.frameAd)
                } else if (preferences.handleFailed) {
                    loadAdmobBanner()
                } else binding.frameAd.beGone()
            }
        } else if (preferences.bannerPriority == "banner") {
            AdmobBanner().preLoad(this, AdUtils.getBannerID(this)) { isLoaded ->
                if (isLoaded) {
                    AdmobBanner().showBannerAd(this, binding.frameAd)
                } else if (preferences.handleFailed) {
                    loadNativeBanner()
                } else binding.frameAd.beGone()
            }
        } else {
            binding.frameAd.beGone()
        }
    }

    private fun loadNativeBanner() {
        AdmobNative().preLoad(this, AdUtils.getNativeID(this)) { isLoaded ->
            if (isLoaded) {
                AdmobNative().showNativeAd(this, binding.frameAd)
            } else binding.frameAd.beGone()
        }
    }

    private fun loadAdmobBanner() {
        AdmobBanner().preLoad(this, AdUtils.getBannerID(this)) { isLoaded ->
            if (isLoaded) {
                AdmobBanner().showBannerAd(this, binding.frameAd)
            } else binding.frameAd.beGone()
        }
    }

    fun longClickListener(isShowSelection: Boolean, selected: Int, isAllSelect: Boolean) {
        setToolbarSelectionMaintain(isShowSelection, selected, isAllSelect)
    }


    var isSelectAll = false
    private fun setToolbarSelectionMaintain(
        isShowSelection: Boolean,
        selectedItem: Int,
        isAllSelect: Boolean
    ) {
        mSelectedItem = selectedItem
        binding.loutToolbar.visibility = View.VISIBLE

        if (isShowSelection) {
            binding.btnUnhide.visibility = View.VISIBLE
            binding.btnHide.visibility = View.GONE
            binding.btnMore.visibility = View.GONE
        }

        binding.groupToolbarSelectHeader.visibility =
            if (isShowSelection) View.VISIBLE else View.GONE

        isSelectAll = isAllSelect

        binding.loutSelectOption.visibility =
            if (isShowSelection && selectedItem != 0) View.VISIBLE else View.GONE

//        binding.btnRename.alpha = if (selectedItem == 1) 1.0f else 0.5f

        binding.groupToolbarHeader.visibility = if (isShowSelection) View.GONE else View.VISIBLE
        binding.icImport.visibility = if (isShowSelection) View.GONE else View.VISIBLE

        binding.txtSelectCount.text = "$selectedItem ${getString(R.string.items_selected)}"
        setSelectAllColor()
    }

    private fun setSelectAllColor() {
//        val color = if (isSelectAll) Color.parseColor("#FFFFFF") else Color.parseColor("#717171")
//        binding.icSelect.setColorFilter(color, PorterDuff.Mode.SRC_IN)
        binding.icSelect.setImageResource(if (isSelectAll) R.drawable.ic_select_all else R.drawable.ic_unselect_all)
    }

    private fun intView() {

        dataBase = AppDatabase.getInstance(activity)

        getData()
//        binding.swipeRefreshLayout.setOnRefreshListener {
//            if (binding.swipeRefreshLayout.isEnabled)
//                getData()
//            else
//                binding.swipeRefreshLayout.isRefreshing = false
//        }
        intListener()
    }


    var lockActivityResultLauncher = registerForActivityResult<Intent, ActivityResult>(
        ActivityResultContracts.StartActivityForResult()
    ) { result: ActivityResult ->
        if (result.resultCode == RESULT_OK) {
//            activity.setResult(AppCompatActivity.RESULT_OK)
//            if (isForgotPassOpen) {
//                isForgotPassOpen = false
//                changeLockStyle()
//                checkSwipe()
//            } else
//                lockListener(true)
        } else {
            intView()
        }
//        activity.finish()
    }

    private fun showPrivateMenu() {

        val dialog = PrivateOptionsDialog(this, clickListener = {
            when (it) {
                1 -> {
                    // ChangePassword
                    val intent = Intent(this, LockSetActivity::class.java)
                    intent.putExtra(Constant.EXTRA_CHANGE_PASS, true)
                    startActivity(intent)
                }

                2 -> {
                    //ChangeEmail
//                    if (preferences.securityEmail.isNotEmpty()) {
//                        binding.btnSetMail.beGone()
//                        binding.btnChangeMail.beVisible()
//                    } else {
//                        binding.btnSetMail.beVisible()
//                        binding.btnChangeMail.beGone()
//                    }
                    val securityMailDialog = SecurityMailDialog(
                        activity,
                        updateListener = {
                            if(it) {
                                toast(getString(R.string.security_mail_updated))
                                if(preferences.securityEmail.isNotEmpty()) binding.llSecurityMail.beGone()
                            }
                        })
                    securityMailDialog.show()
                }

                3 -> {
                    // ChangeQuestion
                    val intent = Intent(this@PrivateActivity, LockQuestionActivity::class.java)
                    intent.putExtra("type", 0)
                    intent.putExtra("isChangePass", true)
                    questionResetLauncher.launch(intent)
                }

                4 -> {
                    //ChangeLockStyle
                    showLockStyleDialog()
                }

//                5 -> {
//                    //Feedback
//                    val intent = Intent(this, FeedbackActivity::class.java)
//                    startActivity(intent)
//                }

                6 -> {
                    //Setting
                    settingLauncher.launch(Intent(this, SettingActivity::class.java))
                }

                7 -> {
                    //RecycleBin
                    vaultLauncher.launch(Intent(this, VaultDeleteActivity::class.java))
                }

            }
        })
        dialog.show()
    }


    var settingLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == RESULT_OK) {
                val intent = intent
                finish()
                overridePendingTransition(0, 0)
                startActivity(intent)
                overridePendingTransition(0, 0)
                Constant.isChangeLanguage = false
            } else if (Constant.isChangeLanguage) {
                Constant.isChangeLanguage = false
                val intent = intent
                finish()
                overridePendingTransition(0, 0)
                startActivity(intent)
                overridePendingTransition(0, 0)
            }
        }


    var questionResetLauncher = registerForActivityResult<Intent, ActivityResult>(
        ActivityResultContracts.StartActivityForResult()
    ) { result: ActivityResult ->
        if (result.resultCode == RESULT_OK) {
            toast(getString(R.string.security_question_changed))
        }
    }
    var vaultLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            intView()
        }


    private fun showLockStyleDialog() {

        val viewTypeDialog = ChangLockStyleDialog(this@PrivateActivity, updateListener = {
            val intent = Intent(this@PrivateActivity, LockSetActivity::class.java)
            intent.putExtra(Constant.EXTRA_CHANGE_LOCK_STYLE, true)
            intent.putExtra(Constant.EXTRA_LOCK_STYLE, it)
            startActivity(intent)
//                changeLockStyleActivityResultLauncher.launch(intent)
        })
        viewTypeDialog.show()

    }

    private fun disableScroll() {
        binding.pictureRecycler.suppressLayout(true)
    }

    private fun enableScroll() {
        binding.pictureRecycler.suppressLayout(false)
    }

    override fun onBackPressed() {

        if (preferences.isNeedInterAd) {
            AdsConfig.showInterstitialAd(this) {
                if (it) preferences.isNeedInterAd = false

                finish()
            }
        } else {
            super.onBackPressed()
        }
    }

    private fun intListener() {
        binding.icBack.setOnClickListener {
            onBackPressed()
        }
        binding.icImport.setOnClickListener {
            val intent = Intent(activity, SelectImageActivity::class.java)
            intent.putExtra(Constant.EXTRA_SELECT_TYPE, Constant.SELECT_TYPE_HIDE)
            selectImageActivityResultLauncher.launch(intent)
        }
        binding.btnImport.setOnClickListener {
            val intent = Intent(activity, SelectImageActivity::class.java)
            intent.putExtra(Constant.EXTRA_SELECT_TYPE, Constant.SELECT_TYPE_HIDE)
            selectImageActivityResultLauncher.launch(intent)
        }
        binding.icMenu.setOnClickListener {
            showPrivateMenu()
        }
        binding.icClose.setOnClickListener {
            setCloseToolbar()
        }
        binding.ivIgnoreMail.setOnClickListener {
            binding.llSecurityMail.beGone()
        }
        if(preferences.securityEmail.isNotEmpty()) binding.llSecurityMail.beGone()
        binding.llSecurityMail.setOnClickListener {
            val securityMailDialog = SecurityMailDialog(
                activity,
                updateListener = {
                    if(it) {
                        toast(getString(R.string.security_mail_updated))
                        if(preferences.securityEmail.isNotEmpty()) binding.llSecurityMail.beGone()
                    }
                })
            securityMailDialog.show()
        }

        binding.icSelect.setOnClickListener {
            isSelectAll = !isSelectAll
            setSelectClick(isSelectAll)
            setSelectAllColor()
        }
        binding.btnDelete.setOnClickListener {
            showDeleteDialog()
        }

        binding.btnUnhide.setOnClickListener {
            setUnHideData()
        }

        binding.btnMore.setOnClickListener {
            showDropDown(binding.btnMore)
        }
    }

    //    lateinit var popupWindow: PopupWindow
    private fun showDropDown(view: View) {
        val layoutInflater = getSystemService(LAYOUT_INFLATER_SERVICE) as LayoutInflater
        val popUpBinding = PopBottomMenuBinding.inflate(layoutInflater)

        val popupWindow =
            PopupWindowHelper(popUpBinding.root)

        popUpBinding.loutMain.setOnClickListener {
            popupWindow.dismiss()
        }

        popUpBinding.menuCopy.setOnClickListener {
            popupWindow.dismiss()
//            if (binding.viewPager.currentItem == 0)
//                photosFragment.showAddAlbumDialog(albumFragment.albumBackupList, true)
        }
        popUpBinding.menuMove.setOnClickListener {
            popupWindow.dismiss()
//            if (binding.viewPager.currentItem == 0)
//                photosFragment.showAddAlbumDialog(albumFragment.albumBackupList, false)
        }
        popupWindow.showAsPopUp(view)
    }

    var selectImageActivityResultLauncher = registerForActivityResult<Intent, ActivityResult>(
        ActivityResultContracts.StartActivityForResult()
    ) { result: ActivityResult ->
        if (result.resultCode == RESULT_OK) {
            Utils.hideFiles(
                activity,
                Constant.selectedImageList,
                Constant.selectedImageList.size,
                hideListener = {
                    getData()
                    Toast.makeText(
                        activity,
                        getString(R.string.hide_successfully),
                        Toast.LENGTH_SHORT
                    ).show()
                })
        }
    }

    private fun notifyAdapter() {
        if (pictureAdapter != null) {
            pictureAdapter?.notifyDataSetChanged()
            Log.e("PrivateTag", "notifyAdapter called")
        }
    }

    private fun setData() {
//        binding.swipeRefreshLayout.isRefreshing = false
        enableScroll()
        if (pictureAdapter != null) notifyAdapter() else initAdapter()
        setEmptyData()
    }

    private var lastLongPressedItem = -1

    //    private var mZoomListener: MyRecyclerView.MyZoomListener? = null
    private var mDragListener: MyRecyclerView.MyDragListener? = null

    private fun initAdapter() {
        setRvLayoutManager()
        pictureAdapter = PrivateAlbumAdapter(
            activity, albumList,
            clickListener = {

                val albumData = albumList[it]
                if (albumData.isCheckboxVisible && !albumData.isCustomAlbum) {
                    albumData.isSelected = !albumData.isSelected
                    pictureAdapter?.notifyItemChanged(it)
                    setSelectedFile()
                } else {
                    openImageList(albumData)
                }

            }, longClickListener = {
                if (!albumList[it].isCustomAlbum) {
                    lastLongPressedItem = it
                    binding.pictureRecycler.setDragSelectActive(it)
                    lastLongPressedItem = if (lastLongPressedItem == -1) {
                        it
                    } else {
                        val min = min(lastLongPressedItem, it)
                        val max = max(lastLongPressedItem, it)
                        for (i in min..max) {
                            toggleItemSelection(true, i, false)
                        }
                        it
                    }

                    if (albumList[it] is AlbumData) {
                        val pictureData = albumList[it] as AlbumData
                        for (i in albumList.indices) {
                            if (albumList[i] != null) {
                                val model = albumList[i] as AlbumData
                                model.isCheckboxVisible = true
                            }
                        }
                        pictureData.isCheckboxVisible = true
                        pictureData.isSelected = true
                        notifyAdapter()
                        setSelectedFile()
                    }
                }
            })

        binding.pictureRecycler.adapter = pictureAdapter

        initDragListener()
        setupDragListener(mDragListener)

    }


    private fun initDragListener() {

        mDragListener = object : MyRecyclerView.MyDragListener {

            override fun selectItem(position: Int) {
                toggleItemSelection(true, position, true)
            }

            override fun selectRange(
                initialSelection: Int, lastDraggedIndex: Int, minReached: Int, maxReached: Int
            ) {
                selectItemRange(
                    initialSelection,
                    Math.max(0, lastDraggedIndex),
                    Math.max(0, minReached),
                    maxReached
                )
                if (minReached != maxReached) {
                    lastLongPressedItem = -1
                }
            }

        }
//        } else {
//            mDragListener = null
//        }
    }

    fun setupDragListener(dragListener: MyRecyclerView.MyDragListener?) {
        binding.pictureRecycler.setupDragListener(dragListener)
    }

    protected fun selectItemRange(from: Int, to: Int, min: Int, max: Int) {
        if (from == to) {
            (min..max).filter { it != from }.forEach { toggleItemSelection(false, it, true) }
            return
        }

        if (to < from) {
            for (i in to..from) {
                toggleItemSelection(true, i, true)
            }

            if (min > -1 && min < to) {
                (min until to).filter { it != from }
                    .forEach { toggleItemSelection(false, it, true) }
            }

            if (max > -1) {
                for (i in from + 1..max) {
                    toggleItemSelection(false, i, true)
                }
            }
        } else {
            for (i in from..to) {
                toggleItemSelection(true, i, true)
            }

            if (max > -1 && max > to) {
                (to + 1..max).filter { it != from }.forEach { toggleItemSelection(false, it, true) }
            }

            if (min > -1) {
                for (i in min until from) {
                    toggleItemSelection(false, i, true)
                }
            }
        }
    }

    protected fun toggleItemSelection(select: Boolean, pos: Int, updateTitle: Boolean = true) {

        if (albumList[pos] is AlbumData) {
            if (select) {
                albumList[pos].isSelected = true
//                albumList[pos].isCheckboxVisible = true
//                selectedKeys.add(itemKey)
            } else {
                albumList[pos].isSelected = false
//                albumList[pos].isCheckboxVisible = true
//                selectedKeys.remove(itemKey)
            }
        }

        pictureAdapter?.notifyItemChanged(pos)
        setSelectedFile()
    }

    private fun reduceColumnCount() {
        val selectedGrid = preferences.getGridCount()
        if (selectedGrid > 2) {
            preferences.setGridCount(selectedGrid - 1)
        }
        setColumnView()
    }

    private fun setColumnView() {
        (binding.pictureRecycler.layoutManager as MyGridLayoutManager).spanCount =
            preferences.getGridCount()
        pictureAdapter?.apply {
            notifyItemRangeChanged(0, albumList.size)
        }
        setRvLayoutManager()
    }

    private fun increaseColumnCount() {
        val selectedGrid = preferences.getGridCount()
        if (selectedGrid < MAX_COLUMN_COUNT_ALBUM) {
            preferences.setGridCount(selectedGrid + 1)
        }
        setColumnView()
    }

    private fun openImageList(albumData: AlbumData) {
        if (albumData.isCustomAlbum && albumData.title == getString(R.string.add)) {
            val createDialog = CreateAlbumDialog(activity, createPathListener = { album ->

                val newData = AlbumData()
                newData.title = album
                newData.mediaData = ArrayList()
                newData.isCustomAlbum = true
                albumList.add(newData)
                notifyAdapter()

                //setCopyMove(isCopy, it, selectImage)
            }, false, true)
            createDialog.show()
        } else {
            Constant.albumData = AlbumData(
                albumData.title,
                albumData.mediaData,
                "",
                0,
                0,
                isCustomAlbum = true
            )
            val intent = Intent(this, PrivateListActivity::class.java)
//            startActivity(intent)
            albumLauncher.launch(intent)
        }
    }

    var albumLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            getData()
        }

    private fun setEmptyData() {
        if (albumList.size != 0) {
            binding.pictureRecycler.visibility = View.VISIBLE
            binding.loutNoData.visibility = View.GONE
            binding.icImport.visibility = View.VISIBLE
            //binding.llAdPlace.beVisible()
        } else {
            binding.pictureRecycler.visibility = View.GONE
            binding.loutNoData.visibility = View.VISIBLE
            binding.icImport.visibility = View.GONE
            //binding.llAdPlace.beGone()
        }
    }

    fun setRvLayoutManager() {
        val gridCount = preferences.getGridCount()

        val layoutManager = binding.pictureRecycler.layoutManager as MyGridLayoutManager
        layoutManager.orientation = RecyclerView.VERTICAL
        layoutManager.spanCount = gridCount


    }


    fun setCloseToolbar() {
        setClose()
        longClickListener(false, 0, false)
    }

    private fun setSelectedFile() {

        var selected = 0
        var allItemCount = 0
        -1
        var photosCount = 0
        var photosSelectCount = 0

        for (i in albumList.indices) {
            if (albumList[i] is AlbumData) {
                val model = albumList[i] as AlbumData
                allItemCount++
                photosCount++
                if (model.isSelected) {
                    selected++
                    photosSelectCount++
                }
            }
        }

        longClickListener(true, selected, allItemCount == selected)
        binding.swipeRefreshLayout.isEnabled = false
        selectedItem = selected
    }

    fun setSelectClick(isSelectAll: Boolean) {
        var selected = 0

        for (i in albumList.indices) {
            if (albumList[i] != null)
                if (albumList[i] is AlbumData) {
                    val model = albumList[i] as AlbumData
                    if (!model.isCustomAlbum) {
                        model.isSelected = isSelectAll
                        if (isSelectAll) selected++
                    }
                }
        }

        notifyAdapter()
        longClickListener(true, selected, isSelectAll)
        selectedItem = selected
    }

    private fun setClose() {
        for (i in albumList.indices) {
            if (albumList[i] != null) if (albumList[i] is AlbumData) {
                val model = albumList[i] as AlbumData
                model.isSelected = false
                model.isCheckboxVisible = false
                Log.e("", "setClose==>> AlbumData selection false")
            }
        }
        binding.swipeRefreshLayout.isEnabled = true
        notifyAdapter()
        selectedItem = 0
//        binding.icImport.visibility= View.VISIBLE
    }

    fun shareImages() {
        if (selectedItem == 0) {
            Toast.makeText(
                activity,
                activity.getString(R.string.please_select_image),
                Toast.LENGTH_SHORT
            ).show()
        } else {
            val uris = ArrayList<Uri>()
            for (i in albumList.indices) {
                if (albumList[i] is AlbumData) {
                    val model = albumList[i] as AlbumData
                    if (model.isSelected) {
                        val pictures = model.mediaData
                        for (j in pictures.indices) {
                            if (pictures[j] is MediaData) {
                                val pictures = pictures[j] as MediaData
                                val uri = FileProvider.getUriForFile(
                                    activity,
                                    activity.packageName + ".provider",
                                    File(pictures.filePath)
                                )
                                uris.add(uri)
                            }
                        }
                    }
                }
            }
            Utils.shareFilesList(activity, uris)
        }
    }


    fun showDeleteDialog() {
        if (selectedItem == 0) {
            Toast.makeText(
                activity,
                activity.getString(R.string.please_select_image),
                Toast.LENGTH_SHORT
            ).show()
        } else {
            val deleteDialog = DeleteDialog.newInstance(
                activity,
//                getString(R.string.selected_delete_msg),
                btnClickListener = {
                    deletePhoto(it)
                })
            deleteDialog.show()
        }
    }

    private fun deletePhoto(isPermanent: Boolean) {
        val deleteList = ArrayList<String>()

        val progressDialog = ProgressDialog(
            activity,
            R.drawable.ic_drawer_delete,
            selectedItem,
            getString(R.string.deleting),
            ""
        )
        progressDialog.show()
        Observable.fromCallable {
            val dataBase = AppDatabase.getInstance(activity)
            for (a in albumList.indices) {
                if (albumList[a].isSelected) {

//                    activity.runOnUiThread {
//                        bindingDialog.txtTitle.text = albumList[a].folderPath
//                    }
                    val pictures = albumList[a].mediaData
                    for (i in pictures.indices) {
                        if (pictures[i] != null) if (pictures[i] is MediaData) {
                            val model = pictures[i] as MediaData
//                            if (model.isSelected) {

                            val isDelete =
                                Utils.deleteHideFile(activity, model, dataBase, isPermanent)
                            if (isDelete) {
                                deleteList.add(model.filePath)
                                activity.runOnUiThread {
                                    progressDialog.setProgress(deleteList.size, selectedItem)
//                                    bindingDialog.txtProgressCount.text =
//                                        deleteList.size.toString() + "/" + selectedItem
//                                    bindingDialog.progressBar.progress = deleteList.size
                                }
                            }
//                            } else {
//                                model.isCheckboxVisible = false
//                            }
                        }
//                    else if (pictures[i] is AlbumData) {
//                        val model = pictures[i] as AlbumData
//                        model.isSelected = false
//                        model.isCheckboxVisible = false
//                    }
                    }
                    if (albumList[a] is AlbumData) {
                        val model = albumList[a] as AlbumData
                        model.isSelected = false
                        model.isCheckboxVisible = false
                    }
                }

            }

            var i = 0

            for (a in albumList.indices) {
                val pictures = albumList[a].mediaData
                while (i < pictures.size) {
                    if (pictures[i] != null) if (pictures[i] is MediaData) {
                        val model = pictures[i] as MediaData
                        model.isSelected = false
                        model.isCheckboxVisible = false

                    } else if (pictures[i] is MediaData) {
                        val model = pictures[i] as MediaData
                        if (model.isSelected) {
                            var isPre = false
                            var isNext = false
                            if (i != 0) {
                                isPre = pictures[i - 1] is MediaData
                            }
                            if (i < pictures.size - 2) {
                                isNext = pictures[i + 1] is MediaData
                            }
                            if (isPre && isNext) {
                                pictures.removeAt(i)
                                pictures.removeAt(i - 1)
                            } else if (i == pictures.size - 1) {
                                pictures.removeAt(i)
                                if (isPre) {
                                    pictures.removeAt(i - 1)
                                }
                            } else {
                                pictures.removeAt(i)
                            }
                            if (i != 0) {
                                i--
                            }
                        } else {
                            model.isSelected = false
                            model.isCheckboxVisible = false
                        }
                    }
                    i++
                }

            }
            true
        }.subscribeOn(Schedulers.io()).doOnError { _: Throwable? ->
            activity.runOnUiThread {
//                if (dialog.isShowing)
                progressDialog.dismiss()
                setBeforeDeleteUpdate(deleteList)
                setCloseToolbar()
                getData()


            }
        }.subscribe { _: Boolean? ->
            activity.runOnUiThread {
//                if (dialog.isShowing)
                progressDialog.dismiss()
                setBeforeDeleteUpdate(deleteList)
                setCloseToolbar()
                getData()

            }
        }

//        showUndoSnackbar(binding.root, selectedAlbum as ArrayList<AlbumData>)
    }

    @SuppressLint("CheckResult")
//    private fun deletePhoto() {
//        val deleteList = ArrayList<String>()
//        val bindingDialog = DialogDeleteProgressBinding.inflate(layoutInflater)
//        val dialog = Dialog(activity, R.style.Dialog)
//        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
//        dialog.setCancelable(false)
//        dialog.setContentView(bindingDialog.root)
//        dialog.setCanceledOnTouchOutside(false)
//        dialog.window?.setGravity(Gravity.BOTTOM)
//        dialog.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
//        bindingDialog.progressBar.max = selectedItem
//
//        activity.runOnUiThread {
//            bindingDialog.txtProgressCount.text = deleteList.size.toString() + "/" + selectedItem
//            bindingDialog.progressBar.progress = deleteList.size
//        }
//        dialog.show()
//
//        Observable.fromCallable {
//            val dataBase = AppDatabase.getInstance(activity)
//
//            for (i in pictures.indices) {
//                if (pictures[i] != null) if (pictures[i] is PictureData) {
//                    val model = pictures[i] as PictureData
//                    if (model.isSelected) {
//                        activity.runOnUiThread {
//                            bindingDialog.txtTitle.text = model.fileName
//                        }
//
//                        val isDelete = Utils.deleteHideFile(activity, model, dataBase)
//                        if (isDelete) {
//                            deleteList.add(model.filePath)
//                            activity.runOnUiThread {
//                                bindingDialog.txtProgressCount.text =
//                                    deleteList.size.toString() + "/" + selectedItem
//                                bindingDialog.progressBar.progress = deleteList.size
//                            }
//                        }
//                    } else {
//                        model.isCheckboxVisible = false
//                    }
//                } else if (pictures[i] is AlbumData) {
//                    val model = pictures[i] as AlbumData
//                    model.isSelected = false
//                    model.isCheckboxVisible = false
//                }
//            }
//
//            var i = 0
//            while (i < pictures.size) {
//                if (pictures[i] != null)
//                    if (pictures[i] is AlbumData) {
//                        val model = pictures[i] as AlbumData
//                        model.isSelected = false
//                        model.isCheckboxVisible = false
//
//                    } else if (pictures[i] is PictureData) {
//                        val model = pictures[i] as PictureData
//                        if (model.isSelected) {
//                            var isPre = false
//                            var isNext = false
//                            if (i != 0) {
//                                isPre = pictures[i - 1] is AlbumData
//                            }
//                            if (i < pictures.size - 2) {
//                                isNext = pictures[i + 1] is AlbumData
//                            }
//                            if (isPre && isNext) {
//                                pictures.removeAt(i)
//                                pictures.removeAt(i - 1)
//                            } else if (i == pictures.size - 1) {
//                                pictures.removeAt(i)
//                                if (isPre) {
//                                    pictures.removeAt(i - 1)
//                                }
//                            } else {
//                                pictures.removeAt(i)
//                            }
//                            if (i != 0) {
//                                i--
//                            }
//                        } else {
//                            model.isSelected = false
//                            model.isCheckboxVisible = false
//                        }
//                    }
//                i++
//            }
//            true
//        }.subscribeOn(Schedulers.io())
//            .doOnError { _: Throwable? ->
//                activity.runOnUiThread {
//                    if (dialog.isShowing)
//                        dialog.dismiss()
//                    setBeforeDeleteUpdate(deleteList)
//                }
//            }
//            .subscribe { _: Boolean? ->
//                activity.runOnUiThread {
//                    if (dialog.isShowing)
//                        dialog.dismiss()
//                    setBeforeDeleteUpdate(deleteList)
//                }
//            }
//    }

    fun setUnHideData() {
        if (selectedItem == 0) {
            Toast.makeText(
                activity,
                activity.getString(R.string.please_select_image),
                Toast.LENGTH_SHORT
            ).show()
        } else {
            val confirmationDialog = ActionConfirmationDialog(
                activity,
                getString(R.string.unhide),
                getString(R.string.unhide_msg),
                getString(R.string.ok),
                positiveBtnClickListener = {
                    unHidePhoto()
                })
            confirmationDialog.show()
        }
    }

    private fun unHidePhoto() {
        val selectImage: ArrayList<MediaData> = ArrayList()

        for (a in albumList.indices) {
            val album = albumList[a]
            if (album.isSelected) {
                selectImage.addAll(album.mediaData)
            }
        }

        Utils.unHideFiles(activity, selectImage, selectedItem, hideListener = {
            Toast.makeText(
                activity,
                getString(R.string.unhide_successfully),
                Toast.LENGTH_SHORT
            ).show()
            selectedItem = 0
            longClickListener(false, 0, false)
            setCloseToolbar()
            getData()
        })
    }

    private fun setBeforeDeleteUpdate(deleteList: ArrayList<String>) {
//        EventBus.getDefault().post(DeleteEvent(1, deleteList))
        selectedItem = 0
        notifyAdapter()
        binding.swipeRefreshLayout.isEnabled = true
        longClickListener(false, 0, false)
        setEmptyData()
        Toast.makeText(
            activity,
            getString(R.string.delete_successfully),
            Toast.LENGTH_SHORT
        ).show()
        deleteMainList(deleteList)
    }

    private fun deleteMainList(deleteList: ArrayList<String>) {
        if (deleteList.size != 0) {
//            val favList = preferences.getFavoriteList()
            for (path in deleteList) {
//                if (favList.contains(path)) {
//                    Log.e("","favList is remove")
//                    favList.remove(path)
//                }
                for (pictureData in allList) {
                    if (pictureData.filePath == path) {
                        allList.remove(pictureData)
                        break
                    }
                }
            }

//            preferences.setFavoriteList(favList)
        }
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    fun onDeleteEvent(event: DeleteEvent) {
        deleteEvent(event)
    }


    @Subscribe(threadMode = ThreadMode.MAIN)
    fun onRestoreDataEvent(event: RestoreDataEvent) {
        restoreEvent(event)
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    fun onHideEvent(event: HideEvent) {
//        getData()
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    fun onDisplayDeleteEvent(event: DisplayDeleteEvent) {
        displayDeleteEvent(event)
    }

    private fun deleteEvent(event: DeleteEvent) {
        if (event.deleteList.isNotEmpty() && event.pos != 0)
            if (pictures.isNotEmpty()) {
                updateDeleteImageData(event.deleteList)
                deleteMainList(event.deleteList)
            }
    }

    private fun restoreEvent(event: RestoreDataEvent) {
        if (event.restoreList.isNotEmpty())
            if (pictures.isNotEmpty()) {
                val list: ArrayList<String> = ArrayList()
                for (restoreData in event.restoreList) {
                    list.add(restoreData.deletedPath)
                }
                updateDeleteImageData(list)
                deleteMainList(list)
            }
    }

    private fun displayDeleteEvent(event: DisplayDeleteEvent) {
        if (event.deleteList.isNotEmpty())
            if (pictures.isNotEmpty()) {
                updateDeleteImageData(event.deleteList)
                deleteMainList(event.deleteList)
            }
    }

    private fun updateDeleteImageData(deleteList: ArrayList<String>) {
        if (pictures.isNotEmpty()) {
            for (d in deleteList.indices) {
                var i = 0
                while (i < pictures.size) {
                    if (pictures[i] is MediaData) {
                        val model = pictures[i] as MediaData
                        if (model.filePath == deleteList[d]) {
                            var isPre = false
                            var isNext = false
                            if (i != 0) {
                                isPre = pictures[i - 1] is AlbumData
                            }
                            if (i < pictures.size - 2) {
                                isNext = pictures[i + 1] is AlbumData
                            }
                            if (isPre && isNext) {
                                pictures.removeAt(i)
                                pictures.removeAt(i - 1)
                            } else if (i == pictures.size - 1) {
                                pictures.removeAt(i)
                                if (isPre) {
                                    pictures.removeAt(i - 1)
                                }
                            } else {
                                pictures.removeAt(i)
                            }
                            if (i != 0) {
                                i--
                            }
                            if (d == deleteList.size - 1) {
                                break
                            }
                        }
                    }
                    i++
                }
            }
            notifyAdapter()
            setEmptyData()
        }
    }

    private fun getData() {
        disableScroll()
//        binding.swipeRefreshLayout.isRefreshing = true

        Observable.fromCallable<Boolean> {
            getMedia()
            true
        }.subscribeOn(Schedulers.io())
            .doOnError { throwable: Throwable? ->
                activity.runOnUiThread {
                    setFilterData()
                }
            }
            .subscribe { result: Boolean? ->
                activity.runOnUiThread {
                    setFilterData()
                }
            }

    }

    private fun getMedia() {

        allList.clear()
        val hiddenList = dataBase.vaultDao().getHiddenList(false)
        try {
            if (!hiddenList.isNullOrEmpty()) {
                for (hiddenData in hiddenList) {
                    val file = File(hiddenData.hidePath)
                    if (file.exists()) {
                        val pictureData =
                            MediaData(
                                hiddenData.hidePath,
                                Utils.getUriFromPath(this@PrivateActivity, hiddenData.hidePath)
                                    .toString(),
                                file.name,
//                                file.parentFile.name,
                                hiddenData.folder,
                                file.lastModified(),
                                file.lastModified(),
                                file.length(),
                                Utils.isVideoFile(hiddenData.hidePath)
                            )
                        pictureData.isPrivate = true
                        pictureData.isFavorite = false
                        pictureData.isVideo = hiddenData.isVideo == 1
                        pictureData.idDataBase = hiddenData.id
                        pictureData.restorePath = hiddenData.restorePath

                        allList.add(pictureData)
                    }
                }

            }
        } catch (e: ArrayIndexOutOfBoundsException) {

        }
    }

    private fun setFilterData() {
        Log.e("PrivateTag", "setFilterData called")
        disableScroll()
//        binding.swipeRefreshLayout.isRefreshing = true
        setFilter()
        setData()

    }

    private fun setFilter() {
        val sortType = preferences.getSortType()
        val sortOrder = preferences.getSortOrder()

        try {

            Collections.sort(allList, Comparator { p1, p2 ->
                if (sortType == Constant.SORT_NAME) {
                    if (sortOrder == Constant.ORDER_ASCENDING)
                        p1.fileName.compareTo(p2.fileName, true)
                    else
                        p2.fileName.compareTo(p1.fileName, true)
                }
//                else if (sortType == Constant.SORT_PATH) {
//                    if (sortOrder == Constant.ORDER_ASCENDING)
//                        p1.filePath.compareTo(p2.filePath, true)
//                    else
//                        p2.filePath.compareTo(p1.filePath, true)
//                }
                else if (sortType == Constant.SORT_SIZE) {
                    if (sortOrder == Constant.ORDER_ASCENDING)
                        p1.fileSize.compareTo(p2.fileSize)
                    else
                        p2.fileSize.compareTo(p1.fileSize)
                } else if (sortType == Constant.SORT_DATE) {
                    if (sortOrder == Constant.ORDER_ASCENDING)
                        p1.date.compareTo(p2.date)
                    else
                        p2.date.compareTo(p1.date)
                }
//                else if (sortType == Constant.SORT_DATE_TAKEN) {
//                    if (sortOrder == Constant.ORDER_ASCENDING)
//                        p1.dateTaken.compareTo(p2.dateTaken)
//                    else
//                        p2.dateTaken.compareTo(p1.dateTaken)
//                }
                else
                    p2.date.compareTo(p1.date)
            })

        } catch (e: Exception) {

        }

        setList()
    }

    private fun setList() {
        pictures.clear()
        albumList.clear()

        val albumWisePictures = LinkedHashMap<String, ArrayList<MediaData>>()

        if (allList.size != 0) {
            for (pictureData in allList) {
                if (pictureData?.folderName != null) {
                    val strKey = pictureData.folderName ?: ""
                    val imagesData1: ArrayList<MediaData> = ArrayList()
                    if (albumWisePictures.containsKey(strKey)) {
                        val list2: ArrayList<MediaData>? = albumWisePictures[strKey]
                        if (list2 != null)
                            imagesData1.addAll(list2)
                    }
                    imagesData1.add(pictureData)
                    albumWisePictures[strKey] = imagesData1
                }
            }

            val keys: Set<String> = albumWisePictures.keys
            val listFolderkeys = ArrayList(keys)

            for (i in listFolderkeys.indices) {
                val imagesData: ArrayList<MediaData> = ArrayList()
                val list = albumWisePictures[listFolderkeys[i]]
                if (list != null) imagesData.addAll(list)

                if (imagesData.size != 0 && imagesData[0].folderName.isNotEmpty()) {
                    val albumData = AlbumData()

                    val folderPath = listFolderkeys[i]
                    albumData.title = folderPath
                    albumData.mediaData = imagesData
                    albumData.folderPath = folderPath
                    val file = File(folderPath)
                    albumData.date = file.lastModified()
                    albumData.fileSize = file.length()
                    albumList.add(albumData)
                    Log.e(
                        "setList",
                        "bucketData:$folderPath, ${albumList.size}, ${imagesData.size}"
                    )

                }
            }

        }


    }


}