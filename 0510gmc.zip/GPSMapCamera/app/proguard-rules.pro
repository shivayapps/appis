# Add project specific ProGuard rules here.
# You can control the set of applied configuration files using the
# proguardFiles setting in build.gradle.kts.
#
# For more details, see
#   http://developer.android.com/guide/developing/tools/proguard.html

# If your project uses WebView with JS, uncomment the following
# and specify the fully qualified class name to the JavaScript interface
# class:
#-keepclassmembers class fqcn.of.javascript.interface.for.webview {
#   public *;
#}

# Uncomment this to preserve the line number information for
# debugging stack traces.
#-keepattributes SourceFile,LineNumberTable

# If you keep the line number information, uncomment this to
# hide the original source file name.
#-renamesourcefileattribute SourceFile

-keepattributes Signature
-keep class com.timestamp.gpsmap.models.ListItem { *; }
-keep public class com.timestamp.gpsmap.cameraview.filter.** { *; }
-keep public class com.timestamp.gpsmap.cameraview.filters.** { *; }
-keep class com.ads.module.adutills.Response { *; }
-keep interface com.ads.module.adutills.ApiService { *; }
# Gson specific classes
-keep class com.jeremyliao.liveeventbus.** { *; }
-keep class androidx.lifecycle.** { *; }
-keep class androidx.arch.core.** { *; }
-keep class retrofit2.* { *; }
-keep class okhttp3.* { *; }

-optimizationpasses 30
-mergeinterfacesaggressively
-dontpreverify
-optimizations !code/simplification/arithmetic

-repackageclasses 'com.timestamp.gpsmap'
-allowaccessmodification
-useuniqueclassmembernames
-keeppackagenames doNotKeepAThing

-dontwarn org.bouncycastle.jsse.BCSSLParameters
-dontwarn org.bouncycastle.jsse.BCSSLSocket
-dontwarn org.bouncycastle.jsse.provider.BouncyCastleJsseProvider
-dontwarn org.conscrypt.Conscrypt$Version
-dontwarn org.conscrypt.Conscrypt
-dontwarn org.conscrypt.ConscryptHostnameVerifier
-dontwarn org.openjsse.javax.net.ssl.SSLParameters
-dontwarn org.openjsse.javax.net.ssl.SSLSocket
-dontwarn org.openjsse.net.ssl.OpenJSSE

# To get exact line number in crashlytics
-renamesourcefileattribute SourceFile
-keepattributes SourceFile,LineNumberTable