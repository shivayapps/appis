package com.locationstamp.camera.adapters

import android.content.Context
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import com.locationstamp.camera.R
import com.locationstamp.camera.databinding.ItemLangungeBinding
import com.locationstamp.camera.models.LanguageData

class LanguageSelectionAdapter(
    var context: Context,
    var list: ArrayList<LanguageData>,
    val clickListener: (pos: Int) -> Unit
) :
    RecyclerView.Adapter<LanguageSelectionAdapter.ViewHolder>() {

    var selectPos = 0

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding =
            ItemLangungeBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(binding)
    }

    override fun getItemCount(): Int {
        return list.size
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.binding.tvTitle.text = list[position].name

        if (selectPos == position) {
            holder.binding.ivSelect.setImageDrawable(ContextCompat.getDrawable(context, R.drawable.checkbox_selected))
            holder.binding.clLang.background = context.resources.getDrawable(R.drawable.bg_lang_select)
        }
        else {
            holder.binding.ivSelect.setImageDrawable(ContextCompat.getDrawable(context, R.drawable.checkbox_unselected))
            holder.binding.clLang.background = context.resources.getDrawable(R.drawable.bg_lang_unselect)
        }

        holder.binding.root.setOnClickListener {
            val p = selectPos
            selectPos = position
            clickListener(position)
            notifyItemChanged(selectPos)
            if (p != -1)
                notifyItemChanged(p)
        }
    }

    class ViewHolder(var binding: ItemLangungeBinding) : RecyclerView.ViewHolder(binding.root) {

    }
}