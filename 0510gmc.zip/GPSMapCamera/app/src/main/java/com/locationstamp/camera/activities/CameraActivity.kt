package com.locationstamp.camera.activities

import android.Manifest
import android.app.Activity
import android.app.Dialog
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.IntentSender
import android.content.IntentSender.SendIntentException
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.PointF
import android.graphics.Typeface
import android.location.Address
import android.location.Geocoder
import android.location.Location
import android.location.LocationManager
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.CountDownTimer
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.util.Base64
import android.util.Log
import android.util.TypedValue
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.view.WindowManager
import android.view.animation.AlphaAnimation
import android.view.animation.Animation
import android.view.animation.LinearInterpolator
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.cardview.widget.CardView
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.core.content.res.ResourcesCompat
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.Observer
import androidx.recyclerview.widget.LinearLayoutManager
import com.android.volley.Request
import com.android.volley.toolbox.StringRequest
import com.android.volley.toolbox.Volley
import com.google.android.gms.common.api.GoogleApiClient
import com.google.android.gms.common.api.PendingResult
import com.google.android.gms.common.api.ResultCallback
import com.google.android.gms.common.api.Status
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationRequest
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.LocationSettingsRequest
import com.google.android.gms.location.LocationSettingsResult
import com.google.android.gms.location.LocationSettingsStatusCodes
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.MapsInitializer
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.OnMapsSdkInitializedCallback
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.MarkerOptions
import com.google.android.gms.tasks.Task
import com.google.android.material.bottomsheet.BottomSheetBehavior
import com.google.android.material.snackbar.Snackbar
import com.google.android.play.core.appupdate.AppUpdateInfo
import com.google.android.play.core.appupdate.AppUpdateManager
import com.google.android.play.core.appupdate.AppUpdateManagerFactory
import com.google.android.play.core.install.InstallStateUpdatedListener
import com.google.android.play.core.install.model.AppUpdateType
import com.google.android.play.core.install.model.InstallStatus
import com.google.android.play.core.install.model.UpdateAvailability
import com.locationstamp.camera.R
import androidx.activity.OnBackPressedCallback
import androidx.activity.enableEdgeToEdge
import androidx.annotation.DrawableRes
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsControllerCompat
import com.adconfig.adsutil.admob.BannerAdHelper
import com.google.android.gms.ads.AdView
import com.google.android.gms.location.LocationCallback
import com.google.android.gms.location.LocationResult
import com.google.android.gms.location.Priority
import com.google.android.gms.maps.model.BitmapDescriptor
import com.google.android.gms.maps.model.BitmapDescriptorFactory
import com.locationstamp.camera.adapters.FilterRecyclerAdapter
import com.locationstamp.camera.adapters.WhiteBalanceRecyclerAdapter
import com.locationstamp.camera.cameraoptions.Option
import com.locationstamp.camera.cameraoptions.OptionView
import com.locationstamp.camera.databinding.ActivityCameraBinding
import com.locationstamp.camera.databinding.CustomNoteDialogBinding
import com.locationstamp.camera.dialogs.RatingDialog
import com.locationstamp.camera.extentions.AdCache
import com.locationstamp.camera.extentions.baseConfig
import com.locationstamp.camera.extentions.beGone
import com.locationstamp.camera.extentions.beVisible
import com.locationstamp.camera.extentions.beVisibleIf
import com.locationstamp.camera.extentions.isVisible
import com.locationstamp.camera.helper.AUTO
import com.locationstamp.camera.helper.AUTO_FIX
import com.locationstamp.camera.helper.LogUtils
import com.locationstamp.camera.helper.BLACK_AND_WHITE
import com.locationstamp.camera.helper.BRIGHTNESS
import com.locationstamp.camera.helper.CLOUDY
import com.locationstamp.camera.helper.CONTRAST
import com.locationstamp.camera.helper.CROSS_PROCESS
import com.locationstamp.camera.helper.DAYLIGHT
import com.locationstamp.camera.helper.DOCUMENTARY
import com.locationstamp.camera.helper.DUOTONE
import com.locationstamp.camera.helper.FILL_LIGHT
import com.locationstamp.camera.helper.FIVE_SECONDS
import com.locationstamp.camera.helper.FLUORESCENT
import com.locationstamp.camera.helper.FOUR_THREE
import com.locationstamp.camera.helper.GAMMA
import com.locationstamp.camera.helper.GRAIN
import com.locationstamp.camera.helper.GRAYSCALE
import com.locationstamp.camera.helper.HUE
import com.locationstamp.camera.helper.INCANDESCENT
import com.locationstamp.camera.helper.INVERT_COLORS
import com.locationstamp.camera.helper.LOMOISH
import com.locationstamp.camera.helper.NONE
import com.locationstamp.camera.helper.ONE_ONE
import com.locationstamp.camera.helper.POSTERIZE
import com.locationstamp.camera.helper.SATURATION
import com.locationstamp.camera.helper.SEPIA
import com.locationstamp.camera.helper.SHARPNESS
import com.locationstamp.camera.helper.SIXTEEN_NINE
import com.locationstamp.camera.helper.TEMPERATURE
import com.locationstamp.camera.helper.TEN_SECONDS
import com.locationstamp.camera.helper.THREE_SECONDS
import com.locationstamp.camera.helper.TINT
import com.locationstamp.camera.helper.VIGNETTE
import com.locationstamp.camera.helper.ZERO_SECONDS
import com.locationstamp.camera.helper.activity_tag
import com.locationstamp.camera.helper.ensureBackgroundThread
import com.locationstamp.camera.helper.isOnline
import com.locationstamp.camera.helper.open_tag
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.util.Date
import java.util.Locale


class CameraActivity : BaseActivity(), OptionView.Callback,
    OnMapReadyCallback, WhiteBalanceRecyclerAdapter.OnItemClickListener, FilterRecyclerAdapter.OnItemClickListener {
    private lateinit var container: FrameLayout
    private lateinit var supportMapFragment: SupportMapFragment
    private lateinit var newLayoutView: View
    private var templatePosition = 0
    private var fullscreen: Boolean = false
    private lateinit var items: List<String>
    private lateinit var filterItems: List<String>
    private lateinit var binding: ActivityCameraBinding

    //    lateinit var camera: CameraView
    private val camera: com.locationstamp.camera.cameraview.CameraView by lazy { binding.camera }
    private val controlPanel: ViewGroup by lazy { binding.controls }
    private var captureTime: Long = 0
    private lateinit var bitmap: Bitmap
    private lateinit var mFusedLocationClient: FusedLocationProviderClient
    private lateinit var locationCallback: LocationCallback
    private var googleMap: GoogleMap? = null
    var mapBitmap: Bitmap? = null
    private var mMapViewFrag: SupportMapFragment? = null
    private var timerCounter = 1
    private var seconds = 1L
    private lateinit var whiteBalanceAdapter: WhiteBalanceRecyclerAdapter
    private lateinit var filterAdapter: FilterRecyclerAdapter
    private val allFilters = com.locationstamp.camera.cameraview.filter.Filters.values()
    private var doubleBackToExitPressedOnce = false
    var aspectRatio = 4f / 3f
    private var googleApiClient: GoogleApiClient? = null

    private val PERMISSION_REQUEST_CODE_33 = 33
    private val PERMISSION_REQUEST_CODE = 999
    private val CREATE_FILE_REQUEST_CODE = 1000
    private val PERMISSION_REQUEST_CODE_LOCATION = 2
    private val PERMISSION_REQUEST_CODE_CAMERA = 22
    private val PERMISSION_REQUEST_CODE_NOTIFICATION = 44
    private val REQUEST_LOCATION = 55

    //    private var stampPosition = 0
    private var rotateDirection = 0
    private var installStateUpdatedListener: InstallStateUpdatedListener? = null
    private val REQ_CODE_VERSION_UPDATE: Int = 530
    private var appUpdateManager: AppUpdateManager? = null

    companion object {
        private val LOG = com.locationstamp.camera.cameraview.CameraLogger.create("GPSMapCamera")
        private const val USE_FRAME_PROCESSOR = false
        private const val DECODE_BITMAP = false
        var tempLatitude: Double = 0.0
        var tempLongitude: Double = 0.0
        var zoomLevel: Float = 150f
        var tempAltitude: Double = 0.0
        var tempAccuracy: Float = 0F
        var tempAddress: String = ""
        var tempWeather: String = "0"
        var tempHumidity: String = "0%"
        var tempPressure: String = "0"
        var tempWind: String = "0"

        //        var listen = MutableLiveData<String>()
        @JvmField
        var listen: MutableLiveData<Int> = MutableLiveData<Int>()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityCameraBinding.inflate(layoutInflater)
        enableEdgeToEdge()
        setContentView(binding.root)
        applyEdgeToEdgeInsets(binding.root)
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (!baseConfig.isRatingDone && !isRatingOpen) {
                    launchRateDialog()
                } else {
                    doublePressExit()
                }
            }
        })

        LogUtils.logAdapterMessages(
            this@CameraActivity,
            activity_tag,
            open_tag,
            CameraActivity::class.java.simpleName.toString()
        )
        MapsInitializer.initialize(this, MapsInitializer.Renderer.LATEST, OnMapsSdkInitializedCallback {
        })
        hideNavigationBar()
        makeStatusBarTransparent()

        isAppUpdateNeed(binding.drawerLayout)
//        if(!MyApplication.remoteConfig.getString(EventKeys.redirectLink).isNullOrEmpty()) {
//            isRedirectAvailable()
//        }
//        loadBanner()

        if (checkCameraPermissions()) {

        } else {
            requestCameraPermissions()
        }
        requestNotificationPermissions()
        camera.setLifecycleOwner(this)
        camera.addCameraListener(Listener())
//        stampPosition = baseConfig.stampPosition
        setTemplate()

        mFusedLocationClient = LocationServices.getFusedLocationProviderClient(this)
        locationCallback = object : LocationCallback() {
            override fun onLocationResult(locationResult: LocationResult) {
                for (location in locationResult.locations) {
                    Log.d("LiveLocation", "Lat: ${location.latitude}, Lng: ${location.longitude}")
                    // 👉 You can update UI or map marker here

                    if (location != null) {
                        if (location.hasAltitude()) {
                            tempAltitude = location.altitude
                        }
                        if (location.hasAccuracy()) {
                            tempAccuracy = location.accuracy
                        }

                        //tempAccuracy = task.result.accuracy
                        ensureBackgroundThread {
                            try {
                                val geocoder = Geocoder(this@CameraActivity, Locale.getDefault())
                                val list: List<Address> =
                                    geocoder.getFromLocation(location.latitude, location.longitude, 1)!!
                                Log.w("msg", "getLocation: " + list[0].getAddressLine(0))
                                Log.w("msg", "latitude: " + list[0].latitude + "longitude: " + list[0].longitude)
//                            tempLatitude = baseConfig.roundToSixDecimalPlaces(list[0].latitude)
//                            tempLongitude = baseConfig.roundToSixDecimalPlaces(list[0].longitude)

                                if (baseConfig.isAutomatic) {
                                    tempLatitude = list[0].latitude
                                    tempLongitude = list[0].longitude
                                    tempAddress = list[0].getAddressLine(0)
                                } else {
                                    tempLatitude = baseConfig.userLatitude
                                    tempLongitude = baseConfig.userLongitude
                                    tempAddress = baseConfig.userAddress
                                    discussCurrentLocation(list[0].latitude, list[0].longitude, list[0].getAddressLine(0))
                                }
//                        Toast.makeText(this@CameraActivity, "latitude: " + tempLatitude + "longitude: " + tempLongitude, Toast.LENGTH_SHORT).show()

                                runOnUiThread {
                                    moveMap()
                                    getWeather(list[0].adminArea)
                                }
                            } catch (e: Exception) {
                                Log.w("catch", "DEADLINE_EXCEEDED: $e")
                            }
                        }

                    } else {
                        Toast.makeText(this@CameraActivity, R.string.internet_permission, Toast.LENGTH_LONG).show()
                    }
                }
            }
        }
//        getLocation()
        enableLoc()

        /*val includeLayout = findViewById<View>(R.id.includeLayout)
          val options: List<Option<*>> = listOf(
            // Layout
            Option.Width(), Option.Height(),
            // Engine and preview
            Option.Mode(), Option.Engine(), Option.Preview(),
            // Some controls
            Option.Flash(), Option.WhiteBalance(), Option.Hdr(),
            Option.PictureMetering(), Option.PictureSnapshotMetering(),
            Option.PictureFormat(),
            // Video recording
            Option.PreviewFrameRate(), Option.VideoCodec(), Option.Audio(), Option.AudioCodec(),
            // Gestures
            Option.Pinch(), Option.HorizontalScroll(), Option.VerticalScroll(),
            Option.Tap(), Option.LongTap(),
            // Watermarks
            Option.OverlayInPreview(includeLayout),
            Option.OverlayInPictureSnapshot(includeLayout),
            Option.OverlayInVideoSnapshot(includeLayout),
            // Frame Processing
            Option.FrameProcessingFormat(),
            // Other
            Option.Grid(), Option.GridColor(), Option.UseDeviceOrientation()
        )
        for (i in options.indices) {
            val view = OptionView<Any>(this)
            view.setOption(options[i] as Option<Any>, this)
//            view.setHasDivider(dividers[i])
//            group.addView(view, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        }*/

        initData()
        navDrawerInit()
        whiteBalanceAdapterData()
        filterAdapterData()
        allClicks()
        iconRotationMethod()
    }


    fun makeStatusBarTransparent() {

        WindowCompat.setDecorFitsSystemWindows(window, false)
        window.statusBarColor = Color.TRANSPARENT

        window.navigationBarColor = Color.TRANSPARENT

        val controller = WindowInsetsControllerCompat(window, window.decorView)
        controller.isAppearanceLightStatusBars = true // or false based on your background
        controller.isAppearanceLightNavigationBars = false

        // Handle cutout (notch)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            val lp = window.attributes
            lp.layoutInDisplayCutoutMode =
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            window.attributes = lp
        }

        controller.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        controller.hide(WindowInsetsCompat.Type.systemBars())


    }

    fun setWindowFlag(activity: Activity, bits: Int, on: Boolean) {
        val win = activity.window
        val winParams = win.attributes
        if (on) {
            winParams.flags = winParams.flags or bits
        } else {
            winParams.flags = winParams.flags and bits.inv()
        }
        win.attributes = winParams
    }

    private fun iconRotationMethod() {
        listen.value = baseConfig.deviceOrientation
        listen.observe(this, Observer {
            //Do something with the changed value -> it
                it ->
            if (it == 90) {
                rotateDirection = -90
            } else if (it == 180) {
                rotateDirection = 180
            } else if (it == 270) {
                rotateDirection = 90
            } else {
                rotateDirection = 0
            }
            //            binding.ivCollection.rotation = it.toFloat()
            binding.clCollection.animate().rotation(rotateDirection.toFloat()).start()
            binding.clMapData.animate().rotation(rotateDirection.toFloat()).start()
            binding.clNote.animate().rotation(rotateDirection.toFloat()).start()
            binding.clTemplate.animate().rotation(rotateDirection.toFloat()).start()
            binding.ivSetting.animate().rotation(rotateDirection.toFloat()).start()
            binding.ivFlash.animate().rotation(rotateDirection.toFloat()).start()
            binding.ivCameraFlip.animate().rotation(rotateDirection.toFloat()).start()
            binding.ivMore.animate().rotation(rotateDirection.toFloat()).start()
            //            binding.frameTemplate.animate().rotation(rotateDirection.toFloat()).start()
        })
    }

    private fun setTemplate() {
        Log.w("msg", "setTemplate: ")
        templatePosition = baseConfig.templateSelected
        /*if(baseConfig.stampPosition == 0) {
            binding.frameTemplateTop.beVisible()
            binding.frameTemplate.beGone()
            container = binding.frameTemplateTop
        } else {
            binding.frameTemplate.beVisible()
            binding.frameTemplateTop.beGone()
            container = binding.frameTemplate
        }*/
        binding.frameTemplate.beVisible()
//        if (baseConfig.stampPosition == 0) {
//            (binding.frameTemplate.layoutParams as FrameLayout.LayoutParams).gravity = Gravity.TOP
//        } else {
//            (binding.frameTemplate.layoutParams as FrameLayout.LayoutParams).gravity = Gravity.BOTTOM
//        }
        container = binding.frameTemplate

        val newLayout = if (templatePosition == 0) {
            R.layout.template_layout_1
        } else if (templatePosition == 1) {
            R.layout.template_layout_2
        } else if (templatePosition == 2) {
            R.layout.template_layout_3
        } else if (templatePosition == 3) {
            R.layout.template_layout_4
        } /*else if (templatePosition == 4) {
            R.layout.template_layout_5
        } */else {
            R.layout.template_layout_1
        }

        val inflater = LayoutInflater.from(this)
        container.removeAllViews() // Remove the current layout
        try {
            newLayoutView = inflater.inflate(newLayout, container, true)
        } catch (e: Exception) {
            Log.e("catch", "setTemplate:newLayoutView " + e.toString())
            val intent = Intent(this@CameraActivity, CameraActivity::class.java)
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(intent)
        }

        /*val layoutParams: OverlayLayout.LayoutParams = newLayoutView.layoutParams as OverlayLayout.LayoutParams
// Set the new rule to align the top of the layout to the bottom of the parent container
//        layoutParams.addRule(RelativeLayout.BELOW, container.id)
        layoutParams.bottomMargin = 500
        newLayoutView.layoutParams = layoutParams*/

//        templateChange(newLayoutView!!)
//        val mapFragment = fragmentManager.findFragmentById(R.id.map) as MapFragment
//        mapFragment.getMapAsync(this)

        supportMapFragment = (supportFragmentManager.findFragmentById(R.id.mapView) as SupportMapFragment?)!!
        mMapViewFrag = supportMapFragment
        if (supportMapFragment != null) {
            supportMapFragment.getMapAsync(this)
        }
    }

    private fun whiteBalanceAdapterData() {
        val recyclerView = binding.rvWhiteBalance
        recyclerView.layoutManager = LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)
        items = listOf(
            AUTO,
            INCANDESCENT,
            FLUORESCENT,
            DAYLIGHT,
            CLOUDY
        )
        whiteBalanceAdapter = WhiteBalanceRecyclerAdapter(items, this@CameraActivity, this@CameraActivity)
        recyclerView.adapter = whiteBalanceAdapter
    }

    override fun onItemClickWhite(position: Int) {
        val clickedItem = items[position]
        when (position) {
            0 -> {
                camera.whiteBalance = com.locationstamp.camera.cameraview.controls.WhiteBalance.AUTO
                baseConfig.cameraWhiteBalance = 0
                binding.includeOptionLayout.ivBrightness.setColorFilter(ResourcesCompat.getColor(resources, R.color.white, null))
                binding.includeOptionLayout.tvBrightness.setTextColor(ResourcesCompat.getColor(resources, R.color.white, null))

            }

            1 -> {
                camera.whiteBalance = com.locationstamp.camera.cameraview.controls.WhiteBalance.INCANDESCENT
                baseConfig.cameraWhiteBalance = 1
                binding.includeOptionLayout.ivBrightness.setColorFilter(ResourcesCompat.getColor(resources, R.color.note_color, null))
                binding.includeOptionLayout.tvBrightness.setTextColor(ResourcesCompat.getColor(resources, R.color.note_color, null))
            }

            2 -> {
                camera.whiteBalance = com.locationstamp.camera.cameraview.controls.WhiteBalance.FLUORESCENT
                baseConfig.cameraWhiteBalance = 2
                binding.includeOptionLayout.ivBrightness.setColorFilter(ResourcesCompat.getColor(resources, R.color.note_color, null))
                binding.includeOptionLayout.tvBrightness.setTextColor(ResourcesCompat.getColor(resources, R.color.note_color, null))
            }

            3 -> {
                camera.whiteBalance = com.locationstamp.camera.cameraview.controls.WhiteBalance.DAYLIGHT
                baseConfig.cameraWhiteBalance = 3
                binding.includeOptionLayout.ivBrightness.setColorFilter(ResourcesCompat.getColor(resources, R.color.note_color, null))
                binding.includeOptionLayout.tvBrightness.setTextColor(ResourcesCompat.getColor(resources, R.color.note_color, null))
            }

            4 -> {
                camera.whiteBalance = com.locationstamp.camera.cameraview.controls.WhiteBalance.CLOUDY
                baseConfig.cameraWhiteBalance = 4
                binding.includeOptionLayout.ivBrightness.setColorFilter(ResourcesCompat.getColor(resources, R.color.note_color, null))
                binding.includeOptionLayout.tvBrightness.setTextColor(ResourcesCompat.getColor(resources, R.color.note_color, null))
            }
        }
    }

    private fun filterAdapterData() {
        val recyclerView = binding.rvFilter
        recyclerView.layoutManager = LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)
        filterItems = listOf(
            NONE,
            AUTO_FIX,
            BLACK_AND_WHITE,
            BRIGHTNESS,
            CONTRAST,
            CROSS_PROCESS,
            DOCUMENTARY,
            DUOTONE,
            FILL_LIGHT,
            GAMMA,
            GRAIN,
            GRAYSCALE,
            HUE,
            INVERT_COLORS,
            LOMOISH,
            POSTERIZE,
            SATURATION,
            SEPIA,
            SHARPNESS,
            TEMPERATURE,
            TINT,
            VIGNETTE
        )
        filterAdapter = FilterRecyclerAdapter(filterItems, this@CameraActivity, this@CameraActivity)
        recyclerView.adapter = filterAdapter
    }


    override fun onItemClickFilter(position: Int) {
        val clickedItem = filterItems[position]
//        var filter = allFilters[position]
        baseConfig.cameraSceneFilter = position
        camera.filter = allFilters[position].newInstance()
        if (baseConfig.cameraSceneFilter != 0) {
            binding.includeOptionLayout.ivScene.setColorFilter(ResourcesCompat.getColor(resources, R.color.note_color, null))
            binding.includeOptionLayout.tvScene.setTextColor(ResourcesCompat.getColor(resources, R.color.note_color, null))
        } else {
            binding.includeOptionLayout.ivScene.setColorFilter(ResourcesCompat.getColor(resources, R.color.white, null))
            binding.includeOptionLayout.tvScene.setTextColor(ResourcesCompat.getColor(resources, R.color.white, null))
        }
    }

    private fun initData() {
        if (baseConfig.lastImageIcon != "") {
            val b: ByteArray = Base64.decode(baseConfig.lastImageIcon, Base64.DEFAULT)
            val bitmap = BitmapFactory.decodeByteArray(b, 0, b.size)
            binding.ivCollection.setImageBitmap(Bitmap.createScaledBitmap(bitmap, 50, 50, false))
        }
        aspectRatio = baseConfig.cameraRatio
        binding.includeOptionLayout.apply {
            tvTimer.text = baseConfig.getPictureDelayText(this@CameraActivity)

            when (baseConfig.cameraGrid) {
                1 -> {
                    tvGrid.text = getString(R.string.grid_3)
                    ivGrid.setColorFilter(ResourcesCompat.getColor(resources, R.color.note_color, null))
                    tvGrid.setTextColor(ResourcesCompat.getColor(resources, R.color.note_color, null))
                }

                2 -> {
                    tvGrid.text = getString(R.string.grid_4)
                    ivGrid.setColorFilter(ResourcesCompat.getColor(resources, R.color.note_color, null))
                    tvGrid.setTextColor(ResourcesCompat.getColor(resources, R.color.note_color, null))
                }

                3 -> {
                    tvGrid.text = getString(R.string.grid_3_phi)
                    ivGrid.setColorFilter(ResourcesCompat.getColor(resources, R.color.note_color, null))
                    tvGrid.setTextColor(ResourcesCompat.getColor(resources, R.color.note_color, null))
                }

                0 -> {
                    tvGrid.text = getString(R.string.none)
                    ivGrid.setColorFilter(ResourcesCompat.getColor(resources, R.color.white, null))
                    tvGrid.setTextColor(ResourcesCompat.getColor(resources, R.color.white, null))
                }
            }

            when (baseConfig.cameraRatio) {
                4f / 3f -> {
                    tvRatio.text = getString(R.string.ratio) + "(" + FOUR_THREE + ")"
                    fullscreen = false
                }

                16f / 9f -> {
                    tvRatio.text = getString(R.string.ratio) + "(" + SIXTEEN_NINE + ")"
                    fullscreen = false
                }

                1f / 1f -> {
                    tvRatio.text = getString(R.string.ratio) + "(" + ONE_ONE + ")"
                    fullscreen = false
                }
                /*8f / 7f -> {
                    tvRatio.text = getString(R.string.full) *//*MATCH_VIEW*//*
                    fullscreen = true
                }*/
                else -> {
                    tvRatio.text = getString(R.string.ratio) + "(" + SIXTEEN_NINE + ")"
                    fullscreen = false
                }
            }
            setRatio(aspectRatio, fullscreen)

            when (baseConfig.delayPictureClick) {
                THREE_SECONDS -> {
                    tvTimer.text = getString(R.string.timer_3sec)
                    ivTimer.apply {
                        setImageDrawable(ResourcesCompat.getDrawable(resources, R.drawable.ic_timer_3sec, null))
                        setColorFilter(ResourcesCompat.getColor(resources, R.color.note_color, null))
                    }
                    tvTimer.setTextColor(ResourcesCompat.getColor(resources, R.color.note_color, null))
                }

                TEN_SECONDS -> {
                    tvTimer.text = getString(R.string.timer_10sec)
                    ivTimer.apply {
                        setImageDrawable(ResourcesCompat.getDrawable(resources, R.drawable.ic_timer_10sec, null))
                        setColorFilter(ResourcesCompat.getColor(resources, R.color.note_color, null))
                    }
                    tvTimer.setTextColor(ResourcesCompat.getColor(resources, R.color.note_color, null))
                }

                ZERO_SECONDS -> {
                    tvTimer.text = getString(R.string.timer_off)
                    ivTimer.apply {
                        setImageDrawable(ResourcesCompat.getDrawable(resources, R.drawable.ic_timer_off, null))
                        setColorFilter(ResourcesCompat.getColor(resources, R.color.white, null))
                    }
                    tvTimer.setTextColor(ResourcesCompat.getColor(resources, R.color.white, null))
                }
            }

            camera.filter = allFilters[baseConfig.cameraSceneFilter].newInstance()
            if (baseConfig.cameraSceneFilter != 0) {
                ivScene.setColorFilter(ResourcesCompat.getColor(resources, R.color.note_color, null))
                tvScene.setTextColor(ResourcesCompat.getColor(resources, R.color.note_color, null))
            }
            if (baseConfig.cameraWhiteBalance != 0) {
                ivBrightness.setColorFilter(ResourcesCompat.getColor(resources, R.color.note_color, null))
                tvBrightness.setTextColor(ResourcesCompat.getColor(resources, R.color.note_color, null))
            }

            if (baseConfig.cameraFocus == 0) {
                Option.Tap().set(camera, com.locationstamp.camera.cameraview.gesture.GestureAction.AUTO_FOCUS)
                tvFocus.text = getString(R.string.focus_auto)
                ivFocus.setColorFilter(ResourcesCompat.getColor(resources, R.color.note_color, null))
                tvFocus.setTextColor(ResourcesCompat.getColor(resources, R.color.note_color, null))
            } else if (baseConfig.cameraFocus == 1) {
                Option.Tap().set(camera, com.locationstamp.camera.cameraview.gesture.GestureAction.NONE)
                tvFocus.text = getString(R.string.focus_manual)
                ivFocus.setColorFilter(ResourcesCompat.getColor(resources, R.color.white, null))
                tvFocus.setTextColor(ResourcesCompat.getColor(resources, R.color.white, null))
            }

            when (baseConfig.cameraFlash) {
                0 -> {
                    camera.flash = com.locationstamp.camera.cameraview.controls.Flash.OFF
                    binding.ivFlash.setImageDrawable(ResourcesCompat.getDrawable(resources, R.drawable.ic_flash_off, null))
                }

                1 -> {
                    camera.flash = com.locationstamp.camera.cameraview.controls.Flash.ON
                    binding.ivFlash.setImageDrawable(ResourcesCompat.getDrawable(resources, R.drawable.ic_flash_on, null))
                }

                3 -> {
                    camera.flash = com.locationstamp.camera.cameraview.controls.Flash.TORCH
                    binding.ivFlash.setImageDrawable(ResourcesCompat.getDrawable(resources, R.drawable.ic_flash_torch, null))
                }

                2 -> {
                    camera.flash = com.locationstamp.camera.cameraview.controls.Flash.AUTO
                    binding.ivFlash.setImageDrawable(ResourcesCompat.getDrawable(resources, R.drawable.ic_flash_auto, null))
                }
            }
        }

    }

    private fun refreshData(newLayoutView: View) {
        baseConfig.stampPlusCode = com.locationstamp.camera.helper.OpenLocationCode.encode(tempLatitude, tempLongitude)
        var fontSize = baseConfig.getTextSize(this@CameraActivity)
        val typefaceCustom = when (baseConfig.stampFontStyle) {
            0 -> Typeface.createFromAsset(assets, "font/sourcecodepro_regular.ttf")
            1 -> Typeface.createFromAsset(assets, "font/robotocondensed.ttf")
            2 -> Typeface.createFromAsset(assets, "font/opensans.ttf")
            3 -> Typeface.createFromAsset(assets, "font/notosansdisplay.ttf")
            4 -> Typeface.createFromAsset(assets, "font/ibmplexsans.ttf")
            5 -> Typeface.createFromAsset(assets, "font/inter_medium.ttf")
            6 -> Typeface.createFromAsset(assets, "font/poppins_medium.ttf")
            7 -> Typeface.createFromAsset(assets, "font/roboto_medium.ttf")
            8 -> Typeface.createFromAsset(assets, "font/sf_ui_medium.otf")
            else -> Typeface.createFromAsset(assets, "font/sourcecodepro_regular.ttf")
        }
        if (findViewById<CardView>(R.id.cv_map) != null) {
            newLayoutView.apply {
                findViewById<CardView>(R.id.cv_map).beVisibleIf(baseConfig.showMap)
//                findViewById<ImageView>(R.id.iv_map_template).setImageDrawable(baseConfig.getMapTypeImage(this@TemplateEditActivity))
                findViewById<TextView>(R.id.tv_address_template).apply {
                    beVisibleIf(baseConfig.showAddress)
                    text = CameraActivity.tempAddress
                    setTextColor(baseConfig.stampColor)
                    typeface = typefaceCustom
                    setTextSize(TypedValue.COMPLEX_UNIT_PX, fontSize * 1.0f)
                }
                findViewById<TextView>(R.id.tv_lat_long_template).apply {
                    beVisibleIf(baseConfig.showLatLong)
                    text = baseConfig.formatLatLong(
                        CameraActivity.tempLatitude,
                        CameraActivity.tempLongitude
                    )
                    setTextColor(baseConfig.stampColor)
                    typeface = typefaceCustom
                    setTextSize(TypedValue.COMPLEX_UNIT_PX, fontSize * 1.0f)
                }
                findViewById<TextView>(R.id.tv_plus_code_template).apply {
                    beVisibleIf(baseConfig.showPlusCode)
                    text = "Plus code:" + baseConfig.stampPlusCode
                    setTextColor(baseConfig.stampColor)
                    typeface = typefaceCustom
                    setTextSize(TypedValue.COMPLEX_UNIT_PX, fontSize * 1.0f)
                }
                findViewById<TextView>(R.id.tv_note_template).apply {
                    beVisibleIf(baseConfig.showNote)
                    text = "Note: " + baseConfig.lastNote
                    typeface = typefaceCustom
                    setTextSize(TypedValue.COMPLEX_UNIT_PX, fontSize * 1.0f)
                }
                findViewById<TextView>(R.id.tv_time_template).apply {
                    beVisibleIf(baseConfig.showDateTime)
                    text = baseConfig.dateFormat
                    setTextColor(baseConfig.stampColor)
                    typeface = typefaceCustom
                    setTextSize(TypedValue.COMPLEX_UNIT_PX, fontSize * 1.0f)
                }
                findViewById<TextView>(R.id.tv_time_zone_template).apply {
                    beVisibleIf(baseConfig.showTimeZone)
                    text = baseConfig.getTimezoneText()
                    setTextColor(baseConfig.stampColor)
                    typeface = typefaceCustom
                    setTextSize(TypedValue.COMPLEX_UNIT_PX, fontSize * 1.0f)
                }
//                findViewById<ImageView>(R.id.iv_logo_template).apply {
//                    beVisibleIf(baseConfig.showLogo)
//                }
                findViewById<TextView>(R.id.tv_altitude_template).apply {
                    beVisibleIf(baseConfig.showAltitude)
                    text = "Altitude:" + baseConfig.getAltitudeText(this@CameraActivity)
                    setTextColor(baseConfig.stampColor)
                    typeface = typefaceCustom
                    setTextSize(TypedValue.COMPLEX_UNIT_PX, fontSize * 1.0f)
                }
                findViewById<TextView>(R.id.tv_accuracy_template).apply {
                    beVisibleIf(baseConfig.showAccuracy)
                    text = "Accuracy:" + baseConfig.getAccuracyText(this@CameraActivity)
                    setTextColor(baseConfig.stampColor)
                    typeface = typefaceCustom
                    setTextSize(TypedValue.COMPLEX_UNIT_PX, fontSize * 1.0f)
                }
                findViewById<TextView>(R.id.tv_weather_template).apply {
                    beVisibleIf(baseConfig.showWeather)
                    text = "" + baseConfig.getWeatherText(this@CameraActivity)
                    setTextColor(baseConfig.stampColor)
                    typeface = typefaceCustom
                    setTextSize(TypedValue.COMPLEX_UNIT_PX, fontSize * 1.0f)
                }
                findViewById<TextView>(R.id.tv_wind_template).apply {
                    beVisibleIf(baseConfig.showWind)
                    text = "" + baseConfig.getWindText(this@CameraActivity)
                    setTextColor(baseConfig.stampColor)
                    typeface = typefaceCustom
                    setTextSize(TypedValue.COMPLEX_UNIT_PX, fontSize * 1.0f)
                }
                findViewById<TextView>(R.id.tv_pressure_template).apply {
                    beVisibleIf(baseConfig.showPressure)
                    text = "" + baseConfig.getPressureText(this@CameraActivity)
                    setTextColor(baseConfig.stampColor)
                    typeface = typefaceCustom
                    setTextSize(TypedValue.COMPLEX_UNIT_PX, fontSize * 1.0f)
                }
                findViewById<TextView>(R.id.tv_humidity_template).apply {
                    beVisibleIf(baseConfig.showHumidity)
                    text = "" + CameraActivity.tempHumidity
                    setTextColor(baseConfig.stampColor)
                    typeface = typefaceCustom
                    setTextSize(TypedValue.COMPLEX_UNIT_PX, fontSize * 1.0f)
                }
            }
        }

        resetMap()
    }

    private fun timeCounterChange() {
        seconds = (baseConfig.delayPictureClick / 1000) % 60
        timerCounter = seconds.toInt()
    }

    private fun navDrawerInit() {
//        val toggle = ActionBarDrawerToggle(
//            this,
//            binding.drawerLayout,
//            null,
//            R.string.navigation_drawer_open,
//            R.string.navigation_drawer_close
//        )
//        binding.drawerLayout.addDrawerListener(toggle)
//        toggle.syncState()

//        binding.includedDrawer.tbTheme.isChecked = (baseConfig.themeSelectedMode == 1)
        binding.ivSetting.setOnClickListener {
            //binding.drawerLayout.openDrawer(GravityCompat.START)
            binding.includeOptionLayout.clOptionsMain.beGone()
            startActivity(Intent(this@CameraActivity, SettingActivity::class.java))
        }
//        binding.includedDrawer.clTheme.setOnClickListener {
//            binding.includedDrawer.tbTheme.toggle()
//            if (baseConfig.themeSelectedMode == 0) {
//                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES)
////                delegate.applyDayNight()
//                baseConfig.themeSelectedMode = 1
//            } else {
//                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
////                delegate.applyDayNight()
//                baseConfig.themeSelectedMode = 0
//            }
//            val intent = Intent(this@CameraActivity, CameraActivity::class.java)
//            finishAffinity()
//            overridePendingTransition(0, 0)
//            startActivity(intent)
//            overridePendingTransition(0, 0)
//        }
//        binding.includedDrawer.tvLanguagesDesc.text = baseConfig.selectLanguageString
//        binding.includedDrawer.clLanguages.setOnClickListener {
//            binding.drawerLayout.close()
//            startActivity(Intent(this@CameraActivity, LanguageActivity::class.java))
//        }
//        binding.includedDrawer.clTemplate.setOnClickListener {
////            startActivity(Intent(this@CameraActivity, TemplateActivity::class.java))
//            binding.drawerLayout.close()
//            intentLauncher.launch(Intent(this@CameraActivity, TemplateActivity::class.java).putExtra("showingTemplate", baseConfig.templateSelected))
//        }
//        binding.includedDrawer.clShare.setOnClickListener {
//            binding.drawerLayout.close()
//            baseConfig.launchShare(this@CameraActivity, packageName)
//        }
//        binding.includedDrawer.clRate.setOnClickListener {
//            binding.drawerLayout.close()
//            launchRateDialog()/*baseConfig.launchRate(this@CameraActivity, packageName)*/
//        }
//        binding.includedDrawer.clPrivacy.setOnClickListener {
//            binding.drawerLayout.close()
//            baseConfig.openWebsiteIntent(this@CameraActivity, "https://sites.google.com/view/shivayappsgallery/home")
//        }
    }

    private fun allClicks() {
        binding.clCapturePic.setOnClickListener {
//            Log.w("msg", "allClicks:flash " + camera.flash)
            binding.includeOptionLayout.clOptionsMain.beGone()
            timeCounterChange()
            if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.N) {
                baseConfig.delayPictureClick + 1000
            } else {
                baseConfig.delayPictureClick
            }
            val timer = object : CountDownTimer(baseConfig.delayPictureClick, 1000) {
                override fun onTick(millisUntilFinished: Long) {
//                    Log.w("msg", "timerCounter: " + timerCounter)
                    binding.flTimer.beVisible()
                    binding.tvTimerCounter.text = timerCounter.toString()
                    timerCounter--
                }

                override fun onFinish() {
                    capturePictureSnapshot()
//                    timerCounter = seconds.toInt()
                    binding.flTimer.beGone()
                }
            }
            timer.start()
        }
        binding.ivCameraFlip.setOnClickListener {
            toggleCamera()
        }
        binding.ivMore.setOnClickListener {
            optionLayoutVisibility()
        }
        binding.clMapData.setOnClickListener {
            binding.includeOptionLayout.clOptionsMain.beGone()
            startActivity(Intent(this@CameraActivity, LocationActivity::class.java))
        }
        binding.clNote.setOnClickListener {
            binding.includeOptionLayout.clOptionsMain.beGone()
            addNoteDialog()
//            startActivity(Intent(this@CameraActivity, com.locationstamp.camera.activities.BarcodeScanningActivity::class.java))
        }
        binding.clTemplate.setOnClickListener {
            binding.includeOptionLayout.clOptionsMain.beGone()
//            startActivity(Intent(this@CameraActivity, TemplateActivity::class.java))
            intentLauncher.launch(Intent(this@CameraActivity, TemplateListActivity::class.java).putExtra("showingTemplate", baseConfig.templateSelected))
        }
        binding.clCollection.setOnClickListener {
            binding.includeOptionLayout.clOptionsMain.beGone()
            showCollection()
        }
        binding.ivFlash.setOnClickListener {
            if (camera.flash == com.locationstamp.camera.cameraview.controls.Flash.AUTO) {
                camera.flash = com.locationstamp.camera.cameraview.controls.Flash.OFF
                binding.ivFlash.setImageDrawable(ResourcesCompat.getDrawable(resources, R.drawable.ic_flash_off, null))
                baseConfig.cameraFlash = 0
            } else if (camera.flash == com.locationstamp.camera.cameraview.controls.Flash.OFF) {
                camera.flash = com.locationstamp.camera.cameraview.controls.Flash.ON
                binding.ivFlash.setImageDrawable(ResourcesCompat.getDrawable(resources, R.drawable.ic_flash_on, null))
                baseConfig.cameraFlash = 1
            } else if (camera.flash == com.locationstamp.camera.cameraview.controls.Flash.ON) {
                camera.flash = com.locationstamp.camera.cameraview.controls.Flash.TORCH
                binding.ivFlash.setImageDrawable(ResourcesCompat.getDrawable(resources, R.drawable.ic_flash_torch, null))
                baseConfig.cameraFlash = 3
            } else if (camera.flash == com.locationstamp.camera.cameraview.controls.Flash.TORCH) {
                camera.flash = com.locationstamp.camera.cameraview.controls.Flash.AUTO
                binding.ivFlash.setImageDrawable(ResourcesCompat.getDrawable(resources, R.drawable.ic_flash_auto, null))
                baseConfig.cameraFlash = 2
            }
            Log.w("msg", "allClicks:ivFlash " + camera.flash)
        }
        binding.flTimer.setOnClickListener { }
        binding.ivCloseWhite.setOnClickListener {
            binding.clWhiteMain.beGone()
            binding.clBottom.beVisible()
        }
        binding.ivCloseFilter.setOnClickListener {
            binding.clFilterMain.beGone()
            binding.clBottom.beVisible()
        }
        binding.includeOptionLayout.apply {
            clRatio.setOnClickListener {
                /*if(aspectRatio == 8f / 7f){
                    tvRatio.text = getString(R.string.ratio) + "(" + FOUR_THREE + ")"
                    aspectRatio = 4f / 3f
                    fullscreen = false
                    baseConfig.cameraRatio = aspectRatio
                } else*/ if (aspectRatio == 4f / 3f) {
                tvRatio.text = getString(R.string.ratio) + "(" + SIXTEEN_NINE + ")"
                aspectRatio = 16f / 9f
                fullscreen = false
                baseConfig.cameraRatio = aspectRatio
            } else if (aspectRatio == 16f / 9f) {
                tvRatio.text = getString(R.string.ratio) + "(" + ONE_ONE + ")"
                aspectRatio = 1f / 1f
                fullscreen = false
                baseConfig.cameraRatio = aspectRatio
            } else if (aspectRatio == 1f / 1f) {
                /*tvRatio.text = getString(R.string.full) *//*MATCH_VIEW*//*
                    aspectRatio = 8f / 7f
                    fullscreen = true
                    baseConfig.cameraRatio = aspectRatio*/
                tvRatio.text = getString(R.string.ratio) + "(" + FOUR_THREE + ")"
                aspectRatio = 4f / 3f
                fullscreen = false
                baseConfig.cameraRatio = aspectRatio
            } else {
                tvRatio.text = getString(R.string.ratio) + "(" + SIXTEEN_NINE + ")"
                aspectRatio = 16f / 9f
                fullscreen = false
                baseConfig.cameraRatio = aspectRatio
            }
                setRatio(aspectRatio, fullscreen)
            }
            clGrid.setOnClickListener {
                if (camera.grid == com.locationstamp.camera.cameraview.controls.Grid.OFF) {
                    camera.grid = com.locationstamp.camera.cameraview.controls.Grid.DRAW_3X3
                    tvGrid.text = getString(R.string.grid_3)
                    ivGrid.setColorFilter(ResourcesCompat.getColor(resources, R.color.note_color, null))
                    tvGrid.setTextColor(ResourcesCompat.getColor(resources, R.color.note_color, null))
                    baseConfig.cameraGrid = 1
                } else if (camera.grid == com.locationstamp.camera.cameraview.controls.Grid.DRAW_3X3) {
                    camera.grid = com.locationstamp.camera.cameraview.controls.Grid.DRAW_4X4   //camera.gridColor
                    tvGrid.text = getString(R.string.grid_4)
                    ivGrid.setColorFilter(ResourcesCompat.getColor(resources, R.color.note_color, null))
                    tvGrid.setTextColor(ResourcesCompat.getColor(resources, R.color.note_color, null))
                    baseConfig.cameraGrid = 2
                } else if (camera.grid == com.locationstamp.camera.cameraview.controls.Grid.DRAW_4X4) {
                    camera.grid = com.locationstamp.camera.cameraview.controls.Grid.DRAW_PHI
                    tvGrid.text = getString(R.string.grid_3_phi)
                    ivGrid.setColorFilter(ResourcesCompat.getColor(resources, R.color.note_color, null))
                    tvGrid.setTextColor(ResourcesCompat.getColor(resources, R.color.note_color, null))
                    baseConfig.cameraGrid = 3
                } else if (camera.grid == com.locationstamp.camera.cameraview.controls.Grid.DRAW_PHI) {
                    camera.grid = com.locationstamp.camera.cameraview.controls.Grid.OFF
                    tvGrid.text = getString(R.string.none)
                    ivGrid.setColorFilter(ResourcesCompat.getColor(resources, R.color.white, null))
                    tvGrid.setTextColor(ResourcesCompat.getColor(resources, R.color.white, null))
                    baseConfig.cameraGrid = 0
                }
            }
            clFocus.setOnClickListener {
                binding.includeOptionLayout.clOptionsMain.beGone()
                Log.w("msg", "option: " + Option.Tap().get(camera))
                if (Option.Tap().get(camera) == com.locationstamp.camera.cameraview.gesture.GestureAction.NONE) {
                    Log.w("msg", "option:none ")
                    Option.Tap().set(camera, com.locationstamp.camera.cameraview.gesture.GestureAction.AUTO_FOCUS)
                    tvFocus.text = getString(R.string.focus_auto)
                    ivFocus.setColorFilter(ResourcesCompat.getColor(resources, R.color.note_color, null))
                    tvFocus.setTextColor(ResourcesCompat.getColor(resources, R.color.note_color, null))
                    baseConfig.cameraFocus = 0
                } else if (Option.Tap().get(camera) == com.locationstamp.camera.cameraview.gesture.GestureAction.AUTO_FOCUS) {
                    Log.w("msg", "option:focus ")
                    Option.Tap().set(camera, com.locationstamp.camera.cameraview.gesture.GestureAction.NONE)
                    tvFocus.text = getString(R.string.focus_manual)
                    ivFocus.setColorFilter(ResourcesCompat.getColor(resources, R.color.white, null))
                    tvFocus.setTextColor(ResourcesCompat.getColor(resources, R.color.white, null))
                    baseConfig.cameraFocus = 1
                }
            }
            clTimer.setOnClickListener {
                if (baseConfig.delayPictureClick == ZERO_SECONDS) {
                    baseConfig.delayPictureClick = THREE_SECONDS
                    tvTimer.text = getString(R.string.timer_3sec)
                    ivTimer.apply {
                        setImageDrawable(ResourcesCompat.getDrawable(resources, R.drawable.ic_timer_3sec, null))
                        setColorFilter(ResourcesCompat.getColor(resources, R.color.note_color, null))

                    }
                    tvTimer.setTextColor(ResourcesCompat.getColor(resources, R.color.note_color, null))
                } else if (baseConfig.delayPictureClick == THREE_SECONDS) {
                    baseConfig.delayPictureClick = FIVE_SECONDS
                    tvTimer.text = getString(R.string.timer_5sec)
                    ivTimer.apply {
                        setImageDrawable(ResourcesCompat.getDrawable(resources, R.drawable.ic_timer_5sec, null))
                        setColorFilter(ResourcesCompat.getColor(resources, R.color.note_color, null))
                    }
                    tvTimer.setTextColor(ResourcesCompat.getColor(resources, R.color.note_color, null))
                } else if (baseConfig.delayPictureClick == FIVE_SECONDS) {
                    baseConfig.delayPictureClick = TEN_SECONDS
                    tvTimer.text = getString(R.string.timer_10sec)
                    ivTimer.apply {
                        setImageDrawable(ResourcesCompat.getDrawable(resources, R.drawable.ic_timer_10sec, null))
                        setColorFilter(ResourcesCompat.getColor(resources, R.color.note_color, null))
                    }
                    tvTimer.setTextColor(ResourcesCompat.getColor(resources, R.color.note_color, null))
                } else if (baseConfig.delayPictureClick == TEN_SECONDS) {
                    baseConfig.delayPictureClick = ZERO_SECONDS
                    tvTimer.text = getString(R.string.timer_off)
                    ivTimer.apply {
                        setImageDrawable(ResourcesCompat.getDrawable(resources, R.drawable.ic_timer_off, null))
                        setColorFilter(ResourcesCompat.getColor(resources, R.color.white, null))
                    }
                    tvTimer.setTextColor(ResourcesCompat.getColor(resources, R.color.white, null))
                }
                timeCounterChange()
            }
            clBrightness.setOnClickListener {
                binding.includeOptionLayout.clOptionsMain.beGone()
                binding.clWhiteMain.beVisible()
                binding.clBottom.beGone()
                /*if(binding.clWhiteMain.isVisible()) {
                    binding.clWhiteMain.beGone()
                } else {
                    binding.clWhiteMain.beVisible()
                }*/
            }
            clScene.setOnClickListener {
                binding.includeOptionLayout.clOptionsMain.beGone()
                binding.clFilterMain.beVisible()
                binding.clBottom.beGone()
            }

        }
    }

    private fun setRatio(aspectRatio: Float, fullPreview: Boolean) {
        val screenHeight = resources.displayMetrics.heightPixels
        val screenWidth = resources.displayMetrics.widthPixels
        val viewHeight = (screenWidth * aspectRatio).toInt()

        if (fullPreview) {
            camera.layoutParams.width = screenWidth
            camera.layoutParams.height = screenHeight
            fullscreen = false
        } else {
            camera.layoutParams.width = screenWidth
            camera.layoutParams.height = viewHeight
        }
        camera.layoutParams = camera.layoutParams
    }

    private fun optionLayoutVisibility() {
        binding.clWhiteMain.beGone()
        binding.clFilterMain.beGone()
        binding.clBottom.beVisible()
        if (binding.includeOptionLayout.clOptionsMain.isVisible()) {
            binding.includeOptionLayout.clOptionsMain.beGone()
        } else {
            binding.includeOptionLayout.clOptionsMain.beVisible()
        }
    }

    private fun addNoteDialog() {
        binding.includeOptionLayout.clOptionsMain.beGone()

        val dialog = Dialog(this@CameraActivity)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        val window = dialog.window
        window?.setBackgroundDrawableResource(android.R.color.transparent)
        dialog.setCancelable(true)
        val dialogBinding = CustomNoteDialogBinding.inflate(layoutInflater)
        dialog.setContentView(dialogBinding.root)
        dialogBinding.tvActionCancel.setOnClickListener {
            dialog.dismiss()
        }
        dialogBinding.etDesc.setText(baseConfig.lastNote)
        dialogBinding.tvActionOk.setOnClickListener {
            if (dialogBinding.etDesc.text.isNullOrEmpty()) {
                Toast.makeText(this@CameraActivity, getString(R.string.add_note_attention), Toast.LENGTH_SHORT).show()
            } else {
                baseConfig.lastNote = dialogBinding.etDesc.text.toString()
                newLayoutView.apply {
                    findViewById<TextView>(R.id.tv_note_template).text = "Note: " + baseConfig.lastNote
                }
                dialog.dismiss()
            }
        }

        dialog.show()
    }

    private fun capturePictureSnapshot() {
        if (camera.isTakingPicture) return
        if (camera.preview != com.locationstamp.camera.cameraview.controls.Preview.GL_SURFACE) return run {
            message("Picture snapshots are only allowed with the GL_SURFACE preview.", true)
        }
        captureTime = System.currentTimeMillis()
        message("Capturing picture snapshot...", false)
        packageManager.hasSystemFeature(PackageManager.FEATURE_CAMERA_FLASH);

        camera.takePictureSnapshot()
    }

    private fun toggleCamera() {
        if (camera.isTakingPicture || camera.isTakingVideo) return
        when (camera.toggleFacing()) {
            com.locationstamp.camera.cameraview.controls.Facing.BACK -> {
                message("Switched to back camera!", false)
                binding.ivFlash.isEnabled = true
            }

            com.locationstamp.camera.cameraview.controls.Facing.FRONT -> {
                message("Switched to front camera!", false)
                baseConfig.cameraFlash = 0
                camera.flash = com.locationstamp.camera.cameraview.controls.Flash.OFF
                binding.ivFlash.setImageDrawable(ResourcesCompat.getDrawable(resources, R.drawable.ic_flash_off, null))
                binding.ivFlash.isEnabled = false
            }
        }
    }

    private inner class Listener : com.locationstamp.camera.cameraview.CameraListener() {
        override fun onCameraOpened(options: com.locationstamp.camera.cameraview.CameraOptions) {
//            message("Camera Open: " + options, true)
            val group = controlPanel.getChildAt(0) as ViewGroup
            for (i in 0 until group.childCount) {
                val view = group.getChildAt(i) as OptionView<*>
                view.onCameraOpened(camera, options)
            }
        }

        override fun onCameraError(exception: com.locationstamp.camera.cameraview.CameraException) {
            super.onCameraError(exception)
            message("Got CameraException #" + exception.reason, true)
        }

        override fun onPictureTaken(result: com.locationstamp.camera.cameraview.PictureResult) {
            super.onPictureTaken(result)
            if (camera.isTakingVideo) {
                message("Captured while taking video. Size=" + result.size, false)
                return
            }

            // This can happen if picture was taken with a gesture.
            val callbackTime = System.currentTimeMillis()
            if (captureTime == 0L) captureTime = callbackTime - 300
            LOG.w("onPictureTaken called! Launching activity. Delay:", callbackTime - captureTime)
//            PicturePreviewActivity.pictureResult = result
//            val intent = Intent(this@CameraActivity, PicturePreviewActivity::class.java)
//            intent.putExtra("delay", callbackTime - captureTime)
//            startActivity(intent)
            captureTime = 0
            bitmap = BitmapFactory.decodeByteArray(
                result.data, 0, result.data.size
            )
            saveImage(bitmap)
            LOG.w("onPictureTaken called! Launched activity.")
        }

        override fun onVideoTaken(result: com.locationstamp.camera.cameraview.VideoResult) {
            super.onVideoTaken(result)
            LOG.w("onVideoTaken called! Launching activity.")
            /*VideoPreviewActivity.videoResult = result
            val intent = Intent(this@CameraActivity, VideoPreviewActivity::class.java)
            startActivity(intent)
            LOG.w("onVideoTaken called! Launched activity.")*/
        }

        override fun onVideoRecordingStart() {
            super.onVideoRecordingStart()
            LOG.w("onVideoRecordingStart!")
        }

        override fun onVideoRecordingEnd() {
            super.onVideoRecordingEnd()
            message("Video taken. Processing...", false)
            LOG.w("onVideoRecordingEnd!")
        }

        override fun onExposureCorrectionChanged(newValue: Float, bounds: FloatArray, fingers: Array<PointF>?) {
            super.onExposureCorrectionChanged(newValue, bounds, fingers)
            message("Exposure correction:$newValue", false)
        }

        override fun onZoomChanged(newValue: Float, bounds: FloatArray, fingers: Array<PointF>?) {
            super.onZoomChanged(newValue, bounds, fingers)
            message("Zoom:$newValue", false)
        }
    }

    private fun message(content: String, important: Boolean) {
        /*if (important) {
            LOG.w(content)
            Toast.makeText(this, content, Toast.LENGTH_LONG).show()
        } else {
            LOG.i(content)
            Toast.makeText(this, content, Toast.LENGTH_SHORT).show()
        }*/
    }


    private fun getLocation() {
        if (checkPermissions()) {
            if (ActivityCompat.checkSelfPermission(
                    this,
                    Manifest.permission.ACCESS_COARSE_LOCATION
                ) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(
                    this,
                    Manifest.permission.ACCESS_FINE_LOCATION
                ) != PackageManager.PERMISSION_GRANTED
            ) {
                return
            }
            val locationRequest = LocationRequest.Builder(
                Priority.PRIORITY_HIGH_ACCURACY,
                2000 // update interval in milliseconds
            ).build()

            mFusedLocationClient.requestLocationUpdates(
                locationRequest,
                locationCallback,
                Looper.getMainLooper()
            )
//            mFusedLocationClient.lastLocation.addOnCompleteListener(this) { task ->
//                val location: Location? = task.result
//                Log.w("msg", "getLocation: " + location)
//
//                if (location != null) {
//                    if (task.result.hasAltitude()) {
//                        tempAltitude = task.result.altitude
//                    }
//                    if (task.result.hasAccuracy()) {
//                        tempAccuracy = task.result.accuracy
//                    }
//
//                    //tempAccuracy = task.result.accuracy
//                    ensureBackgroundThread {
//                        try {
//                            val geocoder = Geocoder(this, Locale.getDefault())
//                            val list: List<Address> =
//                                geocoder.getFromLocation(location.latitude, location.longitude, 1)!!
//                            Log.w("msg", "getLocation: " + list[0].getAddressLine(0))
//                            Log.w("msg", "latitude: " + list[0].latitude + "longitude: " + list[0].longitude)
////                            tempLatitude = baseConfig.roundToSixDecimalPlaces(list[0].latitude)
////                            tempLongitude = baseConfig.roundToSixDecimalPlaces(list[0].longitude)
//
//                            if (baseConfig.isAutomatic) {
//                                tempLatitude = list[0].latitude
//                                tempLongitude = list[0].longitude
//                                tempAddress = list[0].getAddressLine(0)
//                            } else {
//                                tempLatitude = baseConfig.userLatitude
//                                tempLongitude = baseConfig.userLongitude
//                                tempAddress = baseConfig.userAddress
//                                discussCurrentLocation(list[0].latitude, list[0].longitude, list[0].getAddressLine(0))
//                            }
////                        Toast.makeText(this@CameraActivity, "latitude: " + tempLatitude + "longitude: " + tempLongitude, Toast.LENGTH_SHORT).show()
//
//                            runOnUiThread {
//                                moveMap()
//                                getWeather(list[0].adminArea)
//                            }
//                        } catch (e: Exception) {
//                            Log.w("catch", "DEADLINE_EXCEEDED: $e")
//                        }
//                    }
//
//                } else {
//                    Toast.makeText(this, R.string.internet_permission, Toast.LENGTH_LONG).show()
//                }
//            }

        } else {
            requestPermissions()
        }
    }

    fun discussCurrentLocation(currentLatitude: Double, currentLongitude: Double, address: String) {
        val distance = distanceInKm(
            currentLatitude, currentLongitude,
            tempLatitude, tempLongitude
        )

        Log.i("MapData", "distance:$distance")
        if (distance <= 5) {
            Log.i("MapData", "Inside restrict area")
        } else {
            baseConfig.isAutomatic = false
            tempLatitude = currentLatitude
            tempLongitude = currentLongitude
            tempAddress = address
            Log.i("MapData", "Outside restrict area. (distance = ${"%.2f".format(distance)} m)")
        }

    }

    private fun distanceInKm(lat1: Double, lon1: Double, lat2: Double, lon2: Double): Int {
        val R = 6371.0 // Earth radius in kilometers
        val dLat = Math.toRadians(lat2 - lat1)
        val dLon = Math.toRadians(lon2 - lon1)
        val a = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
                Math.cos(Math.toRadians(lat1)) * Math.cos(Math.toRadians(lat2)) *
                Math.sin(dLon / 2) * Math.sin(dLon / 2)
        val c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a))
        val distanceKm = R * c   // normal km

        return (distanceKm * 10).toInt()
    }


    private fun enableLoc() {
        if (googleApiClient == null) {
            googleApiClient = GoogleApiClient.Builder(this@CameraActivity)
                .addApi(LocationServices.API)
                .addConnectionCallbacks(object : GoogleApiClient.ConnectionCallbacks {
                    override fun onConnected(bundle: Bundle?) {
                    }

                    override fun onConnectionSuspended(i: Int) {
                        googleApiClient!!.connect()
                    }
                })
                .addOnConnectionFailedListener { connectionResult ->
                    Log.d(
                        "msg",
                        "Location error " + connectionResult.errorCode
                    )
                }.build()
            googleApiClient!!.connect()
            val locationRequest = LocationRequest.create()
            locationRequest.priority = LocationRequest.PRIORITY_HIGH_ACCURACY
            locationRequest.interval = (30 * 1000).toLong()
            locationRequest.fastestInterval = (5 * 1000).toLong()
            val builder = LocationSettingsRequest.Builder()
                .addLocationRequest(locationRequest)
            builder.setAlwaysShow(true)
            val result: PendingResult<LocationSettingsResult> =
                LocationServices.SettingsApi.checkLocationSettings(googleApiClient!!, builder.build())
            result.setResultCallback(object : ResultCallback<LocationSettingsResult?> {
                override fun onResult(result: LocationSettingsResult) {
                    val status: Status = result.status
                    if (status.isSuccess) {
                        getLocation()
                    }
                    when (status.getStatusCode()) {
                        LocationSettingsStatusCodes.RESOLUTION_REQUIRED -> try {
                            // Show the dialog by calling startResolutionForResult(),
                            // and check the result in onActivityResult().
                            status.startResolutionForResult(this@CameraActivity, REQUEST_LOCATION)
//                                finish();
                        } catch (e: SendIntentException) {
                            // Ignore the error.
                            Log.w("catch", "SendIntentException: " + e.message)
                        }
                    }
                }
            })
        }
    }

    private fun isLocationEnabled(): Boolean {
        val locationManager: LocationManager =
            getSystemService(Context.LOCATION_SERVICE) as LocationManager
        return locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER) || locationManager.isProviderEnabled(
            LocationManager.NETWORK_PROVIDER
        )
    }

    private fun checkPermissions(): Boolean {
        if (ActivityCompat.checkSelfPermission(
                this,
                Manifest.permission.ACCESS_COARSE_LOCATION
            ) == PackageManager.PERMISSION_GRANTED &&
            ActivityCompat.checkSelfPermission(
                this,
                Manifest.permission.ACCESS_FINE_LOCATION
            ) == PackageManager.PERMISSION_GRANTED
        ) {
            return true
        }
        return false
    }

    private fun requestPermissions() {
        ActivityCompat.requestPermissions(
            this,
            arrayOf(
                Manifest.permission.ACCESS_COARSE_LOCATION,
                Manifest.permission.ACCESS_FINE_LOCATION
            ),
            PERMISSION_REQUEST_CODE_LOCATION
        )
    }

    private fun checkCameraPermissions(): Boolean {
        if (ActivityCompat.checkSelfPermission(
                this,
                Manifest.permission.CAMERA
            ) == PackageManager.PERMISSION_GRANTED
        ) {
            return true
        }
        return false
    }

    private fun requestCameraPermissions() {
        ActivityCompat.requestPermissions(
            this,
            arrayOf(
                Manifest.permission.CAMERA
            ),
            PERMISSION_REQUEST_CODE_CAMERA
        )
    }

    private fun requestNotificationPermissions() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) !=
                PackageManager.PERMISSION_GRANTED
            ) {
                ActivityCompat.requestPermissions(
                    this,
                    arrayOf(
                        Manifest.permission.POST_NOTIFICATIONS
                    ),
                    PERMISSION_REQUEST_CODE_NOTIFICATION
                )
            }
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        /*val valid = grantResults.all { it == PackageManager.PERMISSION_GRANTED }
        if (valid && !camera.isOpened) {
            camera.open()
        }*/
        when (requestCode) {
            PERMISSION_REQUEST_CODE -> {
                if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED && grantResults[1] == PackageManager.PERMISSION_GRANTED) {
                    // Permission was granted, you can now access the file
                } else {
                    Toast.makeText(this@CameraActivity, getString(R.string.storage_permission), Toast.LENGTH_SHORT).show()
                }
            }

            PERMISSION_REQUEST_CODE_33 -> {
                if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    // Permission was granted, you can now access the file
                } else {
                    Toast.makeText(this@CameraActivity, getString(R.string.storage_permission), Toast.LENGTH_SHORT).show()
                }
            }

            PERMISSION_REQUEST_CODE_LOCATION -> {
                if ((grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) && (grantResults[1] == PackageManager.PERMISSION_GRANTED)) {
//                    getLocation()
                    enableLoc()
//                mFusedLocationClient.requestLocationUpdates(locationRequest, locationCallback, Looper.getMainLooper())

                } else {

                }
            }

            PERMISSION_REQUEST_CODE_CAMERA -> {
                if ((grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED)) {
                    if (!camera.isOpened) {
                        camera.open()
                    }
                } else {

                }
            }

            PERMISSION_REQUEST_CODE_NOTIFICATION -> {
                if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    // Permission was granted, you can now access the file
                } else {
                    Toast.makeText(this@CameraActivity, getString(R.string.notification_permission), Toast.LENGTH_SHORT).show()
                }
            }
        }
    }


    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        if (requestCode == CREATE_FILE_REQUEST_CODE && resultCode == Activity.RESULT_OK) {
            data?.data?.let { uri ->
                contentResolver.openOutputStream(uri)?.use { outputStream ->
                    bitmap.compress(Bitmap.CompressFormat.JPEG, 100, outputStream)
                    iconAnimation()
                    Toast.makeText(this@CameraActivity, R.string.image_saved, Toast.LENGTH_SHORT).show()
                }
            }
        }
        if (resultCode == Activity.RESULT_OK && requestCode == REQUEST_LOCATION) {
            Handler(Looper.getMainLooper()).postDelayed({
                getLocation()
            }, 1500)
        }
    }

    override fun <T : Any> onValueChanged(option: Option<T>, value: T, name: String): Boolean {
        if (option is Option.Width || option is Option.Height) {
            val preview = camera.preview
            val wrapContent = value as Int == ViewGroup.LayoutParams.WRAP_CONTENT
            if (preview == com.locationstamp.camera.cameraview.controls.Preview.SURFACE && !wrapContent) {
                message(
                    "The SurfaceView preview does not support width or height changes. " +
                            "The view will act as WRAP_CONTENT by default.", true
                )
                return false
            }
        }
        option.set(camera, value)
        BottomSheetBehavior.from(controlPanel).state = BottomSheetBehavior.STATE_HIDDEN
        message("Changed " + option.name + " to " + name, false)
        return true
    }

    override fun onResume() {
        super.onResume()
        if(isAdLoaded){
            mAdView?.resume()
        }else{
            loadBanner()
        }
        val supportMapFragment = mMapViewFrag
        supportMapFragment?.onResume()
        timeCounterChange()
//        if (binding.includedDrawer.tvLanguagesDesc.text != baseConfig.selectLanguageString) {
//            binding.includedDrawer.tvLanguagesDesc.text = baseConfig.selectLanguageString
//        }
        Log.w("msg", "onResume:main1 ")
//        if (stampPosition != baseConfig.stampPosition) {
//        if (baseConfig.stampPosition == 0) {
//            (binding.frameTemplate.layoutParams as FrameLayout.LayoutParams).gravity = Gravity.TOP
//        } else {
//            (binding.frameTemplate.layoutParams as FrameLayout.LayoutParams).gravity = Gravity.BOTTOM
//        }
//    }
        refreshData(newLayoutView)
    }

    override fun onPause() {
        super.onPause()
        mAdView?.pause()
        val supportMapFragment = mMapViewFrag
        supportMapFragment?.onPause()
    }

    override fun onStart() {
        super.onStart()
        val supportMapFragment = mMapViewFrag
        supportMapFragment?.onStart()
    }

    override fun onStop() {
        super.onStop()
        val supportMapFragment = mMapViewFrag
        supportMapFragment?.onStop()
    }

    override fun onLowMemory() {
        super.onLowMemory()
        val supportMapFragment = mMapViewFrag
        supportMapFragment?.onLowMemory()
    }

    override fun onDestroy() {
        super.onDestroy()
        mAdView?.destroy()
        val supportMapFragment = mMapViewFrag
        supportMapFragment?.onDestroy()
//        mFusedLocationClient.removeLocationUpdates(locationCallback)
    }

    var isRatingOpen = false

    private fun launchRateDialog() {
        isRatingOpen = true
        val rateDialog = RatingDialog(this)
        rateDialog.show()
    }

    private fun doublePressExit() {
        if (doubleBackToExitPressedOnce) {
            finishAffinity()
            return
        }

        doubleBackToExitPressedOnce = true
        Toast.makeText(this, R.string.please_click_back_again_to_exit, Toast.LENGTH_SHORT).show()
        Handler(Looper.getMainLooper()).postDelayed(Runnable { doubleBackToExitPressedOnce = false }, 2000)
    }

    private fun dataChange() {
        baseConfig.stampPlusCode = com.locationstamp.camera.helper.OpenLocationCode.encode(tempLatitude, tempLongitude)
        newLayoutView.apply {
            findViewById<CardView>(R.id.cv_map).beVisibleIf(baseConfig.showMap)
//                findViewById<ImageView>(R.id.iv_map_template).setImageDrawable(baseConfig.getMapTypeImage(this@TemplateEditActivity))
            findViewById<TextView>(R.id.tv_address_template).apply {
                beVisibleIf(baseConfig.showAddress)
                text = CameraActivity.tempAddress
                setTextColor(baseConfig.stampColor)
            }
            findViewById<TextView>(R.id.tv_lat_long_template).apply {
                beVisibleIf(baseConfig.showLatLong)
                text = baseConfig.formatLatLong(
                    CameraActivity.tempLatitude,
                    CameraActivity.tempLongitude
                )
                setTextColor(baseConfig.stampColor)
            }
            findViewById<TextView>(R.id.tv_plus_code_template).apply {
                beVisibleIf(baseConfig.showPlusCode)
                text = "Plus code:" + baseConfig.stampPlusCode
                setTextColor(baseConfig.stampColor)
            }
            findViewById<TextView>(R.id.tv_note_template).apply {
                beVisibleIf(baseConfig.showNote)
                text = "Note: " + baseConfig.lastNote
            }
            findViewById<TextView>(R.id.tv_time_template).apply {
                beVisibleIf(baseConfig.showDateTime)
                text = baseConfig.dateFormat
                setTextColor(baseConfig.stampColor)
            }
            findViewById<TextView>(R.id.tv_time_zone_template).apply {
                beVisibleIf(baseConfig.showTimeZone)
                text = baseConfig.getTimezoneText()
                setTextColor(baseConfig.stampColor)
            }
//            findViewById<ImageView>(R.id.iv_logo_template).apply {
//                beVisibleIf(baseConfig.showLogo)
//            }
            findViewById<TextView>(R.id.tv_altitude_template).apply {
                beVisibleIf(baseConfig.showAltitude)
                text = "Altitude:" + baseConfig.getAltitudeText(this@CameraActivity)
                setTextColor(baseConfig.stampColor)
            }
            findViewById<TextView>(R.id.tv_accuracy_template).apply {
                beVisibleIf(baseConfig.showAccuracy)
                text = "Accuracy:" + baseConfig.getAccuracyText(this@CameraActivity)
                setTextColor(baseConfig.stampColor)
            }
            findViewById<TextView>(R.id.tv_weather_template).apply {
                beVisibleIf(baseConfig.showWeather)
                text = "" + baseConfig.getWeatherText(this@CameraActivity)
                setTextColor(baseConfig.stampColor)
            }
            findViewById<TextView>(R.id.tv_wind_template).apply {
                beVisibleIf(baseConfig.showWind)
                text = "" + baseConfig.getWindText(this@CameraActivity)
                setTextColor(baseConfig.stampColor)
            }
            findViewById<TextView>(R.id.tv_pressure_template).apply {
                beVisibleIf(baseConfig.showPressure)
                text = "" + baseConfig.getPressureText(this@CameraActivity)
                setTextColor(baseConfig.stampColor)
            }
            findViewById<TextView>(R.id.tv_humidity_template).apply {
                beVisibleIf(baseConfig.showHumidity)
                text = "" + CameraActivity.tempHumidity
                setTextColor(baseConfig.stampColor)
            }
        }
    }

    override fun onMapReady(gMap: GoogleMap) {
//        Handler(Looper.getMainLooper()).postDelayed({
        googleMap = gMap
        try {
            googleMap?.isMyLocationEnabled = false
        } catch (se: SecurityException) {
            // Handle the security exception here
            Log.w("catch", "SecurityException: " + se.message)
        }

        // Edit the following settings as needed
        googleMap?.isTrafficEnabled = true
        googleMap?.isIndoorEnabled = true
        googleMap?.isBuildingsEnabled = true
        googleMap?.uiSettings!!.isZoomControlsEnabled = false
        googleMap?.uiSettings!!.isMapToolbarEnabled = false
        zoomLevel = baseConfig.zoomLevel

//            Log.w("msg", "placeLocation: latitude: " + tempLatitude + " longitude: " + tempLongitude)
//        val placeLocation = LatLng(tempLatitude, tempLongitude) // Replace with your actual coordinates
//        googleMap.moveCamera(CameraUpdateFactory.newLatLng(placeLocation))

//        }, 3000)
        resetMap()
    }

    private fun resetMap() {
        googleMap?.mapType = baseConfig.getMapType(this@CameraActivity)
        val placeLocation = LatLng(tempLatitude, tempLongitude) // Replace with your actual coordinates
        val customMarker = getResizedMarker(this, R.drawable.location_marker, 62, 62)
        if(customMarker!=null) {

            val latLng = LatLng(tempLatitude, tempLongitude)
            googleMap?.clear()
            googleMap?.addMarker(
                MarkerOptions()
                    .anchor(0.5f, 0.5f)
                    .position(latLng)
                    .icon(customMarker)
            )
            googleMap?.moveCamera(CameraUpdateFactory.newLatLngZoom(placeLocation, zoomLevel))
            //googleMap.animateCamera(CameraUpdateFactory.zoomTo(zoomLevel), 1000, null)
            Handler(Looper.getMainLooper()).postDelayed({
                mapSnapshot()
            }, 2000)
        }
    }

    private fun mapSnapshot() {
        try {
            if (googleMap != null && isOnline == true) {
                if (baseConfig.showMap) {
                    googleMap?.setOnMapLoadedCallback {
                        googleMap?.snapshot { bitmap ->
                            if (bitmap != null) {
                                mapBitmap = bitmap
                                Log.w("msg", "mapSnapshot:1 " + mapBitmap)
                                /*newLayoutView?.findViewById<ImageView>(R.id.iv_map_template)?.apply {
                                    beVisibleIf(baseConfig.showMap)
                                    setImageBitmap(mapBitmap)
                                }*/
                                newLayoutView?.findViewById<ImageView>(R.id.iv_map_template)?.post(
                                    Runnable {
                                        newLayoutView?.findViewById<ImageView>(R.id.iv_map_template)?.beVisibleIf(baseConfig.showMap)
                                        newLayoutView?.findViewById<ImageView>(R.id.iv_map_template)?.setImageBitmap(mapBitmap)
                                    })
//                        binding.includeLayout.ivMapTemplate.setImageBitmap(mapBitmap)
                            }
                        }
                    }
                }
            }
//            System.gc()
//            if (googleMap != null && isOnline == true) {
//                if (baseConfig.showMap) {
//                    googleMap.snapshot(GoogleMap.SnapshotReadyCallback { bitmap ->
//
//                        if (bitmap != null) {
//                            mapBitmap = bitmap
//                            Log.w("msg", "mapSnapshot:1 " + mapBitmap)
//                            /*newLayoutView?.findViewById<ImageView>(R.id.iv_map_template)?.apply {
//                                beVisibleIf(baseConfig.showMap)
//                                setImageBitmap(mapBitmap)
//                            }*/
//                            newLayoutView?.findViewById<ImageView>(R.id.iv_map_template)?.post(
//                                Runnable {
//                                    newLayoutView?.findViewById<ImageView>(R.id.iv_map_template)?.beVisibleIf(baseConfig.showMap)
//                                    newLayoutView?.findViewById<ImageView>(R.id.iv_map_template)?.setImageBitmap(mapBitmap)
//                                })
////                        binding.includeLayout.ivMapTemplate.setImageBitmap(mapBitmap)
//                        }
//                    })
//                }
//            }
        } catch (e: Exception) {
            Log.w("catch", "mapSnapshot: e " + e.message)
        }
    }

    private fun moveMap() {
//        googleMap = gMap
        if (googleMap != null) {
            googleMap?.mapType = baseConfig.getMapType(this@CameraActivity)
            Log.w("msg", "moveMap:mapType " + googleMap?.mapType)
            try {
                googleMap?.isMyLocationEnabled = false
            } catch (se: SecurityException) {
                Log.w("catch", "SecurityException: e " + se.message)
            }

            // Edit the following settings as needed
            googleMap?.isTrafficEnabled = true
            googleMap?.isIndoorEnabled = true
            googleMap?.isBuildingsEnabled = true
            googleMap?.uiSettings!!.isZoomControlsEnabled = false
            googleMap?.uiSettings!!.isMapToolbarEnabled = false

            val placeLocation = LatLng(tempLatitude, tempLongitude) // Replace with your actual coordinates
            zoomLevel = baseConfig.zoomLevel

            val customMarker = getResizedMarker(this, R.drawable.location_marker, 65, 65)
            if(customMarker!=null) {
                val latLng = LatLng(tempLatitude, tempLongitude)
                googleMap?.clear()
                googleMap?.addMarker(
                    MarkerOptions()
                        .anchor(0.5f, 0.5f)
                        .position(latLng)
                        .icon(customMarker)
                )
                googleMap?.moveCamera(CameraUpdateFactory.newLatLngZoom(placeLocation, zoomLevel))
//            googleMap.animateCamera(CameraUpdateFactory.zoomTo(zoomLevel), 1000, null)
                Handler(Looper.getMainLooper()).postDelayed({
                    mapSnapshot()
//                getTemp()
                }, 1000)
            }
        }
    }

    fun getResizedMarker(context: Context, @DrawableRes resId: Int, width: Int, height: Int): BitmapDescriptor? {
        val drawable = ContextCompat.getDrawable(context, resId) ?: return null
        val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        drawable.setBounds(0, 0, canvas.width, canvas.height)
        drawable.draw(canvas)
        return try {
            BitmapDescriptorFactory.fromBitmap(bitmap)
        } catch (e: Exception) {
            e.printStackTrace()
            null // Google Maps not initialized yet
        }
    }

    /*fun getTemp() {
        // Instantiate the RequestQueue.
        val queue = Volley.newRequestQueue(this)
        val url: String = "https://api.weatherbit.io/v2.0/current?" + "lat=" + tempLatitude +"&lon="+ tempLongitude + "&key="+ "b731141b8fdc44df95193bdbe034bea5"
        Log.e("lat", url)
        // Request a string response from the provided URL.
        val stringReq = StringRequest(
            Request.Method.GET, url,
            Response.Listener<String> { response ->
                Log.e("lat", response.toString())
                //get the JSON object
                val obj = JSONObject(response)
                //get the Array from obj of name - "data"
                val arr = obj.getJSONArray("data")
                Log.e("lat obj1", arr.toString())
                //get the JSON object from the array at index position 0
                val obj2 = arr.getJSONObject(0)
                Log.e("lat obj2", obj2.toString())
                //set the temperature and the city name using getString() function
//                textView.text = obj2.getString("temp")+" deg Celcius in "+obj2.getString("city_name")
                Log.w("msg", "getTemp: " + obj2.getString("temp")+" deg Celcius in "+obj2.getString("city_name"))
            },
            //In case of any error
            Response.ErrorListener { textView!!.text = "That didn't work!"
                Log.w("msg", "getTemp: " + "error")})
        queue.add(stringReq)
    }*/

    private fun getWeather(adminArea: String) {
        if (templatePosition == 0) {
            dataChange()
        } else {
            val diff = Date().time - baseConfig.lastApiCall
            if (diff < (3600 * 1000)) {
                //call api after every 1 hour
                tempWeather = baseConfig.stampWeather
                tempHumidity = baseConfig.stampHumidity
                tempPressure = baseConfig.stampPressure
                tempWind = baseConfig.stampWind
                dataChange()
            } else {
                val queue = Volley.newRequestQueue(this)
                //val url: String = "https://api.tomorrow.io/v4/weather/realtime?location=$adminArea&apikey=Kjoc3U4MIKfVt0sQvy7ERK2m2pmtFmff"
                val url: String = "https://api.tomorrow.io/v4/weather/realtime?location=$adminArea&apikey=0jrTX85SmuFoDngs9Diwk36f9kW9nhrJ"
                Log.e("msg", "lat " + url)
                // Request a string response from the provided URL.
                val stringReq = StringRequest(
                    Request.Method.GET, url,
                    { response ->
                        Log.e("msg", "lat " + response.toString())
                        //get the JSON object
                        val obj = JSONObject(response)
                        //get the Array from obj of name - "data"
                        val arr = obj.getJSONObject("data")
                        Log.e("msg", "lat obj1" + arr.toString())
                        //get the JSON object from the array at index position 0
                        val obj2 = arr.getJSONObject("values")
                        Log.e("msg", "lat obj2" + obj2.toString())
                        //set the temperature and the city name using getString() function
                        tempWeather = obj2.getString("temperature")/* + "°C"*/
                        tempHumidity = obj2.getString("humidity") + "%"
                        tempPressure = obj2.getString("pressureSurfaceLevel")/* +"hPa"*/
                        tempWind = obj2.getString("windSpeed")/* +"m/s"*/

                        baseConfig.stampWeather = tempWeather
                        baseConfig.stampHumidity = tempHumidity
                        baseConfig.stampPressure = tempPressure
                        baseConfig.stampWind = tempWind
                        baseConfig.lastApiCall = Date().time
                        dataChange()
                    },
                    //In case of any error
                    {
                        Log.w("msg", "getTemp: " + "error")
                    })
                queue.add(stringReq)
            }
        }
    }

    fun saveImage(savedImage: Bitmap) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_MEDIA_IMAGES) == PackageManager.PERMISSION_GRANTED) {
                // You already have the required permissions
                saveAfterPermission(savedImage)
            } else {
                // Permission has not been granted, request it
                ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.READ_MEDIA_IMAGES, Manifest.permission.WRITE_EXTERNAL_STORAGE), PERMISSION_REQUEST_CODE_33)
            }
        } else {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED
                && ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE)
                == PackageManager.PERMISSION_GRANTED
            ) {
                // You already have the required permissions
                saveAfterPermission(savedImage)
            } else {
                // Permission has not been granted, request it
                ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE), PERMISSION_REQUEST_CODE)
            }
        }

    }

    private fun saveAfterPermission(savedImage: Bitmap) {
//        val root = Environment.getExternalStorageDirectory().toString()
//        val myDir = File("$root/MapStamp")
        val myDir = File(getExternalFilesDir(null), "MapStamp")
        myDir.mkdirs()
        val fName = "MapStamp-${System.currentTimeMillis()}.jpeg"
        val file = File(myDir, fName)
//        if (file.exists()) file.delete()
        try {
            val out = FileOutputStream(file)
            savedImage.compress(Bitmap.CompressFormat.JPEG, 100, out)
            iconDraw(savedImage)
            Toast.makeText(this@CameraActivity, R.string.image_saved, Toast.LENGTH_SHORT).show()
            out.flush()
            out.close()
            MediaScannerConnection.scanFile(this@CameraActivity, arrayOf(file.toString()), null, null)
        } catch (e: Exception) {
            Log.w("catch", "saveAfterPermission: e " + e.message)
            val mimeType = "image/jpeg"
            val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE)
                type = mimeType
                putExtra(Intent.EXTRA_TITLE, "FILENAME-${System.currentTimeMillis()}.jpeg")
            }
            startActivityForResult(intent, CREATE_FILE_REQUEST_CODE)
        }
    }

    private fun saveAfterPermission0(savedImage: Bitmap) {
        try {

            val contentValues = ContentValues().apply {
                put(MediaStore.Images.Media.DISPLAY_NAME, "MapStamp-${System.currentTimeMillis()}.jpeg")
                put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
                put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/MapStamp") // will auto-create
            }
            val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, contentValues)
            uri?.let {
                contentResolver.openOutputStream(it).use { out ->
                    savedImage.compress(Bitmap.CompressFormat.JPEG, 100, out!!)
                    iconDraw(savedImage)
                    Toast.makeText(this, R.string.image_saved, Toast.LENGTH_SHORT).show()
                }
            }
        } catch (e: Exception) {
            Log.w("catch", "saveAfterPermission: e " + e.message)
            val mimeType = "image/jpeg"
            val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE)
                type = mimeType
                putExtra(Intent.EXTRA_TITLE, "FILENAME-${System.currentTimeMillis()}.jpeg")
            }
            startActivityForResult(intent, CREATE_FILE_REQUEST_CODE)

        }

    }

    private fun iconDraw(iconBitmap: Bitmap) {
        binding.ivCollection.setImageBitmap(Bitmap.createScaledBitmap(iconBitmap, 50, 50, false))
        val baos = ByteArrayOutputStream()
        iconBitmap.compress(Bitmap.CompressFormat.JPEG, 100, baos)
        val b: ByteArray = baos.toByteArray()
        val encodedImage: String = Base64.encodeToString(b, Base64.DEFAULT)
        baseConfig.lastImageIcon = encodedImage

        iconAnimation()
    }

    private fun iconAnimation() {
        val animation: Animation = AlphaAnimation(1f, 0.5f)
        animation.duration = 700
        animation.interpolator = LinearInterpolator()
        animation.repeatCount = 2
        animation.repeatMode = Animation.REVERSE
        binding.ivCollection.startAnimation(animation)
    }

    private fun showCollection() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_MEDIA_IMAGES) == PackageManager.PERMISSION_GRANTED) {
                // You already have the required permissions
                startActivity(Intent(this@CameraActivity, MediaGalleryActivity::class.java))
            } else {
                // Permission has not been granted, request it
                ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.READ_MEDIA_IMAGES, Manifest.permission.WRITE_EXTERNAL_STORAGE), PERMISSION_REQUEST_CODE_33)
            }
        } else {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED
                && ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE)
                == PackageManager.PERMISSION_GRANTED
            ) {
                // You already have the required permissions
                startActivity(Intent(this@CameraActivity, MediaGalleryActivity::class.java))
            } else {
                // Permission has not been granted, request it
                ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE), PERMISSION_REQUEST_CODE)
            }
        }
    }

    private fun showGallery() {
        try {
            val media: Media = readFromMediaStore(
                applicationContext,
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI
            )!!
            val shareUri = FileProvider.getUriForFile(this, "$packageName.provider", media.file)
            val intent = Intent()
            intent.action = Intent.ACTION_VIEW
            intent.setDataAndType(shareUri, "image/jpeg")
            intent.flags = Intent.FLAG_GRANT_READ_URI_PERMISSION
            startActivity(intent)
        } catch (e: Exception) {
            Log.w("msg", "showCollection exception: " + e.message)
            val intent = Intent()
            intent.action = Intent.ACTION_VIEW
            intent.type = "image/*"
            intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
            startActivity(intent)
        }
    }

    private fun readFromMediaStore(context: Context, uri: Uri): Media? {
        val cursor = context.contentResolver.query(
            uri, null, null,
            null, "date_added DESC"
        )
        var media: Media? = null
        if (cursor!!.moveToNext()) {
            val dataColumn = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DATA)
            val filePath = cursor.getString(dataColumn)
            val mimeTypeColumn = cursor
                .getColumnIndexOrThrow(MediaStore.MediaColumns.MIME_TYPE)
            val mimeType = cursor.getString(mimeTypeColumn)
            media = Media(File(filePath), mimeType)
        }
        cursor.close()
        return media
    }

    private class Media(val file: File, val type: String)

    private val intentLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == Activity.RESULT_OK) {
//                Log.w("msg", "template_position: " + result.data?.getIntExtra("template_position", 0))
                result.data?.getIntExtra("template_position", 0)
                setTemplate()
            }
        }


    private fun isAppUpdateNeed(main: View) {
        appUpdateManager = AppUpdateManagerFactory.create(this)

        // Returns an intent object that you use to check for an update.
        val appUpdateInfoTask: Task<AppUpdateInfo> = appUpdateManager!!.appUpdateInfo

        // Create a listener to track request state updates.
        installStateUpdatedListener = InstallStateUpdatedListener { installState ->
            // Show module progress, log state, or install the update.
            if (installState.installStatus() == InstallStatus.DOWNLOADED) {
                popupSnackbarForCompleteUpdateAndUnregister(main)
            }
        }
        appUpdateInfoTask.addOnSuccessListener { appUpdateInfo: AppUpdateInfo ->
            if (appUpdateInfo.updateAvailability() == UpdateAvailability.UPDATE_AVAILABLE) {
                // Request the update.
                appUpdateManager!!.registerListener(installStateUpdatedListener!!)
//                if (appUpdateInfo.isUpdateTypeAllowed(AppUpdateType.FLEXIBLE)) {
//                    // Before starting an update, register a listener for updates.
//                    startAppUpdateFlexible(appUpdateInfo)
//                } else if (appUpdateInfo.isUpdateTypeAllowed(AppUpdateType.IMMEDIATE)) {
                // Start an update.
                startAppUpdateImmediate(appUpdateInfo)
//                }
            } else {

            }
        }
    }

    private fun startAppUpdateImmediate(appUpdateInfo: AppUpdateInfo) {
        try {
            appUpdateManager?.startUpdateFlowForResult(
                appUpdateInfo,
                AppUpdateType.IMMEDIATE,
                this,
                REQ_CODE_VERSION_UPDATE
            )
        } catch (e: IntentSender.SendIntentException) {
            e.printStackTrace()
        }
    }

    private fun startAppUpdateFlexible(appUpdateInfo: AppUpdateInfo) {
        try {
            appUpdateManager?.startUpdateFlowForResult(
                appUpdateInfo,
                AppUpdateType.FLEXIBLE,
                this,
                REQ_CODE_VERSION_UPDATE
            )
        } catch (e: IntentSender.SendIntentException) {
            e.printStackTrace()
            unregisterInstallStateUpdListener()
        }
    }

    private fun popupSnackbarForCompleteUpdateAndUnregister(mainviewofactivity: View) {
        val snackbar =
            Snackbar.make(this, mainviewofactivity, "Update Download", Snackbar.LENGTH_INDEFINITE)
        snackbar.setAction("restart") {
            appUpdateManager?.completeUpdate()
        }
        snackbar.setActionTextColor(resources.getColor(R.color.color_primary))
        snackbar.show()
        unregisterInstallStateUpdListener()
    }

    private fun unregisterInstallStateUpdListener() {
        if (appUpdateManager != null && installStateUpdatedListener != null) {
            appUpdateManager!!.unregisterListener(installStateUpdatedListener!!)
        }
    }

    var isAdLoaded = false
    var mAdView: AdView? = null
    private fun loadBanner() {
        val adId = getString(R.string.banner_camera)
        BannerAdHelper.showBanner(
            this, binding.flNative, binding.flNative, adId,
            AdCache.cameraAdView, { isLoaded, adView, message ->
                mAdView = adView
                AdCache.cameraAdView = adView
                isAdLoaded = isLoaded
            })
    }

}