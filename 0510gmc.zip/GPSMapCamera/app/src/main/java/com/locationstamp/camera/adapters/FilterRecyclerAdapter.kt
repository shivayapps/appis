package com.locationstamp.camera.adapters

import android.content.Context
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import com.locationstamp.camera.R
import com.locationstamp.camera.databinding.ListItemBinding
import com.locationstamp.camera.extentions.baseConfig

class FilterRecyclerAdapter(private val items: List<String>, private val context: Context,private val itemClickListener: OnItemClickListener) :
    RecyclerView.Adapter<FilterRecyclerAdapter.ViewHolder>() {
    private var selectedPosition = context.baseConfig.cameraSceneFilter //0 // Initialize with no selection

    inner class ViewHolder(private val binding: ListItemBinding) :
        RecyclerView.ViewHolder(binding.root) {
        init {
            binding.root.setOnClickListener {
                val previousSelectedPosition = selectedPosition
                selectedPosition = adapterPosition

                // Notify item changes to update backgrounds
                notifyItemChanged(previousSelectedPosition)
                notifyItemChanged(selectedPosition)

                itemClickListener.onItemClickFilter(adapterPosition)
            }
        }
        fun bind(item: String) {
            binding.tvWhiteBalance.text = item
            if (adapterPosition == selectedPosition) {
                binding.tvWhiteBalance.setBackgroundResource(R.drawable.recycler_item_bg_select)
                binding.tvWhiteBalance.setTextColor(ContextCompat.getColor(
                    context,
                    R.color.color_primary
                ))
            } else {
                binding.tvWhiteBalance.setBackgroundResource(R.drawable.recycler_item_bg_unselect)
                binding.tvWhiteBalance.setTextColor(ContextCompat.getColor(
                    context,
                    R.color.white
                ))
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding =
            ListItemBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val item = items[position]
        holder.bind(item)
    }

    override fun getItemCount(): Int {
        return items.size
    }

    interface OnItemClickListener {
        fun onItemClickFilter(position: Int)
    }
}
