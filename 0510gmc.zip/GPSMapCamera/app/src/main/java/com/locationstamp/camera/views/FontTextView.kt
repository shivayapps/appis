package com.locationstamp.camera.views

import android.content.Context
import android.graphics.Typeface
import android.util.AttributeSet
import androidx.appcompat.widget.AppCompatTextView
import com.locationstamp.camera.extentions.baseConfig

class FontTextView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyle: Int = 0
) : AppCompatTextView(context, attrs, defStyle) {

//    companion object {
//        private var mTypeface: Typeface? = null
//        private var mTypeface1: Typeface? = null
//        private var mTypeface2: Typeface? = null
//        private var mTypeface3: Typeface? = null
//        private var mTypeface4: Typeface? = null
//    }

    init {
        includeFontPadding = false
        val config = context.baseConfig
//        if (mTypeface == null) {
//            mTypeface = Typeface.createFromAsset(context.assets, "font/sourcecodepro_regular.ttf")
//
//        }
//        if (mTypeface1 == null) {
////            mTypeface1 = Typeface.createFromAsset(context.assets, "font/inter_medium.ttf")
//            mTypeface1 = Typeface.createFromAsset(context.assets, "font/robotocondensed.ttf")
//        }
//        if (mTypeface2 == null) {
////            mTypeface2 = Typeface.createFromAsset(context.assets, "font/roboto_medium.ttf")
//            mTypeface2 = Typeface.createFromAsset(context.assets, "font/opensans.ttf")
//        }
//        if (mTypeface3 == null) {
////            mTypeface3 = Typeface.createFromAsset(context.assets, "font/poppins_medium.ttf")
//            mTypeface3 = Typeface.createFromAsset(context.assets, "font/notosansdisplay.ttf")
//        }
//        if (mTypeface4 == null) {
////            mTypeface4 = Typeface.createFromAsset(context.assets, "font/sf_ui_medium.otf")
//            mTypeface4 = Typeface.createFromAsset(context.assets, "font/ibmplexsans.ttf")
//        }

        typeface = when (config.stampFontStyle) {
            0 -> Typeface.createFromAsset(context.assets, "font/sourcecodepro_regular.ttf")
            1 -> Typeface.createFromAsset(context.assets, "font/robotocondensed.ttf")
            2 -> Typeface.createFromAsset(context.assets, "font/opensans.ttf")
            3 -> Typeface.createFromAsset(context.assets, "font/notosansdisplay.ttf")
            4 -> Typeface.createFromAsset(context.assets, "font/ibmplexsans.ttf")
            5 -> Typeface.createFromAsset(context.assets, "font/inter_medium.ttf")
            6 -> Typeface.createFromAsset(context.assets, "font/poppins_medium.ttf")
            7 -> Typeface.createFromAsset(context.assets, "font/roboto_medium.ttf")
            8 -> Typeface.createFromAsset(context.assets, "font/sf_ui_medium.otf")
            else -> Typeface.createFromAsset(context.assets, "font/sourcecodepro_regular.ttf")
        }
//        Log.w("msg", "typeface: " + typeface)
        /*typeface = if (config.setSystemFont) {
            Typeface.DEFAULT
        } else {
//            Log.w("msg", "stampFontStyle: " + config.stampFontStyle)
            mTypeface
        }*/
    }
}