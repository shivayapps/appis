package com.locationstamp.camera.cameraview.engine;

/**
 * Indicates that some action is being executed on the {@link CameraEngine} thread.
 */
@SuppressWarnings("WeakerAccess")
public @interface EngineThread {}
